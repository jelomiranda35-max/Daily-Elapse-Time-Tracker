/* ==========================================================================
   06-reports.js — analysis rankings, machine detail, monthly report
   ========================================================================== */

function renderAnalysis(){
  groupChips('#analysisGroups','analysis');
  var rows=byGroup(assessAll(),'analysis');
  var mach=machineRollup(rows);
  if(!rows.length){
    $('#analysisBody').innerHTML='<div class="panel"><div class="empty"><p>No parameters in this group.</p></div></div>';
    return;
  }
  var h='<div class="twocol">';

  /* most concerning */
  var concern=mach.slice().sort(function(a,b){ return b.risk-a.risk; }).slice(0,8);
  h+='<div class="panel"><header><h3>Most concerning machines</h3>'+
     '<span class="sub">severity, speed and unusual movement combined</span></header>'+
     '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
     '<th>Machine</th><th>Driven by</th><th class="num">Risk</th><th class="num">Soonest</th>'+
     '</tr></thead><tbody>'+
     concern.map(function(x,i){
       return '<tr class="clickable" data-m="'+esc(x.m.id)+'">'+
         '<td><span class="rank">'+(i+1)+'</span><b>'+esc(x.m.name)+'</b>'+
         '<div class="pname" style="margin-left:22px">'+esc(x.m.group)+
         (x.crit?' · '+x.crit+' at limit':'')+(x.warn?' · '+x.warn+' in warning':'')+'</div></td>'+
         '<td style="font-size:13px">'+esc(x.worst.p.name)+'<div class="pname">'+
         esc(num(x.worst.value))+' of '+esc(num(x.worst.p.threshold))+' '+esc(x.worst.p.unit||'')+'</div></td>'+
         '<td class="num">'+riskBar(x.risk)+'</td>'+
         '<td class="num">'+(x.dtt!=null?'<b>'+Math.round(x.dtt)+'d</b>':'<span style="color:var(--ink-3)">—</span>')+'</td></tr>';
     }).join('')+'</tbody></table></div></div></div>';

  /* running cleanest */
  var perf=mach.filter(function(x){ return x.rows.some(function(r){ return r.n>=5; }); })
    .sort(function(a,b){ return (a.approach==null?999:a.approach)-(b.approach==null?999:b.approach); }).slice(0,8);
  h+='<div class="panel"><header><h3>Running cleanest</h3>'+
     '<span class="sub">furthest from limit with a stable trend</span></header>'+
     '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
     '<th>Machine</th><th class="num">Margin left</th><th class="num">Trend</th><th class="num">Since PM</th>'+
     '</tr></thead><tbody>'+
     perf.map(function(x,i){
       var margin = x.approach==null?null:Math.max(0,100-x.approach);
       var pm=lastPMOf(x.m.id);
       return '<tr class="clickable" data-m="'+esc(x.m.id)+'">'+
         '<td><span class="rank">'+(i+1)+'</span><b>'+esc(x.m.name)+'</b>'+
         '<div class="pname" style="margin-left:22px">'+esc(x.m.group)+'</div></td>'+
         '<td class="num"><b style="color:var(--ok)">'+(margin==null?'—':num(margin,0)+'%')+'</b></td>'+
         '<td class="num">'+trendHTML(x.worst)+'</td>'+
         '<td class="num" style="font-size:13px;color:var(--ink-2)">'+(pm?diffDays(todayISO(),pm)+' days':'—')+'</td></tr>';
     }).join('')+'</tbody></table></div></div></div></div>';

  /* biggest movers */
  var movers=rows.filter(function(r){ return r.anom!=null; })
    .sort(function(a,b){ return b.anom-a.anom; }).slice(0,10);
  h+='<div class="panel"><header><h3>Biggest change against its own normal</h3>'+
     '<span class="sub">recent movement divided by this parameter\u2019s typical movement, so a machine accelerating while still in range still surfaces</span></header>'+
     '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
     '<th>Machine / parameter</th><th>Status</th><th class="num">Recent vs usual</th>'+
     '<th class="num">Latest</th><th class="num">Trend</th><th class="num">Reaches limit</th>'+
     '</tr></thead><tbody>'+
     movers.map(function(a,i){
       return '<tr class="clickable" data-m="'+esc(a.p.machineId)+'">'+
         '<td><span class="rank">'+(i+1)+'</span><b>'+esc(a.m.name)+'</b>'+
         '<div class="pname" style="margin-left:22px">'+esc(a.p.name)+'</div></td>'+
         '<td>'+statusHTML(a.status)+'</td>'+
         '<td class="num">'+moverBar(a.anom)+'</td>'+
         '<td class="num"><b>'+esc(num(a.value))+'</b></td>'+
         '<td class="num">'+trendHTML(a)+'</td>'+
         '<td class="num">'+dttHTML(a)+'</td></tr>';
     }).join('')+'</tbody></table></div></div></div>';

  /* group health */
  var gs = filterGroup.analysis==='All'?DB.groups:[filterGroup.analysis];
  var allRows=assessAll();
  h+='<div class="panel"><header><h3>Group health</h3><span class="sub">where the pressure sits across the fleet</span></header>'+
     '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
     '<th>Group</th><th class="num">Machines</th><th class="num">Parameters</th><th class="num">At limit</th>'+
     '<th class="num">Warning</th><th>Average approach</th><th class="num">Most pressing</th>'+
     '</tr></thead><tbody>';
  gs.forEach(function(g){
    var gr=allRows.filter(function(r){ return groupOf(r.p)===g; });
    if(!gr.length) return;
    var withApp=gr.filter(function(r){ return r.approach!=null; });
    var av=withApp.length?withApp.reduce(function(a,b){ return a+b.approach; },0)/withApp.length:null;
    var w=gr.reduce(function(a,b){ return b.risk>a.risk?b:a; });
    var mset={}; gr.forEach(function(r){ mset[r.p.machineId]=1; });
    h+='<tr><td><b>'+esc(g)+'</b></td><td class="num">'+Object.keys(mset).length+'</td>'+
      '<td class="num">'+gr.length+'</td>'+
      '<td class="num">'+critCell(gr.filter(function(r){return r.status==='crit';}).length,'var(--crit)')+'</td>'+
      '<td class="num">'+critCell(gr.filter(function(r){return r.status==='warn';}).length,'var(--warn)')+'</td>'+
      '<td>'+(av==null?'—':'<div style="display:flex;align-items:center;gap:8px">'+
        '<div class="bar-mini" style="flex:1"><i style="width:'+Math.min(100,Math.max(0,av))+
        '%;background:'+(av>85?'var(--crit)':av>65?'var(--warn)':'var(--ok)')+'"></i></div>'+
        '<span style="font-size:13px;width:36px">'+num(av,0)+'%</span></div>')+'</td>'+
      '<td class="num" style="font-size:13px">'+esc(w.m.name)+'</td></tr>';
  });
  h+='</tbody></table></div></div></div>';

  /* PM schedule vs reality */
  var sched=activeMachines().map(function(m){ return {m:m,s:pmSchedule(m),c:pmCycles(m.id)}; })
    .filter(function(x){ return x.s; }).sort(function(a,b){ return a.s.inDays-b.s.inDays; });
  if(sched.length){
    h+='<div class="panel"><header><h3>PM schedule against measured behaviour</h3>'+
      '<span class="sub">your scheduled interval next to how long each machine actually holds up</span></header>'+
      '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
      '<th>Machine</th><th class="num">Last PM</th><th class="num">Next due</th><th class="num">Interval</th>'+
      '<th class="num">Typical run to warning</th><th>Verdict</th></tr></thead><tbody>';
    sched.forEach(function(x){
      var m=x.m, s=x.s, c=x.c;
      var warns=c.map(function(y){ return y.reachedWarn; }).filter(function(y){ return y!=null; });
      var med=warns.length?median(warns):null;
      var verdict='<span style="color:var(--ink-3)">Not enough cycles yet</span>';
      if(med!=null && warns.length>=2){
        if(med < m.pmIntervalDays*0.75)
          verdict='<span style="color:var(--warn);font-weight:600">Warns well before PM is due — consider a shorter interval</span>';
        else if(med > m.pmIntervalDays*1.2)
          verdict='<span style="color:var(--ok);font-weight:600">Holds past the interval — could be stretched</span>';
        else verdict='<span style="color:var(--ok)">Interval matches behaviour</span>';
      }
      h+='<tr class="clickable" data-m="'+esc(m.id)+'"><td><b>'+esc(m.name)+'</b>'+
        '<div class="pname">'+esc(m.group)+'</div></td>'+
        '<td class="num">'+esc(fmtShort(s.last))+'</td>'+
        '<td class="num" style="color:'+(s.overdue?'var(--crit)':s.due?'var(--warn)':'inherit')+
          ';font-weight:'+(s.due?'700':'400')+'">'+esc(fmtShort(s.next))+
          '<div style="font-size:12px;font-weight:400">'+(s.overdue?Math.abs(s.inDays)+'d overdue':'in '+s.inDays+'d')+'</div></td>'+
        '<td class="num">'+m.pmIntervalDays+'d</td>'+
        '<td class="num">'+(med!=null?Math.round(med)+'d <span style="color:var(--ink-3);font-size:12px">('+warns.length+' cycles)</span>':'—')+'</td>'+
        '<td style="font-size:13px">'+verdict+'</td></tr>';
    });
    h+='</tbody></table></div></div></div>';
  }

  $('#analysisBody').innerHTML=h;
  $('#analysisBody').querySelectorAll('tr[data-m]').forEach(function(tr){
    tr.onclick=function(){ $('#machinePick').value=tr.dataset.m; show('machine'); };
  });
}
function riskBar(r){
  var pct=Math.min(100,r*100/1.2);
  var c = r>0.75?'var(--crit)':r>0.45?'var(--warn)':'var(--ok)';
  return '<div style="display:flex;align-items:center;gap:7px;justify-content:flex-end">'+
    '<div class="bar-mini" style="width:60px"><i style="width:'+pct+'%;background:'+c+'"></i></div>'+
    '<b style="width:28px;text-align:right">'+num(r*100,0)+'</b></div>';
}
function moverBar(v){
  var pct=Math.min(100,Math.max(0,(v+1)/4*100));
  var c = v>2.5?'var(--crit)':v>1.4?'var(--warn)':v<-1?'var(--ok)':'var(--ink-3)';
  return '<div style="display:flex;align-items:center;gap:7px;justify-content:flex-end">'+
    '<div class="bar-mini" style="width:60px"><i style="width:'+pct+'%;background:'+c+'"></i></div>'+
    '<b style="width:40px;text-align:right;color:'+c+'">'+num(v,1)+'&times;</b></div>';
}
function critCell(n,c){ return n? '<b style="color:'+c+'">'+n+'</b>' : '<span style="color:var(--ink-3)">0</span>'; }

/* ========================= MACHINE DETAIL ========================= */
function renderMachine(){
  var sel=$('#machinePick'), cur=sel.value;
  sel.innerHTML = DB.groups.map(function(g){
    var ms=activeMachines().filter(function(m){ return m.group===g; });
    return ms.length?'<optgroup label="'+esc(g)+'">'+ms.map(function(m){
      return '<option value="'+esc(m.id)+'">'+esc(m.name)+'</option>'; }).join('')+'</optgroup>':'';
  }).join('');
  if(cur && machineById(cur)) sel.value=cur;
  sel.onchange=renderMachine;
  var m=machineById(sel.value)||activeMachines()[0];
  if(!m){ $('#machineBody').innerHTML='<div class="panel"><div class="empty"><p>No machines yet.</p></div></div>'; return; }
  sel.value=m.id;

  var rows=paramsOf(m.id).map(assess);
  var s=pmSchedule(m), cycles=pmCycles(m.id);
  var warns=cycles.map(function(x){ return x.reachedWarn; }).filter(function(x){ return x!=null; });

  var h='<div class="sumbar">'+
    sumCell(rows.filter(function(r){return r.status==='crit';}).length,'At limit','of '+rows.length+' parameters',
      rows.some(function(r){return r.status==='crit';})?'crit':'ok')+
    sumCell(s?(s.overdue?Math.abs(s.inDays)+'d late':s.inDays+'d'):'—','Next PM',s?fmtDate(s.next):'no schedule',
      s&&s.overdue?'crit':s&&s.due?'warn':'')+
    sumCell(s?diffDays(todayISO(),s.last)+'d':'—','Since last PM',s?fmtDate(s.last):'—','')+
    sumCell(warns.length>=2?Math.round(median(warns))+'d':'—','Typical run to warning',warns.length+' cycles measured','')+
    sumCell(cycles.length,'PM cycles on record','','')+
    '</div>';

  h+='<div class="panel"><header><h3>Parameters</h3></header><div class="body flush"><div class="tblwrap">'+
    '<table class="tbl"><thead><tr><th>Parameter</th><th>Status</th><th>Approach to limit</th>'+
    '<th class="num">Latest</th><th class="num">Warn</th><th class="num">Limit</th>'+
    '<th class="num">Trend</th><th class="num">Reaches</th></tr></thead><tbody>'+
    rows.map(function(a){
      return '<tr><td><b>'+esc(a.p.name)+'</b><div class="pname">'+esc(a.p.unit||'')+' · '+
        (a.p.bound==='lower'?'lower limit':'upper limit')+'</div></td>'+
        '<td>'+statusHTML(a.status)+'</td>'+
        '<td style="min-width:130px">'+travelBar(a)+
          '<div style="font-size:12px;color:var(--ink-3);margin-top:3px">'+
          (a.approach!=null?num(a.approach,0)+'% of the way there':'no baseline yet')+'</div></td>'+
        '<td class="num"><b>'+esc(num(a.value))+'</b></td>'+
        '<td class="num">'+esc(num(a.p.warn))+'</td>'+
        '<td class="num">'+esc(num(a.p.threshold))+'</td>'+
        '<td class="num">'+trendHTML(a)+'</td>'+
        '<td class="num">'+dttHTML(a)+'</td></tr>';
    }).join('')+'</tbody></table></div></div></div>';

  h+='<div class="chartgrid">'+rows.map(function(a){
    return '<div class="chartcard"><header><h4>'+esc(a.p.name)+'</h4>'+
      '<div class="meta">full history · '+a.n+' readings</div></header>'+trendChart(a,0)+'</div>';
  }).join('')+'</div>';

  if(cycles.length){
    h+='<div class="panel"><header><h3>PM cycle history</h3>'+
      '<span class="sub">how long each cycle ran and how quickly a parameter hit its warn level</span></header>'+
      '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
      '<th>Cycle start</th><th>Ended</th><th class="num">Length</th><th class="num">Days to warning</th>'+
      '<th class="num">Days to limit</th><th>Notes</th></tr></thead><tbody>'+
      cycles.slice().reverse().map(function(c){
        var ev=DB.pmEvents.filter(function(e){ return e.machineId===m.id && e.date===c.from; })[0];
        return '<tr><td>'+esc(fmtDate(c.from))+'</td>'+
          '<td>'+(c.to?esc(fmtDate(c.to)):'<span style="color:var(--accent);font-weight:600">running now</span>')+'</td>'+
          '<td class="num">'+c.len+'d</td>'+
          '<td class="num">'+(c.reachedWarn!=null?'<span style="color:var(--warn);font-weight:600">'+c.reachedWarn+'d</span>':'<span style="color:var(--ok)">never</span>')+'</td>'+
          '<td class="num">'+(c.reachedThr!=null?'<span style="color:var(--crit);font-weight:700">'+c.reachedThr+'d</span>':'<span style="color:var(--ok)">never</span>')+'</td>'+
          '<td style="font-size:13px;color:var(--ink-2)">'+esc(ev?(ev.type+(ev.notes?' — '+ev.notes:'')):'')+'</td></tr>';
      }).join('')+'</tbody></table></div></div></div>';
  }
  $('#machineBody').innerHTML=h;
}

/* ========================= MONTHLY REPORT ========================= */
function renderReport(){
  var sel=$('#reportMonth'), months=monthsAvailable();
  if(!months.length){
    $('#reportBody').innerHTML='<div class="panel"><div class="empty"><p>No readings yet, so there is nothing to report on.</p></div></div>';
    return;
  }
  var cur = (sel.value && months.indexOf(sel.value)>=0) ? sel.value : months[0];
  sel.innerHTML=months.map(function(m){
    var p=m.split('-');
    return '<option value="'+m+'">'+MONTH_FULL[+p[1]-1]+' '+p[0]+'</option>';
  }).join('');
  sel.value=cur; sel.onchange=renderReport;

  var R=monthReport(cur);
  var breached=R.rows.filter(function(r){ return r.breaches>0; });
  var warned=R.rows.filter(function(r){ return r.warns>0 && !r.breaches; });
  var worse=R.rows.filter(function(r){ return r.worsened; })
    .sort(function(a,b){ return Math.abs(b.change)-Math.abs(a.change); });
  var compliance = R.expected? Math.round(R.actual/R.expected*100):0;

  var h='<div class="sumbar">'+
    sumCell(R.days,'Days with readings','in this month','')+
    sumCell(compliance+'%','Logging completeness',R.actual+' of '+R.expected+' expected',compliance<80?'warn':'ok')+
    sumCell(breached.length,'Parameters that hit the limit','during the month',breached.length?'crit':'ok')+
    sumCell(warned.length,'Reached warn only','no limit breach',warned.length?'warn':'ok')+
    sumCell(R.pms.length,'PM jobs completed','','')+
    '</div>';

  if(breached.length) h+='<div class="alert crit" style="margin-bottom:16px"><span class="ic">&#9650;</span><div><b>'+
    breached.length+' parameter'+(breached.length===1?'':'s')+' reached the limit this month.</b><div class="mlist">'+
    breached.map(function(r){ return esc(r.m.name+' — '+r.p.name+', '+r.breaches+' day'+(r.breaches===1?'':'s')); }).join('  ·  ')+
    '</div></div></div>';

  h+='<div class="panel"><header><h3>Parameter summary</h3>'+
    '<span class="sub">month average against the month before</span></header>'+
    '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
    '<th>Machine / parameter</th><th class="num">Readings</th><th class="num">Min</th><th class="num">Average</th>'+
    '<th class="num">Max</th><th class="num">Month end</th><th class="num">Vs last month</th>'+
    '<th class="num">Days at limit</th><th>Status at close</th></tr></thead><tbody>';
  R.rows.sort(function(a,b){ return (b.endApproach||0)-(a.endApproach||0); }).forEach(function(r){
    var chg = r.change==null?'<span style="color:var(--ink-3)">—</span>'
      :'<span style="color:'+(r.worsened?'var(--crit)':'var(--ok)')+';font-weight:600">'+
        (r.change>0?'+':'')+num(r.change,1)+'%</span>';
    h+='<tr><td><b>'+esc(r.m.name)+'</b><div class="pname">'+esc(r.p.name)+'</div></td>'+
      '<td class="num">'+r.n+'</td><td class="num">'+esc(num(r.min))+'</td>'+
      '<td class="num"><b>'+esc(num(r.avg))+'</b></td><td class="num">'+esc(num(r.max))+'</td>'+
      '<td class="num">'+esc(num(r.end))+'</td><td class="num">'+chg+'</td>'+
      '<td class="num">'+(r.breaches?'<b style="color:var(--crit)">'+r.breaches+'</b>':'<span style="color:var(--ink-3)">0</span>')+'</td>'+
      '<td>'+statusHTML(r.endStatus)+'</td></tr>';
  });
  h+='</tbody></table></div></div></div>';

  if(worse.length){
    h+='<div class="panel"><header><h3>Moved in the wrong direction</h3>'+
      '<span class="sub">largest month-on-month deterioration</span></header>'+
      '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
      '<th>Machine / parameter</th><th class="num">Last month</th><th class="num">This month</th><th class="num">Change</th>'+
      '</tr></thead><tbody>'+
      worse.slice(0,10).map(function(r,i){
        return '<tr><td><span class="rank">'+(i+1)+'</span><b>'+esc(r.m.name)+'</b>'+
          '<div class="pname" style="margin-left:22px">'+esc(r.p.name)+'</div></td>'+
          '<td class="num">'+esc(num(r.prevAvg))+'</td><td class="num">'+esc(num(r.avg))+'</td>'+
          '<td class="num"><b style="color:var(--crit)">'+(r.change>0?'+':'')+esc(num(r.change,1))+'%</b></td></tr>';
      }).join('')+'</tbody></table></div></div></div>';
  }
  if(R.pms.length){
    h+='<div class="panel"><header><h3>PM work completed</h3></header><div class="body flush"><div class="tblwrap">'+
      '<table class="tbl"><thead><tr><th class="num">Date</th><th>Machine</th><th>Type</th><th>Technician</th><th>Notes</th></tr></thead><tbody>'+
      R.pms.slice().sort(function(a,b){ return a.date<b.date?1:-1; }).map(function(e){
        var m=machineById(e.machineId);
        return '<tr><td class="num">'+esc(fmtDate(e.date))+'</td><td><b>'+esc(m?m.name:e.machineId)+'</b></td>'+
          '<td>'+esc(e.type||'PM')+'</td><td>'+esc(e.tech||'—')+'</td>'+
          '<td style="color:var(--ink-2);font-size:13px">'+esc(e.notes||'')+'</td></tr>';
      }).join('')+'</tbody></table></div></div></div>';
  }
  $('#reportBody').innerHTML=h;
}
