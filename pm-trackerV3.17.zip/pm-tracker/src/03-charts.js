/* ==========================================================================
   03-charts.js — SVG drawn by hand, no charting library.
   Tile charts follow Tufte's clinical sparkline: a grey normal band with the
   trace on top, so a deviation reads without anyone parsing an axis.
   Gaps in the data are drawn as gaps, never interpolated across.
   ========================================================================== */

var COL = {
  trace:'#2f3d4a', traceOk:'#2f3d4a', traceWarn:'#a06400', traceCrit:'#a32c22',
  band:'#ccd6de', bandEdge:'#b6c3cd',
  thr:'#b02a20', warn:'#c98a1e', pm:'#1c5a9e', axis:'#aeb9c3'
};

/* Tick dates every N days, anchored on the most recent reading so the latest
   date always carries a label. Returns oldest-first. */
function tickDates(first, last, stepDays){
  var out=[], d=last;
  while(dayNum(d) >= dayNum(first)){ out.unshift(d); d = addDays(d, -stepDays); }
  if(out.length && diffDays(out[0], first) >= stepDays*0.6) out.unshift(first);
  return out;
}
var TICK_DAYS = 6;   /* x-axis date interval, shared by tile and full charts */


/* Y range. "auto" keeps the limit on screen, which is safest but squashes the
   trace flat when a reading sits far from its limit. "data" fits the readings
   only, so a small drift becomes visible — the limit may then sit off-chart, and
   the chart says so. "zero" anchors the bottom at zero for absolute magnitude. */
function yRange(p, vals, base){
  var lo, hi, mode=SETTINGS.yMode||'auto';
  var vLo=Math.min.apply(null,vals), vHi=Math.max.apply(null,vals);
  if(mode==='data'){ lo=vLo; hi=vHi; }
  else {
    lo=Math.min(vLo,p.threshold); hi=Math.max(vHi,p.threshold);
    if(SETTINGS.warnLine && p.warn!=null){ lo=Math.min(lo,p.warn); hi=Math.max(hi,p.warn); }
    if(SETTINGS.band && base!=null){ lo=Math.min(lo,base); hi=Math.max(hi,base); }
    if(mode==='zero'){ lo=Math.min(lo,0); }
  }
  var pad=(hi-lo)*0.14 || Math.abs(hi*0.08) || 1;
  return { lo:lo-pad, hi:hi+pad,
           clipped: mode==='data' && (p.threshold>vHi || p.threshold<vLo) };
}

/* ---------- tile microchart ---------- */
var CHART_H = { s:62, m:84, l:112, xl:150 };
function tileChart(a, days, compact){
  var H = CHART_H[SETTINGS.chartH] || CHART_H.m;
  if(compact) H = Math.max(56, H-20);
  var W=268, L=3, T=5, B=17;
  var pts = a.all;
  if(days>0){
    var cut = addDays(latestDate(), -days);
    pts = pts.filter(function(r){ return r.date>=cut; });
  }
  /* reserve exactly enough right margin for the latest-value label */
  var lastLbl = pts.length?num(pts[pts.length-1].value):'';
  var R = Math.max(26, Math.min(74, lastLbl.length*5.4+15));
  if(pts.length<1){
    return '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="No data">'+
      '<text x="'+(W/2)+'" y="'+(H/2+4)+'" text-anchor="middle" font-size="11" fill="#9aa5af">no readings</text></svg>';
  }
  var p=a.p, base=a.baseline;
  var vals=pts.map(function(r){ return r.value; });
  var yr=yRange(p, vals, base);
  var lo=yr.lo, hi=yr.hi;

  var d0=dayNum(pts[0].date), d1=dayNum(pts[pts.length-1].date), span=Math.max(1,d1-d0);
  var PLOT=H-B;
  function X(d){ return L + ((dayNum(d)-d0)/span)*(W-L-R); }
  function Y(v){ return T + (1-(v-lo)/(hi-lo))*(PLOT-T-2); }

  var s='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+
        esc(p.name+' trend, latest '+num(a.value))+'">';

  /* normal band: baseline to warn level */
  if(SETTINGS.band){
    var bandTop = p.warn!=null ? p.warn : p.threshold;
    var y1=Y(base), y2=Y(bandTop);
    s+='<rect x="0" y="'+Math.min(y1,y2)+'" width="'+W+'" height="'+Math.abs(y2-y1)+
       '" fill="'+COL.band+'" opacity=".5"/>';
  }
  /* on taller charts, add value gridlines so magnitude is readable */
  if(H>=100){
    for(var gi=1;gi<=3;gi++){
      var gv=lo+(hi-lo)*gi/4, gy=Y(gv);
      s+='<line x1="0" y1="'+gy+'" x2="'+(W-R+6)+'" y2="'+gy+'" stroke="'+COL.axis+
         '" stroke-width=".5" opacity=".3"/>';
      s+='<text x="2" y="'+(gy-1.5)+'" font-size="7.5" fill="'+COL.axis+'">'+esc(num(gv))+'</text>';
    }
  }

  /* threshold + warn lines */
  var yt=Y(p.threshold);
  if(SETTINGS.limitLine && !yr.clipped){
    s+='<line x1="0" y1="'+yt+'" x2="'+(W-R+6)+'" y2="'+yt+'" stroke="'+COL.thr+
       '" stroke-width="1.4" stroke-dasharray="4 3" opacity=".9"/>';
  }
  if(SETTINGS.warnLine && p.warn!=null && !yr.clipped){
    var yw=Y(p.warn);
    s+='<line x1="0" y1="'+yw+'" x2="'+(W-R+6)+'" y2="'+yw+'" stroke="'+COL.warn+
       '" stroke-width="1" stroke-dasharray="2 3" opacity=".75"/>';
  }
  /* an off-chart limit must never look like an absent one */
  if(yr.clipped){
    s+='<text x="'+(W-R+4)+'" y="9" text-anchor="end" font-size="8" fill="'+COL.thr+
       '" font-weight="700">limit off-chart</text>';
  }

  /* x-axis: a tick every TICK_DAYS days. Every tick gets a mark; labels are
     thinned to whatever actually fits so they never collide. */
  var ticks=tickDates(pts[0].date, pts[pts.length-1].date, TICK_DAYS);
  s+='<line x1="0" y1="'+PLOT+'" x2="'+W+'" y2="'+PLOT+'" stroke="#c3ccd5" stroke-width="1"/>';
  var avail=W-L-R, labelW=17;
  var everyN=Math.max(1, Math.ceil(ticks.length/Math.max(1,Math.floor(avail/labelW))));
  ticks.forEach(function(d,i){
    var x=X(d);
    if(x<L-1 || x>W-R+2) return;
    s+='<line x1="'+x+'" y1="'+(PLOT-2)+'" x2="'+x+'" y2="'+(PLOT+2.5)+'" stroke="#aeb9c3" stroke-width="1"/>';
    var isLast=i===ticks.length-1;
    if(i%everyN!==0 && !isLast) return;
    if(isLast && (ticks.length-1)%everyN!==0 && ticks.length>1){
      /* keep the newest label, drop the previous one if they would touch */
      var prevX=X(ticks[ticks.length-1-((ticks.length-1)%everyN)]);
      if(Math.abs(x-prevX)<labelW) { /* fall through, last wins */ }
    }
    var anchor = i===0?'start':(isLast?'end':'middle');
    var tx = i===0?Math.max(1,x-2):(isLast?Math.min(W-R+3,x+2):x);
    s+='<text x="'+tx+'" y="'+(PLOT+11)+'" text-anchor="'+anchor+
       '" font-size="8.5" fill="#8a96a1">'+esc(fmtNumeric(d))+'</text>';
  });

  /* PM markers */
  var pms = SETTINGS.pmMarks ? pmDatesOf(p.machineId).filter(function(d){
    return d>=pts[0].date && d<=pts[pts.length-1].date;
  }) : [];
  pms.forEach(function(d){
    var x=X(d);
    s+='<line x1="'+x+'" y1="0" x2="'+x+'" y2="'+PLOT+'" stroke="'+COL.pm+
       '" stroke-width="1" stroke-dasharray="2 2" opacity=".55"/>';
    s+='<path d="M'+(x-3)+',0 L'+(x+3)+',0 L'+x+',5 Z" fill="'+COL.pm+'" opacity=".85"/>';
  });

  /* trace, split at PM events and at gaps of more than 4 days */
  var segs=[[]], lastD=null;
  pts.forEach(function(r){
    var brk = false;
    if(lastD!=null){
      if(diffDays(r.date,lastD)>4) brk=true;
      pms.forEach(function(d){ if(d>lastD && d<=r.date) brk=true; });
    }
    if(brk && segs[segs.length-1].length) segs.push([]);
    segs[segs.length-1].push(r);
    lastD=r.date;
  });
  var traceCol = a.status==='crit'?COL.traceCrit : a.status==='warn'?COL.traceWarn : COL.trace;
  segs.forEach(function(seg){
    if(seg.length<2) return;
    s+='<polyline fill="none" stroke="'+traceCol+'" stroke-width="1.6" stroke-linejoin="round" points="'+
       seg.map(function(r){ return X(r.date)+','+Y(r.value); }).join(' ')+'"/>';
  });
  /* mark only out-of-band points, plus the latest */
  if(SETTINGS.dots) pts.forEach(function(r){
    var st=statusOf(p,r.value);
    if(st==='ok') return;
    s+='<circle cx="'+X(r.date)+'" cy="'+Y(r.value)+'" r="1.9" fill="'+
       (st==='crit'?COL.thr:COL.warn)+'"/>';
  });
  /* latest point, marked and labelled with its value */
  var last=pts[pts.length-1];
  var lx=X(last.date), ly=Y(last.value);
  s+='<circle cx="'+lx+'" cy="'+ly+'" r="2.8" fill="'+traceCol+'"/>'+
     '<circle cx="'+lx+'" cy="'+ly+'" r="4.6" fill="none" stroke="'+traceCol+'" stroke-width="1" opacity=".38"/>';
  if(!SETTINGS.label){ s+='</svg>'; return s; }
  var lbl=lastLbl;
  var lw=lbl.length*5.4+8;
  var lxBox=Math.min(lx+5, W-lw-1.5);
  var ly2=Math.max(9, Math.min(PLOT-3, ly+3.2));
  s+='<rect x="'+lxBox+'" y="'+(ly2-8.5)+'" width="'+lw+'" height="12" rx="2.5" '+
     'fill="#ffffff" stroke="'+traceCol+'" stroke-width=".8" opacity=".96"/>';
  s+='<text x="'+(lxBox+lw/2)+'" y="'+(ly2+.8)+'" text-anchor="middle" font-size="9.5" '+
     'font-weight="700" fill="'+traceCol+'">'+esc(lbl)+'</text>';
  s+='</svg>';
  return s;
}

/* ---------- full-size trend chart ---------- */
function trendChart(a, windowDays){
  var p=a.p, W=640, H=252, L=58, R=16, T=14, B=34;
  var pts=a.all;
  if(windowDays>0){
    var cut=addDays(latestDate(), -windowDays);
    pts=pts.filter(function(r){ return r.date>=cut; });
  }
  if(!pts.length){
    return '<svg viewBox="0 0 '+W+' '+H+'"><text x="'+(W/2)+'" y="'+(H/2)+
      '" text-anchor="middle" fill="#77848f" font-size="14">No readings in this window</text></svg>';
  }
  var vals=pts.map(function(r){ return r.value; });
  var yr=yRange(p, vals, a.baseline);
  var lo=yr.lo, hi=yr.hi;
  var d0=dayNum(pts[0].date), d1=dayNum(pts[pts.length-1].date), span=Math.max(1,d1-d0);
  function X(d){ return L + ((dayNum(d)-d0)/span)*(W-L-R); }
  function Y(v){ return T + (1-(v-lo)/(hi-lo))*(H-T-B); }

  var s='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Trend for '+esc(p.name)+'">';
  s+='<rect x="'+L+'" y="'+T+'" width="'+(W-L-R)+'" height="'+(H-T-B)+'" fill="#fbfcfd"/>';

  /* normal band */
  if(SETTINGS.band){
    var bandTop = p.warn!=null?p.warn:p.threshold;
    var b1=Y(a.baseline), b2=Y(bandTop);
    s+='<rect x="'+L+'" y="'+Math.min(b1,b2)+'" width="'+(W-L-R)+'" height="'+Math.abs(b2-b1)+
       '" fill="'+COL.band+'" opacity=".35"/>';
  }

  for(var i=0;i<=4;i++){
    var v=lo+(hi-lo)*i/4, y=Y(v);
    s+='<line x1="'+L+'" y1="'+y+'" x2="'+(W-R)+'" y2="'+y+'" stroke="#e2e8ed" stroke-width="1"/>';
    s+='<text x="'+(L-7)+'" y="'+(y+4)+'" text-anchor="end" font-size="11" fill="#77848f">'+esc(num(v))+'</text>';
  }
  if(SETTINGS.warnLine && p.warn!=null && !yr.clipped){
    var yw=Y(p.warn);
    s+='<line x1="'+L+'" y1="'+yw+'" x2="'+(W-R)+'" y2="'+yw+'" stroke="'+COL.warn+'" stroke-width="1.5" stroke-dasharray="7 4"/>';
    s+='<text x="'+(L+4)+'" y="'+(yw+(p.bound==='lower'?12:-4))+'" text-anchor="start" font-size="10.5" font-weight="600" fill="#8a5300">Warn '+esc(num(p.warn))+'</text>';
  }
  var yt=Y(p.threshold);
  if(SETTINGS.limitLine && !yr.clipped){
    s+='<line x1="'+L+'" y1="'+yt+'" x2="'+(W-R)+'" y2="'+yt+'" stroke="'+COL.thr+'" stroke-width="2" stroke-dasharray="3 3"/>';
    s+='<text x="'+(L+4)+'" y="'+(yt+(p.bound==='lower'?12:-4))+'" text-anchor="start" font-size="10.5" font-weight="700" fill="'+COL.thr+'">Limit '+esc(num(p.threshold))+'</text>';
  }
  if(yr.clipped){
    s+='<text x="'+(W-R-3)+'" y="'+(T+11)+'" text-anchor="end" font-size="10.5" font-weight="700" fill="'+COL.thr+
       '">Limit '+esc(num(p.threshold))+' is off this chart</text>';
  }

  var pms=SETTINGS.pmMarks?pmDatesOf(p.machineId).filter(function(d){ return d>=pts[0].date && d<=pts[pts.length-1].date; }):[];
  pms.forEach(function(d){
    var x=X(d);
    s+='<line x1="'+x+'" y1="'+T+'" x2="'+x+'" y2="'+(H-B)+'" stroke="'+COL.pm+'" stroke-width="1.5" stroke-dasharray="2 3" opacity=".85"/>';
    s+='<rect x="'+(x-9)+'" y="'+(T+2)+'" width="18" height="13" rx="2" fill="'+COL.pm+'"/>';
    s+='<text x="'+x+'" y="'+(T+12)+'" text-anchor="middle" font-size="9.5" font-weight="700" fill="#fff">PM</text>';
  });

  var segs=[[]], lastD=null;
  pts.forEach(function(r){
    var brk=false;
    if(lastD!=null){
      if(diffDays(r.date,lastD)>4) brk=true;
      pms.forEach(function(d){ if(d>lastD && d<=r.date) brk=true; });
    }
    if(brk && segs[segs.length-1].length) segs.push([]);
    segs[segs.length-1].push(r); lastD=r.date;
  });
  segs.forEach(function(seg){
    if(seg.length<2) return;
    s+='<polyline fill="none" stroke="'+COL.pm+'" stroke-width="2" stroke-linejoin="round" points="'+
       seg.map(function(r){ return X(r.date)+','+Y(r.value); }).join(' ')+'"/>';
  });
  if(SETTINGS.dots) pts.forEach(function(r){
    var st=statusOf(p,r.value);
    var c = st==='crit'?COL.thr : st==='warn'?COL.warn : COL.pm;
    s+='<circle cx="'+X(r.date)+'" cy="'+Y(r.value)+'" r="'+(st==='ok'?2.6:3.6)+'" fill="'+c+'">'+
       '<title>'+esc(fmtDate(r.date)+': '+num(r.value)+' '+(p.unit||''))+'</title></circle>';
  });
  var lastPt=pts[pts.length-1];
  if(SETTINGS.projection && !yr.clipped && a.dtt!=null && a.dtt>0 && a.dtt<span*1.6 && a.status!=='crit'){
    var px=X(addDays(lastPt.date, Math.round(a.dtt)));
    if(px<=W-R){
      s+='<line x1="'+X(lastPt.date)+'" y1="'+Y(lastPt.value)+'" x2="'+px+'" y2="'+yt+'" stroke="'+COL.thr+'" stroke-width="1.5" stroke-dasharray="4 4" opacity=".6"/>';
      s+='<circle cx="'+px+'" cy="'+yt+'" r="3.5" fill="none" stroke="'+COL.thr+'" stroke-width="1.5"/>';
    }
  }
  /* data label on the most recent reading */
  if(SETTINGS.label){
  var flx=X(lastPt.date), fly=Y(lastPt.value);
  var flText=num(lastPt.value)+(p.unit?' '+p.unit:'');
  var flW=flText.length*6.1+10;
  var flRight = flx+6+flW <= W-R;
  var flX = flRight ? flx+6 : flx-6-flW;
  var flY = Math.max(T+11, Math.min(H-B-4, fly+4));
  var flCol = a.status==='crit'?COL.thr : a.status==='warn'?COL.warn : COL.pm;
  s+='<rect x="'+flX+'" y="'+(flY-11)+'" width="'+flW+'" height="15.5" rx="3" fill="#fff" '+
     'stroke="'+flCol+'" stroke-width="1"/>';
  s+='<text x="'+(flX+flW/2)+'" y="'+(flY+.5)+'" text-anchor="middle" font-size="11" '+
     'font-weight="700" fill="'+flCol+'">'+esc(flText)+'</text>';
  }
  /* x-axis: a tick and label every TICK_DAYS days, anchored on the latest reading */
  s+='<line x1="'+L+'" y1="'+(H-B)+'" x2="'+(W-R)+'" y2="'+(H-B)+'" stroke="'+COL.axis+'"/>';
  var ticks=tickDates(pts[0].date, pts[pts.length-1].date, TICK_DAYS);
  ticks.forEach(function(d,i){
    var x=X(d);
    if(x<L-1 || x>W-R+1) return;
    s+='<line x1="'+x+'" y1="'+(H-B)+'" x2="'+x+'" y2="'+(H-B+4)+'" stroke="'+COL.axis+'"/>';
    var anchor = i===0?'start':(i===ticks.length-1?'end':'middle');
    s+='<text x="'+x+'" y="'+(H-B+16)+'" text-anchor="'+anchor+
       '" font-size="11" fill="#77848f">'+esc(fmtShort(d))+'</text>';
  });
  s+='<text x="'+(L-7)+'" y="'+(H-B+16)+'" text-anchor="end" font-size="10.5" fill="#9aa5af">'+esc(p.unit||'')+'</text>';
  s+='</svg>';
  return s;
}

/* ---------- small widgets ---------- */
function sparkline(a,w,h){
  w=w||110; h=h||24;
  var pts=a.seg.length>=2?a.seg:a.all;
  if(pts.length<2) return '<svg width="'+w+'" height="'+h+'"></svg>';
  var v=pts.map(function(r){ return r.value; });
  var lo=Math.min.apply(null,v), hi=Math.max.apply(null,v), rng=(hi-lo)||1;
  function X(i){ return (i/(pts.length-1))*(w-2)+1; }
  function Y(x){ return h-2-((x-lo)/rng)*(h-5); }
  var col = a.toward!=null&&a.toward>0 ? COL.thr : (a.toward!=null&&a.toward<0 ? '#1d6b45' : '#77848f');
  return '<svg width="'+w+'" height="'+h+'" aria-hidden="true">'+
    '<polyline fill="none" stroke="'+col+'" stroke-width="1.6" points="'+
      v.map(function(x,i){ return X(i)+','+Y(x); }).join(' ')+'"/>'+
    '<circle cx="'+X(v.length-1)+'" cy="'+Y(v[v.length-1])+'" r="2.2" fill="'+col+'"/></svg>';
}
function statusHTML(st){ return '<span class="st '+st+'"><i class="gl"></i>'+STATUS_LABEL[st]+'</span>'; }
function travelBar(a){
  if(a.approach==null) return '';
  var pct=Math.max(0,Math.min(100,a.approach));
  var cls=a.status==='crit'?'crit':a.status==='warn'?'warn':'ok';
  var warnPos = a.p.warn!=null ? Math.max(0,Math.min(100, approach(a.p,a.p.warn)||0)) : null;
  return '<div class="travel" title="'+esc(num(a.approach,0)+'% of the way from baseline to limit')+'">'+
    '<i class="'+cls+'" style="width:'+pct+'%"></i>'+
    (warnPos!=null&&warnPos>3&&warnPos<98?'<u style="left:'+warnPos+'%"></u>':'')+'</div>';
}
function trendHTML(a){
  if(a.thinSincePM) return '<span class="trend flat" title="Trend restarts after PM and needs a few readings">Rebuilding after PM</span>';
  if(a.slope==null) return '<span class="trend flat">Not enough data</span>';
  var mag=Math.abs(a.slope);
  if(mag<1e-9 || (a.p.threshold && mag/Math.abs(a.p.threshold)<0.0006))
    return '<span class="trend flat"><span class="ar">&rarr;</span>Steady</span>';
  var cls=a.toward>0?'rising':'falling';
  var arrow=a.slope>0?'\u2197':'\u2198';
  return '<span class="trend '+cls+'" title="'+esc(num(a.slope,4)+' '+(a.p.unit||'')+' per day')+'">'+
    '<span class="ar">'+arrow+'</span>'+esc((a.slope>0?'+':'')+num(a.slope*7)+'/wk')+'</span>';
}
function dttHTML(a){
  if(a.status==='crit') return '<b style="color:var(--crit)">Reached</b>';
  if(a.thinSincePM) return '<span style="color:var(--ink-3)">after PM, too soon to say</span>';
  if(a.dtt==null) return '<span style="color:var(--ink-3)">Not trending there</span>';
  var d=Math.round(a.dtt);
  var col = d<=7?'var(--crit)':d<=21?'var(--warn)':'var(--ink-2)';
  return '<span style="color:'+col+';font-weight:'+(d<=7?'700':'600')+'">'+d+' day'+(d===1?'':'s')+'</span>';
}
function anomHTML(a){
  if(a.anom==null) return '<span style="color:var(--ink-3)">—</span>';
  var v=a.anom;
  if(v>2.5) return '<b style="color:var(--crit)">'+num(v,1)+'&times; faster</b>';
  if(v>1.4) return '<span style="color:var(--warn);font-weight:600">'+num(v,1)+'&times; faster</span>';
  if(v<-1.4) return '<span style="color:var(--ok)">recovering</span>';
  return '<span style="color:var(--ink-3)">normal</span>';
}
