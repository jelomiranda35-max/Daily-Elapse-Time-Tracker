/* ==========================================================================
   07-config.js — setup screens: parameters, machines, groups
   ========================================================================== */

function renderConfig(){
  $$('#configTabs button').forEach(function(b){
    b.setAttribute('aria-current', String(b.dataset.tab===configTab));
    b.onclick=function(){ configTab=b.dataset.tab; renderConfig(); };
  });
  var host=$('#configBody');
  host.innerHTML = configTab==='params'?cfgParams():configTab==='machines'?cfgMachines():cfgGroups();
  host.querySelectorAll('[data-act]').forEach(function(b){
    b.onclick=function(){ configAct(b.dataset.act, b.dataset.id); };
  });
}

function cfgParams(){
  var h='<div class="toolbar"><button class="btn primary" data-act="addParam">Add parameter</button>'+
    '<span style="font-size:13.5px;color:var(--ink-2)">A parameter is one reading on one machine. '+
    'Add a second for machines where you track two.</span></div>';
  if(!DB.parameters.length){
    return h+'<div class="panel"><div class="empty"><h4>No parameters yet</h4>'+
      '<p>Add one by hand, or go to Save, load &amp; import and paste your Excel grid to create everything at once.</p>'+
      '<button class="btn primary" data-act="addParam">Add parameter</button></div></div>';
  }
  h+='<div class="panel"><div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
    '<th>Machine</th><th>Parameter</th><th class="num">Unit</th><th class="num">Warn</th><th class="num">Limit</th>'+
    '<th>Direction</th><th class="num">Believable range</th><th class="num">Readings</th><th></th></tr></thead><tbody>';
  DB.groups.concat(['Ungrouped']).forEach(function(g){
    var ps=DB.parameters.filter(function(p){ return groupOf(p)===g; });
    if(!ps.length) return;
    h+='<tr><td colspan="9" style="background:linear-gradient(180deg,#f4f7f9,#eef2f5);font-weight:600;'+
       'font-size:12.5px;color:var(--ink-2)">'+esc(g)+'</td></tr>';
    ps.forEach(function(p){
      var m=machineById(p.machineId);
      h+='<tr><td><b>'+esc(m?m.name:p.machineId)+'</b></td><td>'+esc(p.name)+'</td>'+
        '<td class="num">'+esc(p.unit||'—')+'</td><td class="num">'+esc(num(p.warn))+'</td>'+
        '<td class="num"><b>'+esc(num(p.threshold))+'</b></td>'+
        '<td><span class="tag">'+(p.bound==='lower'?'must not fall to it':'must not rise to it')+'</span></td>'+
        '<td class="num" style="font-size:12.5px;color:var(--ink-3)">'+esc(num(p.validMin))+' – '+esc(num(p.validMax))+'</td>'+
        '<td class="num">'+seriesOf(p.id).length+'</td>'+
        '<td class="num"><button class="btn sm" data-act="editParam" data-id="'+esc(p.id)+'">Edit</button> '+
        '<button class="btn sm danger" data-act="delParam" data-id="'+esc(p.id)+'">Delete</button></td></tr>';
    });
  });
  return h+'</tbody></table></div></div></div>';
}

function cfgMachines(){
  var h='<div class="toolbar"><button class="btn primary" data-act="addMachine">Add machine</button>'+
    '<span style="font-size:13.5px;color:var(--ink-2)">The PM interval drives the reminder on the board. '+
    'Retire a machine rather than deleting it so its history stays intact.</span></div>';
  if(!DB.machines.length){
    return h+'<div class="panel"><div class="empty"><h4>No machines yet</h4>'+
      '<p>Add your first machine, then give it one or two parameters.</p>'+
      '<button class="btn primary" data-act="addMachine">Add machine</button></div></div>';
  }
  h+='<div class="panel"><div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
    '<th>Machine</th><th>Group</th><th class="num">Parameters</th><th class="num">PM interval</th>'+
    '<th class="num">Last PM</th><th class="num">Next due</th><th class="num">Remind before</th>'+
    '<th>State</th><th></th></tr></thead><tbody>';
  DB.machines.forEach(function(m){
    var s=pmSchedule(m);
    h+='<tr><td><b>'+esc(m.name)+'</b><div class="pname">'+esc(m.id)+'</div></td>'+
      '<td><span class="tag">'+esc(m.group)+'</span></td>'+
      '<td class="num">'+paramsOf(m.id).length+'</td>'+
      '<td class="num">'+(m.pmIntervalDays?m.pmIntervalDays+'d':'—')+'</td>'+
      '<td class="num">'+(s?esc(fmtShort(s.last)):'—')+'</td>'+
      '<td class="num" style="color:'+(s&&s.overdue?'var(--crit)':s&&s.due?'var(--warn)':'inherit')+
        ';font-weight:'+(s&&s.due?'700':'400')+'">'+(s?esc(fmtShort(s.next)):'—')+'</td>'+
      '<td class="num">'+(m.pmLeadDays||10)+'d</td>'+
      '<td>'+(m.active===false?'<span class="st none"><i class="gl"></i>Retired</span>'
        :'<span class="st ok"><i class="gl"></i>Active</span>')+'</td>'+
      '<td class="num"><button class="btn sm" data-act="editMachine" data-id="'+esc(m.id)+'">Edit</button> '+
      '<button class="btn sm" data-act="logPM" data-id="'+esc(m.id)+'">Log PM</button></td></tr>';
  });
  return h+'</tbody></table></div></div></div>';
}

function cfgGroups(){
  return '<div class="panel"><header><h3>Groups</h3>'+
    '<span class="sub">used to filter the board, charts and printed report</span></header><div class="body">'+
    '<label class="fld" style="max-width:420px"><span>Groups, one per line</span>'+
    '<textarea id="groupList" rows="6">'+esc(DB.groups.join('\n'))+'</textarea>'+
    '<span class="hint">Renaming a group here does not move machines. Change a machine\u2019s group on its own row.</span></label>'+
    '<button class="btn primary" data-act="saveGroups">Save groups</button></div></div>'+
    '<div class="panel"><header><h3>Site label</h3></header><div class="body">'+
    '<label class="fld" style="max-width:420px"><span>Shown in the sidebar and on printed reports</span>'+
    '<input id="siteLabel" value="'+esc(DB.meta.site||'')+'" placeholder="e.g. Fab 2 — Bay 4"></label>'+
    '<button class="btn primary" data-act="saveSite">Save label</button></div></div>';
}

function configAct(act,id){
  if(act==='addMachine')  return machineDialog(null);
  if(act==='editMachine') return machineDialog(machineById(id));
  if(act==='addParam')    return paramDialog(null);
  if(act==='editParam')   return paramDialog(DB.parameters.filter(function(p){ return p.id===id; })[0]);
  if(act==='logPM')       return pmDialog(id);
  if(act==='delParam'){
    var p=DB.parameters.filter(function(x){ return x.id===id; })[0];
    var n=seriesOf(id).length;
    if(!confirm('Delete "'+p.name+'"?'+(n?'\n\nThis also removes '+n+' reading'+(n===1?'':'s')+'. This cannot be undone.':''))) return;
    DB.parameters=DB.parameters.filter(function(x){ return x.id!==id; });
    DB.readings=DB.readings.filter(function(r){ return r.paramId!==id; });
    unsavedOps++; markDirty(); render(); toast('Parameter deleted.');
    return;
  }
  if(act==='saveGroups'){
    var g=$('#groupList').value.split('\n').map(function(s){ return s.trim(); }).filter(Boolean);
    if(!g.length) return toast('Keep at least one group.',true);
    DB.groups=g; unsavedOps++; markDirty(); render(); toast('Groups saved.');
    return;
  }
  if(act==='saveSite'){
    DB.meta.site=$('#siteLabel').value.trim();
    unsavedOps++; markDirty(); render(); toast('Label saved.');
  }
}

/* ---------- modal helper ---------- */
function modal(title, bodyHTML, onSave, saveLabel){
  var host=$('#modalHost');
  host.innerHTML='<div class="modal"><div class="box" role="dialog" aria-modal="true" aria-label="'+esc(title)+'">'+
    '<header><h3>'+esc(title)+'</h3></header><div class="bd">'+bodyHTML+'</div>'+
    '<footer><button class="btn" id="mCancel">Cancel</button>'+
    '<button class="btn primary" id="mSave">'+esc(saveLabel||'Save')+'</button></footer></div></div>';
  function close(){ host.innerHTML=''; document.removeEventListener('keydown',key); }
  function key(e){ if(e.key==='Escape') close(); }
  document.addEventListener('keydown',key);
  $('#mCancel').onclick=close;
  host.querySelector('.modal').onclick=function(e){ if(e.target.classList.contains('modal')) close(); };
  $('#mSave').onclick=function(){ if(onSave()!==false) close(); };
  var first=host.querySelector('input,select,textarea');
  if(first) first.focus();
  return close;
}
function fld(label,inner,hint){
  return '<label class="fld"><span>'+label+'</span>'+inner+(hint?'<span class="hint">'+hint+'</span>':'')+'</label>';
}

function machineDialog(m){
  var isNew=!m;
  var gopts=DB.groups.map(function(g){
    return '<option'+(m&&m.group===g?' selected':'')+'>'+esc(g)+'</option>';
  }).join('');
  var b='<div class="row">'+
    fld('Machine name','<input id="fName" value="'+esc(m?m.name:'')+'" placeholder="e.g. Scanner 3">')+
    fld('Short ID','<input id="fId" value="'+esc(m?m.id:'')+'" placeholder="e.g. SCN-03"'+(isNew?'':' disabled')+'>',
      'Used internally and on the tile. Cannot change later.')+'</div>'+
    '<div class="row">'+
    fld('Group','<select id="fGroup">'+gopts+'</select>')+
    fld('PM interval','<input id="fIv" type="number" min="1" value="'+esc(m?(m.pmIntervalDays||''):'')+'" placeholder="days">',
      'How often this machine is scheduled for PM.')+
    fld('Remind this many days ahead','<input id="fLead" type="number" min="0" value="'+esc(m?(m.pmLeadDays||10):10)+'">')+'</div>'+
    '<div class="row">'+
    fld('Last PM date','<input id="fLast" type="date" value="'+esc(m?(m.lastPM||''):'')+'">',
      'Used until a PM is logged through the app.')+
    fld('State','<select id="fActive"><option value="1"'+(!m||m.active!==false?' selected':'')+'>Active</option>'+
      '<option value="0"'+(m&&m.active===false?' selected':'')+'>Retired — keep history, stop tracking</option></select>')+'</div>';
  modal(isNew?'Add machine':'Edit '+m.name, b, function(){
    var name=$('#fName').value.trim();
    var id=isNew?$('#fId').value.trim():m.id;
    if(!name||!id){ toast('Name and short ID are both needed.',true); return false; }
    if(isNew && machineById(id)){ toast('That short ID is already in use.',true); return false; }
    var rec = m || { id:id };
    rec.name=name; rec.group=$('#fGroup').value;
    rec.pmIntervalDays=+$('#fIv').value||null;
    rec.pmLeadDays=+$('#fLead').value||10;
    rec.lastPM=$('#fLast').value||null;
    rec.active=$('#fActive').value==='1';
    if(isNew) DB.machines.push(rec);
    unsavedOps++; markDirty(); render(); toast(isNew?'Machine added.':'Machine updated.');
  }, isNew?'Add machine':'Save changes');
}

function paramDialog(p){
  var isNew=!p;
  if(!DB.machines.length){ toast('Add a machine first.',true); return; }
  var mopts=activeMachines().map(function(m){
    return '<option value="'+esc(m.id)+'"'+(p&&p.machineId===m.id?' selected':'')+'>'+
      esc(m.name)+' ('+esc(m.group)+')</option>';
  }).join('');
  var b='<div class="row">'+
    fld('Machine','<select id="pMach"'+(isNew?'':' disabled')+'>'+mopts+'</select>')+
    fld('Parameter name','<input id="pName" value="'+esc(p?p.name:'')+'" placeholder="e.g. Bearing temperature">')+
    fld('Unit','<input id="pUnit" value="'+esc(p?(p.unit||''):'')+'" placeholder="e.g. degC">')+'</div>'+
    '<div class="row">'+
    fld('Which way does the reading move?','<select id="pBound">'+
      '<option value="upper"'+(!p||p.bound!=='lower'?' selected':'')+'>It climbs toward the limit</option>'+
      '<option value="lower"'+(p&&p.bound==='lower'?' selected':'')+'>It falls toward the limit</option></select>',
      'Pick "falls" for readings like lamp intensity or clamp vacuum that are healthy when high.')+'</div>'+
    '<div class="row">'+
    fld('Limit','<input id="pThr" type="number" step="any" value="'+esc(p?p.threshold:'')+'">','The value it must not reach.')+
    fld('Warn level','<input id="pWarn" type="number" step="any" value="'+esc(p&&p.warn!=null?p.warn:'')+'">',
      'Amber before red. Leave blank for 80% of the way.')+'</div>'+
    '<div class="row">'+
    fld('Lowest believable reading','<input id="pMin" type="number" step="any" value="'+esc(p&&p.validMin!=null?p.validMin:'')+'">',
      'Catches a misplaced decimal at entry.')+
    fld('Highest believable reading','<input id="pMax" type="number" step="any" value="'+esc(p&&p.validMax!=null?p.validMax:'')+'">')+'</div>'+
    '<div class="row">'+fld('Group','<input value="'+esc(p?groupOf(p):'')+'" disabled>',
      'Comes from the machine. Change it on the machine row.')+'</div>';
  modal(isNew?'Add parameter':'Edit parameter', b, function(){
    var mid=isNew?$('#pMach').value:p.machineId;
    var name=$('#pName').value.trim();
    var thr=parseFloat($('#pThr').value);
    if(!name||!isFinite(thr)){ toast('A name and a limit are both needed.',true); return false; }
    var bound=$('#pBound').value;
    var warn=parseFloat($('#pWarn').value);
    var id = isNew ? mid+'::'+name : p.id;
    if(isNew && DB.parameters.some(function(x){ return x.id===id; })){
      toast('That machine already has a parameter with this name.',true); return false;
    }
    var rec = p || { id:id, machineId:mid };
    rec.name=name; rec.unit=$('#pUnit').value.trim(); rec.threshold=thr; rec.bound=bound;
    if(!isFinite(warn)){
      var base = isNew ? thr*(bound==='lower'?1.6:0.5) : healthyBaseline(rec);
      warn = base + (thr-base)*0.8;
    }
    rec.warn=warn;
    var mn=parseFloat($('#pMin').value), mx=parseFloat($('#pMax').value);
    rec.validMin = isFinite(mn)?mn:(bound==='upper'?0:thr*0.3);
    rec.validMax = isFinite(mx)?mx:(bound==='upper'?thr*4:thr*6);
    if(isNew) DB.parameters.push(rec);
    delete rec._base;
    unsavedOps++; markDirty(); render(); toast(isNew?'Parameter added.':'Parameter updated.');
  }, isNew?'Add parameter':'Save changes');
}

function pmDialog(mid){
  var m=machineById(mid);
  var b=fld('Date the work was done','<input id="kDate" type="date" value="'+todayISO()+'">',
      'Backdate this if the PM was done earlier and not logged at the time.')+
    '<div class="row">'+
    fld('Type of work','<input id="kType" value="Scheduled PM">')+
    fld('Technician','<input id="kTech" value="'+esc(DB.meta.lastBy||'')+'">')+'</div>'+
    fld('Notes','<textarea id="kNotes" rows="3" placeholder="Parts replaced, anything unusual"></textarea>');
  modal('Log PM for '+m.name, b, function(){
    var date=$('#kDate').value;
    if(!date){ toast('Pick a date.',true); return false; }
    if(DB.pmEvents.some(function(e){ return e.machineId===mid && e.date===date; })){
      toast('A PM is already logged for that date.',true); return false;
    }
    DB.pmEvents.push({ id:uid(), date:date, machineId:mid, type:$('#kType').value.trim()||'PM',
      tech:$('#kTech').value.trim(), notes:$('#kNotes').value.trim() });
    if(!m.lastPM || date>m.lastPM) m.lastPM=date;
    unsavedOps++; markDirty(); render();
    toast('PM logged. The trend for this machine restarts from '+fmtDate(date)+'.');
  },'Log PM');
}
