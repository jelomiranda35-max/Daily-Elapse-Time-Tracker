/* ==========================================================================
   09-demo.js — sample fleet so the app is explorable before real data lands.
   Delete this file and its <script> tag once you are running on your own data.

   Each parameter carries a target severity so the demo shows a realistic
   alarm spread rather than an all-green board. The drift rate is derived from
   how long it has actually been since that machine's last PM, so the trace
   lands where intended no matter where the PM cycle fell.
   ========================================================================== */

function demoDB(){
  var db = blankDB();
  db.meta.site = 'Demo data — replace with your own';

  /* [ id, name, group, pmIntervalDays,
       [ [param, unit, limit, warn, bound, base, noise, severity] ] ]
     severity: 'crit' | 'warn' | 'watch' | 'ok'                              */
  var spec = [
    ['SCN-01','Scanner 1','Photo',90,[
      ['Lens heating drift','nm',3.5,2.8,'upper',0.9,0.10,'crit'],
      ['Stage vibration','mm/s',5.0,4.0,'upper',1.8,0.16,'watch']]],
    ['SCN-03','Scanner 3','Photo',90,[
      ['Illumination uniformity','%',2.5,2.0,'upper',0.8,0.07,'ok'],
      ['Reticle sync error','nm',7.0,5.5,'upper',2.4,0.24,'warn']]],
    ['CTR-02','Coater Track 2','Photo',60,[
      ['Dispense pressure drop','kPa',18,15,'upper',7.5,0.50,'warn']]],
    ['CTR-04','Coater Track 4','Photo',60,[
      ['Dispense pressure drop','kPa',18,15,'upper',7.5,0.45,'ok']]],
    ['DEV-05','Developer 5','Photo',60,[
      ['Nozzle flow deviation','%',6.0,4.8,'upper',1.9,0.18,'watch']]],
    ['DPM-11','Dry Pump 11','Vacuum',120,[
      ['Base pressure','mTorr',60,48,'upper',18,1.60,'crit'],
      ['Motor current','A',9.5,8.2,'upper',5.6,0.13,'watch']]],
    ['DPM-14','Dry Pump 14','Vacuum',120,[
      ['Base pressure','mTorr',60,48,'upper',18,1.40,'ok']]],
    ['TPM-12','Turbo Pump 12','Vacuum',180,[
      ['Bearing temperature','degC',62,55,'upper',38,0.60,'warn']]],
    ['TPM-16','Turbo Pump 16','Vacuum',180,[
      ['Bearing temperature','degC',62,55,'upper',38,0.55,'ok']]],
    ['CHM-13','Etch Chamber 13','Vacuum',45,[
      ['Leak rate','sccm',0.045,0.035,'upper',0.012,0.0018,'warn'],
      ['Chuck clamp vacuum','kPa',22,26,'lower',44,0.45,'watch']]],
    ['CHM-15','Etch Chamber 15','Vacuum',45,[
      ['Leak rate','sccm',0.045,0.035,'upper',0.012,0.0016,'ok']]],
    ['SEM-21','CD-SEM 21','Metrology',75,[
      ['Beam current drift','%',4.0,3.2,'upper',1.1,0.13,'watch'],
      ['Stage repeatability','nm',12,9.5,'upper',4.2,0.34,'warn']]],
    ['SEM-25','CD-SEM 25','Metrology',75,[
      ['Beam current drift','%',4.0,3.2,'upper',1.1,0.11,'ok']]],
    ['OVL-22','Overlay 22','Metrology',75,[
      ['Tool induced shift','nm',3.0,2.4,'upper',1.0,0.09,'ok']]],
    ['ELL-23','Ellipsometer 23','Metrology',150,[
      ['Lamp intensity','counts',7200,7900,'lower',11500,95,'warn']]],
    ['FTM-24','Film Thickness 24','Metrology',75,[
      ['Reference wafer deviation','nm',1.8,1.4,'upper',0.55,0.055,'ok']]]
  ];

  var DAYS=75, today=todayISO(), start=addDays(today,-(DAYS-1));
  var seed=20260915;
  function rnd(){ seed=(seed*1103515245+12345)&0x7fffffff; return seed/0x7fffffff; }
  function gauss(){ return (rnd()+rnd()+rnd()+rnd()-2)/1.2; }

  /* where the trace should finish, as a fraction of the baseline-to-limit span */
  var TARGET = { crit:1.06, warn:0.90, watch:0.55, ok:0.22 };
  var ORDER  = { crit:3, warn:2, watch:1, ok:0 };

  spec.forEach(function(row){
    var mid=row[0], mname=row[1], grp=row[2], iv=row[3], plist=row[4];

    /* A machine carrying an alarm needs enough time since its last PM for the
       drift to be visible, so those get a longer final cycle. */
    var worst = plist.reduce(function(a,b){ return ORDER[b[7]]>ORDER[a]?b[7]:a; },'ok');
    var finalGap = worst==='crit' ? 34+Math.floor(rnd()*8)
                 : worst==='warn' ? 28+Math.floor(rnd()*8)
                 : 12+Math.floor(rnd()*18);
    var cycle = Math.max(22, Math.min(iv, 30+Math.floor(rnd()*16)));
    var lastPMd = (DAYS-1) - finalGap;
    var pmDays=[];
    for(var d=lastPMd; d>=0; d-=cycle) pmDays.unshift(d);

    db.machines.push({ id:mid, name:mname, group:grp, active:true,
      pmIntervalDays:iv, pmLeadDays:10, lastPM:addDays(start,lastPMd), notes:'' });
    pmDays.forEach(function(d){
      db.pmEvents.push({ id:uid(), date:addDays(start,d), machineId:mid,
        type:'Scheduled PM', tech:'Demo', notes:'' });
    });

    plist.forEach(function(pr){
      var pn=pr[0], unit=pr[1], thr=pr[2], warn=pr[3], bound=pr[4];
      var base=pr[5], noise=pr[6], sev=pr[7];
      var pid=mid+'::'+pn;
      db.parameters.push({ id:pid, machineId:mid, name:pn, unit:unit,
        threshold:thr, warn:warn, bound:bound,
        validMin: bound==='upper'?0:thr*0.3,
        validMax: bound==='upper'?thr*4:base*2.2, notes:'' });

      /* drift per day, derived so the latest reading lands on its target */
      var slope = ((thr-base)*TARGET[sev]) / finalGap;

      for(var d2=0; d2<DAYS; d2++){
        var date=addDays(start,d2);
        var dow=new Date(date+'T00:00:00').getDay();
        if(dow===0 && rnd()<0.75) continue;    /* Sundays usually skipped */
        if(rnd()<0.035) continue;               /* occasional missed reading */
        var sincePM=d2;
        for(var k=0;k<pmDays.length;k++) if(pmDays[k]<=d2) sincePM=d2-pmDays[k];
        var v = base + slope*sincePM*(0.92+rnd()*0.16) + gauss()*noise;
        if(rnd()<0.015) v += (bound==='upper'?1:-1)*noise*3.0;   /* spike */
        v = bound==='upper' ? Math.max(v, base*0.4) : Math.min(v, base*1.45);
        db.readings.push({ date:date, paramId:pid, value:+v.toFixed(4), by:'Demo' });
      }
    });
  });
  db.meta.savedAt=new Date().toISOString();
  return db;
}
