/* ==========================================================================
   11-pmsched.js — PM schedule screen
   The countdown for a machine is always measured from its most recent logged
   PM. Logging a PM here restarts that countdown and resets the trend line, so
   the two stay in step and nothing has to be updated twice.
   ========================================================================== */

function renderPM(){
  groupChips('#pmGroups','pm');
  var ms = activeMachines().filter(function(m){
    return filterGroup.pm==='All' || m.group===filterGroup.pm;
  });
  if(!ms.length){
    $('#pmBody').innerHTML='<div class="panel"><div class="empty"><h4>No machines in this group</h4>'+
      '<p>Add machines on the Machines &amp; limits screen, then set a PM interval for each.</p></div></div>';
    return;
  }

  var rows = ms.map(function(m){
    var s=pmSchedule(m), c=pmCycles(m.id);
    var warns=c.map(function(x){ return x.reachedWarn; }).filter(function(x){ return x!=null; });
    var lens=c.filter(function(x){ return !x.open; }).map(function(x){ return x.len; });
    return { m:m, s:s, cycles:c,
      medWarn: warns.length?median(warns):null, warnN:warns.length,
      medLen: lens.length?median(lens):null,
      params: paramsOf(m.id).map(assess) };
  });
  rows.sort(function(a,b){
    if(!a.s) return 1; if(!b.s) return -1;
    return a.s.inDays-b.s.inDays;
  });

  var overdue=rows.filter(function(r){ return r.s&&r.s.overdue; });
  var due=rows.filter(function(r){ return r.s&&r.s.due&&!r.s.overdue; });
  var noSched=rows.filter(function(r){ return !r.s; });
  var done30=DB.pmEvents.filter(function(e){ return diffDays(todayISO(),e.date)<=30 && diffDays(todayISO(),e.date)>=0; });

  var h='<div class="sumbar">'+
    sumCell(overdue.length,'Overdue', overdue.length?'service now':'none', overdue.length?'crit':'ok')+
    sumCell(due.length,'Due within lead time', due.length?'schedule it':'none', due.length?'warn':'ok')+
    sumCell(rows.length-overdue.length-due.length-noSched.length,'On schedule','','ok')+
    sumCell(noSched.length,'No interval set', noSched.length?'needs setup':'all set', noSched.length?'warn':'ok')+
    sumCell(done30.length,'PM done in last 30 days','','')+
    '</div>';

  if(overdue.length) h+='<div class="alert crit"><span class="ic">&#9650;</span><div><b>'+
    overdue.length+' machine'+(overdue.length===1?' is':'s are')+' overdue for PM.</b><div class="mlist">'+
    overdue.map(function(r){ return esc(r.m.name+', '+Math.abs(r.s.inDays)+'d late'); }).join('  ·  ')+
    '</div></div></div>';
  if(due.length) h+='<div class="alert warn"><span class="ic">&#9670;</span><div><b>'+
    due.length+' machine'+(due.length===1?'':'s')+' due within the reminder window.</b><div class="mlist">'+
    due.map(function(r){ return esc(r.m.name+' on '+fmtDate(r.s.next)+', in '+r.s.inDays+'d'); }).join('  ·  ')+
    '</div></div></div>';

  h+='<div class="panel"><header><h3>Schedule</h3>'+
    '<span class="sub">countdown runs from the last logged PM · click Log PM to restart it</span></header>'+
    '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
    '<th>Machine</th><th>Group</th><th class="num">Interval</th><th class="num">Last PM</th>'+
    '<th class="num">Days since</th><th>Countdown</th><th class="num">Next due</th>'+
    '<th class="num">Typical run to warning</th><th></th></tr></thead><tbody>';

  rows.forEach(function(r){
    var m=r.m, s=r.s;
    var pct = s ? Math.max(0, Math.min(100, (diffDays(todayISO(),s.last)/m.pmIntervalDays)*100)) : 0;
    var barCol = !s ? 'var(--ink-3)' : s.overdue ? 'var(--crit)' : s.due ? 'var(--warn)' : 'var(--ok)';
    h+='<tr><td><b>'+esc(m.name)+'</b><div class="pname">'+esc(m.id)+'</div></td>'+
      '<td><span class="tag">'+esc(m.group)+'</span></td>'+
      '<td class="num">'+(m.pmIntervalDays?m.pmIntervalDays+'d':'<span style="color:var(--warn)">not set</span>')+'</td>'+
      '<td class="num">'+(s?esc(fmtShort(s.last)):'—')+'</td>'+
      '<td class="num">'+(s?diffDays(todayISO(),s.last)+'d':'—')+'</td>'+
      '<td style="min-width:120px">'+(s
        ? '<div class="bar-mini"><i style="width:'+pct+'%;background:'+barCol+'"></i></div>'+
          '<div style="font-size:11.5px;color:'+barCol+';font-weight:'+(s.due?'700':'400')+';margin-top:3px">'+
          (s.overdue?Math.abs(s.inDays)+' days overdue':s.inDays+' days remaining')+'</div>'
        : '<span style="color:var(--ink-3);font-size:13px">no schedule</span>')+'</td>'+
      '<td class="num" style="color:'+barCol+';font-weight:'+(s&&s.due?'700':'400')+'">'+(s?esc(fmtShort(s.next)):'—')+'</td>'+
      '<td class="num">'+(r.medWarn!=null&&r.warnN>=2
        ? Math.round(r.medWarn)+'d <span style="color:var(--ink-3);font-size:11.5px">('+r.warnN+' cycles)</span>'
        : '<span style="color:var(--ink-3)">—</span>')+'</td>'+
      '<td class="num"><button class="btn sm primary" data-logpm="'+esc(m.id)+'">Log PM</button> '+
      '<button class="btn sm" data-editpm="'+esc(m.id)+'">Edit</button></td></tr>';
  });
  h+='</tbody></table></div></div></div>';

  /* interval vs measured behaviour */
  var judged=rows.filter(function(r){ return r.s && r.warnN>=2; });
  if(judged.length){
    h+='<div class="panel"><header><h3>Is the interval right?</h3>'+
      '<span class="sub">your scheduled interval against how long each machine actually holds up before a parameter reaches its warn level</span></header>'+
      '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
      '<th>Machine</th><th class="num">Scheduled</th><th class="num">Measured run to warning</th>'+
      '<th class="num">Difference</th><th>Verdict</th></tr></thead><tbody>';
    judged.sort(function(a,b){ return (a.medWarn/a.m.pmIntervalDays)-(b.medWarn/b.m.pmIntervalDays); })
      .forEach(function(r){
      var ratio=r.medWarn/r.m.pmIntervalDays;
      var diff=Math.round(r.medWarn-r.m.pmIntervalDays);
      var verdict, col;
      if(ratio<0.75){ verdict='Warns well before PM is due — consider shortening to about '+
        Math.round(r.medWarn*0.8)+' days'; col='var(--warn)'; }
      else if(ratio>1.2){ verdict='Holds comfortably past the interval — could be stretched toward '+
        Math.round(r.medWarn*0.85)+' days'; col='var(--ok)'; }
      else { verdict='Interval matches how the machine behaves'; col='var(--ok)'; }
      h+='<tr><td><b>'+esc(r.m.name)+'</b></td>'+
        '<td class="num">'+r.m.pmIntervalDays+'d</td>'+
        '<td class="num">'+Math.round(r.medWarn)+'d</td>'+
        '<td class="num">'+(diff>0?'+':'')+diff+'d</td>'+
        '<td style="font-size:13px;color:'+col+'">'+verdict+'</td></tr>';
    });
    h+='</tbody></table></div></div></div>';
  } else {
    h+='<div class="note">Interval advice appears once a machine has at least two completed PM cycles '+
      'with a parameter that reached its warn level. Keep logging PM and it will fill in.</div>';
  }

  /* recent history */
  var recent=DB.pmEvents.slice().sort(function(a,b){ return a.date<b.date?1:-1; }).slice(0,25);
  if(recent.length){
    h+='<div class="panel"><header><h3>Recent PM history</h3>'+
      '<span class="sub">most recent 25 · each one restarted that machine\u2019s countdown and trend</span></header>'+
      '<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
      '<th class="num">Date</th><th>Machine</th><th>Type</th><th>Technician</th><th>Notes</th><th></th>'+
      '</tr></thead><tbody>'+
      recent.map(function(e){
        var m=machineById(e.machineId);
        return '<tr><td class="num">'+esc(fmtDate(e.date))+'</td>'+
          '<td><b>'+esc(m?m.name:e.machineId)+'</b></td>'+
          '<td>'+esc(e.type||'PM')+'</td><td>'+esc(e.tech||'—')+'</td>'+
          '<td style="color:var(--ink-2);font-size:13px">'+esc(e.notes||'')+'</td>'+
          '<td class="num"><button class="btn sm danger" data-delpm="'+esc(e.id)+'">Remove</button></td></tr>';
      }).join('')+'</tbody></table></div></div></div>';
  }

  $('#pmBody').innerHTML=h;
  $('#pmBody').querySelectorAll('[data-logpm]').forEach(function(b){
    b.onclick=function(){ pmDialog(b.dataset.logpm); };
  });
  $('#pmBody').querySelectorAll('[data-editpm]').forEach(function(b){
    b.onclick=function(){ editMachineQuick(b.dataset.editpm); };
  });
  $('#pmBody').querySelectorAll('[data-delpm]').forEach(function(b){
    b.onclick=function(){
      var e=DB.pmEvents.filter(function(x){ return x.id===b.dataset.delpm; })[0];
      if(!e) return;
      var m=machineById(e.machineId);
      if(!confirm('Remove the PM logged on '+fmtDate(e.date)+' for '+(m?m.name:e.machineId)+'?\n\n'+
        'The countdown and the trend line will fall back to the PM before it.')) return;
      DB.pmEvents=DB.pmEvents.filter(function(x){ return x.id!==b.dataset.delpm; });
      if(m) m.lastPM = lastPMOf(m.id);
      unsavedOps++; markDirty(); render();
      toast('PM removed. Countdown recalculated from the previous PM.');
    };
  });
}
