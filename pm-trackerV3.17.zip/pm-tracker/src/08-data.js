/* ==========================================================================
   08-data.js — file in/out and the Excel paste importer
   ========================================================================== */

function renderData(){
  var d=readDraft();
  var draftAge = d? Math.round((Date.now()-new Date(d.at).getTime())/60000) : null;
  var h='';

  if(dirty) h+='<div class="alert warn" style="margin-bottom:14px"><span class="ic">&#9670;</span><div><b>You have '+
    unsavedOps+' change'+(unsavedOps===1?'':'s')+' not yet written to a file.</b> '+
    'Use step 2 below before you close this tab.</div></div>';
  if(!storageOK) h+='<div class="alert crit" style="margin-bottom:14px"><span class="ic">&#9650;</span><div>'+
    '<b>This browser is not keeping a recovery draft.</b> Your work is held in memory only, '+
    'so save often.</div></div>';
  if(window.PM_AUTOLOAD_USED) h+='<div class="alert ok" style="margin-bottom:14px"><span class="ic">&#9679;</span><div>'+
    '<b>Loaded automatically from data/latest.js.</b> You did not have to open anything.</div></div>';

  /* ---------- STEP 1 ---------- */
  h+='<div class="panel"><header><h3><span class="stepn">1</span>Open your data</h3>'+
    '<span class="sub">at the start of the day</span></header><div class="body">'+
    '<div class="steprow">'+
      '<div><b>If the app already shows your machines, skip this.</b> '+
      'It loaded <code>data/latest.js</code> by itself.</div></div>'+
    '<div class="steprow"><div><b>Otherwise pick your file by hand.</b> '+
    'Choose the newest <code>pm-data-*.json</code> from the data folder — sorted by name, it is the last one.</div>'+
    '<button class="btn primary" onclick="pickFile()">Choose a data file</button></div>'+
    '</div></div>';

  /* ---------- STEP 2 ---------- */
  h+='<div class="panel"><header><h3><span class="stepn">2</span>Save your data</h3>'+
    '<span class="sub">at the end of the day, or any time the top bar turns amber</span></header><div class="body">'+
    '<div class="steprow"><div>Saving downloads <b>two</b> files to your Downloads folder:<br>'+
    '<code>pm-data-'+esc(saveStamp())+'.json</code> — your dated archive<br>'+
    '<code>latest.js</code> — the file the app opens by itself next time</div>'+
    '<button class="btn primary" onclick="saveJSON()">Save both files</button></div>'+
    '<div class="steprow"><div>Then move both into the <code>data</code> folder beside <code>index.html</code>, '+
    'replacing the old <code>latest.js</code>. '+
    'The <code>Save to data folder.bat</code> in the app folder does this move for you in one click.</div></div>'+
    '<div class="steprow"><div>Just want a copy, without changing what opens next time?</div>'+
    '<button class="btn" onclick="saveArchiveOnly()">Archive only</button></div>'+
    '<div class="steprow"><div>Weekly snapshot for the backups folder.</div>'+
    '<button class="btn" onclick="exportBackup()">Dated backup</button></div>'+
    '<div class="steprow"><div>Two CSV files that open straight in Excel — readings and PM events.</div>'+
    '<button class="btn" onclick="exportCSV()">Export to Excel</button></div>'+
    (d?'<div class="note" style="margin-top:10px">A recovery draft was written '+
      (draftAge<1?'less than a minute':draftAge+' minute'+(draftAge===1?'':'s'))+' ago. '+
      'If this tab closes unexpectedly, that draft is offered back when you reopen.</div>':'')+
    '</div></div>';

  /* ---------- STEP 3: the importer, spelled out ---------- */
  h+='<div class="panel"><header><h3><span class="stepn">3</span>Bring in data from Excel</h3>'+
    '<span class="sub">one-off, or whenever you have history to add</span></header><div class="body">'+

    '<div class="howto">'+
      '<div class="howstep"><span class="hn">A</span><div><b>Lay your sheet out like this.</b> '+
      'First column dates. Then, for each parameter, a column of readings followed by its target column. '+
      'The target column header must contain the word <b>Target</b>, <b>Limit</b> or <b>Spec</b>.</div></div>'+

      '<div class="sample"><table><tr><th>Date</th><th>SCN-01 Lens drift</th><th>Target</th>'+
      '<th>SCN-01 Stage vib</th><th>Target</th><th>DPM-11 Base pressure</th><th>Target</th></tr>'+
      '<tr><td>01/09/2026</td><td>0.92</td><td>3.5</td><td>1.81</td><td>5.0</td><td>18.4</td><td>60</td></tr>'+
      '<tr><td>02/09/2026</td><td>1.05</td><td>3.5</td><td>1.88</td><td>5.0</td><td>19.1</td><td>60</td></tr>'+
      '<tr><td>03/09/2026</td><td>1.14</td><td>3.5</td><td>1.92</td><td>5.0</td><td>20.3</td><td>60</td></tr>'+
      '</table></div>'+

      '<div class="howstep"><span class="hn">B</span><div><b>Name each reading column</b> as '+
      '<code>MACHINE Parameter</code>. Put the unit in brackets at the end if you want it picked up, '+
      'e.g. <code>DPM-11 Base pressure (mTorr)</code>. The machine name becomes the tile title, so '+
      'write <code>Dry Pump 11 Base pressure</code> if you want the full name on the board.</div></div>'+

      '<div class="howstep"><span class="hn">C</span><div><b>In Excel, select the block including the header row</b> '+
      '— click the top-left cell, then shift-click the bottom-right — and press <b>Ctrl+C</b>.</div></div>'+

      '<div class="howstep"><span class="hn">D</span><div><b>Click in the box below and press Ctrl+V.</b> '+
      'Nothing is saved yet.</div></div>'+

      '<div class="howstep"><span class="hn">E</span><div><b>Read the preview, then confirm.</b> '+
      'Check the machine and parameter names, and that a limit was found for each. '+
      'Direction is worked out for you: readings above their target are treated as lower limits.</div></div>'+
    '</div>'+

    '<textarea class="paste" id="pasteBox" placeholder="Click here and press Ctrl+V"></textarea>'+
    '<div class="toolbar" style="margin-top:12px">'+
    '<button class="btn primary" onclick="parsePaste()">Show me the preview</button>'+
    '<button class="btn" onclick="document.querySelector(\'#pasteBox\').value=\'\';cancelImport()">Clear box</button>'+
    '<span style="font-size:13px;color:var(--ink-2)">Group for new machines:</span>'+
    '<select id="pasteGroup" style="max-width:150px">'+DB.groups.map(function(g){
      return '<option>'+esc(g)+'</option>'; }).join('')+'</select>'+
    '<label style="display:flex;align-items:center;gap:7px;font-size:13px;flex:0 0 auto">'+
      '<input type="checkbox" id="pasteLower" style="width:auto;box-shadow:none"> '+
      'Columns with no target are lower-limit</label>'+
    '</div>'+
    '<div class="note" style="margin-top:10px"><b>Pasting the same block twice is safe.</b> '+
    'A reading is keyed on its date and parameter, so re-importing updates rather than duplicates.</div>'+
    '<div id="pasteResult"></div></div></div>';

  /* ---------- reset ---------- */
  h+='<div class="panel"><header><h3>Start over</h3></header><div class="body"><div class="toolbar">'+
    '<button class="btn" onclick="loadDemo()">Load demo data</button>'+
    '<button class="btn danger" onclick="wipe()">Clear everything</button></div>'+
    '<div class="note">Both replace whatever is loaded now. Save your own file first.</div></div></div>';

  $('#dataBody').innerHTML=h;
}

/* ---------- download / upload ---------- */

/* Save-file stamp: YYYY-MM-DD-HHMMSS, where HHMMSS is the time elapsed in the
   day at the moment of saving. Sorts chronologically by name in Explorer, so
   the file at the bottom of the list is always the newest. */
function saveStamp(){
  var d=new Date();
  function p(n){ return String(n).padStart(2,'0'); }
  return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+'-'+
         p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}
function download(name, text, mime){
  var b=new Blob([text],{type:mime||'application/json'});
  var u=URL.createObjectURL(b), a=document.createElement('a');
  a.href=u; a.download=name; document.body.appendChild(a); a.click();
  setTimeout(function(){ URL.revokeObjectURL(u); a.remove(); },400);
}
function saveJSON(){
  DB.meta.savedAt=new Date().toISOString();
  var stamp=saveStamp();
  var name='pm-data-'+stamp+'.json';
  DB.meta.lastFile=name;
  var body=JSON.stringify(DB,null,1);
  download(name, body);
  /* Second file: the auto-load copy. A page opened from a file path cannot read
     a folder, but it CAN load a script. Dropping this in data/ makes the app
     open with your data already in it. */
  setTimeout(function(){
    download('latest.js',
      '/* PM Tracker auto-load file. Saved '+stamp+'.\n'+
      '   Put this in the data folder beside index.html. Overwrite the old one. */\n'+
      'window.PM_AUTOLOAD = '+body+';\n');
  },500);
  markClean(); clearDraft(); render();
  toast('Two files saved: pm-data-'+stamp+'.json (your archive) and latest.js (auto-load). '+
        'Put both in the data folder.');
}
/* save without the auto-load copy, for a one-off export */
function saveArchiveOnly(){
  DB.meta.savedAt=new Date().toISOString();
  var name='pm-data-'+saveStamp()+'.json';
  download(name, JSON.stringify(DB,null,1));
  markClean(); clearDraft(); render();
  toast('Saved '+name+'.');
}
function exportBackup(){
  DB.meta.savedAt=new Date().toISOString();
  download('pm-backup-'+saveStamp()+'.json', JSON.stringify(DB,null,1));
  toast('Backup saved. Keep these in data/backups on the share.');
}
function exportCSV(){
  var rows=[['date','machine','parameter','value','unit','limit','bound','status','entered_by']];
  DB.readings.slice().sort(function(a,b){ return a.date<b.date?-1:1; }).forEach(function(r){
    var p=DB.parameters.filter(function(x){ return x.id===r.paramId; })[0];
    if(!p) return;
    var m=machineById(p.machineId);
    rows.push([r.date, m?m.name:p.machineId, p.name, r.value, p.unit||'', p.threshold, p.bound,
      statusOf(p,r.value), r.by||'']);
  });
  var pm=[['date','machine','type','technician','notes']].concat(
    DB.pmEvents.slice().sort(function(a,b){ return a.date<b.date?-1:1; }).map(function(e){
      var m=machineById(e.machineId);
      return [e.date, m?m.name:e.machineId, e.type||'PM', e.tech||'', e.notes||''];
    }));
  function csv(a){
    return a.map(function(r){
      return r.map(function(c){
        var s=String(c==null?'':c);
        return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
      }).join(',');
    }).join('\r\n');
  }
  var st=saveStamp();
  download('pm-readings-'+st+'.csv', csv(rows),'text/csv');
  setTimeout(function(){ download('pm-events-'+st+'.csv', csv(pm),'text/csv'); },600);
  toast('Two CSV files saved: readings and PM events. Both open directly in Excel.');
}
function pickFile(){
  var inp=$('#fileInput'); inp.value='';
  inp.onchange=function(){
    var f=inp.files[0]; if(!f) return;
    var r=new FileReader();
    r.onerror=function(){ toast('Could not read that file.',true); };
    r.onload=function(){
      try{
        var db=migrate(JSON.parse(r.result));
        var issues=integrity(db);
        if(db._newerSchema){
          issues.unshift('this file was saved by a newer version of PM Tracker (format '+
            db._newerSchema+', this app understands '+SCHEMA+
            ') — update the app before relying on it');
        }
        DB=db; entryDraft={}; markClean(); clearDraft(); render();
        if(issues.length) toast('Loaded, but with '+issues.length+' data issue'+(issues.length===1?'':'s')+': '+issues.join('; '), true);
        else toast('Loaded '+DB.readings.length.toLocaleString()+' readings across '+DB.machines.length+' machines.');
      }catch(e){
        toast('That file could not be read as PM Tracker data. '+e.message, true);
      }
    };
    r.readAsText(f);
  };
  inp.click();
}
function loadDemo(){
  if(dirty && !confirm('You have unsaved changes. Loading the demo will discard them. Continue?')) return;
  DB=demoDB(); entryDraft={}; markClean(); clearDraft(); show('board');
  toast('Demo data loaded — 16 machines, 23 parameters, 75 days of history.');
}
function wipe(){
  if(!confirm('Delete every machine, parameter and reading currently loaded?\n\nSave your data file first if you need it.')) return;
  DB=blankDB(); entryDraft={}; markClean(); clearDraft(); show('config');
  toast('Cleared. Add machines or load a file to begin.');
}

/* ---------- Excel paste importer ---------- */
function cleanNum(s){
  if(s==null) return NaN;
  s=String(s).trim().replace(/[\u00A0\s]/g,'').replace(/,/g,'').replace(/%$/,'');
  if(s===''||s==='-'||/^n\/?a$/i.test(s)) return NaN;
  return parseFloat(s);
}
function parseDateCell(s){
  s=String(s).trim(); if(!s) return null;
  if(/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
  var m=s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if(m){
    var a=+m[1], b=+m[2], y=+m[3];
    if(y<100) y+=2000;
    var mo=a, d=b;
    if(mo>12){ mo=b; d=a; }
    return y+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
  }
  var dt=new Date(s);
  if(!isNaN(dt)) return dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');
  return null;
}
function isTargetCol(h){ return /target|limit|spec|threshold|usl|lsl|ctrl|max$|min$/i.test(h); }

var pendingImport=null;

function parsePaste(){
  var raw=$('#pasteBox').value;
  if(!raw.trim()) return toast('Paste your copied cells into the box first.',true);
  var lines=raw.replace(/\r/g,'').split('\n').filter(function(l){ return l.trim()!==''; });
  if(lines.length<2) return toast('That looks like only one row. Include the header row and at least one data row.',true);

  var delim = lines[0].indexOf('\t')>=0 ? '\t'
    : (lines[0].split(',').length > lines[0].split(';').length ? ',' : ';');
  var cells = lines.map(function(l){
    return l.split(delim).map(function(c){ return c.trim().replace(/^"|"$/g,''); });
  });
  var head=cells[0];
  var lowerBound=$('#pasteLower').checked;
  var grp=$('#pasteGroup').value;

  /* pair each value column with the target column that follows it */
  var cols=[];
  for(var i=1;i<head.length;i++){
    if(!head[i] || isTargetCol(head[i])) continue;
    var tIdx = (i+1<head.length && isTargetCol(head[i+1])) ? i+1 : null;
    cols.push({ i:i, tIdx:tIdx, label:head[i] });
  }
  if(!cols.length) return toast('No parameter columns found. First column should be the date, and each later column needs a header.',true);

  /* split "MACHINE parameter" — machine token is the leading code-like word */
  cols.forEach(function(c){
    var L=c.label.replace(/\s+/g,' ').trim();
    var m=L.match(/^([A-Za-z]{2,6}[-_ ]?\d{1,3})\s*[-\u2013:|]?\s*(.+)$/);
    if(m){ c.machine=m[1].trim(); c.param=m[2].trim(); }
    else {
      var parts=L.split(/\s+[-\u2013|:]\s+/);
      if(parts.length>1){ c.machine=parts[0].trim(); c.param=parts.slice(1).join(' - ').trim(); }
      else {
        var w=L.split(' ');
        if(w.length>1){ c.machine=w[0]; c.param=w.slice(1).join(' '); }
        else { c.machine=L; c.param=L; }   /* single word: it is both */
      }
    }
    var u=c.param.match(/\(([^)]{1,10})\)\s*$/);
    if(u){ c.unit=u[1]; c.param=c.param.replace(/\s*\([^)]*\)\s*$/,'').trim(); } else c.unit='';
  });

  var readings=[], targets={}, badDates=[], badVals=[];
  for(var r=1;r<cells.length;r++){
    var d=parseDateCell(cells[r][0]);
    if(!d){ badDates.push(cells[r][0]); continue; }
    /* eslint-disable no-loop-func */
    (function(row,date){
      cols.forEach(function(c){
        var v=cleanNum(row[c.i]);
        if(isFinite(v)) readings.push({ date:date, col:c, value:v });
        else if((row[c.i]||'').trim()!=='') badVals.push(row[c.i]);
        if(c.tIdx!=null){
          var t=cleanNum(row[c.tIdx]);
          if(isFinite(t)) (targets[c.label]=targets[c.label]||[]).push(t);
        }
      });
    })(cells[r], d);
  }
  if(!readings.length) return toast('No numeric readings found. Check the first column really holds dates.',true);

  var machines={};
  cols.forEach(function(c){
    var mid=c.machine.toUpperCase().replace(/\s+/g,'-');
    var existing = machineById(mid) || DB.machines.filter(function(m){
      return m.name.toLowerCase()===c.machine.toLowerCase(); })[0];
    c.mid = existing?existing.id:mid;
    if(!existing) machines[c.mid]={ id:c.mid, name:c.machine, group:grp };
    var t=targets[c.label];
    c.threshold = (t&&t.length)?median(t):null;
    /* Direction is readable from the data: if the readings sit above the
       target, the reading must be falling toward it, so it is a lower limit.
       The checkbox is only a fallback for columns with no target. */
    var vals=readings.filter(function(r){ return r.col===c; }).map(function(r){ return r.value; });
    c.med = vals.length?median(vals):null;
    c.bound = (c.threshold!=null && c.med!=null)
      ? (c.med > c.threshold ? 'lower' : 'upper')
      : (lowerBound ? 'lower' : 'upper');
    c.autoBound = (c.threshold!=null && c.med!=null);
    c.pid=c.mid+'::'+c.param;
    var ep=DB.parameters.filter(function(p){ return p.id===c.pid; })[0];
    c.existingParam=!!ep;
    if(ep && c.threshold==null) c.threshold=ep.threshold;
  });
  var dset={}; readings.forEach(function(r){ dset[r.date]=1; });
  var dates=Object.keys(dset).sort();
  var noThr=cols.filter(function(c){ return c.threshold==null; });
  pendingImport={ cols:cols, readings:readings, machines:machines, lowerBound:lowerBound };

  var h='<div class="panel" style="margin-top:16px"><header><h3>Preview</h3>'+
    '<span class="sub">nothing is saved until you confirm</span></header><div class="body">';
  h+='<div class="alert '+(noThr.length?'warn':'info')+'"><span class="ic">'+(noThr.length?'&#9670;':'&#9679;')+'</span><div>'+
    '<b>'+readings.length.toLocaleString()+' readings across '+cols.length+' parameters and '+
    Object.keys(machines).length+' new machines.</b><div class="mlist">'+
    esc(fmtDate(dates[0]))+' to '+esc(fmtDate(dates[dates.length-1]))+' · '+dates.length+' distinct dates'+
    (badDates.length?' · '+badDates.length+' row'+(badDates.length===1?'':'s')+' skipped, unreadable date':'')+
    (badVals.length?' · '+badVals.length+' cell'+(badVals.length===1?'':'s')+' skipped, not a number':'')+
    '</div></div></div>';
  if(noThr.length) h+='<div class="note" style="margin-top:10px">'+noThr.length+' parameter'+
    (noThr.length===1?' has':'s have')+' no target column beside it. '+(noThr.length===1?'It':'They')+
    ' will be created with a placeholder limit — set the real one on the Machines &amp; limits screen '+
    'before relying on the alerts.</div>';
  h+='<div class="tblwrap" style="margin-top:12px;max-height:340px;overflow-y:auto"><table class="tbl"><thead><tr>'+
    '<th>Column header</th><th>Machine</th><th>Parameter</th><th class="num">Unit</th>'+
    '<th class="num">Limit found</th><th>Direction</th><th class="num">Readings</th><th>Action</th></tr></thead><tbody>';
  cols.forEach(function(c){
    var n=readings.filter(function(r){ return r.col===c; }).length;
    h+='<tr><td style="font-family:Consolas,monospace;font-size:12.5px">'+esc(c.label)+'</td>'+
      '<td><b>'+esc(c.machine)+'</b></td><td>'+esc(c.param)+'</td>'+
      '<td class="num">'+esc(c.unit||'—')+'</td>'+
      '<td class="num">'+(c.threshold!=null?'<b>'+esc(num(c.threshold))+'</b>'
        :'<span style="color:var(--warn);font-weight:600">none</span>')+'</td>'+
      '<td style="font-size:12.5px">'+
        (c.bound==='lower'?'<b>falls toward limit</b>':'rises toward limit')+
        (c.autoBound?'':'<div style="color:var(--warn);font-size:11.5px">guessed, no target column</div>')+'</td>'+
      '<td class="num">'+n+'</td>'+
      '<td style="font-size:13px">'+(c.existingParam?'<span style="color:var(--ink-2)">merge into existing</span>'
        :'<span style="color:var(--ok);font-weight:600">create new</span>')+'</td></tr>';
  });
  h+='</tbody></table></div><div class="toolbar" style="margin-top:14px">'+
    '<button class="btn primary" onclick="commitImport()">Import these '+readings.length.toLocaleString()+' readings</button>'+
    '<button class="btn" onclick="cancelImport()">Cancel</button>'+
    '<span style="font-size:13px;color:var(--ink-2)">If a machine or parameter name looks wrong, '+
    'fix the header in Excel and paste again.</span></div></div></div>';
  $('#pasteResult').innerHTML=h;
  $('#pasteResult').scrollIntoView({behavior:'smooth',block:'nearest'});
}
function cancelImport(){ pendingImport=null; $('#pasteResult').innerHTML=''; }

function commitImport(){
  if(!pendingImport) return;
  var cols=pendingImport.cols, readings=pendingImport.readings;
  var machines=pendingImport.machines;

  Object.keys(machines).forEach(function(k){
    var m=machines[k];
    if(machineById(m.id)) return;
    DB.machines.push({ id:m.id, name:m.name, group:m.group, active:true,
      pmIntervalDays:90, pmLeadDays:10, lastPM:null, notes:'' });
  });
  cols.forEach(function(c){
    if(DB.parameters.some(function(p){ return p.id===c.pid; })) return;
    var med = c.med!=null ? c.med : 0;
    var lb = c.bound==='lower';
    var thr=c.threshold;
    if(thr==null) thr = lb ? med*0.6 : med*1.6;
    DB.parameters.push({ id:c.pid, machineId:c.mid, name:c.param, unit:c.unit||'',
      threshold:thr, warn: med+(thr-med)*0.8, bound: c.bound,
      validMin: lb?thr*0.3:0, validMax: lb?med*2.2:thr*4, notes:'' });
  });
  var added=0, updated=0;
  readings.forEach(function(r){
    var ex=DB.readings.filter(function(x){ return x.date===r.date && x.paramId===r.col.pid; })[0];
    if(ex){ ex.value=r.value; updated++; }
    else { DB.readings.push({ date:r.date, paramId:r.col.pid, value:r.value, by:'Excel import' }); added++; }
  });
  pendingImport=null; $('#pasteBox').value=''; $('#pasteResult').innerHTML='';
  unsavedOps+=added+updated; markDirty(); show('board');
  toast('Imported '+added.toLocaleString()+' readings'+(updated?' and updated '+updated:'')+
    '. Check the limits on Machines & limits, then save the data file.');
}
