/* ==========================================================================
   10-boot.js — startup. Loaded last.
   ========================================================================== */

function boot(){
  storageOK = testStorage();
  loadSettings();

  var tp=$('#themePick');
  if(tp){ tp.value=SETTINGS.theme; tp.onchange=function(){ setSetting('theme',tp.value); }; }
  var bw=$('#boardWindow');
  if(bw){ bw.value=String(SETTINGS.window); bw.onchange=function(){ setSetting('window',+bw.value); }; }
  var db=$('#displayBtn');
  if(db) db.onclick=displayMenu;

  $('#nav').onclick = function(e){
    var b=e.target.closest('button[data-screen]');
    if(b) show(b.dataset.screen);
  };
  $('#entrySave').onclick = saveEntry;
  var eu=$('#entryUndo');
  if(eu) eu.onclick = undoLastBatch;
  $('#entryClear').onclick = function(){
    entryDraft={}; saveDraft(); renderEntry();
    toast('Form cleared. Nothing already saved was removed.');
  };
  $('#quickSave').onclick = saveJSON;

  /* 1. a file dropped in data/latest.js wins — nothing to click */
  if(window.PM_AUTOLOAD && typeof window.PM_AUTOLOAD==='object'){
    try{
      DB = migrate(window.PM_AUTOLOAD);
      window.PM_AUTOLOAD_USED = true;
      markClean(); render(); show('board');
      var iss = integrity(DB);
      if(DB._newerSchema) iss.unshift('saved by a newer version of PM Tracker (format '+
        DB._newerSchema+', this app understands '+SCHEMA+') — update the app');
      setTimeout(function(){
        toast(iss.length
          ? 'Loaded from data/latest.js with '+iss.length+' data issue'+(iss.length===1?'':'s')+': '+iss.join('; ')
          : 'Loaded '+DB.readings.length.toLocaleString()+' readings automatically from data/latest.js.', iss.length>0);
      },600);
      return;
    }catch(e){
      setTimeout(function(){ toast('data/latest.js could not be read: '+e.message,true); },600);
    }
  }

  var d = readDraft();
  if(d && d.db && (d.db.readings||[]).length){
    var when = new Date(d.at).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
    DB = blankDB();
    render();
    setTimeout(function(){
      modal('Unsaved work found',
        '<p style="margin-bottom:12px">A recovery draft from <b>'+esc(when)+'</b> is still in this browser, '+
        'holding '+d.db.readings.length.toLocaleString()+' readings across '+(d.db.machines||[]).length+' machines.</p>'+
        '<p>This happens when the tab closed before the data file was saved. Restore it, or discard it and '+
        'load your file from the shared folder instead.</p>',
        function(){
          DB=migrate(d.db); dirty=true; unsavedOps=1; render();
          toast('Draft restored. Save the data file now so it is not lost again.');
        },
        'Restore this draft');
      $('#mCancel').textContent='Discard draft';
      $('#mCancel').onclick=function(){
        clearDraft(); $('#modalHost').innerHTML=''; DB=demoDB(); DB.meta.isDemo=true; render();
      };
    },300);
  } else {
    DB = demoDB();
    DB.meta.isDemo = true;
    setTimeout(function(){
      toast('Showing demo data so you can explore. Load your own file, or paste your Excel grid, from "Save, load & import".');
    },800);
  }
  show('board');
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
