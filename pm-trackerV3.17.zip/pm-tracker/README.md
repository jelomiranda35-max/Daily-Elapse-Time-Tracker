# PM Tracker

A single-screen status board for preventive-maintenance parameter monitoring.
Replaces the Excel chart sheet and the screenshot-to-the-team routine.

No installation, no dependencies, no build step, no server. Plain HTML, CSS and
JavaScript. You run it by double-clicking a file.

---

## Contents

1. [What it does](#what-it-does)
2. [Install](#install)
3. [The shortcut and auto-loading](#the-shortcut-and-auto-loading)
4. [Daily routine](#daily-routine)
5. [Reading the board](#reading-the-board)
6. [Customising the board](#customising-the-board)
7. [Controlling what the charts show](#controlling-what-the-charts-show)
8. [Themes](#themes)
8. [Editing limits and PM from a tile](#editing-limits-and-pm-from-a-tile)
9. [Entering readings, and undoing them](#entering-readings-and-undoing-them)
10. [How PM works](#how-pm-works)
11. [Importing from Excel](#importing-from-excel)
12. [Saving and file naming](#saving-and-file-naming)
13. [Capacity](#capacity)
14. [Repository layout](#repository-layout)
15. [Updating the app](#updating-the-app)
16. [Privacy](#privacy)
17. [Troubleshooting](#troubleshooting)
18. [Design notes](#design-notes)

---

## What it does

| Screen | Purpose |
|---|---|
| **Status board** | One tile per machine, all on one screen, built to be screenshotted |
| **Log readings** | Daily entry with yesterday's value beside each field, undo and revert |
| **Trend charts** | Full-size charts with axes, limit lines and PM markers |
| **PM schedule** | Every machine's countdown, and whether your intervals match reality |
| **Analysis** | Risk ranking, machines accelerating against their own normal |
| **Machine detail** | Full history for one machine across every PM cycle |
| **Monthly report** | Breaches, PM completed, month-on-month movement, print-ready |
| **Machines & limits** | Setup |
| **Save, load & import** | Three numbered steps, including the Excel paste guide |

---

## Install

No admin rights and nothing to install.

1. On the GitHub repo page: **Code → Download ZIP**
2. Right-click the ZIP → **Extract All**
3. Copy the `pm-tracker` folder to your shared folder, e.g. `\\PC-ENG-01\shared\pm-tracker\`
4. Double-click **`Open PM Tracker.bat`**

That is the whole install. Everyone else opens the same folder over the network.

> **If the board loads but nothing renders,** group policy is blocking scripts
> from a network location. Copy the folder to `C:\PM-Tracker\` on each PC instead.
> Everything still works; only updates become more manual.

---

## The shortcut and auto-loading

**Right-click `Open PM Tracker.bat` → Send to → Desktop (create shortcut).** Rename
it "PM Tracker". One click from then on.

The launcher does two things before opening the app:

1. Moves any `latest.js` and `pm-data-*.json` sitting in your Downloads folder into
   `data\`, so you never drag files by hand
2. Opens `index.html`, which loads `data\latest.js` and comes up **with your data
   already in it** — no file picker, no clicking

### Why it works this way

A browser opened from a file path cannot read a folder. `fetch()` is blocked, and
there is no directory listing. That is a security boundary in Chrome and Edge, not
something the app can switch off.

What a browser *can* do is load a script. So saving produces two files:

| File | What it is |
|---|---|
| `pm-data-2026-09-16-143052.json` | Your dated archive. Never overwritten. |
| `latest.js` | The same data wrapped as `window.PM_AUTOLOAD = {...}` |

`index.html` has `<script src="data/latest.js">` at the top. If the file is there,
the app opens with your data loaded. If it is missing or damaged, the app says so
and carries on — it never blocks startup.

If you prefer not to use the `.bat`, open `index.html` directly and move the two
downloaded files into `data\` yourself. Same result, one more step.

---

## Daily routine

1. **Click the PM Tracker shortcut.** Your data is already loaded.
2. **Log readings.** Check the date, type your initials, work down the list.
   Tick **PM done** on any machine serviced today.
3. **Save these readings.**
4. **Save data file** (top-right). Two files land in Downloads.
5. **Status board → Screenshot view →** <kbd>Win</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd>
   → send it to the team. Press <kbd>Esc</kbd> or the round **✕** to come back.
6. Next time you use the shortcut, the launcher files those two downloads for you.

The pill at the top-left turns amber with a count whenever you have unsaved work,
and does not clear until you save.

---

## Reading the board

| What you see | What it means |
|---|---|
| Green spine, "Normal" | Comfortable margin |
| Amber spine, "Warning" | Past the warn level — plan work |
| Red spine, "At limit" | Reached the limit — act now |
| Grey band on the chart | The normal range. The line leaving it is the signal |
| Red dashed line | The limit it must not reach |
| Small blue flag | A PM event. The trend restarts there |
| Boxed number at the right | The most recent reading |
| Dates along the bottom | Every 6 days |
| "6d left" | Days to the limit at the current rate |
| "119% of limit" | How far it has travelled from healthy baseline to limit |
| "PM reset" | Serviced recently; not enough new readings to call a trend yet |

When several alerts are active they collapse to one summary line. **Show detail**
expands them.

---

## Customising the board

All of this lives in the toolbar above the board and is remembered per PC.

- **Columns** — Auto, or force 2 to 6. Auto fits to the window.
- **Chart size** — S, M, L, XL. L and XL add value gridlines to the chart.
  At S, a machine with two parameters shows one chart and one summary line;
  at M and above, every parameter gets its own chart.
- **Days** — 30, 45, 60, 90 or all history drawn on each tile.
- **Chart content** — a three-tab panel controlling what is drawn inside each
  chart, what sits around it, and which parameters appear at all. See
  [Controlling what the charts show](#controlling-what-the-charts-show).
- **Sort** — by risk, name or group.
- **Group chips** — Photo / Vacuum / Metrology, or all.

**Screenshot view** hides every control, goes fullscreen, and scales the board so
the whole fleet fills one screen with no scrolling. Verified at 1280×720, 1366×768
and 1920×1080 — 99% of the panel height in each case, with 16 machines.

---

## Controlling what the charts show

**Chart content** in the board toolbar. Three tabs, all remembered per PC, and all
applying to the board *and* the Trend charts screen.

### Inside the chart

| Option | Effect |
|---|---|
| Grey normal-range band | The shaded region from healthy baseline to warn level |
| Limit line | Red dashed |
| Warn line | Amber dashed |
| Value label | The boxed number on the most recent reading |
| PM markers | Blue flags, and the break in the line at each PM |
| Dots | Marks on out-of-range readings |
| Projection | Dashed run-out to where the trend meets the limit |

### Vertical scale — the one that matters

| Mode | What it does |
|---|---|
| **Always show the limit** | Default. The limit is always on screen. |
| **Fit the readings** | Scales to the data only. |
| **Start at zero** | Anchors the bottom at zero. |

Default keeps the limit visible, which is safest but squashes the trace flat when a
machine sits far from its limit — a real 5% drift can look like a dead straight
line. **Fit the readings** magnifies it: in testing, the same gentle drift rendered
over 3× more vertical travel.

The trade-off is that the limit can then fall outside the chart. Rather than let a
missing red line read as a safe one, any chart in that state prints **limit
off-chart** in red. Verified: in *Always show the limit* mode that label never
appears; in *Fit the readings* it appears whenever the limit is out of range.

### Which parameters

Hide any parameter from the board and the trend charts. Readings are kept and it
still appears in the monthly report and machine detail — it is only left off the
visual board. Useful when one parameter is noisy or under investigation and you do
not want it dominating the screenshot.

### Around the chart

Progress bar, PM footer strip, and the summary figures above the board — the same
three toggles as before, for fitting more machines into one screenshot.

---

## Themes

Top-right dropdown. Remembered per PC.

| Theme | Use it for |
|---|---|
| **Light** | Default. Best for screenshots pasted into email or chat |
| **Slate** | Cooler and slightly darker; easier on the eyes over a long shift |
| **Warm** | Softer paper tone, less glare under fluorescent light |
| **Dark** | Dim rooms and wall-mounted displays |
| **High contrast** | Pure black on white, heavy borders, no shadows — for projectors, poor monitors, or anyone who finds the others hard to read |

Every theme keeps the same rule: grey structure, colour reserved for alarm state.

---

## Editing limits and PM from a tile

Each tile has a small **✎** in its corner. It opens one panel holding everything
for that machine:

- **Warn level** and **limit** for each parameter
- **Direction** — whether the reading rises or falls toward its limit
- **PM interval**, **reminder lead time**, **last PM date**
- A **Log a PM as done on [date]** checkbox

Changes take effect immediately. Lowering a warn level can move a machine straight
into warning, which is the point.

The same panel is reachable from the **Edit** button on any PM schedule row.

---

## Entering readings, and undoing them

Yesterday's value sits beside each field. Fields turn amber past the warn level and
red at the limit. "Below/above expected range" means check your decimal point — the
value still saves, because a real spike must be recordable.

Four ways to correct a mistake:

| Situation | What to use |
|---|---|
| Typed the wrong number, not saved yet | Just retype it |
| Changed a value that was already saved | **Revert** appears on that row — puts the saved value back |
| A saved reading should not exist at all | **Undo** on that row — deletes just that reading |
| The whole batch you just saved was wrong | **Undo last save** — rolls back every reading *and* any PM logged with it |

A green **saved** tag marks any field already stored for that date.

---

## How PM works

This is the part that makes the tool better than a spreadsheet, so it is worth
understanding.

**Logging a PM does two things at once:**

1. **Restarts the countdown.** Next due becomes the PM date plus the interval. A
   machine that was 3 days from due goes back to a full interval.
2. **Resets the trend.** Every derived number — slope, projection, "days left" —
   is computed only on readings *since* the last PM.

That second point matters. If a trend line were fitted across a PM reset, the rise
before and the drop after would average into a falsely flat, reassuring slope. The
app never crosses a PM boundary when fitting a trend.

**Immediately after a PM** there are not enough new readings to fit a line, so the
tile shows **"PM reset"** and the trend reads **"Rebuilding after PM"** rather than
a number. It fills in after about three readings.

> This was a real bug caught in QA: an earlier version fell back to full history
> when the post-PM segment was short, so a machine serviced yesterday showed its
> *pre-PM* rising trend and a "3 days to limit" warning. It now reports honestly
> that it does not know yet.

**You can log a PM from four places** — the tick box on the entry screen, the tile
edit panel, the PM schedule screen, or Machines & limits. All four are equivalent.

**Backdating is supported everywhere.** Someone will forget to tick the box and
realise three days later; if the only way to log it were on the day, they would skip
it and the data would rot.

**The PM schedule screen** compares your scheduled interval against how long each
machine actually holds up before a parameter reaches its warn level, across every
recorded cycle. After a few cycles it will tell you plainly whether an interval
should be shortened or could be stretched. That is preventive maintenance answering
its own central question with your own data.

---

## Importing from Excel

**Save, load & import → step 3.** The screen walks through it with a worked example;
this is the same thing in text.

Your sheet should look like this — the layout you already use:

| Date | SCN-01 Lens drift | Target | SCN-01 Stage vib | Target | DPM-11 Base pressure | Target |
|---|---|---|---|---|---|---|
| 01/09/2026 | 0.92 | 3.5 | 1.81 | 5.0 | 18.4 | 60 |
| 02/09/2026 | 1.05 | 3.5 | 1.88 | 5.0 | 19.1 | 60 |

Rules:

- **First column is the date.** `2026-09-01`, `01/09/2026` and `1/9/26` all work.
- **Each reading column is followed by its target column.** The target header must
  contain `Target`, `Limit` or `Spec`.
- **Name reading columns `MACHINE Parameter`.** The machine part becomes the tile
  title, so write `Dry Pump 11 Base pressure` if you want the full name on the board
  rather than `DPM-11`.
- **Units go in brackets at the end**: `Base pressure (mTorr)`.

Then: select the block including the header row, **Ctrl+C**, click the box in the
app, **Ctrl+V**, and read the preview before confirming.

**Direction is detected for you.** If a column's readings sit above its target, the
reading must be falling toward it, so it is treated as a lower limit. One paste can
mix rising and falling parameters. The preview shows what was decided for each.

**Pasting twice is safe.** A reading is keyed on date plus parameter, so
re-importing updates rather than duplicates.

Handled without complaint: thousands separators (`11,420`), percent signs, blank
cells, `N/A`, ragged rows, missing target columns, comma- or semicolon-separated
text, and unicode in headers.

---

## Saving and file naming

```
pm-data-2026-09-16-143052.json
        └── date ──┘ └HHMMSS┘
```

`HHMMSS` is the time of day at the moment of saving. Nothing is ever silently
overwritten, and sorting the folder by name puts the newest file last.

| Button | Produces |
|---|---|
| **Save both files** | The dated archive **and** `latest.js` for auto-load |
| **Archive only** | Just the dated file; does not change what opens next time |
| **Dated backup** | `pm-backup-*.json` for `data/backups/` |
| **Export to Excel** | Two CSVs — readings and PM events — that open directly in Excel |

---

## Capacity

Measured, not estimated:

| History | Readings | File size | Slowest screen |
|---|---|---|---|
| 1 year | 6,800 | 0.6 MB | 56 ms |
| 5 years | 34,000 | 2.9 MB | 58 ms |
| 10 years | 68,000 | 5.8 MB | 93 ms |
| 20 years | 137,000 | 11.6 MB | 161 ms |

Speed is not the limit. The limit is the crash-recovery draft, which lives in
browser storage capped at about 5 MB. Past that the app works normally but can no
longer hold unsaved work if the tab closes, and it warns you when that happens.

For 30 machines and roughly 45 parameters, that arrives at about **four years** of
daily readings.

**Archive yearly past year three.** Copy the current file into `data/backups/`, then
delete readings older than three years from the working file. Nothing on the board
changes — trends and PM statistics only look at the current cycle.

---

## Repository layout

```
pm-tracker/
├── index.html                 The application. Open this to run.
├── Open PM Tracker.bat        Launcher: files your downloads, then opens the app.
├── README.md                  This file.
├── .gitignore                 Keeps real data out of the public repo.
│
├── assets/
│   ├── styles.css             All styling, including the five themes.
│   └── favicon.svg            Tab icon.
│
├── src/                       Loaded in numeric order by index.html.
│   ├── 01-core.js             State, settings, themes, storage, dates, migration.
│   ├── 02-analysis.js         Status, trend, projection, anomaly, risk, PM cycles.
│   ├── 03-charts.js           All SVG drawing.
│   ├── 04-board.js            Router, status board, tile edit, screenshot mode.
│   ├── 05-entry.js            Reading entry, undo and revert, trend charts.
│   ├── 06-reports.js          Analysis, machine detail, monthly report.
│   ├── 07-config.js           Machine and parameter setup, dialogs.
│   ├── 08-data.js             Save, load, CSV export, Excel importer.
│   ├── 09-demo.js             Sample dataset. Safe to delete once live.
│   ├── 10-boot.js             Startup, auto-load, draft recovery.
│   └── 11-pmsched.js          PM schedule screen.
│
├── data/                      Your real data. NOT in the repo.
│   ├── latest.js              Auto-load file. Replaced on every save.
│   ├── pm-data-*.json         Dated archives, newest last by name.
│   ├── backups/               Weekly snapshots.
│   └── config.example.json    Shape reference only. Safe to commit.
│
└── docs/
    ├── INSTALL.md             Team setup, step by step.
    ├── DAILY-USE.md           One page to print and pin up.
    └── RECOVERY.md            If it breaks, how to get your data out.
```

The number prefixes in `src/` are **load order, not decoration**. These are classic
scripts, not ES modules, because ES modules fail on a `file://` path. Keep the
prefixes, and add new files in sequence in both `src/` and the `<script>` list at
the bottom of `index.html`.

---

## Updating the app

You do this; nobody else needs to touch it.

```bash
git pull
```

Then copy `index.html`, `assets/`, `src/` and the `.bat` into the shared folder,
replacing what is there. **Never touch `data/`** — that is everyone's readings, and
it is not in the repo. Users get the update on their next refresh.

---

## Privacy

The code is public; the data is not. `.gitignore` excludes `data/`, all `*.csv`, and
any `pm-data-*.json`, `pm-backup-*.json` and `latest.js`.

A file committed once stays in git history even after deletion, so check
`git status` before your first push.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Blank or unstyled page | Scripts blocked from the network path. Copy the folder to `C:\PM-Tracker\`. |
| App opens with demo data, not mine | `data\latest.js` is missing. Run the `.bat`, or save once and move the file in. |
| "latest.js could not be read" | The file is damaged. Load a `pm-data-*.json` by hand, then save again. |
| Amber pill will not clear | Click **Save data file**. |
| Closed the tab before saving | Reopen — it offers to restore your work. |
| Reading typed wrong | Re-enter it on the same date, or use **Undo** on that row. |
| Chart flat but the value is climbing | Check whether a PM reset it. The trend restarts at every PM. |
| Trend says "Rebuilding after PM" | Correct behaviour. Needs about three readings since the PM. |
| Machine disappeared | It may be retired. Machines & limits → edit → Active. |
| Screenshot view too small | Turn off tile content you do not need, or reduce Chart size. |

`docs/RECOVERY.md` covers getting your data out without the app at all.

---

## Design notes

Three sources shaped the board, and knowing them makes the choices easier to change:

**ISA-101 high-performance HMI.** An overview screen should carry 15–25 equipment
items and no more, on a grey base, with colour reserved strictly for alarm state.
That is why the tiles are neutral until something is wrong. It also warns about
designing on a large monitor and deploying on a 1366×768 panel, which is why fit is
verified at that size.

**Tufte's small multiples.** Identical tiles at the same scale, arranged in a grid,
so the eye compares shapes instead of reading fourteen separate charts. The grey
normal-range band comes from his clinical sparklines: a deviation registers without
anyone parsing an axis.

**Gaps are drawn as gaps.** A missed reading leaves a break in the line rather than
a straight segment across it, and so does a PM. Interpolating either would invent
data.

### Testing

`tests/` holds five suites — **212 assertions** — run against a real headless
Chrome. See `tests/README.md` for how to run them and a table of the bugs they
have caught.

| Suite | Assertions | Covers |
|---|---|---|
| `01-unit.js` | 91 | Dates across DST and year boundaries, status logic at exact thresholds, projection, slope, save/load round trip, migration, integrity checks, PM cycle maths, month boundaries, importer parsing, HTML escaping |
| `02-features.js` | 63 | Every screen and feature, in three themes, and against an empty database |
| `03-chart-controls.js` | 19 | Every chart toggle, all three scale modes, parameter visibility, settings persistence |
| `04-edge-cases.js` | 25 | Separator collisions in names, zero variance, zero and negative limits, future dates, retired machines, corrupt settings, duplicate headers, 160-character names, empty boards |
| `05-regressions.js` | 14 | Guards on bugs already found and fixed |

Two suites deliberately run outside UTC — `America/New_York` for daylight saving,
`Pacific/Chatham` for a +12:45 offset — because UTC hides a whole class of date
bug.

The two most serious bugs found so far were the post-PM trend fallback described
under [How PM works](#how-pm-works), and an empty-state bug where viewing the board
with no data destroyed its markup, so a later import threw and left the board dead
until the page was reloaded. Both now have regression guards.
