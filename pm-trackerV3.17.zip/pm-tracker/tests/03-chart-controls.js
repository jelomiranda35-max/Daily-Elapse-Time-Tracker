const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
const b=await pup.launch({executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
 args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
p.on('dialog',async d=>await d.accept());
await p.setViewport({width:1366,height:900});
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1400));
const R=[]; const rec=(n,ok,d='')=>R.push({n,ok:!!ok,d});

// counts of each chart element, with everything on
const base = await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.chartH='m'; show('board');
  const svg=document.querySelector('.well svg');
  return { rects:svg.querySelectorAll('rect').length, lines:svg.querySelectorAll('line').length,
           circles:svg.querySelectorAll('circle').length, texts:svg.querySelectorAll('text').length };
});
rec('all elements present by default', base.rects>0 && base.lines>0, JSON.stringify(base));

// each toggle must actually remove something
const toggles = [
  ['band','rect','grey band'],
  ['limitLine','line','limit line'],
  ['warnLine','line','warn line'],
  ['pmMarks','line','PM markers'],
  ['dots','circle','out-of-range dots'],
  ['label','rect','value label']
];
for (const [key, tag, label] of toggles) {
  const r = await p.evaluate((k,t)=>{
    SETTINGS.band=SETTINGS.limitLine=SETTINGS.warnLine=SETTINGS.label=SETTINGS.pmMarks=SETTINGS.dots=true;
    show('board');
    const on=document.querySelectorAll('.well svg '+t).length;
    SETTINGS[k]=false; show('board');
    const off=document.querySelectorAll('.well svg '+t).length;
    SETTINGS[k]=true; show('board');
    return {on,off};
  }, key, tag);
  rec(`toggle off: ${label}`, r.off < r.on, JSON.stringify(r));
}

// y-scale modes
const y = await p.evaluate(()=>{
  const out={};
  ['auto','data','zero'].forEach(m=>{
    SETTINGS.yMode=m; show('board');
    const txt=document.querySelector('#boardGrid').innerText;
    out[m]={ offchart:/off-chart/.test(document.querySelector('#boardGrid').innerHTML) };
  });
  SETTINGS.yMode='auto'; show('board');
  return out;
});
rec('y-scale: auto never hides the limit', y.auto.offchart===false, JSON.stringify(y));
rec('y-scale: data mode warns when the limit falls off', y.data.offchart===true, JSON.stringify(y));

// "fit the readings" must actually magnify a flat-looking trace
const magnify = await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'M',name:'M',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5,lastPM:addDays(todayISO(),-20)});
  DB.parameters.push({id:'M::p',machineId:'M',name:'p',unit:'',threshold:100,warn:80,bound:'upper'});
  for(let i=20;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'M::p',value:5+(20-i)*0.05});
  function spread(){
    const a=assess(DB.parameters[0]);
    const svg=tileChart(a,45,false);
    const ys=[...svg.matchAll(/points="([^"]+)"/g)].flatMap(m=>m[1].split(' ').map(q=>+q.split(',')[1]));
    return ys.length? Math.max(...ys)-Math.min(...ys) : 0;
  }
  SETTINGS.yMode='auto'; const a=spread();
  SETTINGS.yMode='data'; const d=spread();
  SETTINGS.yMode='auto';
  return { autoSpread:Math.round(a), dataSpread:Math.round(d) };
});
rec('y-scale: fitting the readings magnifies a small drift',
    magnify.dataSpread > magnify.autoSpread*3, JSON.stringify(magnify));

// per-parameter hide
const hide = await p.evaluate(()=>{
  DB=demoDB(); show('board');
  const before=document.querySelectorAll('.well svg').length;
  const pid=DB.parameters[0].id;
  DB.parameters[0].hidden=true; show('board');
  const after=document.querySelectorAll('.well svg').length;
  show('charts'); const charts=document.querySelectorAll('.chartcard').length;
  show('report'); const inReport=monthReport(monthsAvailable()[0]).rows.some(r=>r.p.id===pid);
  DB.parameters[0].hidden=false; show('board');
  return {before, after, charts, inReport, restored:document.querySelectorAll('.well svg').length};
});
rec('hide: parameter drops off the board', hide.after===hide.before-1, JSON.stringify(hide));
rec('hide: parameter still counted in the monthly report', hide.inReport===true, JSON.stringify(hide));
rec('hide: unhiding restores it', hide.restored===hide.before, JSON.stringify(hide));

// panel opens and has three tabs
const ui = await p.evaluate(()=>{
  show('board'); displayMenu();
  const tabs=document.querySelectorAll('#dispTabs button').length;
  const chartOpts=document.querySelectorAll('#dispPane .optrow').length;
  const hasY=!!document.querySelector('#oY');
  document.querySelector('#dispTabs button[data-t="params"]').click();
  const paramOpts=document.querySelectorAll('#dispPane [data-pv]').length;
  document.querySelector('#mCancel').click();
  return {tabs, chartOpts, hasY, paramOpts};
});
rec('panel has three tabs', ui.tabs===3, JSON.stringify(ui));
rec('panel exposes the scale selector', ui.hasY);
rec('panel lists every chart element', ui.chartOpts>=6, 'opts='+ui.chartOpts);
rec('panel lists every parameter', ui.paramOpts>=21, 'params='+ui.paramOpts);

// settings survive a reload
await p.evaluate(()=>{ SETTINGS.yMode='data'; SETTINGS.band=false; SETTINGS.chartH='xl'; saveSettings(); });
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1400));
const persist=await p.evaluate(()=>({y:SETTINGS.yMode,band:SETTINGS.band,h:SETTINGS.chartH}));
rec('settings persist across reload', persist.y==='data'&&persist.band===false&&persist.h==='xl',
    JSON.stringify(persist));
await p.evaluate(()=>{ SETTINGS.yMode='auto'; SETTINGS.band=true; SETTINGS.chartH='m'; saveSettings(); });

// everything off must not crash
const allOff = await p.evaluate(()=>{
  ['band','limitLine','warnLine','label','pmMarks','dots','projection','showTravel','showPM','showSummary']
    .forEach(k=>SETTINGS[k]=false);
  let err=null;
  try{ show('board'); show('charts'); show('machine'); }catch(e){ err=e.message; }
  const tiles=document.querySelectorAll('.tile').length;
  ['band','limitLine','warnLine','label','pmMarks','dots','projection','showTravel','showPM','showSummary']
    .forEach(k=>SETTINGS[k]=true);
  show('board');
  return {err, tiles};
});
rec('every option off still renders', !allOff.err && allOff.tiles>0, allOff.err||('tiles='+allOff.tiles));

const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
console.log(`\nCHART CONTROL QA — ${pass}/${R.length} passed`);
if(fail.length){ console.log('FAILURES:'); fail.forEach(f=>console.log('  x '+f.n+'\n      '+f.d)); }
console.log(errs.length?'RUNTIME ERRORS: '+errs.join(' | '):'No runtime errors.');
await b.close(); process.exit(fail.length?1:0);
})();
