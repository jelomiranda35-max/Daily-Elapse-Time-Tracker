# Test suites

Run against a real headless Chrome. They need Node and Puppeteer; the app itself
needs neither.

```bash
node tests/01-unit.js          # 91  maths, dates, IO, parsing, escaping
node tests/02-features.js      # 63  every screen and feature behaviour
node tests/03-chart-controls.js# 19  chart content toggles and scale modes
node tests/04-edge-cases.js    # 25  adversarial input and boundary conditions
node tests/05-regressions.js   # 14  guards on bugs already found and fixed
```

Edit the `executablePath` at the top of each file to point at your Chrome.

`01-unit.js` runs in `America/New_York` and `04-edge-cases.js` in
`Pacific/Chatham` (+12:45), because UTC hides daylight-saving and half-hour-offset
date bugs.

## Bugs these have caught

| Bug | Found by | Fixed |
|---|---|---|
| Trend fell back to full history after a PM, reporting the pre-PM rise on a machine just serviced | features | Never cross a PM boundary; show "Rebuilding after PM" |
| `renderEmpty` destroyed the screen's markup, so importing after viewing an empty board threw and left the board dead until reload | edge cases | Hide the content, never wipe it; restore on next render |
| A file from a newer app version was silently stamped down to this schema | edge cases | Keep its version, load it, warn the user |
| `setSelectionRange` crashed on `<input type=number>` | features | Focus only |
| Import ignored limit direction, so a lower-limit column read "At limit" from day one | manual | Direction inferred from readings vs target |
| Value labels clipped at the right edge of a chart | visual | Right margin sized to the label |
| Limit labels collided with value labels | visual | Limit labels moved to the left edge |
| Panel title rendered as `Chart &amp; tile content` | visual | Removed double escaping |

Several were caught by looking at rendered screenshots rather than by an assertion.
Both matter.
