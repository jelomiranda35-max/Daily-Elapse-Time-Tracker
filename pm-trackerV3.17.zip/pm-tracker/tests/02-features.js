const puppeteer = require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
const fs = require('fs');

(async () => {
  const b = await puppeteer.launch({
    executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
    args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']
  });
  const p = await b.newPage();
  await p.emulateTimezone('America/New_York');
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  p.on('dialog', async d => await d.accept());
  await p.setViewport({ width:1366, height:768 });

  const R=[]; const rec=(n,ok,d='')=>R.push({n,ok:!!ok,d});

  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1500));

  // ---- 1. LARGER / CUSTOMISABLE CHARTS ----
  const sizes={};
  for (const sz of ['s','m','l','xl']) {
    sizes[sz] = await p.evaluate(x=>{
      SETTINGS.chartH=x; show('board');
      const svg=document.querySelector('.well svg');
      return Math.round(svg.getBoundingClientRect().height);
    }, sz);
  }
  rec('1. chart sizes S<M<L<XL', sizes.s<sizes.m && sizes.m<sizes.l && sizes.l<sizes.xl, JSON.stringify(sizes));
  rec('1. XL chart is at least double S', sizes.xl >= sizes.s*2, JSON.stringify(sizes));
  const colTest={};
  for (const c of ['auto','2','3','4','5','6']) {
    colTest[c] = await p.evaluate(x=>{
      SETTINGS.cols=x; show('board');
      return getComputedStyle(document.querySelector('#boardGrid')).gridTemplateColumns.split(' ').length;
    }, c);
  }
  rec('1. column count control works', colTest['2']===2&&colTest['3']===3&&colTest['4']===4&&colTest['6']===6,
      JSON.stringify(colTest));
  const gridlines = await p.evaluate(()=>{
    SETTINGS.chartH='xl'; SETTINGS.cols='3'; show('board');
    return document.querySelectorAll('.well svg line').length;
  });
  rec('1. large charts gain value gridlines', gridlines>6, 'lines='+gridlines);

  // ---- 2. EDIT PARAMS FROM THE TILE ----
  const editUI = await p.evaluate(()=>{
    SETTINGS.chartH='m'; SETTINGS.cols='auto'; show('board');
    return document.querySelectorAll('.tedit').length;
  });
  rec('2. every tile has an edit button', editUI>0, 'buttons='+editUI);
  const edited = await p.evaluate(()=>{
    const mid = DB.machines[0].id;
    const pa  = paramsOf(mid)[0];
    const beforeThr = pa.threshold, beforeIv = DB.machines[0].pmIntervalDays;
    editMachineQuick(mid);
    const ok = !!document.querySelector('#qt0') && !!document.querySelector('#qiv') && !!document.querySelector('#qpm');
    document.querySelector('#qt0').value = beforeThr*2;
    document.querySelector('#qw0').value = beforeThr*1.5;
    document.querySelector('#qiv').value = 42;
    document.querySelector('#mSave').click();
    return { fieldsPresent:ok, thrChanged: paramsOf(mid)[0].threshold===beforeThr*2,
             warnChanged: paramsOf(mid)[0].warn===beforeThr*1.5,
             ivChanged: DB.machines[0].pmIntervalDays===42, beforeIv };
  });
  rec('2. quick-edit shows limit, warn, PM fields', edited.fieldsPresent);
  rec('2. limit edit saves', edited.thrChanged);
  rec('2. warn edit saves', edited.warnChanged);
  rec('2. PM interval edit saves', edited.ivChanged);

  // ---- 3. THEMES ----
  for (const t of ['light','slate','warm','dark','contrast']) {
    const r = await p.evaluate(x=>{
      SETTINGS.theme=x; applyTheme(); show('board');
      const cs=getComputedStyle(document.documentElement);
      const bg=cs.getPropertyValue('--board').trim();
      const ink=cs.getPropertyValue('--ink').trim();
      return { attr:document.documentElement.getAttribute('data-theme'), bg, ink,
               tiles:document.querySelectorAll('.tile').length };
    }, t);
    rec(`3. theme "${t}" applies`, r.attr===t && r.bg && r.ink && r.tiles>0, JSON.stringify(r));
  }
  const darkDiff = await p.evaluate(()=>{
    SETTINGS.theme='light'; applyTheme();
    const l=getComputedStyle(document.documentElement).getPropertyValue('--ink').trim();
    SETTINGS.theme='dark'; applyTheme();
    const d=getComputedStyle(document.documentElement).getPropertyValue('--ink').trim();
    SETTINGS.theme='light'; applyTheme();
    return l!==d;
  });
  rec('3. dark theme actually inverts ink', darkDiff);

  // ---- 4. ENTRY UNDO / EDIT ----
  const entry = await p.evaluate(()=>{
    DB=demoDB(); markClean(); entryDraft={}; lastBatch=null;
    show('entry');
    const d=document.querySelector('#entryDate').value;
    const inp=document.querySelector('#entryBody input.val');
    const pid=inp.dataset.pid;
    const before = DB.readings.filter(r=>r.date===d&&r.paramId===pid).length;
    inp.value='1.234'; inp.dispatchEvent(new Event('input',{bubbles:true}));
    saveEntry();
    const after = DB.readings.filter(r=>r.date===d&&r.paramId===pid)[0];
    const savedTag = document.querySelectorAll('#entryBody .savedtag').length;
    const undoBtns = document.querySelectorAll('#entryBody [data-undo]').length;
    return { before, savedVal:after?after.value:null, savedTag, undoBtns, pid, d };
  });
  rec('4. reading saves', entry.savedVal===1.234, JSON.stringify(entry));
  rec('4. saved values show a "saved" marker', entry.savedTag>0, 'tags='+entry.savedTag);
  rec('4. saved values offer an Undo button', entry.undoBtns>0, 'btns='+entry.undoBtns);

  const undone = await p.evaluate(()=>{
    const d=document.querySelector('#entryDate').value;
    const inp=document.querySelector('#entryBody input.val');
    const pid=inp.dataset.pid;
    const n=DB.readings.length;
    const nowVal=DB.readings.filter(r=>r.date===d&&r.paramId===pid)[0].value;
    undoLastBatch();
    const row=DB.readings.filter(r=>r.date===d&&r.paramId===pid)[0];
    return { valueBeforeUndo:nowVal, valueAfterUndo: row?row.value:null,
             rowRemoved: !row, countBefore:n, countAfter:DB.readings.length };
  });
  rec('4. undo last save rolls the batch back',
      undone.rowRemoved || undone.valueAfterUndo!==undone.valueBeforeUndo, JSON.stringify(undone));

  // a brand-new reading (no prior value) must be removed entirely by undo
  const undoNew = await p.evaluate(()=>{
    const d = addDays(todayISO(), 3);              // a date with nothing on it
    document.querySelector('#entryDate').value = d; renderEntry();
    const inp=document.querySelector('#entryBody input.val');
    inp.value='7.77'; inp.dispatchEvent(new Event('input',{bubbles:true}));
    saveEntry();
    const added = DB.readings.filter(r=>r.date===d).length;
    undoLastBatch();
    const left = DB.readings.filter(r=>r.date===d).length;
    document.querySelector('#entryDate').value = todayISO(); renderEntry();
    return { added, left };
  });
  rec('4. undo removes readings that were newly created',
      undoNew.added===1 && undoNew.left===0, JSON.stringify(undoNew));

  const reverted = await p.evaluate(()=>{
    show('entry');
    const d=document.querySelector('#entryDate').value;
    const inp=document.querySelector('#entryBody input.val');
    inp.value='5'; inp.dispatchEvent(new Event('input',{bubbles:true}));
    saveEntry(); show('entry');
    const inp2=document.querySelector('#entryBody input.val');
    inp2.value='99'; inp2.dispatchEvent(new Event('input',{bubbles:true}));
    const hasRevert = !!document.querySelector('#entryBody [data-revert]');
    if(hasRevert) document.querySelector('#entryBody [data-revert]').click();
    const inp3=document.querySelector('#entryBody input.val');
    return { hasRevert, backTo: inp3 ? inp3.value : null };
  });
  rec('4. editing a saved value offers Revert', reverted.hasRevert);
  rec('4. Revert restores the saved value', reverted.backTo==='5', JSON.stringify(reverted));

  const singleUndo = await p.evaluate(()=>{
    show('entry');
    const n=DB.readings.length;
    const btn=document.querySelector('#entryBody [data-undo]');
    if(!btn) return {ok:false, why:'no undo button'};
    btn.click();
    return { ok: DB.readings.length===n-1, was:n, now:DB.readings.length };
  });
  rec('4. per-row Undo deletes just that reading', singleUndo.ok, JSON.stringify(singleUndo));

  // ---- 5. DATA SCREEN INSTRUCTIONS ----
  const dataUI = await p.evaluate(()=>{
    show('data');
    const t=document.querySelector('#scr-data').innerText;
    return {
      steps: document.querySelectorAll('.stepn').length,
      howSteps: document.querySelectorAll('.howstep').length,
      sampleTable: document.querySelectorAll('.sample table tr').length,
      mentionsCtrlC: /Ctrl\+C/.test(t), mentionsCtrlV: /Ctrl\+V/.test(t),
      mentionsTarget: /Target/.test(t), hasPasteBox: !!document.querySelector('#pasteBox')
    };
  });
  rec('5. data screen is numbered into steps', dataUI.steps>=3, JSON.stringify(dataUI));
  rec('5. paste guide has lettered sub-steps', dataUI.howSteps>=5);
  rec('5. shows a worked example table', dataUI.sampleTable>=4);
  rec('5. tells the user which keys to press', dataUI.mentionsCtrlC && dataUI.mentionsCtrlV);

  // ---- 6/7. AUTOLOAD FROM data/ ----
  const savePair = await p.evaluate(()=>{
    const names=[];
    const orig=window.download;
    window.download=function(n,t){ names.push({n, len:t.length, isAuto:/PM_AUTOLOAD/.test(t)}); };
    saveJSON();
    return new Promise(res=>setTimeout(()=>{ window.download=orig; res(names); },900));
  });
  rec('6. save emits an archive file', savePair.some(f=>/^pm-data-\d{4}-\d{2}-\d{2}-\d{6}\.json$/.test(f.n)),
      JSON.stringify(savePair.map(f=>f.n)));
  rec('6. save emits latest.js for auto-load', savePair.some(f=>f.n==='latest.js' && f.isAuto),
      JSON.stringify(savePair.map(f=>f.n)));

  // write a real latest.js and reload to prove it auto-loads
  fs.mkdirSync('/home/claude/pm-tracker/data',{recursive:true});
  const payload = await p.evaluate(()=>JSON.stringify(DB));
  fs.writeFileSync('/home/claude/pm-tracker/data/latest.js',
    'window.PM_AUTOLOAD = '+payload+';\n');
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1600));
  const auto = await p.evaluate(()=>({
    used: !!window.PM_AUTOLOAD_USED,
    machines: DB.machines.length,
    readings: DB.readings.length,
    tiles: document.querySelectorAll('.tile').length,
    clean: !dirty
  }));
  rec('7. app auto-loads data/latest.js on open', auto.used && auto.readings>0, JSON.stringify(auto));
  rec('7. auto-loaded board renders tiles', auto.tiles>0, 'tiles='+auto.tiles);
  rec('7. auto-load does not mark the file dirty', auto.clean);

  // missing latest.js must be harmless
  fs.unlinkSync('/home/claude/pm-tracker/data/latest.js');
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1500));
  const noAuto = await p.evaluate(()=>({
    used: !!window.PM_AUTOLOAD_USED,
    tiles: document.querySelectorAll('.tile').length
  }));
  rec('7. missing latest.js falls back to demo without error', !noAuto.used && noAuto.tiles>0,
      JSON.stringify(noAuto));

  // corrupt latest.js must not brick the app
  fs.writeFileSync('/home/claude/pm-tracker/data/latest.js','window.PM_AUTOLOAD = {broken:true};\n');
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1500));
  const corrupt = await p.evaluate(()=>({ alive: typeof render==='function', screen: screen }));
  rec('7. malformed latest.js does not brick the app', corrupt.alive, JSON.stringify(corrupt));
  fs.unlinkSync('/home/claude/pm-tracker/data/latest.js');

  // ---- 9/10. SCREENSHOT VIEW ----
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1500));
  const wall = await p.evaluate(()=>{
    show('board'); enterWall();
    const x=document.querySelector('#wallExit');
    const style=getComputedStyle(x);
    return {
      xVisible: !x.hidden,
      xIsX: x.textContent.trim()==='\u2715' || x.innerHTML.indexOf('10005')>=0 || x.textContent.trim().length<=2,
      round: style.borderRadius,
      railHidden: getComputedStyle(document.querySelector('.rail')).display==='none',
      fits: document.body.scrollHeight<=window.innerHeight+2,
      tiles: document.querySelectorAll('.tile').length
    };
  });
  rec('9. screenshot view has a visible X button', wall.xVisible && wall.xIsX, JSON.stringify(wall));
  rec('9. X is a round button', wall.round==='50%', wall.round);
  rec('10. screenshot view hides all chrome', wall.railHidden);
  rec('10. screenshot view fits one screen', wall.fits);
  const escWorks = await p.evaluate(()=>{
    document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));
    return !document.body.classList.contains('wall');
  });
  rec('9. Esc exits screenshot view', escWorks);
  const xWorks = await p.evaluate(()=>{
    enterWall(); document.querySelector('#wallExit').click();
    return !document.body.classList.contains('wall');
  });
  rec('9. X button exits screenshot view', xWorks);

  // editable content in the screenshot
  const toggles = await p.evaluate(()=>{
    show('board');
    SETTINGS.showTravel=false; SETTINGS.showPM=false; SETTINGS.showSummary=false; render();
    const a={ travel:document.querySelectorAll('.travel').length,
              pm:document.querySelectorAll('.tpm').length,
              sum:document.querySelector('#boardSummary').style.display };
    SETTINGS.showTravel=true; SETTINGS.showPM=true; SETTINGS.showSummary=true; render();
    const c={ travel:document.querySelectorAll('.travel').length,
              pm:document.querySelectorAll('.tpm').length,
              sum:document.querySelector('#boardSummary').style.display };
    return {a,c};
  });
  rec('10. tile content can be switched off', toggles.a.travel===0 && toggles.a.pm===0 && toggles.a.sum==='none',
      JSON.stringify(toggles.a));
  rec('10. tile content can be switched back on', toggles.c.travel>0 && toggles.c.pm>0 && toggles.c.sum==='',
      JSON.stringify(toggles.c));

  // ---- 11. PM RESETS THE COUNTDOWN AND THE TREND ----
  const pmReset = await p.evaluate(()=>{
    DB=blankDB();
    DB.machines.push({id:'T1',name:'T',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5,
      lastPM: addDays(todayISO(),-29)});
    DB.parameters.push({id:'T1::p',machineId:'T1',name:'p',unit:'',threshold:20,warn:16,bound:'upper'});
    for(let i=20;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'T1::p',value:2+(20-i)*0.7});
    const before = pmSchedule(machineById('T1'));
    const aBefore = assess(DB.parameters[0]);

    // log PM today, exactly as the UI does
    DB.pmEvents.push({id:uid(),date:todayISO(),machineId:'T1',type:'Scheduled PM',tech:'QA',notes:''});
    machineById('T1').lastPM = todayISO();

    const after = pmSchedule(machineById('T1'));
    const aAfter = assess(DB.parameters[0]);
    return {
      beforeIn: before.inDays, afterIn: after.inDays,
      beforeNext: before.next, afterNext: after.next,
      beforeSegStart: aBefore.seg[0].date, afterSegStart: aAfter.seg[0].date,
      beforeSlope: aBefore.slope, afterSlope: aAfter.slope,
      expectedNext: addDays(todayISO(),30)
    };
  });
  rec('11. logging PM restarts the countdown to a full interval',
      pmReset.afterIn===30 && pmReset.afterNext===pmReset.expectedNext, JSON.stringify(pmReset));
  rec('11. countdown was shorter before the PM', pmReset.beforeIn < pmReset.afterIn,
      `${pmReset.beforeIn} -> ${pmReset.afterIn}`);
  rec('11. trend segment restarts at the PM date', pmReset.afterSegStart===new Date().toISOString().slice(0,10)
      || pmReset.afterSegStart!==pmReset.beforeSegStart, JSON.stringify(pmReset));
  rec('11. post-PM slope no longer reflects the old rise',
      pmReset.afterSlope===null || pmReset.afterSlope<pmReset.beforeSlope,
      `${pmReset.beforeSlope} -> ${pmReset.afterSlope}`);

  const pmViaQuick = await p.evaluate(()=>{
    DB=blankDB();
    DB.machines.push({id:'Q1',name:'Q',group:'Photo',active:true,pmIntervalDays:20,pmLeadDays:5,
      lastPM: addDays(todayISO(),-19)});
    DB.parameters.push({id:'Q1::p',machineId:'Q1',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'Q1::p',value:5});
    const before = pmSchedule(machineById('Q1')).inDays;
    editMachineQuick('Q1');
    document.querySelector('#qpm').checked = true;
    document.querySelector('#mSave').click();
    return { before, after: pmSchedule(machineById('Q1')).inDays,
             logged: DB.pmEvents.length };
  });
  rec('11. PM logged from the tile edit panel resets the countdown',
      pmViaQuick.after===20 && pmViaQuick.logged===1, JSON.stringify(pmViaQuick));

  // ---- 12. PM SCHEDULE TAB ----
  const pmTab = await p.evaluate(()=>{
    DB=demoDB();
    let err=null;
    try{ show('pm'); }catch(e){ err=e.message; }
    const t=document.querySelector('#scr-pm');
    return {
      err,
      visible: !t.hidden,
      inNav: !!document.querySelector('#nav button[data-screen="pm"]'),
      rows: document.querySelectorAll('#pmBody tbody tr').length,
      hasCountdownBars: document.querySelectorAll('#pmBody .bar-mini').length,
      hasLogButtons: document.querySelectorAll('#pmBody [data-logpm]').length,
      hasSummary: document.querySelectorAll('#pmBody .sumcell').length
    };
  });
  rec('12. PM schedule screen exists in the nav', pmTab.inNav);
  rec('12. PM schedule screen renders', !pmTab.err && pmTab.visible, pmTab.err||'');
  rec('12. one row per machine', pmTab.rows>=16, 'rows='+pmTab.rows);
  rec('12. countdown bars drawn', pmTab.hasCountdownBars>=16, 'bars='+pmTab.hasCountdownBars);
  rec('12. Log PM button on every row', pmTab.hasLogButtons>=16, 'btns='+pmTab.hasLogButtons);
  rec('12. summary figures present', pmTab.hasSummary>=5, 'cells='+pmTab.hasSummary);

  // ---- REGRESSION: every screen, every theme ----
  const SCREENS=['board','entry','charts','analysis','machine','report','config','data','pm'];
  for (const th of ['light','dark','contrast']) {
    for (const sc of SCREENS) {
      const r = await p.evaluate((t,s)=>{
        try{ SETTINGS.theme=t; applyTheme(); show(s); return 'ok'; }
        catch(e){ return 'ERR '+e.message; }
      }, th, sc);
      if (r!=='ok') rec(`regression: ${sc} in ${th}`, false, r);
    }
  }
  rec('regression: all 9 screens render in 3 themes', !R.some(x=>x.n.startsWith('regression:')&&!x.ok));

  // empty DB across all screens
  await p.evaluate(()=>{ DB=blankDB(); markClean(); });
  for (const sc of SCREENS) {
    const r = await p.evaluate(s=>{ try{ show(s); return 'ok'; }catch(e){ return 'ERR '+e.message; } }, sc);
    rec(`empty db: ${sc}`, r==='ok', r);
  }

  const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
  console.log(`\n${'='.repeat(66)}\nFEATURE QA — ${pass}/${R.length} passed\n${'='.repeat(66)}`);
  if(fail.length){ console.log('\nFAILURES:'); fail.forEach(f=>console.log(`  x ${f.n}\n      ${f.d}`)); }
  else console.log('\nAll assertions passed.');
  console.log(errs.length?'\nRUNTIME ERRORS:\n  '+errs.join('\n  '):'\nNo runtime errors.');
  await b.close();
  process.exit(fail.length?1:0);
})();
