const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
const b=await pup.launch({executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
 args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
p.on('dialog',async d=>await d.accept());
await p.setViewport({width:1366,height:900});
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1400));
const R=[]; const rec=(n,ok,d='')=>R.push({n,ok:!!ok,d});

// regression guards for the empty-state bug, on EVERY screen
const SCREENS=['board','entry','charts','analysis','machine','report','pm'];
for (const sc of SCREENS){
  const r = await p.evaluate(s=>{
    DB=blankDB(); markClean();
    show(s);                                   // empty state hides the markup
    DB=demoDB();                               // data arrives
    let err=null;
    try{ show(s); }catch(e){ err=e.message; }
    const host=document.querySelector('#scr-'+s);
    return { err,
      leftovers: host.querySelectorAll('.emptystate').length,
      stillHidden: host.querySelectorAll('[data-empty-hidden]').length,
      content: host.innerText.trim().length };
  }, sc);
  rec(`empty -> data recovers on ${sc}`, !r.err && r.leftovers===0 && r.stillHidden===0 && r.content>60,
      JSON.stringify(r));
}

// the full user path, end to end
const path = await p.evaluate(()=>{
  DB=blankDB(); markClean();
  show('board');
  const t=['Date\tSCN-01 Lens drift\tTarget\tDPM-11 Base pressure\tTarget',
           '01/09/2026\t1.0\t3.5\t18\t60','02/09/2026\t1.2\t3.5\t19\t60',
           '03/09/2026\t1.4\t3.5\t21\t60','04/09/2026\t1.7\t3.5\t23\t60'].join('\n');
  show('data');
  document.querySelector('#pasteBox').value=t;
  let err=null;
  try{ parsePaste(); commitImport(); }catch(e){ err=e.message; }
  const tiles=document.querySelectorAll('.tile').length;
  let screensOk=true, which='';
  ['entry','charts','analysis','machine','report','pm','config'].forEach(s=>{
    try{ show(s); }catch(e){ screensOk=false; which=s+': '+e.message; }
  });
  show('board');
  return { err, tiles, readings:DB.readings.length, screensOk, which };
});
rec('clear -> view board -> import -> board works', !path.err && path.tiles===2, JSON.stringify(path));
rec('every screen usable after that path', path.screensOk, path.which);

// and the same via Load demo rather than import
const viaDemo = await p.evaluate(()=>{
  DB=blankDB(); markClean(); show('board');
  let err=null;
  try{ DB=demoDB(); markClean(); show('board'); }catch(e){ err=e.message; }
  return { err, tiles:document.querySelectorAll('.tile').length };
});
rec('clear -> view board -> load demo works', !viaDemo.err && viaDemo.tiles===16, JSON.stringify(viaDemo));

// wall mode after recovering from empty
const wallAfter = await p.evaluate(()=>{
  DB=blankDB(); show('board'); DB=demoDB(); show('board');
  let err=null;
  try{ enterWall(); }catch(e){ err=e.message; }
  const fits=document.body.scrollHeight<=window.innerHeight+2;
  exitWall();
  return { err, fits };
});
rec('screenshot view works after recovering from empty', !wallAfter.err && wallAfter.fits, JSON.stringify(wallAfter));

// schema guard
const schema = await p.evaluate(()=>{
  const newer=migrate({schemaVersion:99,groups:['G'],machines:[],parameters:[],readings:[],pmEvents:[],meta:{}});
  const older=migrate({schemaVersion:1,groups:['G'],machines:[],parameters:[],readings:[],pmEvents:[],meta:{}});
  return { newerKept:newer.schemaVersion===99, flagged:!!newer._newerSchema,
           olderStamped:older.schemaVersion===SCHEMA, olderFlagged:!!older._newerSchema };
});
rec('newer-format file keeps its version', schema.newerKept && schema.flagged, JSON.stringify(schema));
rec('current-format file unaffected', schema.olderStamped && !schema.olderFlagged, JSON.stringify(schema));

// single-word header
const oneWord = await p.evaluate(()=>{
  DB=blankDB(); show('data');
  document.querySelector('#pasteBox').value='Date\tTemp\tTarget\n2026-09-01\t1\t10\n2026-09-02\t2\t10';
  parsePaste(); commitImport();
  return { machine:DB.machines[0].name, param:DB.parameters[0].name };
});
rec('single-word header names the parameter sensibly', oneWord.param==='Temp', JSON.stringify(oneWord));

const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
console.log(`\nREGRESSION GUARDS — ${pass}/${R.length} passed`);
if(fail.length){ console.log('FAILURES:'); fail.forEach(f=>console.log('  x '+f.n+'\n      '+f.d)); }
console.log(errs.length?'RUNTIME ERRORS: '+errs.join(' | '):'No runtime errors.');
await b.close(); process.exit(fail.length?1:0);
})();
