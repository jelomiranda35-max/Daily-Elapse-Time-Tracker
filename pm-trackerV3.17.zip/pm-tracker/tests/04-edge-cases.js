const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
const b=await pup.launch({executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
 args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
p.on('dialog',async d=>await d.accept());
await p.emulateTimezone('Pacific/Chatham');            // +12:45, a half-hour offset zone
await p.setViewport({width:1366,height:900});
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1400));

const out = await p.evaluate(()=>{
  const R=[]; const ok=(n,c,d='')=>R.push({n,ok:!!c,d});
  const guard=(n,fn)=>{ try{ const v=fn(); ok(n,v===true||v===undefined,v===true||v===undefined?'':String(v)); }
                        catch(e){ ok(n,false,'THREW '+e.message); } };

  // ---- 1. separator collision: "::" inside a parameter name ----
  guard('paramId survives "::" in a parameter name', ()=>{
    DB=blankDB();
    DB.machines.push({id:'A',name:'A',group:'Photo',active:true});
    const pid='A'+'::'+'Temp::inner';
    DB.parameters.push({id:pid,machineId:'A',name:'Temp::inner',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:pid,value:5});
    const a=assess(DB.parameters[0]);
    return a.value===5 || 'value='+a.value;
  });

  // ---- 2. entryDraft key uses "|" — a paramId containing "|" would split wrong ----
  guard('entry draft key survives "|" in a parameter name', ()=>{
    DB=blankDB();
    DB.machines.push({id:'B',name:'B',group:'Photo',active:true});
    const pid='B::Flow|rate';
    DB.parameters.push({id:pid,machineId:'B',name:'Flow|rate',unit:'',threshold:10,warn:8,bound:'upper'});
    entryDraft={}; lastBatch=null;
    const d=todayISO();
    entryDraft[d+'|'+pid]='7';
    document.querySelector('#entryDate').value=d;
    document.querySelector('#entryBy').value='QA';
    saveEntry();
    const row=DB.readings.filter(r=>r.paramId===pid)[0];
    return (row && row.value===7) || 'stored='+JSON.stringify(DB.readings);
  });

  // ---- 3. machine where every parameter is hidden ----
  guard('machine with all parameters hidden does not render a broken tile', ()=>{
    DB=demoDB();
    const mid=DB.machines[0].id;
    paramsOf(mid).forEach(x=>x.hidden=true);
    show('board');
    const tiles=document.querySelectorAll('.tile').length;
    const empty=[...document.querySelectorAll('.tile')].some(t=>!t.querySelector('.well')&&!t.querySelector('.pline'));
    return (!empty) || 'an empty tile rendered; tiles='+tiles;
  });

  // ---- 4. future-dated readings ----
  guard('future-dated reading does not break the board', ()=>{
    DB=demoDB();
    const pid=DB.parameters[0].id;
    DB.readings.push({date:addDays(todayISO(),30),paramId:pid,value:1});
    show('board');
    const a=assess(DB.parameters[0]);
    return isFinite(a.risk) || 'risk='+a.risk;
  });

  // ---- 5. zero variance: every reading identical ----
  guard('identical readings do not divide by zero', ()=>{
    DB=blankDB();
    DB.machines.push({id:'C',name:'C',group:'Photo',active:true});
    DB.parameters.push({id:'C::p',machineId:'C',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    for(let i=15;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'C::p',value:4});
    const a=assess(DB.parameters[0]);
    const chart=tileChart(a,45,false);
    return (isFinite(a.risk) && (a.anom===null||isFinite(a.anom)) && chart.indexOf('NaN')<0)
      || 'risk='+a.risk+' anom='+a.anom+' nan='+(chart.indexOf('NaN')>=0);
  });

  // ---- 6. threshold of zero ----
  guard('threshold of zero does not produce NaN', ()=>{
    DB=blankDB();
    DB.machines.push({id:'D',name:'D',group:'Photo',active:true});
    DB.parameters.push({id:'D::p',machineId:'D',name:'p',unit:'',threshold:0,warn:0.5,bound:'lower'});
    for(let i=10;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'D::p',value:2-i*0.1});
    const a=assess(DB.parameters[0]);
    const chart=tileChart(a,45,false);
    return (isFinite(a.risk) && chart.indexOf('NaN')<0) || 'risk='+a.risk+' nanInChart='+(chart.indexOf('NaN')>=0);
  });

  // ---- 7. negative readings with a negative limit ----
  guard('negative values and negative limit', ()=>{
    DB=blankDB();
    DB.machines.push({id:'E',name:'E',group:'Photo',active:true});
    DB.parameters.push({id:'E::p',machineId:'E',name:'p',unit:'',threshold:-5,warn:-8,bound:'upper'});
    for(let i=10;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'E::p',value:-20+i*0.5});
    const a=assess(DB.parameters[0]);
    const chart=tileChart(a,45,false);
    return (isFinite(a.risk) && chart.indexOf('NaN')<0) || 'risk='+a.risk;
  });

  // ---- 8. baseline already past the limit ----
  guard('baseline already beyond the limit', ()=>{
    DB=blankDB();
    DB.machines.push({id:'F',name:'F',group:'Photo',active:true});
    DB.parameters.push({id:'F::p',machineId:'F',name:'p',unit:'',threshold:5,warn:4,bound:'upper'});
    for(let i=10;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'F::p',value:50});
    const a=assess(DB.parameters[0]);
    return (isFinite(a.risk) && a.status==='crit') || 'status='+a.status+' risk='+a.risk;
  });

  // ---- 9. single reading in the whole database, chart span = 0 ----
  guard('single reading renders a chart without NaN', ()=>{
    DB=blankDB();
    DB.machines.push({id:'G',name:'G',group:'Photo',active:true});
    DB.parameters.push({id:'G::p',machineId:'G',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'G::p',value:3});
    const a=assess(DB.parameters[0]);
    const t=tileChart(a,45,false), f=trendChart(a,0);
    return (t.indexOf('NaN')<0 && f.indexOf('NaN')<0) || 'tileNaN='+(t.indexOf('NaN')>=0)+' fullNaN='+(f.indexOf('NaN')>=0);
  });

  // ---- 10. PM logged before any reading exists ----
  guard('PM dated before the first reading', ()=>{
    DB=blankDB();
    DB.machines.push({id:'H',name:'H',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5});
    DB.parameters.push({id:'H::p',machineId:'H',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.pmEvents.push({id:'x',date:addDays(todayISO(),-90),machineId:'H'});
    for(let i=5;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'H::p',value:3+i*0.1});
    const c=pmCycles('H');
    const a=assess(DB.parameters[0]);
    return (c.length===1 && isFinite(a.risk)) || 'cycles='+c.length+' risk='+a.risk;
  });

  // ---- 11. PM dated in the future ----
  guard('PM dated in the future', ()=>{
    DB=blankDB();
    DB.machines.push({id:'I',name:'I',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5,
      lastPM:addDays(todayISO(),15)});
    DB.parameters.push({id:'I::p',machineId:'I',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'I::p',value:3});
    DB.pmEvents.push({id:'y',date:addDays(todayISO(),15),machineId:'I'});
    const s=pmSchedule(machineById('I'));
    show('pm');
    return (s && isFinite(s.inDays)) || 'sched='+JSON.stringify(s);
  });

  // ---- 12. retired machine still carrying readings ----
  guard('retired machine leaves board but stays in reports', ()=>{
    DB=demoDB();
    DB.machines[0].active=false;
    show('board');
    const onBoard=[...document.querySelectorAll('.tile')].length;
    const rep=monthReport(monthsAvailable()[0]);
    const inRep=rep.rows.some(r=>r.m && r.m.id===DB.machines[0].id);
    show('pm'); show('analysis');
    return (onBoard===15 && !inRep) || 'tiles='+onBoard+' inReport='+inRep;
  });

  // ---- 13. previous month has no data at all ----
  guard('month report with an empty previous month', ()=>{
    DB=blankDB();
    DB.machines.push({id:'J',name:'J',group:'Photo',active:true});
    DB.parameters.push({id:'J::p',machineId:'J',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:'2026-05-10',paramId:'J::p',value:3});
    const r=monthReport('2026-05');
    return (r.rows[0].change===null) || 'change='+r.rows[0].change;
  });

  // ---- 14. CSV escaping of commas, quotes and newlines ----
  guard('CSV escapes commas, quotes and newlines in notes', ()=>{
    DB=blankDB();
    DB.machines.push({id:'K',name:'Pump, "big"',group:'Photo',active:true});
    DB.parameters.push({id:'K::p',machineId:'K',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'K::p',value:3,by:'a,b'});
    DB.pmEvents.push({id:'z',date:todayISO(),machineId:'K',type:'PM',tech:'x',notes:'line1\nline2, "q"'});
    let captured=[];
    const orig=window.download;
    window.download=function(n,t){ captured.push(t); };
    exportCSV();
    window.download=orig;
    const csv=captured[0]||'';
    const quotedName = csv.indexOf('"Pump, ""big"""')>=0;
    return quotedName || 'header row: '+csv.split('\r\n')[1];
  });

  // ---- 15. a data file claiming a future schema version ----
  guard('file from a newer schema version is not silently downgraded', ()=>{
    const future={schemaVersion:99,groups:['G'],machines:[],parameters:[],readings:[],pmEvents:[],meta:{}};
    const m=migrate(JSON.parse(JSON.stringify(future)));
    return m.schemaVersion===99 ? true
      : 'stamped down to '+m.schemaVersion+' — a newer file would be silently rewritten';
  });

  // ---- 16. corrupt settings in browser storage ----
  guard('corrupt settings JSON does not break startup', ()=>{
    try{ localStorage.setItem('pmtracker.settings.v1','{not json'); }catch(e){}
    loadSettings();
    const good = !!(SETTINGS.theme && SETTINGS.chartH);
    try{ localStorage.removeItem('pmtracker.settings.v1'); }catch(e){}
    return good || 'settings='+JSON.stringify(SETTINGS);
  });

  // ---- 17. settings file with hostile values ----
  guard('settings with out-of-range values do not break rendering', ()=>{
    try{ localStorage.setItem('pmtracker.settings.v1',
      JSON.stringify({theme:'<script>',chartH:'nope',cols:'999',window:-5})); }catch(e){}
    loadSettings();
    DB=demoDB();
    show('board');
    const tiles=document.querySelectorAll('.tile').length;
    SETTINGS.theme='light'; SETTINGS.chartH='m'; SETTINGS.cols='auto'; SETTINGS.window=45;
    saveSettings(); applyTheme();
    return tiles>0 || 'tiles='+tiles;
  });

  // ---- 18. undo after loading a different file (stale batch) ----
  guard('undo after switching files does not corrupt the new data', ()=>{
    DB=demoDB(); entryDraft={}; lastBatch=null;
    show('entry');
    const inp=document.querySelector('#entryBody input.val');
    inp.value='1.5'; inp.dispatchEvent(new Event('input',{bubbles:true}));
    saveEntry();
    const staleBatch=JSON.parse(JSON.stringify(lastBatch));
    // now "load" an unrelated database
    DB=blankDB();
    DB.machines.push({id:'Z',name:'Z',group:'Photo',active:true});
    DB.parameters.push({id:'Z::p',machineId:'Z',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'Z::p',value:9});
    lastBatch=staleBatch;                   // simulate the stale pointer
    const before=JSON.stringify(DB.readings);
    undoLastBatch();
    const after=JSON.stringify(DB.readings);
    return before===after ? true : 'undo mutated the newly loaded data: '+after;
  });

  // ---- 19. duplicate column headers in one paste ----
  guard('duplicate column headers in a paste', ()=>{
    DB=blankDB();
    const t=['Date\tM1 Temp\tTarget\tM1 Temp\tTarget',
             '2026-09-01\t1\t10\t2\t10',
             '2026-09-02\t3\t10\t4\t10'].join('\n');
    show('data');
    document.querySelector('#pasteBox').value=t;
    document.querySelector('#pasteGroup').value='Photo';
    parsePaste();
    commitImport();
    const dupes=DB.readings.length !== new Set(DB.readings.map(r=>r.date+'|'+r.paramId)).size;
    return !dupes ? true : 'duplicate date+parameter rows created: '+DB.readings.length;
  });

  // ---- 20. header that leaves an empty machine name ----
  guard('paste with a one-word header still produces a usable machine', ()=>{
    DB=blankDB();
    const t=['Date\tTemp\tTarget','2026-09-01\t1\t10','2026-09-02\t2\t10'].join('\n');
    show('data');
    document.querySelector('#pasteBox').value=t;
    parsePaste(); commitImport();
    const m=DB.machines[0];
    return !!(m && m.name && m.id && m.name.length) || 'machine='+JSON.stringify(m);
  });

  // ---- 21. very long names ----
  guard('very long machine and parameter names do not break the tile', ()=>{
    DB=blankDB();
    const long='X'.repeat(160);
    DB.machines.push({id:'L',name:long,group:'Photo',active:true});
    DB.parameters.push({id:'L::p',machineId:'L',name:long,unit:'yyyyyyyyyy',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:todayISO(),paramId:'L::p',value:3});
    show('board');
    const t=document.querySelector('.tile');
    const grid=document.querySelector('#boardGrid');
    return (t && t.getBoundingClientRect().width <= grid.getBoundingClientRect().width+2)
      || 'tile overflows its column';
  });

  // ---- 22. wall mode with an empty board ----
  guard('screenshot view with zero machines', ()=>{
    DB=blankDB(); show('board');
    enterWall();
    const cls=document.body.classList.contains('wall');
    exitWall();
    return cls===true || 'wall mode did not engage';
  });

  // ---- 23. deleting a parameter while machine detail is open ----
  guard('deleting a parameter while viewing that machine', ()=>{
    DB=demoDB();
    const mid=DB.machines[0].id;
    document.querySelector('#machinePick').value=mid;
    show('machine');
    const pid=paramsOf(mid)[0].id;
    DB.parameters=DB.parameters.filter(x=>x.id!==pid);
    DB.readings=DB.readings.filter(r=>r.paramId!==pid);
    show('machine');
    return true;
  });

  // ---- 24. every machine retired ----
  guard('all machines retired', ()=>{
    DB=demoDB();
    DB.machines.forEach(m=>m.active=false);
    show('board'); show('pm'); show('analysis'); show('charts'); show('entry');
    return true;
  });

  // ---- 25. half-hour timezone offset (Chatham +12:45) ----
  guard('date arithmetic in a 45-minute-offset timezone', ()=>{
    const a=diffDays('2026-09-10','2026-09-01');
    const bd=addDays('2026-09-01',9);
    return (a===9 && bd==='2026-09-10') || 'diff='+a+' add='+bd;
  });

  return R;
});

const pass=out.filter(x=>x.ok).length, fail=out.filter(x=>!x.ok);
console.log(`\nBUG HUNT — ${pass}/${out.length} clean`);
if(fail.length){ console.log('\nISSUES FOUND:'); fail.forEach(f=>console.log('  ! '+f.n+'\n      '+f.d)); }
else console.log('No issues found.');
console.log(errs.length?'\nRUNTIME ERRORS:\n  '+errs.join('\n  '):'\nNo runtime errors.');
await b.close();
})();
