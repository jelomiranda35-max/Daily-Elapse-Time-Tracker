const puppeteer = require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');

(async () => {
  const b = await puppeteer.launch({
    executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
    args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']
  });
  const p = await b.newPage();
  // A DST timezone — the UTC container would hide date-arithmetic bugs
  await p.emulateTimezone('America/New_York');
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  p.on('dialog', async d => await d.accept());
  await p.setViewport({ width:1366, height:900 });
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1300));

  const results = await p.evaluate(() => {
    const R = [];
    const ok  = (name, cond, detail) => R.push({name, pass:!!cond, detail:detail||''});
    const eq  = (name, a, b) => R.push({name, pass:a===b, detail:`got ${JSON.stringify(a)} want ${JSON.stringify(b)}`});
    const near= (name,a,b,tol)=> R.push({name, pass:Math.abs(a-b)<=(tol||1e-6), detail:`got ${a} want ~${b}`});

    // ---------- 1. DATE ARITHMETIC (DST) ----------
    eq('date: addDays forward over month end', addDays('2026-01-31',1), '2026-02-01');
    eq('date: addDays over leap day', addDays('2028-02-28',1), '2028-02-29');
    eq('date: addDays over year end', addDays('2026-12-31',1), '2027-01-01');
    eq('date: addDays backward over year start', addDays('2026-01-01',-1), '2025-12-31');
    eq('date: addDays across spring DST', addDays('2026-03-07',1), '2026-03-08');
    eq('date: addDays across autumn DST', addDays('2026-10-31',1), '2026-11-01');
    eq('date: diffDays across spring DST', diffDays('2026-03-09','2026-03-07'), 2);
    eq('date: diffDays across autumn DST', diffDays('2026-11-02','2026-10-31'), 2);
    eq('date: diffDays across full DST year', diffDays('2027-01-01','2026-01-01'), 365);
    eq('date: 30-day window exact', diffDays(addDays('2026-06-15',30),'2026-06-15'), 30);
    eq('date: fmtNumeric', fmtNumeric('2026-09-03'), '3/9');

    // ---------- 2. STATUS LOGIC ----------
    const up = {threshold:10, warn:8, bound:'upper'};
    const lo = {threshold:20, warn:26, bound:'lower'};
    eq('status: upper below warn', statusOf(up,5), 'ok');
    eq('status: upper exactly at warn', statusOf(up,8), 'warn');
    eq('status: upper exactly at limit', statusOf(up,10), 'crit');
    eq('status: upper past limit', statusOf(up,11), 'crit');
    eq('status: lower above warn', statusOf(lo,40), 'ok');
    eq('status: lower exactly at warn', statusOf(lo,26), 'warn');
    eq('status: lower exactly at limit', statusOf(lo,20), 'crit');
    eq('status: lower below limit', statusOf(lo,19), 'crit');
    eq('status: null value', statusOf(up,null), 'none');
    eq('status: negative reading, upper', statusOf({threshold:-5,warn:-8,bound:'upper'},-4), 'crit');

    // ---------- 3. PROJECTION ----------
    near('dtt: upper, 1/day, gap 5', daysToThreshold(up,5,1), 5);
    eq('dtt: moving away returns null', daysToThreshold(up,5,-1), null);
    eq('dtt: flat returns null', daysToThreshold(up,5,0), null);
    near('dtt: lower bound, falling 2/day', daysToThreshold(lo,30,-2), 5);
    eq('dtt: lower bound rising returns null', daysToThreshold(lo,30,2), null);
    eq('dtt: already past limit = 0', daysToThreshold(up,12,1), 0);

    // ---------- 4. SLOPE ----------
    const mk = (vals,start)=>vals.map((v,i)=>({date:addDays(start||'2026-06-01',i), value:v}));
    near('slope: perfect +1/day', slopeOf(mk([1,2,3,4,5])), 1, 1e-9);
    near('slope: perfect -2/day', slopeOf(mk([10,8,6,4,2])), -2, 1e-9);
    near('slope: flat', slopeOf(mk([3,3,3,3])), 0, 1e-9);
    eq('slope: too few points', slopeOf(mk([1,2])), null);
    ok('slope: tolerates gaps', Math.abs(slopeOf([
      {date:'2026-06-01',value:1},{date:'2026-06-05',value:5},{date:'2026-06-09',value:9}
    ]) - 1) < 1e-9);

    // ---------- 5. SAVE / LOAD ROUND TRIP ----------
    DB = demoDB();
    const before = { m:DB.machines.length, p:DB.parameters.length,
                     r:DB.readings.length, e:DB.pmEvents.length,
                     firstVal: DB.readings[0].value };
    const json = JSON.stringify(DB);
    DB = migrate(JSON.parse(json));
    const after = { m:DB.machines.length, p:DB.parameters.length,
                    r:DB.readings.length, e:DB.pmEvents.length,
                    firstVal: DB.readings[0].value };
    eq('io: round trip preserves everything', JSON.stringify(before), JSON.stringify(after));
    eq('io: round trip is byte-identical', JSON.stringify(DB).length, json.length);

    // ---------- 6. MIGRATION OF PARTIAL FILES ----------
    let mg = migrate({ machines:[{id:'A',name:'A',group:'Photo'}] });
    ok('migrate: fills missing arrays', Array.isArray(mg.readings)&&Array.isArray(mg.pmEvents));
    eq('migrate: defaults active flag', mg.machines[0].active, true);
    eq('migrate: stamps schema version', mg.schemaVersion, SCHEMA);
    let threw=false; try{ migrate(null); }catch(e){ threw=true; }
    ok('migrate: rejects null', threw);
    threw=false; try{ migrate('hello'); }catch(e){ threw=true; }
    ok('migrate: rejects a string', threw);

    // ---------- 7. INTEGRITY CHECKS ----------
    const bad = { schemaVersion:1, groups:['G'],
      machines:[{id:'M1',name:'M1',group:'G',active:true}],
      parameters:[{id:'M1::P',machineId:'M1',name:'P',threshold:5,warn:4,bound:'upper'}],
      readings:[
        {date:'2026-09-01',paramId:'M1::P',value:1},
        {date:'2026-09-01',paramId:'M1::P',value:2},        // duplicate
        {date:'2026-09-02',paramId:'GONE::X',value:3}       // orphan
      ],
      pmEvents:[{id:'x',date:'2026-09-01',machineId:'NOPE'}] // orphan event
    };
    const iss = integrity(bad);
    ok('integrity: finds duplicate', iss.some(s=>/duplicate/.test(s)), iss.join(' / '));
    ok('integrity: finds orphan reading', iss.some(s=>/no longer exists/.test(s)));
    ok('integrity: finds orphan PM event', iss.some(s=>/unknown machine/.test(s)));

    // ---------- 8. EDGE CASES ON assess() ----------
    DB = blankDB();
    DB.machines.push({id:'E1',name:'Edge 1',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5,lastPM:null});
    DB.parameters.push({id:'E1::none',machineId:'E1',name:'none',unit:'',threshold:10,warn:8,bound:'upper'});
    let a = assess(DB.parameters[0]);
    eq('edge: zero readings -> status none', a.status, 'none');
    eq('edge: zero readings -> risk 0', a.risk, 0);
    eq('edge: zero readings -> no projection', a.dtt, null);

    DB.readings.push({date:'2026-09-01',paramId:'E1::none',value:5});
    a = assess(DB.parameters[0]);
    eq('edge: single reading -> no slope', a.slope, null);
    eq('edge: single reading -> status ok', a.status, 'ok');

    // threshold equal to baseline (zero span)
    DB.parameters.push({id:'E1::flat',machineId:'E1',name:'flat',unit:'',threshold:5,warn:5,bound:'upper'});
    DB.readings.push({date:'2026-09-01',paramId:'E1::flat',value:5});
    a = assess(DB.parameters[1]);
    ok('edge: zero-span threshold does not produce NaN', a.approach===null || isFinite(a.approach),
       'approach='+a.approach);
    ok('edge: zero-span risk is finite', isFinite(a.risk), 'risk='+a.risk);

    // machine with no parameters at all
    DB.machines.push({id:'E2',name:'Edge 2',group:'Photo',active:true});
    ok('edge: machine with no parameters does not crash rollup',
       (function(){ try{ machineRollup(assessAll()); return true; }catch(e){ return 'ERR '+e.message; } })()===true);

    // retired machine excluded
    DB.machines[0].active=false;
    ok('edge: retired machine drops out of active set',
       activeParams().filter(x=>x.machineId==='E1').length===0);
    DB.machines[0].active=true;

    // ---------- 9. PM CYCLES ----------
    DB = blankDB();
    DB.machines.push({id:'C1',name:'Cyc',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5,lastPM:'2026-08-01'});
    DB.parameters.push({id:'C1::p',machineId:'C1',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.pmEvents.push({id:'1',date:'2026-06-01',machineId:'C1'});
    DB.pmEvents.push({id:'2',date:'2026-07-01',machineId:'C1'});
    DB.pmEvents.push({id:'3',date:'2026-08-01',machineId:'C1'});
    [['2026-06-05',2],['2026-06-20',9],['2026-07-05',2],['2026-07-25',3],['2026-08-05',4]]
      .forEach(x=>DB.readings.push({date:x[0],paramId:'C1::p',value:x[1]}));
    const cyc = pmCycles('C1');
    eq('pm: cycle count', cyc.length, 3);
    eq('pm: first cycle length', cyc[0].len, 30);
    eq('pm: warn detected in cycle 1', cyc[0].reachedWarn, 19);
    eq('pm: no warn in cycle 2', cyc[1].reachedWarn, null);
    ok('pm: final cycle still open', cyc[2].open===true);
    eq('pm: lastPMOf respects before-date', lastPMOf('C1','2026-07-15'), '2026-07-01');
    eq('pm: lastPMOf latest', lastPMOf('C1'), '2026-08-01');

    // PM segmentation: trend must reset, not average across the reset
    DB = blankDB();
    DB.machines.push({id:'S1',name:'Seg',group:'Photo',active:true});
    DB.parameters.push({id:'S1::p',machineId:'S1',name:'p',unit:'',threshold:20,warn:16,bound:'upper'});
    for(let i=0;i<10;i++) DB.readings.push({date:addDays('2026-08-01',i),paramId:'S1::p',value:2+i});   // rising
    DB.pmEvents.push({id:'r',date:'2026-08-11',machineId:'S1'});
    for(let i=0;i<10;i++) DB.readings.push({date:addDays('2026-08-11',i),paramId:'S1::p',value:2+i});   // reset, rising again
    a = assess(DB.parameters[0]);
    near('pm: slope uses post-PM segment only', a.slope, 1, 0.01);
    eq('pm: segment starts at the PM date', a.seg[0].date, '2026-08-11');

    // ---------- 10. MONTHLY REPORT BOUNDARIES ----------
    DB = blankDB();
    DB.machines.push({id:'M',name:'M',group:'Photo',active:true});
    DB.parameters.push({id:'M::p',machineId:'M',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:'2025-12-15',paramId:'M::p',value:2});
    DB.readings.push({date:'2026-01-15',paramId:'M::p',value:4});
    const rep = monthReport('2026-01');
    eq('report: previous month crosses year boundary', rep.prevYm, '2025-12');
    ok('report: month-on-month change computed', rep.rows[0].change!=null && Math.abs(rep.rows[0].change-100)<0.01,
       'change='+rep.rows[0].change);
    eq('report: months listed newest first', monthsAvailable()[0], '2026-01');

    // ---------- 11. IMPORTER PARSING ----------
    eq('parse: ISO date', parseDateCell('2026-09-15'), '2026-09-15');
    eq('parse: DD/MM/YYYY', parseDateCell('15/09/2026'), '2026-09-15');
    eq('parse: MM/DD/YYYY disambiguated by >12', parseDateCell('09/15/2026'), '2026-09-15');
    eq('parse: 2-digit year', parseDateCell('15/09/26'), '2026-09-15');
    eq('parse: junk rejected', parseDateCell('not a date'), null);
    eq('parse: empty rejected', parseDateCell(''), null);
    near('parse: thousands separator', cleanNum('11,420'), 11420);
    near('parse: percent sign', cleanNum('84%'), 84);
    near('parse: non-breaking space', cleanNum('1\u00A0234'), 1234);
    near('parse: negative', cleanNum('-3.5'), -3.5);
    ok('parse: N/A rejected', isNaN(cleanNum('N/A')));
    ok('parse: dash rejected', isNaN(cleanNum('-')));
    ok('parse: blank rejected', isNaN(cleanNum('')));
    ok('target col: Target', isTargetCol('Target'));
    ok('target col: lowercase limit', isTargetCol('limit'));
    ok('target col: Spec Limit', isTargetCol('Spec Limit'));
    ok('target col: reading column not matched', !isTargetCol('Lens heating drift'));

    // ---------- 12. NUMBER FORMATTING ----------
    eq('num: null', num(null), '—');
    eq('num: NaN', num(NaN), '—');
    eq('num: Infinity', num(Infinity), '—');
    eq('num: large', num(12345), '12345');
    eq('num: small', num(0.00123), '0.0012');
    eq('num: zero', num(0), '0.0012'.slice(0,0)+num(0), '');

    // ---------- 13. XSS / ESCAPING ----------
    ok('security: escapes angle brackets', esc('<script>').indexOf('<')===-1);
    ok('security: escapes quotes', esc('a"b').indexOf('"')===-1);
    DB = blankDB();
    DB.machines.push({id:'X1',name:'<img src=x onerror=alert(1)>',group:'Photo',active:true});
    DB.parameters.push({id:'X1::p',machineId:'X1',name:'"><b>bold',unit:'',threshold:10,warn:8,bound:'upper'});
    DB.readings.push({date:'2026-09-01',paramId:'X1::p',value:5});
    try {
      renderBoard();
      const html = document.querySelector('#boardGrid').innerHTML;
      ok('security: injected tag not live in DOM', document.querySelectorAll('#boardGrid img').length===0);
      ok('security: injected bold not live in DOM', document.querySelectorAll('#boardGrid b.injected').length===0);
      ok('security: board still renders with hostile names', document.querySelectorAll('.tile').length===1);
    } catch(e){ ok('security: board renders with hostile names', false, e.message); }

    return R;
  });

  const pass = results.filter(r=>r.pass).length;
  const fail = results.filter(r=>!r.pass);
  console.log(`\n${'='.repeat(64)}\nQA SUITE — ${pass}/${results.length} passed\n${'='.repeat(64)}`);
  if (fail.length) {
    console.log('\nFAILURES:');
    fail.forEach(f=>console.log(`  ✗ ${f.name}\n      ${f.detail}`));
  } else {
    console.log('\nAll assertions passed.');
  }
  console.log(errs.length ? '\nRUNTIME ERRORS:\n  '+errs.join('\n  ') : '\nNo runtime errors.');
  await b.close();
  process.exit(fail.length?1:0);
})();
