@echo off
REM ===================================================================
REM  PM Tracker launcher
REM  1. Moves any freshly saved data files out of Downloads into data\
REM  2. Opens the app, which then loads data\latest.js by itself
REM ===================================================================
setlocal
set "APP=%~dp0"
set "DL=%USERPROFILE%\Downloads"

if not exist "%APP%data" mkdir "%APP%data"
if not exist "%APP%data\backups" mkdir "%APP%data\backups"

REM newest latest.js wins; browsers add (1), (2) to repeat downloads
for /f "delims=" %%F in ('dir /b /o-d "%DL%\latest*.js" 2^>nul') do (
    move /y "%DL%\%%F" "%APP%data\latest.js" >nul 2>&1
    echo Moved %%F into data\latest.js
    goto :archives
)

:archives
for /f "delims=" %%F in ('dir /b /o-d "%DL%\pm-data-*.json" 2^>nul') do (
    move /y "%DL%\%%F" "%APP%data\" >nul 2>&1
)
for /f "delims=" %%F in ('dir /b /o-d "%DL%\pm-backup-*.json" 2^>nul') do (
    move /y "%DL%\%%F" "%APP%data\backups\" >nul 2>&1
)

start "" "%APP%index.html"
endlocal
