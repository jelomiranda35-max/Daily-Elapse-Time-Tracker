# Setting up PM Tracker for the team

One person does this once. Budget fifteen minutes.

## 1. Pick the shared folder

Any folder on a PC that stays switched on and that everyone can already browse to.
Note its UNC path — the `\\COMPUTER\share\` form, which you can paste into the File
Explorer address bar.

Example: `\\PC-ENG-01\shared\`

Confirm two things before going further:

- Everyone can **open** that folder.
- Everyone can **write** to it (right-click inside, New → Text Document; delete it after).

## 2. Put the app there

1. GitHub repo page → **Code → Download ZIP**.
2. Right-click the ZIP → **Extract All**.
3. Copy the `pm-tracker` folder into the shared folder.

You should end up with `\\PC-ENG-01\shared\pm-tracker\index.html`.

## 3. Check it opens

Double-click `index.html`. You should see the status board with demo data.

If the page is blank or unstyled, group policy is blocking scripts from a network
location. Fall back to a local copy: `C:\PM-Tracker\` on each PC, updated by copying
the folder over. Everything still works; only the update step gets more manual.

## 4. Check the recovery draft works

Press <kbd>F12</kbd> to open the console, paste this, press Enter:

```js
localStorage.setItem('t','1'); localStorage.getItem('t')
```

- Returns `"1"` → crash recovery is active. Good.
- Throws an error → the app still works, but nothing is held between sessions. The
  red banner on the data screen will say so. Save more often.

## 5. Load your real data

**Save, load & import → Paste from Excel.**

In Excel, select your existing grid including the header row, copy, paste it into the
box, and read the preview carefully:

- Is each machine name correct?
- Did it find a limit for every parameter?
- Are any parameters *lower*-limit ones (healthy when high, like lamp intensity or
  clamp vacuum)? If so, import those separately with the **lower-limit** box ticked.

Confirm, then go to **Machines & limits** and fix anything the importer guessed.

## 6. Set the PM schedule

On **Machines & limits → Machines & PM schedule**, edit each machine and set:

- **PM interval** — how many days between scheduled PM.
- **Last PM date** — when it was last done.
- **Remind this many days ahead** — how much warning you want. 10 is a sensible start.

The board starts flagging upcoming and overdue PM immediately.

## 7. Save and hand over

Click **Save data file**. Move the downloaded `pm-data-*.json` into the shared
`data` folder. Print `DAILY-USE.md` and pin it up.

## 8. Make desktop shortcuts

On each PC: browse to the shared folder, right-click `index.html` →
**Send to → Desktop (create shortcut)**. Rename it "PM Tracker".

---

## Two habits worth starting now

**Weekly backup.** On Fridays, click *Save dated backup* and drop the file in
`data/backups/`. Costs ten seconds and makes any mistake reversible.

**Keep the old Excel sheet for two weeks.** Run both in parallel and compare the
numbers. Any mismatch is a bug worth catching while you still have a fallback. Archive
the final workbook permanently once you cut over.
