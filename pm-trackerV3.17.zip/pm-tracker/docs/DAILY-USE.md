# PM Tracker — daily routine

Pin this near the workstation.

---

## Every morning

**1. Click the PM Tracker shortcut.** Your data loads by itself — the launcher
files yesterday's downloads into `data\` and the app reads `data\latest.js`.
If it opens showing demo data instead, go to Save, load & import → step 1.

**2. Enter readings.**
**Log readings** → check the date at the top → type your initials → work down
the list.

- Yesterday's value sits beside each field so you can sanity-check as you go.
- A field turns amber past the warn level, red at the limit.
- "below/above expected range" means check your decimal point.
- Tick **PM done** on any machine serviced today. You can backdate a missed one from
  Machines & limits → Log PM.

**3. Save the readings.** Click **Save these readings**.

**4. Save the file.** Click **Save data file** top-right. Two files download.
Leave them in Downloads — the shortcut files them next time you open the app.

**5. Send the board.**
Status board → **Screenshot view** → <kbd>Win</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> →
paste into the team chat or email. <kbd>Esc</kbd> or the round **X** to come back.

## Fixing a mistake

| Situation | What to use |
|---|---|
| Not saved yet | Just retype it |
| Changed an already-saved value | **Revert** on that row |
| A saved reading shouldn't exist | **Undo** on that row |
| Whole batch was wrong | **Undo last save** |

---

## Reading the board

| What you see | What it means |
|---|---|
| Green spine, "Normal" | Comfortable margin |
| Amber spine, "Warning" | Past the warn level — plan work |
| Red spine, "At limit" | Reached the limit — act now |
| Grey band on the chart | Normal range. The line leaving it is the signal |
| Red dashed line | The limit it must not reach |
| Small blue flag | A PM event. The trend restarts there |
| "6d left" | Days until it reaches the limit at the current rate |
| "119% of limit" | How far it has travelled from healthy baseline to limit |

**Columns**, **Chart size** and **Days** change the layout. **Tile content** hides
parts you don't need. **Theme** is top-right — try High contrast if the screen is
hard to read. All of it is remembered on your PC.

"PM reset" or "Rebuilding after PM" means that machine was serviced recently and
needs about three readings before a trend can be drawn. That is correct, not a bug.

---

## Once a month

**Monthly report** → pick the month → **Print report** → save as PDF.

**Analysis** → check *PM schedule against measured behaviour*. If a machine reaches
warning well before its PM is due, shorten the interval. If it holds comfortably past,
you may be servicing it too often.

---

## If something looks wrong

| Problem | Fix |
|---|---|
| Amber "unsaved changes" pill won't clear | Click **Save data file** |
| Closed the tab before saving | Reopen — it offers to restore your work |
| A reading was typed wrong | Re-enter it on the same date; it overwrites |
| A machine is gone | It may be retired. Machines & limits → edit → Active |
| Chart looks flat but the value is climbing | Check whether a PM reset it — the trend restarts at each PM |
