# Photo-Vac Engineering Notes

A personal equipment-engineering knowledge base: fundamentals, one page per machine, troubleshooting playbooks, engineering methods (KPIs, PM, RCA, eFMEA, RFQ, safety), and templates. It is fast, searchable, works in light and dark mode, and is built for phone use on the floor.

Built with [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/).

---

## 1. Preview it on your computer

You need **Python 3.9+** ([python.org](https://www.python.org/downloads/); on Windows, tick *Add Python to PATH* during install).

| System | Do this |
|---|---|
| **Windows** | Double-click **`start.bat`** |
| **macOS / Linux** | Run `./start.sh` in a terminal |

The first run takes about a minute to set up. Your browser then opens **http://127.0.0.1:8000**, and the page refreshes every time you save a file.

**Want a copy with no server at all?** Run `OFFLINE=true mkdocs build` (on Windows: `set OFFLINE=true && mkdocs build`), then open `site/index.html` directly.

---

## 2. Add content with one command

Run these from the project folder. After `start.bat` has run once, first activate the environment with `.venv\Scripts\activate` (Windows) or `. .venv/bin/activate` (macOS/Linux).

| I want to… | Command |
|---|---|
| Add a machine | `python scripts/kb.py tool "VEECO 2" Vacuum --ownership Primary` |
| Write a learning note | `python scripts/kb.py note "Cryo regeneration" --area Vacuum --tool IOMIL` |
| Start a playbook | `python scripts/kb.py playbook "Turbo pump fault"` |
| See what's left to confirm | `python scripts/kb.py todo` |

Each command creates the page from a template **and** adds it to the menu or list, so there's no YAML to edit by hand.

Areas with built-in icons and colors: `Pick-and-Place`, `Vacuum`, `Cleaning`, `Metrology`, `Photo`. Any other area name also works.

**Editing pages:** Open any `.md` file in `docs/` with any text editor (VS Code is ideal). You can also press `.` on your GitHub repo page to edit in the browser.

**Mark something to confirm on site:** `<span class="todo">base pressure spec</span>` shows as an amber marker, and `kb.py todo` lists them all.

---

## 3. Put it on GitHub

### ⚠️ Confidentiality first
- Keep the repo **private**.
- Store **general knowledge and your own notes only**: no recipes, specs, drawings, vendor manuals, part numbers, or production data.
- Reference internal documents by number (`SOP-1234`, `WO-5678`).
- Check your company's IT/IP policy before hosting anything online.

### Upload
1. On GitHub, create a new **private** repository (e.g. `photovac-kb`).
2. Choose **uploading an existing file** and drag in everything from this folder, **except** `.venv` and `site` if they exist. Or use git:
   ```bash
   git init && git add . && git commit -m "Initial knowledge base"
   git branch -M main
   git remote add origin https://github.com/<you>/photovac-kb.git
   git push -u origin main
   ```

### Reading options

| Option | Cost | Privacy | Notes |
|---|---|---|---|
| **Read on GitHub** (private repo) | Free | Private | Pages render as formatted Markdown; no site theme. *Best start.* |
| **Local preview** (`start.bat`) | Free | Private | The full site on your own computer |
| **GitHub Pages** | Free for public repos; paid plans for private | A published site can be publicly reachable | Only for fully generic content, or with an access-controlled plan |

**Publishing with Pages:** Every push to `main` runs `.github/workflows/deploy.yml`. It checks for broken links, then publishes to the `gh-pages` branch. In the repo, go to **Settings → Pages → Build and deployment → Deploy from a branch → `gh-pages` / root**.
**Not publishing?** Delete `.github/workflows/deploy.yml`.

---

## Project layout

```
docs/
  index.md          home page
  fundamentals/     how each tool type works
  tools/            one page per machine
  playbooks/        step-by-step troubleshooting
  engineering/      KPIs, PM, RCA, eFMEA, RFQ, safety
  notes/            dated learning notes
  page-templates/   copy-and-fill templates
  assets/           stylesheet and favicon
includes/
  abbreviations.md  hover definitions for acronyms (add your own)
scripts/
  kb.py             helper: tool / note / playbook / todo
  tool-template.md  template for every tool page
start.bat / start.sh  one-click local preview
mkdocs.yml          site settings and menu
```

## Customizing

- **Colors and look:** `docs/assets/stylesheets/extra.css`. The palette variables are at the top.
- **Acronym tooltips:** Add a line like `*[SPC]: Statistical Process Control` to `includes/abbreviations.md`.
- **Menu order:** Edit the `nav:` section in `mkdocs.yml`.

## Notes

- `requirements.txt` pins MkDocs below 2.0, which is planned to break Material's plugins. Leave the pin in place.
- **Pairs with `EE_Evidence_Tracker.xlsx`:** The tracker is your *evidence* (what, when, results); this site is your *knowledge* (how and why). Link them by writing log IDs such as `L-012` or `T-004` in your notes.
