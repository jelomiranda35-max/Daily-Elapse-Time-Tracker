#!/usr/bin/env python3
"""Helper for the Photo-Vac knowledge base.

Commands
  tool      Add a machine page and put it in the menu
  note      Start a dated learning note and list it on the Notes page
  playbook  Start a troubleshooting playbook and put it in the menu
  todo      List every "confirm on site" marker still open

Examples
  python scripts/kb.py tool "VEECO 2" Vacuum --ownership Primary
  python scripts/kb.py note "Cryo regeneration" --area Vacuum
  python scripts/kb.py playbook "Turbo pump fault"
  python scripts/kb.py todo
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
MKDOCS = ROOT / "mkdocs.yml"

AREAS = {
    # key: (icon, css dot class, fundamentals page)
    "pick-and-place": ("material/robot-industrial", "pnp", "pick-and-place.md"),
    "vacuum": ("material/gauge", "vac", "vacuum-basics.md"),
    "cleaning": ("material/spray-bottle", "cln", "cleaning.md"),
    "metrology": ("material/microscope", "met", "metrology.md"),
    "photo": ("material/lightbulb-on-outline", "pho", "photolithography.md"),
}


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "page"


def insert_before_marker(path: Path, marker: str, new_line: str) -> bool:
    """Insert new_line (matching the marker's indent) right above the marker line."""
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    for i, line in enumerate(lines):
        if marker in line:
            indent = line[: len(line) - len(line.lstrip())]
            lines.insert(i, f"{indent}{new_line}\n")
            path.write_text("".join(lines), encoding="utf-8")
            return True
    return False


def render_tool(name: str, area: str, ownership: str) -> str:
    icon, dot, fund = AREAS.get(slugify(area), ("material/cog-outline", "", None))
    tip = ""
    if fund:
        tip = ('!!! tip "Start with the fundamentals"\n'
               f"    Read [{area} fundamentals](../fundamentals/{fund}) before filling this page.")
        if slugify(area) == "vacuum":
            tip += " Ion mills: also read [ion beam milling](../fundamentals/ion-beam-milling.md)."
    tpl = (ROOT / "scripts" / "tool-template.md").read_text(encoding="utf-8")
    return tpl.format(
        name=name, area=area, ownership=ownership, icon=icon, dot=dot,
        own_class="primary" if ownership.lower() == "primary" else "",
        fundamentals_tip=tip,
    )


def cmd_tool(a: argparse.Namespace) -> int:
    slug = slugify(a.name)
    page = DOCS / "tools" / f"{slug}.md"
    if page.exists():
        print(f"Already exists: {page.relative_to(ROOT)}")
        return 1
    page.write_text(render_tool(a.name, a.area, a.ownership), encoding="utf-8")
    if not insert_before_marker(MKDOCS, "# TOOLS-END", f'- "{a.name}": tools/{slug}.md'):
        print("Note: TOOLS-END marker not found in mkdocs.yml; add the page to nav by hand.")
    _, dot, _ = AREAS.get(slugify(a.area), ("", "", None))
    own = f'<span class="own primary">{a.ownership}</span>' if a.ownership.lower() == "primary" else a.ownership
    insert_before_marker(DOCS / "tools" / "index.md", "<!-- TOOLS-TABLE-END -->",
                         f'| [{a.name}]({slug}.md) | <span class="area {dot}">{a.area}</span> | {own} |')
    print(f"Created {page.relative_to(ROOT)} and added it to the menu and tools table.")
    return 0


def cmd_note(a: argparse.Namespace) -> int:
    today = dt.date.today().isoformat()
    slug = f"{today}-{slugify(a.title)}"
    page = DOCS / "notes" / f"{slug}.md"
    if page.exists():
        print(f"Already exists: {page.relative_to(ROOT)}")
        return 1
    tags = f"tags:\n  - {a.area}\n" if a.area else ""
    page.write_text(
        f"---\n{tags}---\n\n# {a.title}\n\n"
        f"**Date:** {today} · **Tool:** {a.tool or ''} · **Learned from:** \n\n"
        "## What I learned\n\n\n## Why it works that way\n\n\n"
        "## How I applied it\n\n\n## Result\n\n\n## Still unclear\n\n",
        encoding="utf-8",
    )
    index = DOCS / "notes" / "index.md"
    text = index.read_text(encoding="utf-8")
    text = text.replace("*No notes yet. Write the first one today.*\n", "")
    entry = f"- **{today}**: [{a.title}]({slug}.md)\n"
    text = text.replace("<!-- NOTES-START -->\n", "<!-- NOTES-START -->\n" + entry, 1)
    index.write_text(text, encoding="utf-8")
    print(f"Created {page.relative_to(ROOT)} and listed it on the Notes page.")
    return 0


def cmd_playbook(a: argparse.Namespace) -> int:
    slug = slugify(a.title)
    page = DOCS / "playbooks" / f"{slug}.md"
    if page.exists():
        print(f"Already exists: {page.relative_to(ROOT)}")
        return 1
    tpl = (DOCS / "page-templates" / "playbook.md").read_text(encoding="utf-8")
    body = tpl.split("````markdown\n", 1)[1].rsplit("````", 1)[0]
    page.write_text(body.replace("Problem title", a.title), encoding="utf-8")
    if not insert_before_marker(MKDOCS, "# PLAYBOOKS-END", f'- "{a.title}": playbooks/{slug}.md'):
        print("Note: PLAYBOOKS-END marker not found; add the page to nav by hand.")
    print(f"Created {page.relative_to(ROOT)} and added it to the menu. Add a card on playbooks/index.md if you like.")
    return 0


def cmd_todo(_: argparse.Namespace) -> int:
    pat = re.compile(r'<span class="todo">(.*?)</span>')
    skip = {"page-templates", "index.md"}
    total = 0
    for md in sorted(DOCS.rglob("*.md")):
        rel = md.relative_to(DOCS)
        if rel.parts[0] in skip or rel.as_posix() == "index.md":
            continue
        items = [m.group(1) for line in md.read_text(encoding="utf-8").splitlines() for m in pat.finditer(line)]
        if items:
            total += len(items)
            print(f"\n{rel.as_posix()}  ({len(items)})")
            for it in items:
                print(f"  ◆ {it}")
    print(f"\n{total} item(s) to confirm on site.")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("tool", help="add a machine")
    t.add_argument("name")
    t.add_argument("area", help="Pick-and-Place, Vacuum, Cleaning, Metrology, Photo, or other")
    t.add_argument("--ownership", default="Cross-train", help="Primary, Cross-train, or Backup")
    t.set_defaults(func=cmd_tool)

    n = sub.add_parser("note", help="start a learning note")
    n.add_argument("title")
    n.add_argument("--area", default="")
    n.add_argument("--tool", default="")
    n.set_defaults(func=cmd_note)

    b = sub.add_parser("playbook", help="start a playbook")
    b.add_argument("title")
    b.set_defaults(func=cmd_playbook)

    d = sub.add_parser("todo", help="list items to confirm on site")
    d.set_defaults(func=cmd_todo)

    a = p.parse_args()
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
