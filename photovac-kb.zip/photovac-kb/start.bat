@echo off
REM Double-click to preview the knowledge base on Windows.
cd /d "%~dp0"
if not exist .venv (
  echo First run: setting up (about a minute^)...
  python -m venv .venv || (echo Python not found. Install Python 3 from python.org and tick "Add to PATH". & pause & exit /b 1)
  call .venv\Scripts\activate
  pip install -q -r requirements.txt
) else (
  call .venv\Scripts\activate
)
start "" http://127.0.0.1:8000
mkdocs serve
