*[ABS]: Air Bearing Surface: the patterned face of the slider that makes it fly
*[CD]: Critical Dimension: size of key printed features
*[CDA]: Clean Dry Air
*[DI]: Deionized (water)
*[eFMEA]: Equipment Failure Mode and Effects Analysis
*[FMEA]: Failure Mode and Effects Analysis
*[EHS]: Environment, Health and Safety
*[FSE]: Field Service Engineer (vendor)
*[LOTO]: Lockout/Tagout
*[MFC]: Mass Flow Controller
*[MTBF]: Mean Time Between Failures
*[MTTR]: Mean Time To Repair
*[OEE]: Overall Equipment Effectiveness
*[RCA]: Root Cause Analysis
*[RFQ]: Request for Quotation
*[RPN]: Risk Priority Number = Severity × Occurrence × Detection
*[SOP]: Standard Operating Procedure
*[SPC]: Statistical Process Control
*[WO]: Work Order
*[XPS]: X-ray Photoelectron Spectroscopy
*[UHV]: Ultra-high vacuum
*[PLC]: Programmable Logic Controller
*[SECS/GEM]: Standard protocol for equipment-to-host communication in fabs
*[WIP]: Work in progress
*[SDS]: Safety Data Sheet
*[PPE]: Personal Protective Equipment
