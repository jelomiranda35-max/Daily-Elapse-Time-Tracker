---
icon: material/notebook-edit-outline
---

# Notes

Dated learning notes, newest first. Each one answers: what I learned, why it works, how I applied it, and the result.

```bash
python scripts/kb.py note "IOMIL pump-down sequence" --area Vacuum
```

The command creates the note from the template and adds it to this list.

## All notes

<!-- NOTES-START -->
*No notes yet. Write the first one today.*
<!-- NOTES-END -->
