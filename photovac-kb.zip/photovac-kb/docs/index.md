---
hide:
  - navigation
  - toc
  - path
---

<div class="kb-hero" markdown>

# How the tools work, and how to fix them

My field notes for the Photo-Vac tools in slider ABS production. Built to open fast on the floor, on any screen.

<div class="kb-actions" markdown>
[:material-wrench: Fix a tool that's down](playbooks/index.md){ .md-button .md-button--primary }
[:material-cog-outline: Browse tools](tools/index.md){ .md-button }
</div>

</div>

<div class="kb-down" markdown>
**Tool down right now?** Start with a playbook:
[Slow pump-down / leak](playbooks/vacuum-leak.md) ·
[Pick errors / drops](playbooks/pick-errors.md) ·
[Ion source arcing](playbooks/ion-source.md)

Press ++slash++ or ++s++ to search every page.
{ .kb-hint }
</div>

## My tools

<div class="grid cards" markdown>

-   :material-robot-industrial:{ .lg } **Pick-and-Place** <span class="own primary">Primary</span>

    ---

    [DAU](tools/dau.md) · [BAU](tools/bau.md)

-   :material-gauge:{ .lg } **Vacuum** <span class="own primary">Primary</span>

    ---

    [IOMIL](tools/iomil.md) · [MR3](tools/mr3.md) · [VEECO](tools/veeco.md)

-   :material-school-outline:{ .lg } **Cross-training**

    ---

    [BAU (Cleaning)](tools/bau-cleaning.md) · [Nexsa](tools/nexsa.md) · [ZYGO](tools/zygo.md) · [Stepper](tools/stepper.md)

</div>

## Learn and work

<div class="grid cards" markdown>

-   :material-book-open-variant:{ .lg } **[Fundamentals](fundamentals/index.md)**

    How each tool type works: vacuum, ion milling, pick-and-place, lithography, metrology, cleaning.

-   :material-chart-line:{ .lg } **[Engineering](engineering/index.md)**

    KPIs, PM, RCA, eFMEA, RFQs, and safety: the methods behind the fixes.

-   :material-notebook-edit-outline:{ .lg } **[Notes](notes/index.md)**

    Dated learning notes: what I learned, how, and how I applied it.

-   :material-file-document-multiple-outline:{ .lg } **[Templates](page-templates/index.md)**

    Copy-and-fill pages for tools, notes, playbooks, and RCAs.

</div>

!!! warning "Keep it clean"
    General knowledge and personal notes only. No recipes, specs, drawings, vendor manuals, part numbers, or production data. Reference internal documents by number instead (SOP-…, WO-…).

<small>Amber-highlighted text like <span class="todo">this</span> marks something still to confirm on site. Hover a dotted term such as MTBF to see its meaning.</small>
