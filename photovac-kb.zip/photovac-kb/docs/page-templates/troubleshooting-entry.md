# Troubleshooting entry template

````markdown
### YYYY-MM-DD: Short title

- **Tool:**
- **Symptom / alarm:**
- **What changed recently:**
- **Checks done (in order):**
    1.
    2.
- **Root cause:**
- **Fix:**
- **Verification:**
- **Downtime:** min
- **Recurring?** Y/N (if Y, create or update a playbook)
- **Lesson:**
- **Ref:** WO-
````
