---
icon: material/file-document-multiple-outline
---

# Templates

Most templates have a one-line command that creates the page for you. Otherwise, copy the block and save it where the table says.

| Template | Fastest way | Saved to |
|---|---|---|
| [Tool page](tool-page.md) | `python scripts/kb.py tool "Name" Area` | `docs/tools/` |
| [Learning note](learning-note.md) | `python scripts/kb.py note "Title" --area Vacuum` | `docs/notes/` |
| [Playbook](playbook.md) | `python scripts/kb.py playbook "Title"` | `docs/playbooks/` |
| [Troubleshooting entry](troubleshooting-entry.md) | Copy into a tool page's notes | tool page |
| [RCA report](rca-report.md) | Copy | `docs/notes/` (no confidential data) |

Run `python scripts/kb.py todo` any time to list every item still marked <span class="todo">confirm</span>.
