# Tool page template

Create a new tool page with one command. It fills in the area icon, color, tags, and fundamentals link for you:

```bash
python scripts/kb.py tool "Tool Name" Vacuum --ownership Primary
```

Sections every tool page gets:

1. **Quick facts:** vendor, location, contacts, doc numbers
2. **Purpose:** what it does to the product
3. **Subsystems:** the major blocks
4. **Daily / shift checks**
5. **Preventive maintenance** and after-PM recovery
6. **Alarms and fixes**, linked to playbooks
7. **Health indicators I trend**
8. **My competency** checklist
9. **My notes**, collapsed, newest first

The source template lives at `scripts/tool-template.md`. Edit it to change every future tool page.
