# Playbook template

Create one with `python scripts/kb.py playbook "Title"`, or copy the block below.

````markdown
# Problem title

**Symptom:** What the operator or alarm reports.
**Tools:** Which machines this applies to.

!!! danger "Safety"
    Hazards involved and the LOTO/EHS procedure to follow.

## 1. What changed?

- [ ] Recent PM, part change, recipe change, or new lot?
- [ ] Any related alarms before this one?

## 2. Narrow it down

| Observation | Points to | Next step |
|---|---|---|
| | | |

## 3. Checks, most likely first

1.
2.
3.

## 4. Fix

## 5. Verify and record

- [ ] Health indicator back to normal: value vs. baseline
- [ ] Qual passed before release to production
- [ ] Logged in the Troubleshooting sheet (T-…)
- [ ] If recurring: PM checklist or eFMEA updated
````
