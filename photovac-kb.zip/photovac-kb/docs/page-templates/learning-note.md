# Learning note template

Create one with `python scripts/kb.py note "Title" --area Vacuum --tool IOMIL`. It saves a dated file and lists it on the [Notes](../notes/index.md) page automatically.

````markdown
---
tags:
  - Vacuum
---

# Title

**Date:** YYYY-MM-DD · **Tool:** · **Learned from:** trainer / vendor / manual / hands-on

## What I learned

## Why it works that way

## How I applied it

## Result

## Still unclear
````

Link the note to your Evidence Tracker by adding the log ID (e.g. `L-012`) under **How I applied it**.
