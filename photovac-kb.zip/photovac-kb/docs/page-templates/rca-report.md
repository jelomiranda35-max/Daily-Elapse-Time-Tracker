# RCA report template

````markdown
# RCA: Title

| | |
|---|---|
| Tool | |
| Date of event | |
| Author | |
| Ref | |

## 1. Problem statement
What happened, where, when, how much (data).

## 2. Containment
What was done immediately to protect production.

## 3. Analysis
Fishbone categories considered, 5-Why chain.

## 4. Root cause (verified)
Evidence that confirms it.

## 5. Corrective action
| Action | Owner | Due | Status |
|---|---|---|---|

## 6. Preventive action
PM, SOP, or FMEA updates.

## 7. Effectiveness check
Data after the fix.
````
