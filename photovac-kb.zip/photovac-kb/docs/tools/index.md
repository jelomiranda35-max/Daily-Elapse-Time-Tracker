---
icon: material/cog-outline
---

# Tools

One page per machine, all with the same layout: quick facts, purpose, subsystems, checks, PM, alarms, health indicators, and my competency.

| Tool | Area | Ownership |
|---|---|---|
| [DAU](dau.md) | <span class="area pnp">Pick-and-Place</span> | <span class="own primary">Primary</span> |
| [BAU](bau.md) | <span class="area pnp">Pick-and-Place</span> | <span class="own primary">Primary</span> |
| [IOMIL](iomil.md) | <span class="area vac">Vacuum</span> | <span class="own primary">Primary</span> |
| [MR3](mr3.md) | <span class="area vac">Vacuum</span> | <span class="own primary">Primary</span> |
| [VEECO](veeco.md) | <span class="area vac">Vacuum</span> | <span class="own primary">Primary</span> |
| [BAU (Cleaning)](bau-cleaning.md) | <span class="area cln">Cleaning</span> | Cross-train |
| [Nexsa](nexsa.md) | <span class="area met">Metrology</span> | Cross-train |
| [ZYGO](zygo.md) | <span class="area met">Metrology</span> | Cross-train |
| [Stepper](stepper.md) | <span class="area pho">Photo</span> | Cross-train |
<!-- TOOLS-TABLE-END -->

## Add a machine

```bash
python scripts/kb.py tool "New Tool" Vacuum --ownership Primary
```

Creates the page from the template, adds it to the menu, and adds a row to this table.
