---
icon: material/gauge
tags:
  - Vacuum
  - Primary
---

# MR3

!!! tip "Start with the fundamentals"
    Read [Vacuum fundamentals](../fundamentals/vacuum-basics.md) before filling this page. Ion mills: also read [ion beam milling](../fundamentals/ion-beam-milling.md).

## Quick facts

| Item | Details |
|---|---|
| **Vendor / model** | <span class="todo">confirm</span> |
| **Location / bay** | <span class="todo">confirm</span> |
| **Trainer** | <span class="todo">name</span> |
| **Vendor FSE** | <span class="todo">name / contact route</span> |
| **SOP** | <span class="todo">doc no.</span> |
| **PM checklist** | <span class="todo">doc no.</span> |

## Purpose

What this tool does to the product and where it sits in the [process flow](../fundamentals/slider-abs-overview.md).

<span class="todo">Fill in after your first walkthrough.</span>

## Subsystems

| Subsystem | Function | Notes |
|---|---|---|
| <span class="todo">e.g. vacuum system</span> | | |

## Daily / shift checks

- [ ] <span class="todo">check item</span>

## Preventive maintenance

| PM | Interval | Main tasks | Doc |
|---|---|---|---|
| <span class="todo">weekly PM</span> | | | |

**After-PM recovery:** <span class="todo">pump-down, seasoning, calibration, qual steps</span>

## Alarms and fixes

| Alarm / symptom | Likely cause | Fix | Playbook |
|---|---|---|---|
| <span class="todo">first alarm you see</span> | | | |

## Health indicators I trend

| Parameter | Normal | Action limit |
|---|---|---|
| <span class="todo">e.g. base pressure</span> | | |

## My competency

- [ ] Safety / LOTO
- [ ] Basic operation
- [ ] Daily checks
- [ ] PM, supervised
- [ ] PM, independent
- [ ] Troubleshooting
- [ ] Recovery / qual after PM

??? note "My notes (newest first)"
    *Add dated entries here, e.g. `2026-09-22: learned the door interlock sequence (L-012)`.*
