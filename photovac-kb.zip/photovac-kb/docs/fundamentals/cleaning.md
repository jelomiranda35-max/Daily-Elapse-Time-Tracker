---
icon: material/spray-bottle
---

# Cleaning & contamination

At nanometer fly heights, a single particle or residue can kill a slider. Cleaning tools remove particles, resist residue, and organic films between process steps.

## Common methods

| Method | Removes | Notes |
|---|---|---|
| Wet chemical cleaning | Residues, organics | Chemical concentration, temperature, bath life |
| Ultrasonic / megasonic | Particles | Power and frequency; too much can damage parts |
| DI water rinse | Chemical traces | Water resistivity is a key health indicator |
| Spin rinse dry / N₂ dry | Water marks | Incomplete drying leaves stains |
| Plasma / dry clean | Organics | Uses vacuum, so vacuum basics apply |

## Health indicators

- Particle counts on test pieces
- DI water resistivity
- Bath temperature, chemical concentration, bath age or change counts
- Filter differential pressure

## Where contamination comes from

People, flaking chamber shields, worn moving parts, degraded chemicals, dirty carriers, and poor handling. When a defect spike appears, check **what changed**: PM, parts, chemicals, or operators.

<span class="todo">BAU (Cleaning) process sequence and monitored parameters.</span>
