---
icon: material/book-open-variant
---

# Fundamentals

How each class of tool works, independent of any one machine. Learn the principle here, then the specifics on the machine's [tool page](../tools/index.md).

<div class="grid cards" markdown>

-   :material-transit-connection-variant:{ .lg } **[Slider ABS process](slider-abs-overview.md)**

    Where every Photo-Vac tool fits in the flow, and why it matters.

-   :material-gauge:{ .lg } **[Vacuum basics](vacuum-basics.md)**

    Pumps, gauges, pump-down curves, and how to tell a leak from outgassing.

-   :material-flare:{ .lg } **[Ion beam milling](ion-beam-milling.md)**

    Source, grids, neutralizer, stage, and what drifts.

-   :material-robot-industrial:{ .lg } **[Pick-and-place](pick-and-place.md)**

    Motion, vacuum pick-up, vision, and the pick cycle.

-   :material-lightbulb-on-outline:{ .lg } **[Photolithography](photolithography.md)**

    Coat, expose, develop; dose, focus, overlay.

-   :material-microscope:{ .lg } **[Metrology](metrology.md)**

    Interferometry (ZYGO) and XPS (Nexsa), and using both to watch your tools.

-   :material-spray-bottle:{ .lg } **[Cleaning](cleaning.md)**

    Methods, health indicators, and where contamination comes from.

</div>

## Learn every tool in five layers

1. **Purpose:** What does it do to the product, and where is it in the flow?
2. **Principle:** What physics or chemistry makes it work?
3. **Subsystems:** What are the major blocks, and how do they connect?
4. **Failure modes:** How does each subsystem fail, and what does that look like?
5. **Key parameters:** Which numbers tell me it's healthy?
