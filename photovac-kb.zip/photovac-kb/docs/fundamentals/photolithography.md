---
icon: material/lightbulb-on-outline
---

# Photolithography

Photolithography transfers a pattern from a mask (reticle) onto the part using light-sensitive resist. The resist pattern then acts as the mask for ion milling.

## Process flow

```mermaid
flowchart LR
  A[Clean / dehydrate] --> B[Coat resist] --> C[Soft bake] --> D[Align + expose<br/>stepper] --> E[Post-exposure bake] --> F[Develop] --> G[Inspect] --> H[Hard bake]
```

## The stepper

A stepper exposes one field at a time, then **steps** to the next position and repeats. Its projection lens usually reduces the reticle image. The main subsystems are the light source (often a mercury lamp i-line at 365 nm in older tools), illumination optics, reticle stage, projection lens, wafer/carrier stage, alignment system, and environmental control.

## Key parameters

| Parameter | What it controls | If wrong |
|---|---|---|
| Dose (exposure energy) | How much resist is exposed | CD too big or too small |
| Focus | Image sharpness in the resist | Sloped sidewalls, CD variation |
| Overlay / alignment | Position vs. previous layer | Features misplaced |
| CD (critical dimension) | Feature size | Out-of-spec ABS features |
| Resist thickness | Mask durability during etch | Resist punched through |

## Why the room is yellow

Resist is sensitive to UV and blue light, so photo areas use filtered yellow lighting.

## EE focus areas

- Lamp hours and intensity trend (lamps degrade and need replacement)
- Stage and alignment calibration
- Environmental stability (temperature and vibration affect overlay)

<span class="todo">Stepper model, light source, lamp change interval.</span>
