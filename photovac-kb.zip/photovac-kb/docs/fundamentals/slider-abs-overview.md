---
icon: material/transit-connection-variant
---

# Slider ABS process overview

The **air bearing surface (ABS)** is the patterned face of a hard-disk slider. As the disk spins, the ABS pattern generates air pressure that makes the slider "fly" a few nanometers above the disk. The shape and depth of the ABS features set the fly height and stability, so small etch-depth errors translate directly into yield loss.

!!! note "General industry flow"
    This is the typical sequence. Confirm your site's actual flow with process engineering and add it under <span class="todo">site flow notes</span> below.

```mermaid
flowchart LR
  A[Rows / bars from wafer] --> B[Cleaning]
  B --> C[Photo: coat, expose, develop]
  C --> D[Vacuum: ion mill / etch]
  D --> E[Resist strip + clean]
  E --> F{More etch depths?}
  F -- yes --> C
  F -- no --> G[Metrology: depth, profile, surface]
  G --> H[Next area]
```

## How the Photo-Vac tools fit

| Step | Tool type | What it controls |
|---|---|---|
| Handling | Pick-and-place | Correct part placement, no damage or drops |
| Patterning | Photo (stepper) | Feature shape, size (CD), and position (overlay) |
| Etching / deposition | Vacuum (ion mill, ion beam) | Etch depth, uniformity, sidewall profile, overcoat |
| Cleaning | Cleaning tools | Particles and residues that cause defects |
| Measurement | Metrology (ZYGO, Nexsa) | Proof that each step hit its target |

## Why this matters to an EE

Every tool problem eventually shows up as a **product** problem. Etch rate drift shows up as wrong ABS depth on ZYGO. A particle burst shows up as defects after cleaning. Learn to read metrology results and you'll catch your tools drifting before production does.

## Site flow notes

<span class="todo">Add your site's actual step sequence, step names, and which tool runs each step.</span>
