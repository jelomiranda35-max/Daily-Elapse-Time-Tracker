---
icon: material/gauge
---

# Vacuum basics

Nearly every vacuum problem is one of three things: **a leak, a pump that can't keep up, or something outgassing.** This page explains how to tell them apart.

## Pressure units and ranges

1 atm = 760 Torr ≈ 1013 mbar ≈ 101 325 Pa. 1 Torr ≈ 1.33 mbar ≈ 133 Pa.

| Range | Approx. pressure (Torr) | Typical pumps |
|---|---|---|
| Rough / low | 760 → ~1 | Dry or rotary vane pump |
| Medium | ~1 → 10⁻³ | Roots blower + backing pump |
| High | 10⁻³ → 10⁻⁹ | Turbomolecular or cryopump |
| Ultra-high | < 10⁻⁹ | Ion, cryo, bake-out |

## Pumps

- **Roughing pumps** (dry scroll, screw, rotary vane) take the chamber from atmosphere down to the crossover pressure. They also back the turbo pump.
- **Turbomolecular pumps** are high-speed rotor blades that knock gas molecules downward. They need a backing pump and are sensitive to shock, particles, and sudden venting.
- **Cryopumps** trap gas by freezing it onto very cold arrays. They don't need a backing pump while running, but they fill up and must be **regenerated** (warmed, purged, re-cooled).
- **Crossover** is the switch from roughing to high-vacuum pumping. Crossing over at too high a pressure overloads the high-vac pump. <span class="todo">Crossover pressure per tool: confirm from vendor spec.</span>

## Gauges

| Gauge | Range (typical) | Notes |
|---|---|---|
| Pirani / thermocouple | Atm → ~10⁻³ Torr | Reading depends on gas type |
| Capacitance manometer | Process pressures | Gas-independent; used for process control |
| Cold cathode (Penning) | ~10⁻² → 10⁻⁹ Torr | Can be slow to strike at low pressure; gets contaminated |
| Hot-filament ion gauge | ~10⁻³ → 10⁻¹⁰ Torr | Filament burnout is a common failure |

Compare gauges against each other. If one disagrees with the rest, suspect the gauge before the chamber.

## The pump-down curve

```mermaid
flowchart LR
  A["Volume gas<br/>(fast drop)"] --> B["Surface desorption<br/>(water vapor, slow tail)"] --> C["Base pressure<br/>(pumping = gas load)"]
```

- **Normal:** A fast drop, then a slow tail dominated by water vapor, then a stable base pressure.
- **Leak:** The curve flattens early and base pressure plateaus higher than normal. It doesn't improve with more pumping time.
- **Outgassing:** Pressure keeps slowly improving over hours. It's common after a chamber has been open, and worse with humid air or new parts.
- **Tip:** Overlay today's curve on a known-good curve. The shape tells you more than one pressure number.

## Leak checking

**Rate-of-rise test:** Pump down, isolate the chamber from the pumps, and record pressure over time.

$$Q = V \cdot \frac{\Delta P}{\Delta t}$$

where *Q* is leak rate (Torr·L/s), *V* is chamber volume (L), and ΔP/Δt is the pressure rise rate. A straight-line rise suggests a real leak. A rise that curves and levels off suggests outgassing.

**Helium leak detection:** Spray helium around suspect seals while a mass-spectrometer detector watches for it. Work from the top down (helium rises), and go slowly.

Usual suspects: door O-rings, recently opened flanges, feedthroughs, viewports, gas line fittings, bellows.

## Good habits

- Vent with dry N₂, not room air, to reduce water load.
- Wear gloves, keep O-rings clean, and never touch sealing surfaces bare-handed.
- Record base pressure and pump-down time after every PM. The trend is your early warning.

<span class="todo">Base pressure spec and normal pump-down time per tool.</span>
