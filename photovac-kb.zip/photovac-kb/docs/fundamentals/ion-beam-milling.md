---
icon: material/flare
---

# Ion beam milling (ion beam etch)

Ion beam milling removes material by physically sputtering it with a beam of energetic ions, usually argon. Because it's physical rather than chemical, it etches almost any material, including the hard ceramic and metal films in a slider. That's why it's widely used for ABS patterning.

## How it works

```mermaid
flowchart LR
  G[Ar gas] --> S[Ion source<br/>plasma]
  S --> GR[Grids<br/>extract + accelerate]
  GR --> B((Ion beam))
  N[Neutralizer<br/>adds electrons] --> B
  B --> W[Parts on stage<br/>tilt + rotate + cooled]
```

1. **Ion source:** Argon is ionized into a plasma (RF or DC/filament discharge).
2. **Grids:** A set of 2–3 perforated grids (screen, accel, sometimes decel) extracts ions and accelerates them into a beam. Beam voltage sets ion energy.
3. **Neutralizer:** Adds electrons to the beam so the parts and insulating films don't charge up and arc.
4. **Stage:** Holds the parts. It **tilts** to set the angle of incidence, **rotates** for uniformity, and is **cooled** to protect the photoresist.
5. **Photoresist mask:** Protects the areas that shouldn't be etched.

## Key parameters

| Parameter | Effect |
|---|---|
| Beam voltage | Ion energy → etch rate, damage |
| Beam current | Number of ions → etch rate |
| Accel voltage | Beam focus/divergence; protects grids |
| Incidence angle | Etch rate, sidewall angle, redeposition |
| Rotation | Uniformity across the stage |
| Stage cooling | Resist integrity (burnt resist is hard to strip) |
| Etch time | Depth (with etch rate) |

**Redeposition:** Sputtered material can land back on feature sidewalls. Tilting and rotating help control it.

## Typical failure modes

| Symptom | Likely areas |
|---|---|
| Etch rate drifting | Grid wear, source degradation, beam current calibration |
| Poor uniformity | Grid erosion or misalignment, rotation fault, source aging |
| Arcing / beam trips | Flakes on grids, grid shorts, contamination, charging (neutralizer) |
| Particles on parts | Chamber flaking (shields due for change), post-PM seasoning skipped |
| Burnt/hard-to-strip resist | Stage cooling or clamping problem |
| Can't reach base pressure | See [vacuum leak playbook](../playbooks/vacuum-leak.md) |

## After a PM

After a chamber is opened, it usually needs **pump-down → seasoning/conditioning → qualification** (etch rate and uniformity check, particle check) before running product. Skipping steps is a common cause of post-PM excursions.

<span class="todo">Site qual procedure and acceptance limits: reference doc number.</span>
