---
icon: material/microscope
---

# Metrology

Metrology tells you whether the process hit its target. For an EE, it's also the best early warning that a tool is drifting.

## Optical interferometry (ZYGO)

A white-light interferometer splits light into a reference beam and a beam reflected from the part. When they recombine, they form interference fringes. By scanning vertically and finding where fringe contrast peaks at each pixel, the tool builds a 3D height map.

Used for step height and etch depth, surface flatness, and profile shapes such as crown and camber.

**Things that disturb it:** vibration, a dirty objective, poor calibration, and very steep or transparent features.

## XPS (Nexsa)

X-ray photoelectron spectroscopy shines X-rays on the surface and measures the energy of emitted electrons. That energy identifies **which elements** are present and their **chemical state**, within roughly the top few nanometers. With an ion gun, it can also etch layer by layer to build a **depth profile**.

Used for surface contamination, film composition, and overcoat checks. It requires ultra-high vacuum, so the vacuum knowledge carries over.

## Using metrology to watch your tools

| Metrology signal | Possible tool cause |
|---|---|
| Etch depth trending off target | Ion mill etch rate drift |
| Depth varies across the carrier | Beam uniformity, rotation, tilt |
| Unexpected surface elements | Cleaning issue, chamber contamination |
| CD or overlay shift | Stepper dose, focus, or alignment |

## Basic concepts

- **Accuracy:** Closeness to the true value.
- **Precision/repeatability:** How consistently the same result is measured.
- **Gauge R&R:** How much of the measured variation comes from the gauge itself.

<span class="todo">What each metrology step measures on site, plus limits by doc number.</span>
