---
icon: material/robot-industrial
---

# Pick-and-place systems

Pick-and-place tools move parts precisely: pick, align, place, verify. Most of what goes wrong comes down to **vacuum, vision, motion, or sensors**, which is familiar territory for anyone who has built MCU projects.

## Subsystems

| Subsystem | What it does | MCU-world analogy |
|---|---|---|
| Motion (X, Y, Z, θ) | Moves the head | Stepper/servo + driver |
| Encoders / home sensors | Tell the controller where the axes are | Rotary encoder, limit switch |
| Vacuum pick-up | Nozzle/collet holds the part by suction | Vacuum pump + solenoid valve |
| Vacuum sensor | Confirms "part picked" / "part released" | Analog sensor + threshold |
| Vision | Camera finds part/fiducials and corrects offset | Camera + image processing |
| Controller / PLC | Runs the sequence and interlocks | The main loop |
| Safety interlocks | Door switches, light curtains, E-stop | Hardware interrupt / kill switch |

## A pick cycle

```mermaid
sequenceDiagram
  participant C as Controller
  participant M as Motion
  participant V as Vacuum
  participant I as Vision
  C->>M: Move to pick position
  C->>V: Vacuum ON
  V-->>C: Pressure below threshold? (part present)
  C->>M: Lift and move
  C->>I: Inspect / align
  I-->>C: Offset correction
  C->>M: Move to place position
  C->>V: Vacuum OFF / blow-off
  V-->>C: Part released?
```

Every arrow is a place where the cycle can fail. An alarm tells you *which step* failed, which narrows the search.

## Common failure modes

| Symptom | Check first |
|---|---|
| "No part detected" after pick | Nozzle clog/wear, vacuum filter, tubing leak, sensor threshold |
| Part dropped in transit | Weak vacuum, worn nozzle tip, acceleration too high |
| Part won't release | Blow-off not working, static, sticky nozzle |
| Placement offset | Vision calibration, lighting change, dirty lens, axis mechanics |
| Vision fails to find part | Lighting, focus, lens contamination, part orientation |
| Axis alarm / position error | Encoder, cable, driver, mechanical binding, lubrication |

## Health indicators to trend

- Vacuum level at the nozzle (picked vs. empty)
- Pick/placement error rate per shift
- Vision retry count
- Axis following error (if the controller exposes it)

<span class="todo">Normal vacuum readings and calibration interval for DAU/BAU.</span>
