---
icon: material/flash-alert-outline
---

# Ion source arcing & beam instability

**Symptom:** Beam trips, arc count alarms, unstable beam current, or etch rate or uniformity out of spec.  
**Tools:** <span class="area vac">IOMIL · VEECO</span>

!!! danger "High voltage"
    Ion sources use high voltage and RF. Follow LOTO and confirm grids and supplies are discharged before touching anything.

## 1. Pattern

- Arcing right after a PM → contamination, flakes, or insufficient conditioning
- Arcing that gradually increases over weeks → grid erosion, deposit buildup, source nearing PM
- Sudden onset → debris, a shorted grid, a failing supply or cable

## 2. Checks

1. **Grids:** Look for flakes, deposits, erosion, warping, and shorts between grids (check isolation per SOP).
2. **Grid alignment:** Misalignment hurts uniformity and increases grid impingement.
3. **Neutralizer:** Check emission current. A weak neutralizer can cause charging and arcs on the parts.
4. **Gas flow:** Check that the MFC is stable and reading correctly. Low flow causes plasma instability.
5. **Chamber shields:** Flaking shields drop debris into the beam path.
6. **Power supplies and cables:** Look for connector damage, insulation tracking, and loose grounds.

## 3. After fixing

- [ ] Condition/season the source per procedure
- [ ] Qualify etch rate and uniformity
- [ ] Run a particle check
- [ ] Record arc counts as a baseline for trending
