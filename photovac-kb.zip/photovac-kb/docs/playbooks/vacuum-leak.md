---
icon: material/gauge-low
---

# Slow pump-down / vacuum leak

**Symptom:** Chamber is slow to reach base pressure, can't reach it at all, or trips a pressure interlock.  
**Tools:** <span class="area vac">IOMIL · MR3 · VEECO · Nexsa</span>

## 1. What changed?

- [ ] Was the chamber recently opened (PM, part change, shield swap)?
- [ ] Was a vent done with room air instead of N₂?
- [ ] Were new parts installed (they outgas)?
- [ ] Any recent alarms on pumps or valves?

Most slow pump-downs follow a PM. Start with whatever was touched last.

## 2. Leak or outgassing?

Run a **rate-of-rise test** (isolate chamber, log pressure vs. time):

| Pressure rise shape | Meaning | Next step |
|---|---|---|
| Straight line, doesn't level off | Real leak | Go to step 3 |
| Curves and levels off | Outgassing / water | Keep pumping; consider bake or N₂ purge cycles |
| Normal rate | Pumping problem | Go to step 4 |

## 3. Find the leak

1. Check anything opened most recently: **door O-ring, flanges, viewports**.
2. Inspect O-rings for cuts, flat spots, hair, particles, and correct seating.
3. Use a helium leak detector, spraying **top-down** and **slowly**.
4. Check feedthroughs, bellows, gas line fittings, and vent valve seat.
5. If the gas system is suspect, check for backflow from process lines (valves passing).

## 4. Check the pumps

- [ ] Roughing pump: Is the base pressure normal? Any noise, oil level issues, or high temperature?
- [ ] Turbo: Is it at full speed? Any vibration or current alarms?
- [ ] Cryo: Is the array temperature normal? When was the last regen? Is it due now?
- [ ] Valves: Do gate and roughing valves fully open and close? Check pneumatic air supply.

## 5. Check the gauges

Does a second gauge agree? A contaminated cold cathode or a failed ion gauge filament can make a healthy chamber look bad.

## 6. Verify and record

- [ ] Base pressure and pump-down time back to normal (compare to a known-good curve)
- [ ] Rate-of-rise within limit <span class="todo">site limit</span>
- [ ] Qual run passed before releasing to production
- [ ] Logged in Troubleshooting sheet with root cause
