---
icon: material/wrench
---

# Playbooks

Step-by-step troubleshooting for when a tool is down. Every playbook follows the same path:

**safety → what changed → narrow it down → fix → verify → record**

!!! danger "Safety first"
    Follow site LOTO and EHS procedures before opening any tool. If a playbook step conflicts with a site SOP, **the SOP wins**.

<div class="grid cards" markdown>

-   :material-gauge-low:{ .lg } **[Slow pump-down / leak](vacuum-leak.md)**

    <span class="area vac">IOMIL · MR3 · VEECO · Nexsa</span>

-   :material-hand-back-left-off-outline:{ .lg } **[Pick errors / drops](pick-errors.md)**

    <span class="area pnp">DAU · BAU</span>

-   :material-flash-alert-outline:{ .lg } **[Ion source arcing](ion-source.md)**

    <span class="area vac">IOMIL · VEECO</span>

</div>

## New playbook

When the same problem shows up twice, write a playbook:

```bash
python scripts/kb.py playbook "Turbo pump fault"
```
