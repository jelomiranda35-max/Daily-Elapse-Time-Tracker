---
icon: material/hand-back-left-off-outline
---

# Pick errors / dropped parts

**Symptom:** "Part not detected" alarms, parts dropped in transit, parts not releasing, or placement offset.  
**Tools:** <span class="area pnp">DAU · BAU</span>

## 1. Read the alarm carefully

The alarm tells you *which step* of the cycle failed. See the [pick cycle](../fundamentals/pick-and-place.md#a-pick-cycle).

| Failed step | Focus |
|---|---|
| Pick confirmation | Vacuum path |
| During transfer | Vacuum strength, motion profile |
| Release | Blow-off, static, nozzle |
| Vision / alignment | Camera, lighting, calibration |
| Placement accuracy | Calibration, mechanics |

## 2. Vacuum path (most common)

Trace from the nozzle back to the source:

1. **Nozzle/collet tip:** worn, chipped, dirty, or clogged?
2. **Inline filter:** clogged? (A frequent cause of repeat errors.)
3. **Tubing and fittings:** cracked, kinked, or loose?
4. **Solenoid valve:** switching properly?
5. **Vacuum sensor:** Is the reading with a part vs. without a part clearly different? Is the threshold correct?
6. **Vacuum source:** Is the supply pressure normal?

## 3. Vision

- Clean the lens, check lighting intensity, and confirm nothing in the environment changed (new light, reflective surface).
- Re-run vision calibration if offsets appeared after a PM or collision.

## 4. Motion

- Check for axis alarms, unusual noise, or binding.
- Check whether errors increase at higher speed or acceleration.
- Look for cable wear at moving points and loose encoder connectors.

## 5. Is it the parts?

If one lot or carrier is much worse than others, the problem may be the incoming parts or carrier, not the tool.

## 6. Verify and record

- [ ] Run a test sequence (e.g. <span class="todo">N</span> picks) with zero errors
- [ ] Record the vacuum readings after the fix as the new baseline
- [ ] Log it; if it's recurring, add a check to the PM checklist
