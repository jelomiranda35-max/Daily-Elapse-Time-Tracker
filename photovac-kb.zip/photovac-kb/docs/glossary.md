---
icon: material/format-list-bulleted-square
---

# Glossary

ABS
:   Air Bearing Surface. The patterned face of the slider that makes it fly over the disk.

Base pressure
:   The lowest pressure a vacuum chamber reaches with no gas flowing. A key health indicator.

CD
:   Critical Dimension. The size of the key features printed by lithography.

Crossover
:   The switch from roughing pump to high-vacuum pump during pump-down.

Cryopump
:   A high-vacuum pump that traps gas on very cold surfaces. Needs periodic regeneration.

eFMEA
:   Equipment Failure Mode and Effects Analysis.

FSE
:   Field Service Engineer (vendor).

LOTO
:   Lockout/Tagout. Procedure for isolating energy before servicing.

MFC
:   Mass Flow Controller. Controls gas flow rate.

MTBF / MTTR
:   Mean Time Between Failures / Mean Time To Repair.

Neutralizer
:   Electron source that neutralizes the ion beam to prevent charging.

OEE
:   Overall Equipment Effectiveness = Availability × Performance × Quality.

Overlay
:   How accurately a lithography layer is aligned to previous layers.

PM
:   Preventive Maintenance.

Qual
:   Qualification. Tests that prove a tool is fit to run product after maintenance.

Rate-of-rise
:   A leak test measuring pressure increase in an isolated chamber.

RCA
:   Root Cause Analysis.

Regeneration (regen)
:   Warming a cryopump to release trapped gases, then cooling it again.

RFQ
:   Request for Quotation.

Seasoning
:   Running a chamber under process conditions after maintenance to stabilize it before product.

SECS/GEM
:   Standard protocol for communication between fab equipment and factory host systems.

SEMI E10
:   Industry standard defining equipment states and reliability metrics.

Stepper
:   Lithography tool that exposes one field at a time and steps across the substrate.

Turbo pump
:   Turbomolecular pump. High-speed rotor high-vacuum pump.

XPS
:   X-ray Photoelectron Spectroscopy. Surface chemical analysis (e.g. Nexsa).

<span class="todo">Add site-specific acronyms (DAU, BAU, MR3, IOMIL…) once confirmed.</span>
