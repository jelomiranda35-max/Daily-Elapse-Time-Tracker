---
icon: material/chart-line
---

# Engineering

The non-hardware side of the job: measuring, documenting, analyzing, and improving.

<div class="grid cards" markdown>

-   :material-speedometer:{ .lg } **[Equipment KPIs](kpis.md)**

    SEMI E10 states, availability, MTBF, MTTR, OEE.

-   :material-calendar-check:{ .lg } **[Preventive maintenance](pm.md)**

    Before, during, and after, plus vendor PMs.

-   :material-magnify-scan:{ .lg } **[RCA methods](rca.md)**

    5-Why, fishbone, 8D, and what a good RCA contains.

-   :material-table-alert:{ .lg } **[eFMEA](efmea.md)**

    Severity, occurrence, detection, and prioritizing risk.

-   :material-cart-outline:{ .lg } **[RFQs](rfq.md)**

    Writing requests and comparing quotes.

-   :material-shield-check-outline:{ .lg } **[Safety](safety.md)**

    Photo-Vac hazards and LOTO essentials.

</div>
