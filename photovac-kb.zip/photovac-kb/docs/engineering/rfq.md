---
icon: material/cart-outline
---

# RFQs

A Request for Quotation asks suppliers for price, lead time, and terms on a part or service.

## A good RFQ includes

- [ ] Clear description, part number, drawing or spec reference
- [ ] Quantity, and whether it's a one-time or recurring need
- [ ] Required delivery date
- [ ] Quality requirements (cleanroom packaging, certificates, cleanliness)
- [ ] Warranty and support expectations
- [ ] For services: scope, duration, onsite needs, safety requirements

## Comparing quotes

| Factor | Why it matters |
|---|---|
| Price | Total cost, including shipping and duties |
| Lead time | Downtime cost while waiting |
| OEM vs. third party | Fit, warranty, qualification needed |
| Quality history | Past failures with this supplier |
| Support | Response time when it breaks |

## Tips

- Know the cost of **downtime** per hour. It often matters more than the part price.
- Keep critical spares data: usage per year, lead time, and on-hand quantity.

<span class="todo">Site RFQ approval flow and system.</span>
