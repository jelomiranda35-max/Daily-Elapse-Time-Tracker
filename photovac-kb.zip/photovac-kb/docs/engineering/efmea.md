---
icon: material/table-alert
---

# eFMEA (Equipment FMEA)

An equipment FMEA lists how each part of a tool can fail, what that failure does, and how well we'd catch it. It's done **before** failures happen, unlike an RCA.

## Columns

| Column | Question |
|---|---|
| Item / function | What does this subsystem do? |
| Failure mode | How can it fail to do that? |
| Effect | What happens to the tool and the product? |
| Severity (S) | How bad is the effect? (1–10) |
| Cause | Why would it fail? |
| Occurrence (O) | How often? (1–10) |
| Current controls | What prevents or detects it today? |
| Detection (D) | How likely are we to catch it before it hurts? (1 = certain, 10 = can't detect) |
| RPN | S × O × D |
| Actions | What will we do to reduce risk? |

## Prioritizing

The classic method ranks by **RPN = S × O × D**. The newer AIAG-VDA approach uses **Action Priority (High/Medium/Low)** tables that weigh severity first. <span class="todo">Which method does the site use?</span>

**Always look at high Severity items**, even if the RPN is low.

## Example row

| Item | Failure mode | Effect | S | Cause | O | Control | D | RPN |
|---|---|---|---|---|---|---|---|---|
| Nozzle vacuum filter | Clogged | Pick errors, dropped parts | 6 | No replacement interval | 5 | Operator notices alarms | 4 | 120 |

Action: Add filter replacement to PM and trend nozzle vacuum → O and D go down.

## Where eFMEA inputs come from

Your Troubleshooting log, vendor service bulletins, RCAs, and PM findings.
