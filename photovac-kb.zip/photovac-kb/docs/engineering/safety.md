---
icon: material/shield-check-outline
---

# Safety

!!! danger "Site procedures always win"
    This page is a study summary. Your site's EHS procedures, LOTO program, and qualifications are the authority.

## Hazards in Photo-Vac

| Hazard | Where | Key controls |
|---|---|---|
| Electrical / high voltage | Ion sources, power supplies, RF generators | LOTO, verify zero energy, discharge |
| RF energy | Plasma sources | Interlocks, shielding intact |
| Pressurized and hazardous gases | Process gas lines, N₂, CDA | Gas procedures, leak checks, detectors |
| Vacuum / implosion | Viewports, chambers | Never stress viewports; vent properly |
| Cryogenic / cold | Cryopumps | Proper warm-up before service |
| Hot surfaces | Heaters, pumps, bakes | Cool-down time, gloves |
| Chemicals | Cleaning, photo | SDS, PPE, spill kits |
| UV light | Stepper / exposure tools | Interlocks, don't bypass covers |
| Moving parts | Pick-and-place, robots, stages | Interlocks, LOTO before reaching in |
| X-rays | XPS | Interlocks; only qualified staff service |

## LOTO essentials

1. Notify affected people.
2. Shut down the equipment normally.
3. Isolate **all** energy sources: electrical, pneumatic, gas, vacuum, stored energy.
4. Apply your own lock and tag.
5. Release stored energy (capacitors, springs, pressure).
6. **Verify** zero energy by trying to start or measuring.
7. Reverse the steps carefully when finished.

## Rules I don't break

- Never bypass an interlock to "save time"
- Never work on a tool I'm not qualified for
- Stop and ask when unsure
