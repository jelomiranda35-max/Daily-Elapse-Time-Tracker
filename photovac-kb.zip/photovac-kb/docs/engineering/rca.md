---
icon: material/magnify-scan
---

# RCA methods

Root cause analysis finds **why** something failed, so the fix prevents it from coming back.

!!! tip "Rule of thumb"
    If the corrective action is "replaced part" and nothing else, you've fixed the symptom, not the root cause. Ask why the part failed.

## 5-Why

Ask "why" until you reach a cause you can act on to prevent recurrence.

| Why? | Answer |
|---|---|
| Why did the tool stop? | Pick errors exceeded the limit |
| Why were there pick errors? | Vacuum at the nozzle was low |
| Why was the vacuum low? | Inline filter was clogged |
| Why was the filter clogged? | It's never replaced; not in the PM checklist |
| Why isn't it in the PM? | Checklist was written before this filter was added |

**Root cause:** PM checklist doesn't cover the filter. **Action:** Add filter replacement to the PM checklist.

## Fishbone (Ishikawa)

Brainstorm causes by category, then test the likely ones with data.

```mermaid
flowchart LR
  M1[Machine] --> P((Problem))
  M2[Method] --> P
  M3[Material] --> P
  M4[Man / people] --> P
  M5[Measurement] --> P
  M6[Environment] --> P
```

## 8D (for bigger issues)

| D | Step |
|---|---|
| D1 | Form the team |
| D2 | Describe the problem (what, where, when, how much) |
| D3 | Containment: protect production now |
| D4 | Root cause(s), verified with data |
| D5 | Choose permanent corrective actions |
| D6 | Implement and validate |
| D7 | Prevent recurrence (update PMs, SOPs, FMEA) |
| D8 | Recognize the team and close |

## A good RCA has

- A clear problem statement with data
- A root cause **verified** by evidence (not guessed)
- Corrective **and** preventive actions with owners and dates
- A check that the fix worked (data after)

Use the [RCA report template](../page-templates/rca-report.md).
