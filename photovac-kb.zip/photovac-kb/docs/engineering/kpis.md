---
icon: material/speedometer
---

# Equipment KPIs

Equipment time is commonly categorized using the **SEMI E10** standard. Learn these states, because every KPI is built on them.

| State | Meaning |
|---|---|
| Productive | Running product |
| Standby | Ready but not running (no operator, no material) |
| Engineering | Experiments, process development |
| Scheduled downtime | PMs, planned changes, quals |
| Unscheduled downtime | Breakdowns: the one you're fighting |
| Non-scheduled | Not planned to be used (holidays, shutdown) |

## Core formulas

$$\text{Availability} = \frac{\text{Uptime}}{\text{Total time}}$$

$$\text{MTBF} = \frac{\text{Productive (operating) time}}{\text{Number of failures}}$$

$$\text{MTTR} = \frac{\text{Total repair time}}{\text{Number of repairs}}$$

$$\text{OEE} = \text{Availability} \times \text{Performance} \times \text{Quality}$$

- **MTBF up** means the tool fails less often (reliability improving).
- **MTTR down** means you fix it faster (maintainability improving).

## How an EE moves these numbers

| KPI | Levers |
|---|---|
| MTBF | Better PMs, fixing root causes, replacing parts before failure |
| MTTR | Playbooks, spare parts on hand, training, clear alarms |
| Availability | Both of the above, plus shorter PMs and faster quals |

## Pareto thinking

Rank downtime by cause. Usually a few causes explain most of the lost time, so fix those first. Your Troubleshooting log is the data source.

<span class="todo">Site definitions and targets for each KPI.</span>
