---
icon: material/calendar-check
---

# Preventive maintenance

A PM exists to prevent failures. A PM that's done but doesn't prevent failures needs to change.

## Before

- [ ] Coordinate timing with production (lot status, WIP)
- [ ] Check parts and consumables are in stock
- [ ] Review the checklist and last PM notes
- [ ] Record "before" readings (base pressure, vacuum levels, counts)

## During

- [ ] LOTO and PPE per site procedure
- [ ] Follow the checklist in order and record measured values, not just checkmarks
- [ ] Photograph anything worn or unusual
- [ ] Keep sealing surfaces and O-rings clean

## After

- [ ] Recovery: pump-down, seasoning, calibration
- [ ] Qualification per procedure before releasing to production
- [ ] Record "after" readings and compare with "before"
- [ ] Note anything that should change in the PM checklist

## Vendor PMs

Vendor visits are free training. Shadow the whole visit, ask why each step is done, and write down what they check that isn't in our checklist.

## Improving PMs

If a failure happens shortly after a PM, or the same part keeps failing between PMs, the PM interval or content may need adjusting. Bring data: your Troubleshooting log.
