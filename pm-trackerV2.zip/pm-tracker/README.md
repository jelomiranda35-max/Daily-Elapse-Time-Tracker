# PM Tracker

A single-screen status board for preventive-maintenance parameter monitoring.
Replaces the Excel chart sheet and the screenshot-to-the-team routine.

No installation, no dependencies, no build step, no server required. It is plain
HTML, CSS and JavaScript, and runs by double-clicking a file.

---

## What it does

- **Status board** — one tile per machine, all on one screen, built to be screenshotted and sent to the team.
- **Daily entry** — type readings with yesterday's value beside each field, tick a box when PM is done.
- **Trend charts** — full-size charts with limit lines and PM markers.
- **Analysis** — ranks machines by risk, flags anything accelerating against its own normal behaviour, and compares your PM intervals against how the machines actually behave.
- **Monthly report** — breaches, PM work done, month-on-month movement, print-ready.
- **Excel import** — paste your existing grid and it creates machines, limits and history in one go.

---

## Install (office PC)

You need no admin rights and no software to install.

1. On the GitHub repo page, click **Code → Download ZIP**.
2. Right-click the downloaded ZIP → **Extract All**.
3. Copy the extracted `pm-tracker` folder to the shared folder, e.g. `\\PC-ENG-01\shared\pm-tracker\`.
4. Inside it, create an empty folder called `data` if one is not already there.
5. Open `index.html` by double-clicking it.

That is the whole install. Everyone else opens the same `index.html` over the network.

To put a shortcut on each desktop: right-click `index.html` → **Send to → Desktop (create shortcut)**.

> **Browser note.** Chrome or Edge. If the board loads but nothing renders, the PC's
> policy is blocking scripts from a network location — copy the folder to the local
> `C:\PM-Tracker\` instead and point the shortcut there.

---

## First run

The app opens showing **demo data** so you can click around safely. Nothing you do
to the demo touches your real files.

To bring in your own data, go to **Save, load & import**:

- **Already have a data file?** Click *Load data file* and pick the newest `pm-data-*.json` from the `data` folder.
- **Starting from Excel?** Select your grid in Excel including the header row, copy, and paste it into the box. Review the preview, then confirm. Machines, limits and history are created in one pass.
- **Starting from scratch?** Go to **Machines & limits** and add them by hand.

After importing, check **Machines & limits** — anything the importer could not find a
target column for gets a placeholder limit that you should correct before relying on
the alerts.

---

## Daily routine

1. Open `index.html` from the shared folder.
2. **Save, load & import → Load data file →** pick the newest `pm-data-*.json`.
3. **Log readings** — enter today's values. Tick *PM done* on any machine that was serviced.
4. Click **Save these readings**.
5. Click **Save data file**. It downloads as `pm-data-YYYY-MM-DD-HHMMSS.json`.
6. Move that file from `Downloads` into the shared `data` folder.
7. **Status board → Screenshot view →** press <kbd>PrtScn</kbd> or <kbd>Win</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd>, and send it to the team.

The amber pill at the top-right shows unsaved changes and does not go away until you
save. If the tab closes before you save, the app offers to restore your work when it
reopens.

### Why saving downloads instead of writing directly

A browser opened from a file path is not allowed to write to disk — that is a security
boundary in Chrome and Edge, not a limitation of this app. Every save is therefore a
download you move into place. See `docs/RECOVERY.md` for how to lift this restriction
if an internal web server ever becomes available.

---

## File naming

Saves are stamped with the date and the time of day:

```
pm-data-2026-09-15-143052.json
        └── date ──┘ └─ HHMMSS
```

Nothing is ever silently overwritten, and sorting the folder by name puts the newest
file last. Always load the newest one.

---

## Updating the app

You (the maintainer) do this; nobody else needs to touch it.

```bash
git pull                       # on your own machine
```

Then copy `index.html`, `assets/` and `src/` into the shared folder, replacing what is
there. **Do not touch `data/`** — that is everyone's readings and it is not in the repo.

Users see the update the next time they refresh.

---

## Repository layout

```
pm-tracker/
├── index.html              Application shell. Open this to run.
├── README.md               This file.
├── .gitignore              Keeps real data out of the public repo.
│
├── assets/
│   ├── styles.css          All styling.
│   └── favicon.svg         Tab icon.
│
├── src/                    Loaded in numeric order by index.html.
│   ├── 01-core.js          State, storage, date and number helpers, migration.
│   ├── 02-analysis.js      Status, trend, projection, anomaly, risk, PM cycles.
│   ├── 03-charts.js        All SVG drawing.
│   ├── 04-board.js         Router and the status board.
│   ├── 05-entry.js         Reading entry and the trend-chart screen.
│   ├── 06-reports.js       Analysis, machine detail, monthly report.
│   ├── 07-config.js        Machine and parameter setup, dialogs.
│   ├── 08-data.js          Save, load, CSV export, Excel paste importer.
│   ├── 09-demo.js          Sample dataset. Safe to delete once live.
│   └── 10-boot.js          Startup and draft recovery.
│
├── data/                   Your real data. NOT in the repo.
│   ├── pm-data-*.json      Saved data files, newest last by name.
│   ├── backups/            Dated snapshots.
│   └── config.example.json Shape reference only, safe to commit.
│
└── docs/
    ├── INSTALL.md          Setup for the whole team, step by step.
    ├── DAILY-USE.md        One-page routine to print and pin up.
    └── RECOVERY.md         If it breaks, how to get your data out.
```

The number prefixes in `src/` are the load order, not decoration. These are classic
scripts rather than ES modules, because ES modules fail on a `file://` path. Load order
matters, so keep the prefixes and add new files in sequence.

---

## How much data it holds

Measured on the real app in Chrome, not estimated.

| History | Readings | File size | Slowest screen |
|---|---|---|---|
| 1 year | 6,800 | 0.6 MB | 56 ms |
| 5 years | 34,000 | 2.9 MB | 58 ms |
| 10 years | 68,000 | 5.8 MB | 86 ms |
| 20 years | 137,000 | 11.6 MB | 167 ms |

Speed is not the limit. The limit is the crash-recovery draft, which lives in browser
storage capped at about 5 MB. Past that the app keeps working normally but can no
longer hold your unsaved work if the tab closes — it warns you when this happens.

For a fleet of 30 machines with around 45 tracked parameters, that ceiling arrives at
roughly **four years** of daily readings.

**Archive once a year past year three.** Copy the current file to
`data/backups/pm-archive-2026.json`, then delete readings older than three years from
the working file. Trends and PM cycle statistics only ever look at recent data, so
nothing on the board changes. Keep the archives — they are your long-term record.

---

## Privacy

The code is public; the data is not. `.gitignore` excludes `data/`, all `*.csv`, and
any `pm-data-*.json`. Machine names, limits and readings never leave the shared folder.

Be aware that a file committed once stays in git history even after it is deleted, so
check `git status` before your first push.

---

## If something breaks

Your data is plain JSON and exports to CSV that opens directly in Excel. You are never
locked in. See `docs/RECOVERY.md`.

---

## Adding a machine

**Machines & limits → Machines & PM schedule → Add machine**, then add one or two
parameters for it. Never edit the JSON by hand.

Retire machines instead of deleting them — history stays intact and old reports still
render.
