# PM Tracker — daily routine

Pin this near the workstation.

---

## Every morning

**1. Open** the PM Tracker shortcut.

**2. Load the data.**
Save, load & import → **Load data file** → pick the **newest** `pm-data-*.json`
in the `data` folder. Sorted by name, the newest is at the bottom.

**3. Enter readings.**
**Log readings** → check the date at the top → type your initials → work down
the list.

- Yesterday's value sits beside each field so you can sanity-check as you go.
- A field turns amber past the warn level, red at the limit.
- "below/above expected range" means check your decimal point.
- Tick **PM done** on any machine serviced today. You can backdate a missed one from
  Machines & limits → Log PM.

**4. Save the readings.** Click **Save these readings**.

**5. Save the file.** Click **Save data file** top-right. Move the downloaded
`pm-data-*.json` from `Downloads` into the shared `data` folder.

**6. Send the board.**
Status board → **Screenshot view** → <kbd>Win</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> →
paste into the team chat or email. <kbd>Esc</kbd> to come back.

---

## Reading the board

| What you see | What it means |
|---|---|
| Green spine, "Normal" | Comfortable margin |
| Amber spine, "Warning" | Past the warn level — plan work |
| Red spine, "At limit" | Reached the limit — act now |
| Grey band on the chart | Normal range. The line leaving it is the signal |
| Red dashed line | The limit it must not reach |
| Small blue flag | A PM event. The trend restarts there |
| "6d left" | Days until it reaches the limit at the current rate |
| "119% of limit" | How far it has travelled from healthy baseline to limit |

**Compact / Standard / Large** change tile size. Compact fits the whole fleet on one
screen.

---

## Once a month

**Monthly report** → pick the month → **Print report** → save as PDF.

**Analysis** → check *PM schedule against measured behaviour*. If a machine reaches
warning well before its PM is due, shorten the interval. If it holds comfortably past,
you may be servicing it too often.

---

## If something looks wrong

| Problem | Fix |
|---|---|
| Amber "unsaved changes" pill won't clear | Click **Save data file** |
| Closed the tab before saving | Reopen — it offers to restore your work |
| A reading was typed wrong | Re-enter it on the same date; it overwrites |
| A machine is gone | It may be retired. Machines & limits → edit → Active |
| Chart looks flat but the value is climbing | Check whether a PM reset it — the trend restarts at each PM |
