/* ==========================================================================
   04-board.js — router + the status board
   The board is the screenshot. One tile per machine, identical framing, sized
   so 14–18 tiles fit a 1366x768 screen without scrolling.
   ========================================================================== */

function show(name){
  screen=name;
  $$('.page').forEach(function(s){ s.hidden = s.id!=='scr-'+name; });
  $$('#nav button').forEach(function(b){ b.setAttribute('aria-current', String(b.dataset.screen===name)); });
  if(name!=='board') exitWall();
  render();
  window.scrollTo(0,0);
}

function render(){
  var stamp=new Date().toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
  ['#printDate','#printDate2','#printDate3','#printDate4'].forEach(function(s){
    var e=$(s); if(e) e.textContent='Generated '+stamp;
  });
  var ws=$('#wallStamp'); if(ws) ws.textContent=stamp+(DB.meta.site?'  ·  '+DB.meta.site:'');
  var pt=$('#printTitle'); if(pt) pt.textContent='Equipment PM Status Board'+(DB.meta.site?' — '+DB.meta.site:'');
  $('#asOf').textContent = DB.readings.length
    ? DB.readings.length.toLocaleString()+' readings · latest '+fmtDate(latestDate())
    : 'No readings yet';
  $('#railFoot').textContent = activeMachines().length+' machines · '+activeParams().length+
    ' parameters'+(DB.meta.site?' · '+DB.meta.site:'');
  paintSaveState();

  if(!DB.parameters.length && screen!=='config' && screen!=='data'){ renderEmpty(); return; }
  ({ board:renderBoard, entry:renderEntry, charts:renderCharts, analysis:renderAnalysis,
     machine:renderMachine, report:renderReport, config:renderConfig, data:renderData
   }[screen]||function(){})();
  updateNavBadge();
}

function updateNavBadge(){
  var rows=assessAll();
  var n=rows.filter(function(r){ return r.status==='crit'; }).length;
  var w=rows.filter(function(r){ return r.status==='warn'; }).length;
  var b=$('#navBadge');
  if(n){ b.hidden=false; b.className='badge'; b.textContent=n; }
  else if(w){ b.hidden=false; b.className='badge amber'; b.textContent=w; }
  else b.hidden=true;
}

function renderEmpty(){
  var host=$('#scr-'+screen);
  var keep=host.querySelector('.phead');
  host.innerHTML=''; if(keep) host.appendChild(keep);
  var d=document.createElement('div'); d.className='panel';
  d.innerHTML='<div class="empty"><h4>Nothing is set up yet</h4>'+
    '<p>Load an existing data file, paste your Excel grid to bring in machines and history at once, '+
    'or open the demo to see how it all works.</p>'+
    '<div style="display:flex;gap:9px;justify-content:center;flex-wrap:wrap">'+
    '<button class="btn primary" onclick="show(\'data\')">Load or import data</button>'+
    '<button class="btn" onclick="loadDemo()">Open demo data</button>'+
    '<button class="btn" onclick="show(\'config\')">Add machines by hand</button></div></div>';
  host.appendChild(d);
}

/* ---------- toolbar segmented controls ---------- */
function segChips(sel, items, current, onPick){
  var host=$(sel); if(!host) return;
  host.innerHTML = items.map(function(it){
    return '<button class="chip" data-v="'+esc(it[0])+'" aria-pressed="'+(current===it[0])+'">'+esc(it[1])+'</button>';
  }).join('');
  host.onclick=function(e){
    var b=e.target.closest('.chip'); if(!b) return;
    onPick(b.dataset.v); render();
  };
}

/* ========================= THE BOARD ========================= */
function renderBoard(){
  groupChips('#boardGroups','board');
  segChips('#boardSort', [['risk','By risk'],['name','By name'],['group','By group']],
    boardSort, function(v){ boardSort=v; });
  segChips('#boardDensity', [['dense','Compact'],['normal','Standard'],['wide','Large']],
    boardDensity, function(v){ boardDensity=v; });

  var all=assessAll();
  var rows=byGroup(all,'board');
  var machines=machineRollup(rows);

  /* sort */
  if(boardSort==='risk') machines.sort(function(a,b){ return b.risk-a.risk; });
  else if(boardSort==='name') machines.sort(function(a,b){ return a.m.name.localeCompare(b.m.name); });
  else machines.sort(function(a,b){
    var g=a.m.group.localeCompare(b.m.group);
    return g!==0?g:(b.risk-a.risk);
  });

  /* --- summary bar --- */
  var crit=rows.filter(function(r){ return r.status==='crit'; });
  var warn=rows.filter(function(r){ return r.status==='warn'; });
  var soon=rows.filter(function(r){ return r.status!=='crit' && r.dtt!=null && r.dtt<=14; });
  var pmDue=activeMachines().map(pmSchedule).filter(function(s){ return s&&s.due; });
  var pmOver=pmDue.filter(function(s){ return s.overdue; });
  var nextPM=activeMachines().map(function(m){ return {m:m,s:pmSchedule(m)}; })
    .filter(function(x){ return x.s; }).sort(function(a,b){ return a.s.inDays-b.s.inDays; })[0];
  var worst=rows.length?rows.reduce(function(a,b){ return b.risk>a.risk?b:a; }):null;

  $('#boardSummary').innerHTML =
    sumCell(machines.length,'Machines on board', rows.length+' parameters tracked','')+
    sumCell(crit.length,'At limit', crit.length?'act now':'none', crit.length?'crit':'ok')+
    sumCell(warn.length,'In warning', warn.length?'plan work':'none', warn.length?'warn':'ok')+
    sumCell(soon.length,'Reaching limit in 14d','at current rate', soon.length?'crit':'ok')+
    sumCell(nextPM?(nextPM.s.overdue?Math.abs(nextPM.s.inDays)+'d late':nextPM.s.inDays+'d'):'—',
      'Next PM due', nextPM?nextPM.m.name:'—',
      nextPM&&nextPM.s.overdue?'crit':(nextPM&&nextPM.s.due?'warn':''))+
    sumCell(pmDue.length,'PM due soon', pmOver.length?pmOver.length+' overdue':'within lead time',
      pmOver.length?'crit':(pmDue.length?'warn':'ok'));

  /* --- alerts --- */
  var A='';
  function list(rs){
    return '<div class="mlist">'+rs.slice(0,7).map(function(r){ return esc(r.m.name+' — '+r.p.name); }).join('  ·  ')+
      (rs.length>7?'  and '+(rs.length-7)+' more':'')+'</div>';
  }
  if(crit.length) A+='<div class="alert crit"><span class="ic">&#9650;</span><div><b>'+crit.length+
    ' parameter'+(crit.length===1?' has':'s have')+' reached the limit.</b>'+list(crit)+'</div></div>';
  if(soon.length) A+='<div class="alert crit"><span class="ic">&#9650;</span><div><b>'+soon.length+
    ' parameter'+(soon.length===1?'':'s')+' will reach the limit within two weeks</b> at the current rate.'+
    '<div class="mlist">'+soon.slice(0,7).map(function(r){
      return esc(r.m.name+' — '+r.p.name+' in '+Math.round(r.dtt)+'d'); }).join('  ·  ')+'</div></div></div>';
  if(pmOver.length) A+='<div class="alert crit"><span class="ic">&#9650;</span><div><b>'+pmOver.length+
    ' machine'+(pmOver.length===1?' is':'s are')+' overdue for PM.</b><div class="mlist">'+
    activeMachines().filter(function(m){ var s=pmSchedule(m); return s&&s.overdue; })
      .map(function(m){ var s=pmSchedule(m); return esc(m.name+', '+Math.abs(s.inDays)+'d late'); }).join('  ·  ')+
    '</div></div></div>';
  var pmSoon=activeMachines().filter(function(m){ var s=pmSchedule(m); return s&&s.due&&!s.overdue; });
  if(pmSoon.length) A+='<div class="alert warn"><span class="ic">&#9670;</span><div><b>PM coming up on '+
    pmSoon.length+' machine'+(pmSoon.length===1?'':'s')+'.</b><div class="mlist">'+
    pmSoon.map(function(m){ var s=pmSchedule(m); return esc(m.name+' in '+s.inDays+'d, '+fmtShort(s.next)); }).join('  ·  ')+
    '</div></div></div>';
  if(warn.length) A+='<div class="alert warn"><span class="ic">&#9670;</span><div><b>'+warn.length+
    ' parameter'+(warn.length===1?' is':'s are')+' past the warn level.</b>'+list(warn)+'</div></div>';
  var movers=rows.filter(function(r){ return r.anom!=null && r.anom>2 && r.status!=='crit'; });
  if(movers.length) A+='<div class="alert info"><span class="ic">&#9679;</span><div><b>'+movers.length+
    ' parameter'+(movers.length===1?' is':'s are')+' moving unusually fast</b> for their own normal behaviour, '+
    'though still in range.'+list(movers)+'</div></div>';
  var stale=rows.filter(function(r){ return r.asOf && diffDays(todayISO(),r.asOf)>3; });
  if(stale.length) A+='<div class="alert info"><span class="ic">&#9679;</span><div><b>'+stale.length+
    ' parameter'+(stale.length===1?' has':'s have')+' not been read in over three days.</b> '+
    'Projections below are based on stale data.</div></div>';
  if(!A) A='<div class="alert ok"><span class="ic">&#9679;</span><div><b>Everything is within limits.</b> '+
    'No parameter is near its threshold and no PM falls inside its reminder window.</div></div>';
  $('#boardAlerts').innerHTML=A;

  /* --- the grid --- */
  var grid=$('#boardGrid');
  grid.className='boardgrid'+(boardDensity==='dense'?' dense':boardDensity==='wide'?' wide':'');
  grid.innerHTML = machines.map(tileHTML).join('');
  grid.querySelectorAll('[data-m]').forEach(function(el){
    el.onclick=function(){ $('#machinePick').value=el.dataset.m; show('machine'); };
  });

  $('#wallBtn').onclick=enterWall;
  $('#wallExit').onclick=exitWall;
  if(document.body.classList.contains('wall')) setTimeout(fitWall,30);
}

function sumCell(v,k,n,cls){
  return '<div class="sumcell '+(cls||'')+'"><div class="v">'+esc(v)+'</div>'+
    '<div class="k">'+esc(k)+'</div><div class="n">'+esc(n||'')+'</div></div>';
}

/* ---------- one tile ---------- */
function tileHTML(x){
  var m=x.m;
  var compact = boardDensity==='dense';
  var win = compact?30:boardDensity==='wide'?60:45;
  var h='<div class="tile '+x.status+'" data-m="'+esc(m.id)+'" role="button" tabindex="0" '+
    'aria-label="'+esc(m.name+', '+STATUS_LABEL[x.status])+'">';

  h+='<div class="th"><div class="tid"><b>'+esc(m.name)+'</b><span>'+esc(m.id+'  ·  '+m.group)+'</span></div>'+
     '<span class="tstat '+x.status+'"><i></i>'+STATUS_LABEL[x.status]+'</span></div>';

  /* In compact mode only the governing parameter gets a chart; any second
     parameter becomes a one-line readout. That keeps every tile the same
     height, which is what lets a full fleet clear the fold. */
  var charted = compact ? [x.worst] : x.rows;
  var inline  = compact ? x.rows.filter(function(r){ return r!==x.worst; }) : [];

  charted.forEach(function(a){
    h+='<div class="pblock">'+
      '<div class="plabel"><b>'+esc(a.p.name)+'</b>'+
      (a.p.bound==='lower'?'<span class="lb">LOW LIMIT</span>':'')+'</div>'+
      '<div class="well">'+tileChart(a,win,compact)+'</div>'+
      '<div class="readout">'+
        '<span class="rv '+(a.status==='crit'?'crit':a.status==='warn'?'warn':'')+'">'+esc(num(a.value))+'</span>'+
        '<span class="ru">'+esc(a.p.unit||'')+'</span>'+
        '<span class="rsep"></span>'+
        '<span class="rdays">'+tileDtt(a)+'</span>'+
      '</div>'+
      '<div class="rmeta">'+
        (a.approach!=null?'<b>'+esc(num(a.approach,0))+'%</b> of limit '+esc(num(a.p.threshold)):'limit '+esc(num(a.p.threshold)))+
        ' · '+tileTrend(a)+'</div>'+
      travelBar(a)+
    '</div>';
  });

  inline.forEach(function(a){
    h+='<div class="pline">'+
      '<span class="st '+a.status+'"><i class="gl"></i></span>'+
      '<b>'+esc(a.p.name)+'</b>'+
      '<span class="pv">'+esc(num(a.value))+' <em>'+esc(a.p.unit||'')+'</em></span>'+
      '<span class="pp">'+(a.approach!=null?esc(num(a.approach,0))+'%':'—')+'</span>'+
      '</div>';
  });

  var s=x.pmDue;
  h+='<div class="tpm">';
  if(s){
    h+='<span>Last PM '+esc(fmtShort(s.last))+'</span><span class="sp"></span>'+
       '<span class="'+(s.overdue?'over':s.due?'due':'')+'">'+
       (s.overdue?'PM '+Math.abs(s.inDays)+'d overdue':'PM in '+s.inDays+'d')+'</span>';
  } else {
    h+='<span>No PM schedule set</span>';
  }
  h+='</div></div>';
  return h;
}
function tileDtt(a){
  if(a.status==='crit') return '<span style="color:var(--crit)">at limit</span>';
  if(a.dtt==null) return '<span style="color:var(--ok)">stable</span>';
  var d=Math.round(a.dtt);
  var c = d<=7?'var(--crit)':d<=21?'var(--warn)':'var(--ink-2)';
  return '<span style="color:'+c+'">'+d+'d left</span>';
}
function tileTrend(a){
  if(a.slope==null) return 'new';
  if(a.toward>0) return 'rising';
  if(a.toward<0) return 'easing';
  return 'steady';
}

/* ---------- screenshot / wall mode ----------
   Shrinks the board as one block until the whole fleet fits the viewport, so
   a single screenshot always captures every machine however many there are. */
function fitWall(){
  var box=$('#wallFit');
  if(!box) return;
  if(!document.body.classList.contains('wall')){ box.style.transform=''; return; }
  box.style.transform='';
  var bar=$('.wallbar');
  var avail=window.innerHeight-(bar?bar.getBoundingClientRect().height:0)-16;
  var need=box.scrollHeight;
  var k = need>avail ? Math.max(0.55, avail/need) : 1;
  box.style.transform = k<1 ? 'scale('+k.toFixed(4)+')' : '';
}
function enterWall(){
  document.body.classList.add('wall');
  $('#wallExit').hidden=false;
  var t=$('#wallTitle');
  if(t) t.textContent='Equipment PM Status Board'+(DB.meta.site?' — '+DB.meta.site:'');
  fitWall();
  toast('Screenshot view. Press Esc or the button top-right to come back.');
}
function exitWall(){
  document.body.classList.remove('wall');
  $('#wallExit').hidden=true;
  var box=$('#wallFit'); if(box) box.style.transform='';
}
window.addEventListener('resize', fitWall);
document.addEventListener('keydown', function(e){
  if(e.key==='Escape' && document.body.classList.contains('wall')) exitWall();
});
