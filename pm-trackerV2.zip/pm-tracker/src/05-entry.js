/* ==========================================================================
   05-entry.js — daily reading entry
   ========================================================================== */

var entryDraft = {};

function renderEntry(){
  groupChips('#entryGroups','entry');
  var de=$('#entryDate');
  if(!de.value) de.value=todayISO();
  de.onchange=renderEntry;
  var by=$('#entryBy');
  by.value = by.value || (DB.meta.lastBy||'');
  var date=de.value;

  var before=DB.readings.filter(function(r){ return r.date<date; }).map(function(r){ return r.date; });
  var pd = before.length?before.sort().pop():null;

  var ms=activeMachines().filter(function(m){
    return filterGroup.entry==='All'||m.group===filterGroup.entry;
  });
  var h='';
  if(!ms.length) h='<div class="panel"><div class="empty"><p>No machines in this group.</p></div></div>';

  ms.forEach(function(m){
    var already = DB.pmEvents.some(function(e){ return e.machineId===m.id && e.date===date; });
    var sch=pmSchedule(m);
    var on = entryDraft['pm|'+m.id] || already;
    h+='<div class="egrp"><header><h4>'+esc(m.name)+'</h4><span class="tag">'+esc(m.group)+'</span>'+
      (sch?'<span style="font-size:12.5px;color:'+(sch.overdue?'var(--crit)':sch.due?'var(--warn)':'var(--ink-3)')+'">'+
        (sch.overdue?'PM overdue by '+Math.abs(sch.inDays)+'d':'Next PM '+fmtDate(sch.next)+', in '+sch.inDays+'d')+'</span>':'')+
      '<span class="sp"></span>'+
      '<label class="pmbox'+(on?' on':'')+'"><input type="checkbox" data-pm="'+esc(m.id)+'"'+
        (on?' checked':'')+(already?' disabled':'')+'> '+
        (already?'PM logged for this date':'PM done on this date')+'</label></header>';
    paramsOf(m.id).forEach(function(p){
      var key=date+'|'+p.id;
      var existing = DB.readings.filter(function(r){ return r.date===date && r.paramId===p.id; })[0];
      var prev = pd?DB.readings.filter(function(r){ return r.date===pd && r.paramId===p.id; })[0]:null;
      var v = entryDraft[key]!==undefined ? entryDraft[key] : (existing?existing.value:'');
      h+='<div class="erow"><div class="lab">'+esc(p.name)+
        '<small>limit '+esc(num(p.threshold))+' '+esc(p.unit||'')+', '+
        (p.bound==='lower'?'must not fall to it':'must not rise to it')+'</small></div>'+
        '<div class="prev">'+(prev?'prev '+esc(num(prev.value)):'<span style="opacity:.55">no prev</span>')+'</div>'+
        '<div><input class="val" type="number" step="any" inputmode="decimal" data-pid="'+esc(p.id)+
          '" value="'+esc(v)+'" aria-label="'+esc(m.name+' '+p.name)+'"></div>'+
        '<div class="fb" data-fb="'+esc(p.id)+'"></div></div>';
    });
    h+='</div>';
  });
  $('#entryBody').innerHTML=h;

  $('#entryBody').querySelectorAll('input.val').forEach(function(inp){
    inp.oninput=function(){
      entryDraft[date+'|'+inp.dataset.pid]=inp.value;
      validateEntry(inp); saveDraft(); updateEntryCount(date);
    };
    validateEntry(inp);
  });
  $('#entryBody').querySelectorAll('input[data-pm]').forEach(function(cb){
    cb.onchange=function(){
      entryDraft['pm|'+cb.dataset.pm]=cb.checked;
      cb.closest('.pmbox').classList.toggle('on',cb.checked);
      saveDraft();
    };
  });
  updateEntryCount(date);
}
function updateEntryCount(date){
  var n=Object.keys(entryDraft).filter(function(k){
    return k.indexOf(date+'|')===0 && entryDraft[k]!=='';
  }).length;
  $('#entryStatus').textContent = n? n+' value'+(n===1?'':'s')+' ready to save' : '';
}
function validateEntry(inp){
  var p=DB.parameters.filter(function(x){ return x.id===inp.dataset.pid; })[0];
  if(!p) return;
  var fb=$('[data-fb="'+CSS.escape(p.id)+'"]');
  var v=parseFloat(inp.value);
  inp.classList.remove('bad','warnv');
  if(inp.value===''||!isFinite(v)){ if(fb) fb.innerHTML=''; return; }
  var st=statusOf(p,v);
  if(st==='crit') inp.classList.add('bad');
  else if(st==='warn') inp.classList.add('warnv');
  var msg='';
  if(p.validMin!=null && v<p.validMin)
    msg='<span style="color:var(--crit);font-weight:600">below expected range</span>';
  else if(p.validMax!=null && v>p.validMax)
    msg='<span style="color:var(--crit);font-weight:600">above expected range</span>';
  else if(st==='crit') msg='<span style="color:var(--crit);font-weight:600">at limit</span>';
  else if(st==='warn') msg='<span style="color:var(--warn);font-weight:600">past warn</span>';
  else { var a=approach(p,v); if(a!=null) msg='<span style="color:var(--ink-3)">'+num(a,0)+'% there</span>'; }
  if(fb) fb.innerHTML=msg;
}
function saveEntry(){
  var date=$('#entryDate').value;
  var by=($('#entryBy').value||'').trim();
  if(!date) return toast('Pick a reading date first.',true);
  var n=0, pmN=0;
  DB.meta.lastBy=by;
  Object.keys(entryDraft).forEach(function(k){
    if(k.indexOf('pm|')===0){
      if(!entryDraft[k]) return;
      var mid=k.slice(3);
      if(!DB.pmEvents.some(function(e){ return e.machineId===mid && e.date===date; })){
        DB.pmEvents.push({ id:uid(), date:date, machineId:mid, type:'Scheduled PM', tech:by, notes:'' });
        var m=machineById(mid);
        if(m && (!m.lastPM || date>m.lastPM)) m.lastPM=date;
        pmN++;
      }
      return;
    }
    if(k.indexOf(date+'|')!==0) return;
    var raw=entryDraft[k];
    if(raw===''||raw==null) return;
    var v=parseFloat(raw);
    if(!isFinite(v)) return;
    var pid=k.slice(date.length+1);
    var ex=DB.readings.filter(function(r){ return r.date===date && r.paramId===pid; })[0];
    if(ex){ ex.value=v; ex.by=by; ex.enteredAt=new Date().toISOString(); }
    else DB.readings.push({ date:date, paramId:pid, value:v, by:by, enteredAt:new Date().toISOString() });
    n++;
  });
  if(!n && !pmN) return toast('Nothing to save — enter at least one value.',true);
  entryDraft={};
  unsavedOps+=n+pmN;
  markDirty();
  toast('Saved '+n+' reading'+(n===1?'':'s')+(pmN?' and '+pmN+' PM event'+(pmN===1?'':'s'):'')+
    '. Remember to save the data file.');
  renderEntry(); updateNavBadge(); paintSaveState();
}

/* ========================= CHARTS SCREEN ========================= */
function renderCharts(){
  groupChips('#chartGroups','charts');
  var win=+$('#chartWindow').value, filt=$('#chartFilter').value;
  $('#chartWindow').onchange=renderCharts;
  $('#chartFilter').onchange=renderCharts;
  var rows=byGroup(assessAll(),'charts');
  if(filt==='attention') rows=rows.filter(function(r){ return r.status!=='ok'||(r.dtt!=null&&r.dtt<=21); });
  if(filt==='crit') rows=rows.filter(function(r){ return r.status==='crit'; });
  rows.sort(function(a,b){ return b.risk-a.risk; });
  if(!rows.length){
    $('#chartGrid').innerHTML='<div class="panel"><div class="empty"><h4>Nothing matches</h4>'+
      '<p>No parameters in this group meet the filter. Try widening it.</p></div></div>';
    return;
  }
  $('#chartGrid').innerHTML = rows.map(function(a){
    return '<div class="chartcard"><header><h4>'+esc(a.m.name)+' — '+esc(a.p.name)+' '+statusHTML(a.status)+'</h4>'+
      '<div class="meta">'+esc(a.m.group)+' · latest '+esc(num(a.value))+' '+esc(a.p.unit||'')+
      ' · limit '+esc(num(a.p.threshold))+' · '+
      (a.dtt!=null&&a.status!=='crit'?'reaches it in about '+Math.round(a.dtt)+' days'
        :a.status==='crit'?'limit reached':'not trending toward it')+
      (a.lastPM?' · last PM '+esc(fmtShort(a.lastPM)):'')+'</div></header>'+
      trendChart(a,win)+'</div>';
  }).join('');
}
