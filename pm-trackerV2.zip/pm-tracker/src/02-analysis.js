/* ==========================================================================
   02-analysis.js — the maths
   Every derived number is computed on the current PM segment only. Averaging
   across a PM reset produces a falsely flat trend, which is the exact failure
   this whole tool exists to avoid.
   ========================================================================== */

/* Healthy baseline: median of the first readings after the most recent PM,
   falling back to the earliest readings on record. Cached per render pass. */
function healthyBaseline(p){
  if(p._base!=null) return p._base;
  var s = seriesOf(p.id);
  if(!s.length){ p._base = p.threshold*0.5; return p._base; }
  var pm = lastPMOf(p.machineId, s[s.length-1].date);
  var pool = pm ? s.filter(function(r){ return r.date>=pm; }).slice(0,5) : [];
  if(pool.length<3) pool = s.slice(0,5);
  p._base = median(pool.map(function(r){ return r.value; }));
  return p._base;
}

/* How far the reading has travelled from its healthy baseline to the
   threshold, as a percentage. Anchoring on the baseline means "80% of the way
   there" reads the same for an upper-bound and a lower-bound parameter. */
function approach(p, value){
  if(value==null||!isFinite(value)) return null;
  var b = healthyBaseline(p);
  var span = p.threshold - b;
  if(!isFinite(span) || Math.abs(span) < 1e-12) return value===p.threshold?100:null;
  return ((value - b)/span)*100;
}

function statusOf(p, v){
  if(v==null) return 'none';
  if(p.bound==='lower'){
    if(v<=p.threshold) return 'crit';
    if(p.warn!=null && v<=p.warn) return 'warn';
    return 'ok';
  }
  if(v>=p.threshold) return 'crit';
  if(p.warn!=null && v>=p.warn) return 'warn';
  return 'ok';
}
var STATUS_LABEL = { crit:'At limit', warn:'Warning', ok:'Normal', none:'No data' };

/* least-squares slope, units per day */
function slopeOf(pts){
  if(pts.length<3) return null;
  var x=pts.map(function(p){ return dayNum(p.date); });
  var y=pts.map(function(p){ return p.value; });
  var n=x.length;
  var mx=x.reduce(function(a,b){return a+b;},0)/n;
  var my=y.reduce(function(a,b){return a+b;},0)/n;
  var sxy=0, sxx=0;
  for(var i=0;i<n;i++){ sxy+=(x[i]-mx)*(y[i]-my); sxx+=(x[i]-mx)*(x[i]-mx); }
  return sxx===0?null:sxy/sxx;
}
/* positive = moving toward the threshold, whichever side it sits on */
function towardRate(p,s){ return s==null?null:(p.bound==='lower'? -s : s); }

function daysToThreshold(p, value, slope){
  var t = towardRate(p, slope);
  if(t==null || t<=1e-12 || value==null) return null;
  var gap = p.bound==='lower' ? value-p.threshold : p.threshold-value;
  if(gap<=0) return 0;
  var d = gap/t;
  return d>3650?null:d;
}

/* Recent movement divided by this parameter's own typical movement.
   Above ~1.5 means it is accelerating relative to its normal behaviour —
   which catches a machine going wrong while still comfortably in range. */
function anomalyScore(p, seg){
  if(seg.length<8) return null;
  var v=seg.map(function(r){ return r.value; });
  var recentArr = v.slice(-3);
  var recent = recentArr.reduce(function(a,b){return a+b;},0)/recentArr.length;
  var prior = v.slice(-7,-3);
  if(!prior.length) return null;
  var priorAvg = prior.reduce(function(a,b){return a+b;},0)/prior.length;
  var delta = recent-priorAvg;
  if(p.bound==='lower') delta = -delta;
  var steps=[];
  for(var i=3;i<v.length;i++) steps.push(Math.abs(v[i]-v[i-3]));
  var typical = median(steps) || 1e-9;
  return delta/typical;
}

/* ---------- PM schedule ---------- */
function pmSchedule(m){
  if(!m || !m.pmIntervalDays) return null;
  var last = lastPMOf(m.id) || m.lastPM;
  if(!last) return null;
  var next = addDays(last, +m.pmIntervalDays);
  var inDays = diffDays(next, todayISO());
  var lead = m.pmLeadDays||10;
  return { last:last, next:next, inDays:inDays, lead:lead, due:inDays<=lead, overdue:inDays<0 };
}

/* ---------- the per-parameter fact sheet everything else reads ---------- */
function assess(p){
  var all = seriesOf(p.id);
  var last = all.length?all[all.length-1]:null;
  var value = last?last.value:null;
  var asOf = last?last.date:null;
  var pm = asOf?lastPMOf(p.machineId, asOf):lastPMOf(p.machineId);
  var seg = pm ? all.filter(function(r){ return r.date>=pm; }) : all;
  var slope = slopeOf(seg.length>=3?seg:all);
  var status = statusOf(p, value);
  var app = approach(p, value);
  var dtt = daysToThreshold(p, value, slope);
  var anom = anomalyScore(p, seg.length>=8?seg:all);
  var m = machineById(p.machineId);
  var sch = pmSchedule(m);
  var prev = all.length>1?all[all.length-2]:null;

  var risk = 0;
  if(status!=='none'){
    var sev = Math.max(0, Math.min(1.25, (app==null?0:app)/100));
    risk += 0.46*Math.min(1, sev);
    if(status==='crit') risk += 0.14;
    if(dtt!=null) risk += 0.26*Math.max(0, Math.min(1, (60-dtt)/60));
    if(anom!=null && anom>0) risk += 0.14*Math.min(1, anom/2.5);
    if(sch && sch.overdue) risk += 0.06;
    if(all.length<4) risk *= 0.8;   /* thin data, less confident */
  }
  return {
    p:p, m:m, all:all, seg:seg, value:value, prevValue:prev?prev.value:null,
    asOf:asOf, lastPM:pm, slope:slope, toward:towardRate(p,slope),
    status:status, approach:app, dtt:dtt, anom:anom,
    risk:Math.min(1.35,risk), n:all.length, pmDue:sch,
    baseline:healthyBaseline(p)
  };
}
function assessAll(){
  DB.parameters.forEach(function(p){ delete p._base; });
  return activeParams().map(assess);
}

/* ---------- machine roll-up: one row per machine, for the board ---------- */
function machineRollup(rows){
  var byM = {};
  rows.forEach(function(r){ (byM[r.p.machineId] = byM[r.p.machineId]||[]).push(r); });
  return Object.keys(byM).map(function(mid){
    var list=byM[mid], m=machineById(mid);
    var worst = list.reduce(function(a,b){ return b.risk>a.risk?b:a; });
    var withApp = list.filter(function(r){ return r.approach!=null; });
    var rank = { crit:3, warn:2, ok:1, none:0 };
    var status = list.reduce(function(a,b){ return rank[b.status]>rank[a]?b.status:a; }, 'none');
    return {
      m:m, rows:list, worst:worst, risk:worst.risk, status:status,
      approach: withApp.length ? withApp.reduce(function(a,b){ return Math.max(a,b.approach); }, -1e9) : null,
      crit:list.filter(function(r){ return r.status==='crit'; }).length,
      warn:list.filter(function(r){ return r.status==='warn'; }).length,
      anom:list.reduce(function(a,b){ return (b.anom!=null&&b.anom>a)?b.anom:a; }, -99),
      dtt:list.reduce(function(a,b){ return (b.dtt!=null&&(a==null||b.dtt<a))?b.dtt:a; }, null),
      pmDue:pmSchedule(m)
    };
  });
}

/* ---------- PM cycle statistics ---------- */
function pmCycles(mid){
  var dates = pmDatesOf(mid), out=[];
  for(var i=0;i<dates.length;i++){
    var from=dates[i], to=dates[i+1]||null;
    var len = to?diffDays(to,from):diffDays(todayISO(),from);
    var reachedWarn=null, reachedThr=null;
    paramsOf(mid).forEach(function(p){
      seriesOf(p.id).filter(function(r){ return r.date>=from && (!to||r.date<to); })
        .forEach(function(r){
          var st=statusOf(p,r.value);
          if((st==='warn'||st==='crit') && reachedWarn==null) reachedWarn=diffDays(r.date,from);
          if(st==='crit' && reachedThr==null) reachedThr=diffDays(r.date,from);
        });
    });
    out.push({ from:from, to:to, len:len, open:!to, reachedWarn:reachedWarn, reachedThr:reachedThr });
  }
  return out;
}

/* ---------- monthly report ---------- */
function monthsAvailable(){
  var s={};
  DB.readings.forEach(function(r){ s[r.date.slice(0,7)]=1; });
  return Object.keys(s).sort().reverse();
}
function monthReport(ym){
  var parts=ym.split('-'), y=+parts[0], mo=+parts[1];
  var pd=new Date(y,mo-2,1);
  var prevYm = pd.getFullYear()+'-'+String(pd.getMonth()+1).padStart(2,'0');
  var rows = activeParams().map(function(p){
    var inM = seriesOf(p.id).filter(function(r){ return r.date.indexOf(ym)===0; });
    var inP = seriesOf(p.id).filter(function(r){ return r.date.indexOf(prevYm)===0; });
    if(!inM.length) return null;
    var vals=inM.map(function(r){ return r.value; });
    var end=inM[inM.length-1];
    var avg=vals.reduce(function(a,b){return a+b;},0)/vals.length;
    var pAvg=inP.length?inP.map(function(r){return r.value;}).reduce(function(a,b){return a+b;},0)/inP.length:null;
    var chg = (pAvg!=null && pAvg!==0) ? ((avg-pAvg)/Math.abs(pAvg))*100 : null;
    return {
      p:p, m:machineById(p.machineId), n:inM.length, avg:avg,
      min:Math.min.apply(null,vals), max:Math.max.apply(null,vals),
      end:end.value, endDate:end.date,
      breaches:inM.filter(function(r){ return statusOf(p,r.value)==='crit'; }).length,
      warns:inM.filter(function(r){ return statusOf(p,r.value)==='warn'; }).length,
      prevAvg:pAvg, change:chg,
      worsened: chg!=null && (p.bound==='lower'? chg<-1 : chg>1),
      endStatus:statusOf(p,end.value), endApproach:approach(p,end.value)
    };
  }).filter(Boolean);
  var days = Object.keys(DB.readings.filter(function(r){ return r.date.indexOf(ym)===0; })
    .reduce(function(a,r){ a[r.date]=1; return a; },{})).length;
  return {
    ym:ym, prevYm:prevYm, rows:rows,
    pms: DB.pmEvents.filter(function(e){ return e.date.indexOf(ym)===0; }),
    days:days,
    expected: days*activeParams().length,
    actual: rows.reduce(function(a,b){ return a+b.n; },0)
  };
}
