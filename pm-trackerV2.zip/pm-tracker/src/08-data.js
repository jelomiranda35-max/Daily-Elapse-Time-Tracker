/* ==========================================================================
   08-data.js — file in/out and the Excel paste importer
   ========================================================================== */

function renderData(){
  var d=readDraft();
  var draftAge = d? Math.round((Date.now()-new Date(d.at).getTime())/60000) : null;
  var h='';
  if(dirty) h+='<div class="alert warn" style="margin-bottom:16px"><span class="ic">&#9670;</span><div><b>You have '+
    unsavedOps+' change'+(unsavedOps===1?'':'s')+' not yet written to a file.</b> '+
    'Save now, then copy the downloaded file over the one on the shared folder.</div></div>';
  if(!storageOK) h+='<div class="alert crit" style="margin-bottom:16px"><span class="ic">&#9650;</span><div>'+
    '<b>This browser is not keeping a recovery draft.</b> Your work is held in memory only, '+
    'so save the data file before closing the tab.</div></div>';

  h+='<div class="panel"><header><h3>Data file</h3>'+
    '<span class="sub">one JSON file holds machines, limits, readings and PM history</span></header><div class="body">'+
    '<div class="toolbar"><button class="btn primary" onclick="saveJSON()">Save data file</button>'+
    '<button class="btn" onclick="pickFile()">Load data file</button>'+
    '<button class="btn" onclick="exportCSV()">Export readings as CSV</button>'+
    '<button class="btn" onclick="exportBackup()">Save dated backup</button></div>'+
    '<div class="note"><b>The routine:</b> load the newest file from the shared folder when you start, '+
    'enter readings, save, then move the downloaded file into that folder. Saving always goes to your '+
    'Downloads folder — a browser opened from a file path is not allowed to write straight to the network.<br><br>'+
    '<b>File naming.</b> Saves are stamped <span style="font-family:Consolas,monospace">pm-data-YYYY-MM-DD-HHMMSS.json</span>, '+
    'so nothing is ever silently overwritten and the newest file is always last when the folder is sorted by name.</div>'+
    (d?'<div class="note" style="margin-top:8px">A recovery draft was written '+
      (draftAge<1?'less than a minute':draftAge+' minute'+(draftAge===1?'':'s'))+' ago. '+
      'If this tab closes unexpectedly, that draft is offered back on reopening.</div>':'')+
    '</div></div>';

  h+='<div class="panel"><header><h3>Paste from Excel</h3>'+
    '<span class="sub">brings in machines, limits and history in one go</span></header><div class="body">'+
    '<div class="note" style="margin-bottom:12px"><b>Expected layout — the one you already use.</b> '+
    'First column is the date. Then, for each parameter, a column of readings followed by its target column. '+
    'Put the machine and parameter in the header, and make sure target columns say "target", "limit" or "spec".<br><br>'+
    '<span style="font-family:Consolas,monospace;font-size:12px">'+
    'Date | SCN-01 Lens drift | Target | SCN-01 Stage vib | Target | DPM-11 Base pressure | Target</span><br><br>'+
    'Select the block in Excel including the header row, copy, and paste below. '+
    'Nothing is written until you review the preview.</div>'+
    '<textarea class="paste" id="pasteBox" placeholder="Paste your copied Excel cells here"></textarea>'+
    '<div class="toolbar" style="margin-top:12px">'+
    '<button class="btn primary" onclick="parsePaste()">Read this and show a preview</button>'+
    '<label style="display:flex;align-items:center;gap:7px;font-size:13.5px;flex:0 0 auto">'+
      '<input type="checkbox" id="pasteLower" style="width:auto;box-shadow:none"> Columns with no target are lower-limit</label>'+
    '<span style="font-size:13px;color:var(--ink-2)">Group for new machines:</span>'+
    '<select id="pasteGroup" style="max-width:150px">'+DB.groups.map(function(g){
      return '<option>'+esc(g)+'</option>'; }).join('')+'</select></div>'+
    '<div id="pasteResult"></div></div></div>';

  h+='<div class="panel"><header><h3>Start over</h3></header><div class="body"><div class="toolbar">'+
    '<button class="btn" onclick="loadDemo()">Load demo data</button>'+
    '<button class="btn danger" onclick="wipe()">Clear everything</button></div>'+
    '<div class="note">The demo replaces whatever is loaded now, so save your own file first.</div></div></div>';
  $('#dataBody').innerHTML=h;
}

/* ---------- download / upload ---------- */

/* Save-file stamp: YYYY-MM-DD-HHMMSS, where HHMMSS is the time elapsed in the
   day at the moment of saving. Sorts chronologically by name in Explorer, so
   the file at the bottom of the list is always the newest. */
function saveStamp(){
  var d=new Date();
  function p(n){ return String(n).padStart(2,'0'); }
  return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+'-'+
         p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}
function download(name, text, mime){
  var b=new Blob([text],{type:mime||'application/json'});
  var u=URL.createObjectURL(b), a=document.createElement('a');
  a.href=u; a.download=name; document.body.appendChild(a); a.click();
  setTimeout(function(){ URL.revokeObjectURL(u); a.remove(); },400);
}
function saveJSON(){
  DB.meta.savedAt=new Date().toISOString();
  var name='pm-data-'+saveStamp()+'.json';
  DB.meta.lastFile=name;
  download(name, JSON.stringify(DB,null,1));
  markClean(); clearDraft(); render();
  toast('Saved as '+name+'. Copy it into the shared data folder — it is the newest by name and by date.');
}
function exportBackup(){
  DB.meta.savedAt=new Date().toISOString();
  download('pm-backup-'+saveStamp()+'.json', JSON.stringify(DB,null,1));
  toast('Backup saved. Keep these in data/backups on the share.');
}
function exportCSV(){
  var rows=[['date','machine','parameter','value','unit','limit','bound','status','entered_by']];
  DB.readings.slice().sort(function(a,b){ return a.date<b.date?-1:1; }).forEach(function(r){
    var p=DB.parameters.filter(function(x){ return x.id===r.paramId; })[0];
    if(!p) return;
    var m=machineById(p.machineId);
    rows.push([r.date, m?m.name:p.machineId, p.name, r.value, p.unit||'', p.threshold, p.bound,
      statusOf(p,r.value), r.by||'']);
  });
  var pm=[['date','machine','type','technician','notes']].concat(
    DB.pmEvents.slice().sort(function(a,b){ return a.date<b.date?-1:1; }).map(function(e){
      var m=machineById(e.machineId);
      return [e.date, m?m.name:e.machineId, e.type||'PM', e.tech||'', e.notes||''];
    }));
  function csv(a){
    return a.map(function(r){
      return r.map(function(c){
        var s=String(c==null?'':c);
        return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
      }).join(',');
    }).join('\r\n');
  }
  var st=saveStamp();
  download('pm-readings-'+st+'.csv', csv(rows),'text/csv');
  setTimeout(function(){ download('pm-events-'+st+'.csv', csv(pm),'text/csv'); },600);
  toast('Two CSV files saved: readings and PM events. Both open directly in Excel.');
}
function pickFile(){
  var inp=$('#fileInput'); inp.value='';
  inp.onchange=function(){
    var f=inp.files[0]; if(!f) return;
    var r=new FileReader();
    r.onerror=function(){ toast('Could not read that file.',true); };
    r.onload=function(){
      try{
        var db=migrate(JSON.parse(r.result));
        var issues=integrity(db);
        DB=db; entryDraft={}; markClean(); clearDraft(); render();
        if(issues.length) toast('Loaded, but with '+issues.length+' data issue'+(issues.length===1?'':'s')+': '+issues.join('; '), true);
        else toast('Loaded '+DB.readings.length.toLocaleString()+' readings across '+DB.machines.length+' machines.');
      }catch(e){
        toast('That file could not be read as PM Tracker data. '+e.message, true);
      }
    };
    r.readAsText(f);
  };
  inp.click();
}
function loadDemo(){
  if(dirty && !confirm('You have unsaved changes. Loading the demo will discard them. Continue?')) return;
  DB=demoDB(); entryDraft={}; markClean(); clearDraft(); show('board');
  toast('Demo data loaded — 16 machines, 23 parameters, 75 days of history.');
}
function wipe(){
  if(!confirm('Delete every machine, parameter and reading currently loaded?\n\nSave your data file first if you need it.')) return;
  DB=blankDB(); entryDraft={}; markClean(); clearDraft(); show('config');
  toast('Cleared. Add machines or load a file to begin.');
}

/* ---------- Excel paste importer ---------- */
function cleanNum(s){
  if(s==null) return NaN;
  s=String(s).trim().replace(/[\u00A0\s]/g,'').replace(/,/g,'').replace(/%$/,'');
  if(s===''||s==='-'||/^n\/?a$/i.test(s)) return NaN;
  return parseFloat(s);
}
function parseDateCell(s){
  s=String(s).trim(); if(!s) return null;
  if(/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
  var m=s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if(m){
    var a=+m[1], b=+m[2], y=+m[3];
    if(y<100) y+=2000;
    var mo=a, d=b;
    if(mo>12){ mo=b; d=a; }
    return y+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
  }
  var dt=new Date(s);
  if(!isNaN(dt)) return dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');
  return null;
}
function isTargetCol(h){ return /target|limit|spec|threshold|usl|lsl|ctrl|max$|min$/i.test(h); }

var pendingImport=null;

function parsePaste(){
  var raw=$('#pasteBox').value;
  if(!raw.trim()) return toast('Paste your copied cells into the box first.',true);
  var lines=raw.replace(/\r/g,'').split('\n').filter(function(l){ return l.trim()!==''; });
  if(lines.length<2) return toast('That looks like only one row. Include the header row and at least one data row.',true);

  var delim = lines[0].indexOf('\t')>=0 ? '\t'
    : (lines[0].split(',').length > lines[0].split(';').length ? ',' : ';');
  var cells = lines.map(function(l){
    return l.split(delim).map(function(c){ return c.trim().replace(/^"|"$/g,''); });
  });
  var head=cells[0];
  var lowerBound=$('#pasteLower').checked;
  var grp=$('#pasteGroup').value;

  /* pair each value column with the target column that follows it */
  var cols=[];
  for(var i=1;i<head.length;i++){
    if(!head[i] || isTargetCol(head[i])) continue;
    var tIdx = (i+1<head.length && isTargetCol(head[i+1])) ? i+1 : null;
    cols.push({ i:i, tIdx:tIdx, label:head[i] });
  }
  if(!cols.length) return toast('No parameter columns found. First column should be the date, and each later column needs a header.',true);

  /* split "MACHINE parameter" — machine token is the leading code-like word */
  cols.forEach(function(c){
    var L=c.label.replace(/\s+/g,' ').trim();
    var m=L.match(/^([A-Za-z]{2,6}[-_ ]?\d{1,3})\s*[-\u2013:|]?\s*(.+)$/);
    if(m){ c.machine=m[1].trim(); c.param=m[2].trim(); }
    else {
      var parts=L.split(/\s+[-\u2013|:]\s+/);
      if(parts.length>1){ c.machine=parts[0].trim(); c.param=parts.slice(1).join(' - ').trim(); }
      else { var w=L.split(' '); c.machine=w[0]; c.param=w.slice(1).join(' ')||'Value'; }
    }
    var u=c.param.match(/\(([^)]{1,10})\)\s*$/);
    if(u){ c.unit=u[1]; c.param=c.param.replace(/\s*\([^)]*\)\s*$/,'').trim(); } else c.unit='';
  });

  var readings=[], targets={}, badDates=[], badVals=[];
  for(var r=1;r<cells.length;r++){
    var d=parseDateCell(cells[r][0]);
    if(!d){ badDates.push(cells[r][0]); continue; }
    /* eslint-disable no-loop-func */
    (function(row,date){
      cols.forEach(function(c){
        var v=cleanNum(row[c.i]);
        if(isFinite(v)) readings.push({ date:date, col:c, value:v });
        else if((row[c.i]||'').trim()!=='') badVals.push(row[c.i]);
        if(c.tIdx!=null){
          var t=cleanNum(row[c.tIdx]);
          if(isFinite(t)) (targets[c.label]=targets[c.label]||[]).push(t);
        }
      });
    })(cells[r], d);
  }
  if(!readings.length) return toast('No numeric readings found. Check the first column really holds dates.',true);

  var machines={};
  cols.forEach(function(c){
    var mid=c.machine.toUpperCase().replace(/\s+/g,'-');
    var existing = machineById(mid) || DB.machines.filter(function(m){
      return m.name.toLowerCase()===c.machine.toLowerCase(); })[0];
    c.mid = existing?existing.id:mid;
    if(!existing) machines[c.mid]={ id:c.mid, name:c.machine, group:grp };
    var t=targets[c.label];
    c.threshold = (t&&t.length)?median(t):null;
    /* Direction is readable from the data: if the readings sit above the
       target, the reading must be falling toward it, so it is a lower limit.
       The checkbox is only a fallback for columns with no target. */
    var vals=readings.filter(function(r){ return r.col===c; }).map(function(r){ return r.value; });
    c.med = vals.length?median(vals):null;
    c.bound = (c.threshold!=null && c.med!=null)
      ? (c.med > c.threshold ? 'lower' : 'upper')
      : (lowerBound ? 'lower' : 'upper');
    c.autoBound = (c.threshold!=null && c.med!=null);
    c.pid=c.mid+'::'+c.param;
    var ep=DB.parameters.filter(function(p){ return p.id===c.pid; })[0];
    c.existingParam=!!ep;
    if(ep && c.threshold==null) c.threshold=ep.threshold;
  });
  var dset={}; readings.forEach(function(r){ dset[r.date]=1; });
  var dates=Object.keys(dset).sort();
  var noThr=cols.filter(function(c){ return c.threshold==null; });
  pendingImport={ cols:cols, readings:readings, machines:machines, lowerBound:lowerBound };

  var h='<div class="panel" style="margin-top:16px"><header><h3>Preview</h3>'+
    '<span class="sub">nothing is saved until you confirm</span></header><div class="body">';
  h+='<div class="alert '+(noThr.length?'warn':'info')+'"><span class="ic">'+(noThr.length?'&#9670;':'&#9679;')+'</span><div>'+
    '<b>'+readings.length.toLocaleString()+' readings across '+cols.length+' parameters and '+
    Object.keys(machines).length+' new machines.</b><div class="mlist">'+
    esc(fmtDate(dates[0]))+' to '+esc(fmtDate(dates[dates.length-1]))+' · '+dates.length+' distinct dates'+
    (badDates.length?' · '+badDates.length+' row'+(badDates.length===1?'':'s')+' skipped, unreadable date':'')+
    (badVals.length?' · '+badVals.length+' cell'+(badVals.length===1?'':'s')+' skipped, not a number':'')+
    '</div></div></div>';
  if(noThr.length) h+='<div class="note" style="margin-top:10px">'+noThr.length+' parameter'+
    (noThr.length===1?' has':'s have')+' no target column beside it. '+(noThr.length===1?'It':'They')+
    ' will be created with a placeholder limit — set the real one on the Machines &amp; limits screen '+
    'before relying on the alerts.</div>';
  h+='<div class="tblwrap" style="margin-top:12px;max-height:340px;overflow-y:auto"><table class="tbl"><thead><tr>'+
    '<th>Column header</th><th>Machine</th><th>Parameter</th><th class="num">Unit</th>'+
    '<th class="num">Limit found</th><th>Direction</th><th class="num">Readings</th><th>Action</th></tr></thead><tbody>';
  cols.forEach(function(c){
    var n=readings.filter(function(r){ return r.col===c; }).length;
    h+='<tr><td style="font-family:Consolas,monospace;font-size:12.5px">'+esc(c.label)+'</td>'+
      '<td><b>'+esc(c.machine)+'</b></td><td>'+esc(c.param)+'</td>'+
      '<td class="num">'+esc(c.unit||'—')+'</td>'+
      '<td class="num">'+(c.threshold!=null?'<b>'+esc(num(c.threshold))+'</b>'
        :'<span style="color:var(--warn);font-weight:600">none</span>')+'</td>'+
      '<td style="font-size:12.5px">'+
        (c.bound==='lower'?'<b>falls toward limit</b>':'rises toward limit')+
        (c.autoBound?'':'<div style="color:var(--warn);font-size:11.5px">guessed, no target column</div>')+'</td>'+
      '<td class="num">'+n+'</td>'+
      '<td style="font-size:13px">'+(c.existingParam?'<span style="color:var(--ink-2)">merge into existing</span>'
        :'<span style="color:var(--ok);font-weight:600">create new</span>')+'</td></tr>';
  });
  h+='</tbody></table></div><div class="toolbar" style="margin-top:14px">'+
    '<button class="btn primary" onclick="commitImport()">Import these '+readings.length.toLocaleString()+' readings</button>'+
    '<button class="btn" onclick="cancelImport()">Cancel</button>'+
    '<span style="font-size:13px;color:var(--ink-2)">If a machine or parameter name looks wrong, '+
    'fix the header in Excel and paste again.</span></div></div></div>';
  $('#pasteResult').innerHTML=h;
  $('#pasteResult').scrollIntoView({behavior:'smooth',block:'nearest'});
}
function cancelImport(){ pendingImport=null; $('#pasteResult').innerHTML=''; }

function commitImport(){
  if(!pendingImport) return;
  var cols=pendingImport.cols, readings=pendingImport.readings;
  var machines=pendingImport.machines;

  Object.keys(machines).forEach(function(k){
    var m=machines[k];
    if(machineById(m.id)) return;
    DB.machines.push({ id:m.id, name:m.name, group:m.group, active:true,
      pmIntervalDays:90, pmLeadDays:10, lastPM:null, notes:'' });
  });
  cols.forEach(function(c){
    if(DB.parameters.some(function(p){ return p.id===c.pid; })) return;
    var med = c.med!=null ? c.med : 0;
    var lb = c.bound==='lower';
    var thr=c.threshold;
    if(thr==null) thr = lb ? med*0.6 : med*1.6;
    DB.parameters.push({ id:c.pid, machineId:c.mid, name:c.param, unit:c.unit||'',
      threshold:thr, warn: med+(thr-med)*0.8, bound: c.bound,
      validMin: lb?thr*0.3:0, validMax: lb?med*2.2:thr*4, notes:'' });
  });
  var added=0, updated=0;
  readings.forEach(function(r){
    var ex=DB.readings.filter(function(x){ return x.date===r.date && x.paramId===r.col.pid; })[0];
    if(ex){ ex.value=r.value; updated++; }
    else { DB.readings.push({ date:r.date, paramId:r.col.pid, value:r.value, by:'Excel import' }); added++; }
  });
  pendingImport=null; $('#pasteBox').value=''; $('#pasteResult').innerHTML='';
  unsavedOps+=added+updated; markDirty(); show('board');
  toast('Imported '+added.toLocaleString()+' readings'+(updated?' and updated '+updated:'')+
    '. Check the limits on Machines & limits, then save the data file.');
}
