/* ==========================================================================
   10-boot.js — startup. Loaded last.
   ========================================================================== */

function boot(){
  storageOK = testStorage();

  $('#nav').onclick = function(e){
    var b=e.target.closest('button[data-screen]');
    if(b) show(b.dataset.screen);
  };
  $('#entrySave').onclick = saveEntry;
  $('#entryClear').onclick = function(){
    entryDraft={}; saveDraft(); renderEntry();
    toast('Form cleared. Nothing already saved was removed.');
  };
  $('#quickSave').onclick = saveJSON;

  var d = readDraft();
  if(d && d.db && (d.db.readings||[]).length){
    var when = new Date(d.at).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
    DB = blankDB();
    render();
    setTimeout(function(){
      modal('Unsaved work found',
        '<p style="margin-bottom:12px">A recovery draft from <b>'+esc(when)+'</b> is still in this browser, '+
        'holding '+d.db.readings.length.toLocaleString()+' readings across '+(d.db.machines||[]).length+' machines.</p>'+
        '<p>This happens when the tab closed before the data file was saved. Restore it, or discard it and '+
        'load your file from the shared folder instead.</p>',
        function(){
          DB=migrate(d.db); dirty=true; unsavedOps=1; render();
          toast('Draft restored. Save the data file now so it is not lost again.');
        },
        'Restore this draft');
      $('#mCancel').textContent='Discard draft';
      $('#mCancel').onclick=function(){
        clearDraft(); $('#modalHost').innerHTML=''; DB=demoDB(); DB.meta.isDemo=true; render();
      };
    },300);
  } else {
    DB = demoDB();
    DB.meta.isDemo = true;
    setTimeout(function(){
      toast('Showing demo data so you can explore. Load your own file, or paste your Excel grid, from "Save, load & import".');
    },800);
  }
  show('board');
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
