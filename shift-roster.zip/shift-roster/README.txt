SHIFT ROSTER — desktop web app
==============================

START
  1. Unzip the folder anywhere (e.g. Documents\shift-roster).
  2. Double-click index.html. Use Chrome or Edge on a desktop/laptop.
  3. It opens with sample data (Engineer 1-4, Technician 1-8) and the
     current month filled from the shift templates.
  4. Go to "Rules & setup" -> People and replace the sample people with
     your team (or use "Start blank" at the bottom of that page).

No internet or installation needed. (Fonts load from Google if online;
otherwise the system font is used.)

SAVING
  - Every change autosaves in this browser on this PC.
  - Export -> JSON backup saves EVERYTHING (all months, people, rules) to
    a file. Do this regularly — clearing browser data deletes the autosave.
    A yellow bar reminds you when the last backup is older than 2 days.
  - Import loads a JSON backup (replaces current data; it asks first).
  - To move to another PC: Export JSON here, Import JSON there.
  - Keep the app in the same folder; moving index.html can make the
    browser treat it as a new app with empty storage (just Import again).

MONTH SHEET
  - One sheet per month, day 1 on the left, last day on the right.
  - Top band = work week (WW). Thick line = start of each week (Saturday).
  - Row colour = pair colour. D = day, N = night (dark band on top).
  - Yellow = OT. It is automatic when someone works on:
      a rest day of their template (e.g. L4 on Sat/Sun),
      a company holiday,
      their personal rest weekday,
      their designated OT weekday (the one yellow weekday for D6).
    You can override per cell (Force OT / Not OT, with a reason).
  - Days / Hrs / OT columns are this month's totals per person.
    "Sep run" (previous month) = days in a row carried into this month.
  - Coverage rows at the bottom count people on D and N per day.
    Orange = under the minimum. Click it to see who can cover.

EDITING
  - Click a cell to open the editor. Drag to select many cells.
  - Keys on selected cells:
      D day   N night   R rest   V/S/E/T leave types   Del clear
      O toggle OT   A OT back to automatic
      Arrow keys move, Enter opens the editor, Esc closes
      Ctrl+Z undo   Ctrl+Y redo
  - After typing a code on one cell, the selection moves to the next day,
    so you can type a whole week: D D D D D R R.

RULES CHECKED (all editable in Rules & setup)
  - Minimum people per shift per day (default 3 day / 3 night)
  - Max consecutive working days (default 6), across months
  - No day shift right after a night shift (24 h on duty)
  - Weekend OT eligibility: 5 weekdays worked -> max 1 weekend rest day;
    fewer -> max 2 (for templates with the rule on: L4, D6)
  - Max OT weekdays per week per template (D6 = 1)
  - Optional: at least one Engineer per shift
  Broken rules get an orange outline and appear under "Needs a decision"
  with a one-click fix. Nothing is blocked.

GENERATE FROM TEMPLATES
  Fills the month from each person's shift template and rest weekday.
  Choose: fill empty days only (safe), replace shifts but keep leave, or
  start over. It is a single undo step. Weekend/Sunday cover is NOT
  auto-assigned — use the coverage gaps + "Show who can cover".

EXPORT / PRINT
  - Excel (.xls): this month with colours. If Excel warns the format
    doesn't match the extension, click Yes — it is safe.
  - CSV: plain data (* marks OT).
  - PDF: Print -> "Save as PDF". The sheet fits A4 landscape.
    In the print dialog, tick "Background graphics" if colours are missing.

ASSUMPTIONS (change them in Rules & setup)
  - Company holidays = day 3 and 4 of every month.
  - WW28 = week starting Sat 10 Oct 2026; WW resets after 52 weeks.
  - Hours = shift end minus start, no break deducted
    (L4 9.5 h, D6 11 h, E6 11 h).
  - History/undo covers changes since the app was opened; the change log
    is kept with your data.

FILES
  index.html        the app
  css/styles.css    look and print layout
  js/core.js        data, saving, undo, work weeks
  js/rules.js       OT and rule checks, coverage, generator
  js/sheet.js       month sheet, editor, dialogs
  js/setup.js       Rules & setup page
  js/app.js         start-up, exports, keyboard
