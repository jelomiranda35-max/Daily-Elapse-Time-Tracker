/* Shift Roster — month sheet: rendering, selection, editing, dialogs */
(function () {
  'use strict';
  var R = window.R, esc = R.esc;
  var $ = function (s, el) { return (el || document).querySelector(s); };

  R.ui = { y: 0, m: 0, view: 'month', sel: null, anchor: null, A: null, order: [] };
  var cellEls = [];
  var dragging = false;

  var COLW = [190, 44, 40, 50, 40, 40];
  var LEFT = [0, 190, 234, 274, 324, 364];
  var LEFTW = 404;

  function colsCss(n) { return COLW.map(function (w) { return w + 'px'; }).join(' ') + ' repeat(' + n + ', 30px)'; }
  function stick(i) { return 'sticky s' + i; }

  /* ---------- month render ---------- */
  R.renderMonth = function () {
    var A = R.analyze(R.ui.y, R.ui.m);
    R.ui.A = A;
    var S = R.state.settings;
    document.documentElement.style.setProperty('--ot', S.otColor || '#FFD43B');

    $('#monthTitle').textContent = R.MONTHS[A.m] + ' ' + A.y;
    var wws = []; A.days.forEach(function (x) { if (wws.indexOf(x.ww) < 0) wws.push(x.ww); });
    $('#monthSub').textContent = 'WW' + wws[0] + ' – WW' + wws[wws.length - 1] + ' · weeks start ' + R.WD_LONG[S.weekStart];

    var personFlags = A.flags.length;
    $('#stats').innerHTML =
      stat('Day min', A.minDay ? '<b class="' + (A.minDay.n < S.minDay ? 'bad' : '') + '">' + A.minDay.n + '</b> <span class="muted">(' + R.label(A.minDay.k) + ')</span>' : '–') +
      stat('Night min', A.minNight ? '<b class="' + (A.minNight.n < S.minNight ? 'bad' : '') + '">' + A.minNight.n + '</b> <span class="muted">(' + R.label(A.minNight.k) + ')</span>' : '–') +
      stat('OT', '<b>' + A.otTotal + '</b> shifts · <b>' + fmtH(A.otHours) + '</b> h') +
      stat('Flags', '<span class="pill ' + (personFlags ? 'red' : 'ok') + '">' + personFlags + '</span>');

    renderLegend();
    renderSheet(A);
    renderFlags(A);
  };

  function stat(label, html) { return '<div class="stat">' + label + ' ' + html + '</div>'; }
  function fmtH(h) { return (Math.round(h * 10) / 10).toString(); }

  function renderLegend() {
    var leaves = R.leaveCodes().join(' ');
    $('#legend').innerHTML =
      '<span><i class="lg" style="background:#9DC3EE">D</i>Day</span>' +
      '<span><i class="lg night" style="background:#9DC3EE">N</i>Night (dark band)</span>' +
      '<span><i class="lg" style="background:var(--ot)">D</i>OT (auto on rest days, holidays)</span>' +
      '<span><i class="lg rest"></i>Rest</span>' +
      '<span><i class="lg empty">·</i>Not set</span>' +
      '<span><i class="lg leave">' + esc(R.leaveCodes()[0] || 'VL') + '</i>Leave · ' + esc(leaves) + '</span>' +
      '<span><i class="lg hol"></i>Company holiday</span>' +
      '<span><i class="lg flag" style="background:#9DC3EE"></i>Person breaks a rule</span>' +
      '<span><i class="lg low">2</i>Shift under minimum</span>';
  }

  function renderSheet(A) {
    var S = R.state.settings, n = A.days.length;
    var h = [];
    var css = colsCss(n);
    h.push('<div class="sheet" style="--cols:' + css + ';min-width:' + (LEFTW + 30 * n) + 'px">');

    /* WW band */
    h.push('<div class="row hrow ww">');
    h.push('<div class="lhead sticky s0" style="grid-column:span 6;width:' + LEFTW + 'px">Work week</div>');
    var todayWW = R.wwOf(R.todayKey());
    var i = 0;
    while (i < n) {
      var ww = A.days[i].ww, span = 0;
      while (i + span < n && A.days[i + span].ww === ww) span++;
      h.push('<div class="band' + (ww === todayWW ? ' now' : '') + (span < 2 ? ' tiny' : '') + '" style="grid-column:span ' + span + '">WW' + ww + '</div>');
      i += span;
    }
    h.push('</div>');

    /* day header */
    h.push('<div class="row hrow days">');
    h.push('<div class="lhead ' + stick(0) + '">Personnel</div>');
    h.push('<div class="lhead c2 ' + stick(1) + '">Shift</div>');
    h.push('<div class="lhead c2 tot ' + stick(2) + '" title="Days worked this month">Days</div>');
    h.push('<div class="lhead c2 tot ' + stick(3) + '" title="Hours worked this month">Hrs</div>');
    h.push('<div class="lhead c2 tot ' + stick(4) + '" title="OT shifts this month">OT</div>');
    var prevName = R.MON[(A.m + 11) % 12];
    h.push('<div class="lhead c2 tot edge ' + stick(5) + '" title="Days in a row carried in from ' + prevName + '"><span>' + prevName + '</span><span>run</span></div>');
    A.days.forEach(function (x) {
      var cls = 'dh';
      if (x.dow === S.weekStart) cls += ' wkstart';
      if (x.today) cls += ' today';
      else if (x.hol) cls += ' hol';
      else if (x.dow === 0 || x.dow === 6) cls += ' wk';
      h.push('<div class="' + cls + '" title="' + esc(R.label(x.k) + ' · WW' + x.ww + (x.hol ? ' · Company holiday' : '')) + '"><span>' + R.WD[x.dow] + '</span><b>' + x.d + '</b></div>');
    });
    h.push('</div>');

    /* sections */
    var bySection = [];
    R.state.shifts.forEach(function (s) { bySection.push({ s: s, rows: [] }); });
    var orphan = { s: null, rows: [] };
    A.rows.forEach(function (r) {
      var sec = null;
      for (var j = 0; j < bySection.length; j++) if (bySection[j].s === r.shift) sec = bySection[j];
      (sec || orphan).rows.push(r);
    });
    if (orphan.rows.length) bySection.push(orphan);

    R.ui.order = [];
    cellEls = [];
    var rIndex = 0;
    bySection.forEach(function (sec) {
      if (!sec.rows.length) return;
      var s = sec.s;
      var title = s ? (s.kind === 'night' ? 'Night' : 'Day') + ' · ' + s.name : 'No shift template';
      var sub = s ? daysText(s.days) + ' · ' + s.start + '–' + s.end + ' · ' + fmtH(R.hoursOf(s)) + ' h' + (s.maxOtWeekdays ? ' · ' + s.maxOtWeekdays + ' OT weekday' + (s.maxOtWeekdays > 1 ? 's' : '') : '') : 'Assign a template in Rules & setup';
      h.push('<div class="sec"><span class="sticky s0 sect"><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></span></div>');
      sec.rows.forEach(function (r) {
        R.ui.order.push(r.p.id);
        var lv = Object.keys(r.leave).map(function (c) { return c + ' ' + r.leave[c]; }).join(' · ');
        h.push('<div class="row prow">');
        h.push('<div class="nm ' + stick(0) + '" title="' + esc(r.p.name + (r.p.role ? ' · ' + r.p.role : '') + (lv ? ' · Leave: ' + lv : '')) + '"><i style="background:' + esc(r.color) + '"></i><b>' + esc(r.p.name) + '</b><span>' + esc(shortRole(r.p.role)) + '</span></div>');
        h.push('<div class="c2 ' + stick(1) + '"><span class="tag">' + esc(r.shift ? r.shift.name : '—') + '</span></div>');
        h.push('<div class="c2 tot ' + stick(2) + '"><b>' + r.worked + '</b></div>');
        h.push('<div class="c2 tot ' + stick(3) + '">' + fmtH(r.hours) + '</div>');
        h.push('<div class="c2 tot ' + stick(4) + '"><b>' + r.ot + '</b></div>');
        h.push('<div class="c2 tot edge muted ' + stick(5) + '">' + r.carry + '</div>');
        r.cells.forEach(function (ci, di) {
          var x = A.days[di], c = ci.c;
          var cls = 'c', style = '', label = '';
          if (x.dow === S.weekStart) cls += ' wkstart';
          if (x.today) cls += ' today';
          if (ci.work) {
            cls += ' work ' + c.c;
            label = c.c;
            if (ci.ot) cls += ' ot';
            else style = 'background-color:' + r.color;
          } else if (x.hol) { cls += ' hol'; }
          else if (!c) { cls += ' empty'; label = '·'; if (x.dow === 0 || x.dow === 6) cls += ' wk'; }
          else if (R.isLeave(c)) { cls += ' leave'; label = c.c; }
          else { cls += ' rest'; if (x.dow === 0 || x.dow === 6) cls += ' wk'; }
          if (c && !ci.work && R.isLeave(c) && x.hol) { cls = cls.replace(' hol', '') + ' leave'; label = c.c; }
          if (ci.flags.length) cls += ' flag';
          var tip = r.p.name + ' · ' + R.label(x.k) + ' · WW' + x.ww;
          if (ci.work) tip += ' · ' + (c.c === 'D' ? 'Day' : 'Night') + ' · day ' + ci.run + ' in a row';
          else if (c && R.isLeave(c)) tip += ' · ' + leaveName(c.c);
          else if (c && c.c === 'R') tip += ' · Rest';
          else if (!c) tip += ' · Not set';
          if (ci.ot) tip += ' · OT: ' + ci.otWhy;
          if (x.hol) tip += ' · Company holiday';
          ci.flags.forEach(function (f) { tip += '\n⚠ ' + f; });
          h.push('<div class="' + cls + '" data-r="' + rIndex + '" data-i="' + di + '"' + (style ? ' style="' + style + '"' : '') + ' title="' + esc(tip) + '">' + esc(label) + '</div>');
        });
        h.push('</div>');
        rIndex++;
      });
    });

    if (!A.rows.length) {
      h.push('<div class="emptystate">No people yet. Add them in <a href="#" data-goto="setup">Rules &amp; setup → People</a>, then use <b>Generate from templates</b>.</div>');
    }

    /* coverage */
    h.push('<div class="sec dark"><span class="sticky s0 sect"><b>Coverage</b><span>minimum ' + S.minDay + ' day · ' + S.minNight + ' night</span></span></div>');
    [['day', 'Day', 'D'], ['night', 'Night', 'N']].forEach(function (cv) {
      h.push('<div class="row prow">');
      h.push('<div class="nm covl ' + stick(0) + '" style="grid-column:span 6;width:' + LEFTW + 'px"><b>' + cv[1] + '</b><span>people on ' + cv[1].toLowerCase() + ' shift (' + cv[2] + ')</span></div>');
      A.days.forEach(function (x, di) {
        var cls = 'cv';
        if (x.dow === S.weekStart) cls += ' wkstart';
        if (x.today) cls += ' today';
        var nn = A.cov[x.k][cv[0]];
        var min = cv[0] === 'day' ? S.minDay : S.minNight;
        if (x.hol && !S.coverageOnHolidays) { cls += ' holc'; h.push('<div class="' + cls + '" title="Company holiday — not checked">' + (nn || '–') + '</div>'); return; }
        if (nn < min) cls += ' low';
        h.push('<div class="' + cls + '" data-cover="' + cv[0] + '" data-k="' + x.k + '" title="' + esc(R.label(x.k) + ': ' + nn + ' on ' + cv[1].toLowerCase() + ' shift' + (nn < min ? ' — click to find cover' : '')) + '">' + nn + '</div>');
      });
      h.push('</div>');
    });
    h.push('</div>');

    var wrap = $('#sheetWrap');
    wrap.innerHTML = h.join('');
    var els = wrap.querySelectorAll('.c[data-r]');
    for (var e = 0; e < els.length; e++) {
      var el = els[e], rr = +el.getAttribute('data-r'), ii = +el.getAttribute('data-i');
      (cellEls[rr] = cellEls[rr] || [])[ii] = el;
    }
    if (R.ui.sel) clampSel();
    paintSel();
  }

  function shortRole(r) { r = r || ''; return r.length > 10 ? r.slice(0, 9) + '…' : r; }
  function daysText(days) {
    var names = days.slice().sort().map(function (d) { return R.WD_LONG[d]; });
    var s = days.slice().sort().join(',');
    if (s === '1,2,3,4,5') return 'Mon–Fri';
    if (s === '1,2,3,4,5,6') return 'Mon–Sat';
    if (s === '0,1,2,3,4,5,6') return 'Every day';
    return names.join(' ');
  }
  function leaveName(code) {
    var l = R.state.settings.leaveTypes.filter(function (t) { return t.code === code; })[0];
    return l ? l.name + ' (' + code + ')' : code;
  }

  /* ---------- flags panel ---------- */
  function renderFlags(A) {
    var h = [];
    h.push('<div class="ptitle"><h2>Needs a decision</h2><span class="pill ' + (A.flags.length ? 'red' : 'ok') + '">' + A.flags.length + '</span></div>');
    if (!A.flags.length) h.push('<p class="muted">No rule breaks or coverage gaps this month.</p>');
    A.flags.forEach(function (f, idx) {
      var act;
      if (f.type === 'person') act = '<button class="btn sm" data-flag="' + idx + '" data-act="rest">Set ' + esc(R.label(f.k)) + ' to Rest</button>';
      else act = '<button class="btn sm" data-flag="' + idx + '" data-act="cover">Show who can cover</button>';
      h.push('<div class="frow"><button class="flink mono" data-flag="' + idx + '" data-act="goto">' + esc(R.label(f.k)) + '</button><b class="fwho">' + esc(f.who) + '</b><span class="frule">' + esc(f.rule) + '</span>' + act + '</div>');
    });
    $('#flags').innerHTML = h.join('');
  }

  /* ---------- selection ---------- */
  function rect() {
    var s = R.ui.sel; if (!s) return null;
    return { r0: Math.min(s.r0, s.r1), r1: Math.max(s.r0, s.r1), i0: Math.min(s.i0, s.i1), i1: Math.max(s.i0, s.i1) };
  }
  function clampSel() {
    var s = R.ui.sel, maxR = R.ui.order.length - 1, maxI = R.ui.A.days.length - 1;
    if (maxR < 0) { R.ui.sel = null; return; }
    ['r0', 'r1'].forEach(function (k) { s[k] = Math.max(0, Math.min(maxR, s[k])); });
    ['i0', 'i1'].forEach(function (k) { s[k] = Math.max(0, Math.min(maxI, s[k])); });
  }
  function paintSel() {
    var old = document.querySelectorAll('.c.sel');
    for (var i = 0; i < old.length; i++) old[i].classList.remove('sel');
    var q = rect(); if (!q) return;
    for (var r = q.r0; r <= q.r1; r++) for (var c = q.i0; c <= q.i1; c++) if (cellEls[r] && cellEls[r][c]) cellEls[r][c].classList.add('sel');
  }
  R.selectedCells = function () {
    var q = rect(), out = []; if (!q) return out;
    for (var r = q.r0; r <= q.r1; r++) for (var c = q.i0; c <= q.i1; c++) out.push({ pid: R.ui.order[r], k: R.ui.A.days[c].k });
    return out;
  };
  R.selectCell = function (pid, k) {
    var r = R.ui.order.indexOf(pid), i = -1;
    R.ui.A.days.forEach(function (x, j) { if (x.k === k) i = j; });
    if (r < 0 || i < 0) return;
    R.ui.sel = { r0: r, r1: r, i0: i, i1: i }; R.ui.anchor = { r: r, i: i };
    paintSel();
    var el = cellEls[r][i];
    if (el) {
      var wrap = $('#sheetWrap');
      var er = el.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
      if (er.left < wr.left + LEFTW || er.right > wr.right) wrap.scrollLeft += er.left - wr.left - LEFTW - 120;
      if (er.top < wr.top + 80 || er.bottom > wr.bottom) wrap.scrollTop += er.top - wr.top - 140;
    }
  };

  /* ---------- apply values ---------- */
  R.applyToSelection = function (val, label) {
    var cells = R.selectedCells(); if (!cells.length) return;
    var list = cells.map(function (x) {
      var v = val;
      if (typeof val === 'function') v = val(R.getCell(x.pid, x.k), x);
      return { pid: x.pid, k: x.k, v: v };
    });
    var n = R.setCells(list, label + (cells.length > 1 ? ' (' + cells.length + ' cells)' : ' · ' + nameOf(cells[0].pid) + ' ' + R.label(cells[0].k)));
    return n;
  };
  function nameOf(pid) { var p = R.personById(pid); return p ? p.name : ''; }

  function codeValue(code) {
    return function (prev) {
      var v = { c: code };
      if (prev && (code === 'D' || code === 'N') && prev.ot != null && (prev.c === 'D' || prev.c === 'N')) { v.ot = prev.ot; if (prev.reason) v.reason = prev.reason; }
      return v;
    };
  }
  R.applyCode = function (code) {
    var names = { D: 'Day', N: 'Night', R: 'Rest' };
    R.applyToSelection(code === null ? null : codeValue(code), code === null ? 'Clear' : 'Set ' + (names[code] || code));
  };
  R.applyOT = function (mode, reason) {
    R.applyToSelection(function (prev) {
      if (!R.isWork(prev)) return prev || null;
      var v = { c: prev.c };
      if (mode === 'on') { v.ot = true; if (reason) v.reason = reason; }
      else if (mode === 'off') { v.ot = false; if (reason) v.reason = reason; }
      return v;
    }, mode === 'auto' ? 'OT back to automatic' : mode === 'on' ? 'Mark OT' : 'Mark not OT');
  };

  /* ---------- popover editor ---------- */
  R.openEditor = function () {
    var cells = R.selectedCells(); if (!cells.length) return;
    var q = rect(), anchorEl = cellEls[q.r1] && cellEls[q.r1][q.i1];
    var pop = $('#pop'), A = R.ui.A, S = R.state.settings;
    var h = [];
    var single = cells.length === 1;
    var cur = single ? R.getCell(cells[0].pid, cells[0].k) : null;
    if (single) {
      var p = R.personById(cells[0].pid), k = cells[0].k, sh = R.shiftOf(p);
      var row = null; A.rows.forEach(function (r) { if (r.p.id === p.id) row = r; });
      var di = -1; A.days.forEach(function (x, j) { if (x.k === k) di = j; });
      var info = row.cells[di];
      h.push('<div class="ph"><div><div class="pt">' + esc(R.label(k)) + ' · WW' + R.wwOf(k) + '</div><div class="ps">' + esc(p.name) + (sh ? ' · ' + esc(sh.name) + ' ' + sh.start + '–' + sh.end : '') + (info.work ? ' · day ' + info.run + ' in a row' : '') + (R.isHoliday(k) ? ' · Company holiday' : '') + '</div></div><button class="icon" data-pop="close" aria-label="Close">' + R.icon('x') + '</button></div>');
    } else {
      var ppl = {}; cells.forEach(function (c) { ppl[c.pid] = 1; });
      h.push('<div class="ph"><div><div class="pt">' + cells.length + ' cells selected</div><div class="ps">' + Object.keys(ppl).length + ' people · ' + esc(R.label(cells[0].k)) + ' → ' + esc(R.label(cells[cells.length - 1].k)) + '</div></div><button class="icon" data-pop="close" aria-label="Close">' + R.icon('x') + '</button></div>');
    }
    function codeBtn(code, name, key) {
      var on = cur && cur.c === code;
      var cls = 'cb' + (on ? ' on' : '') + (code === 'N' ? ' n' : '');
      return '<button class="' + cls + '" data-code="' + esc(code) + '" aria-pressed="' + (on ? 'true' : 'false') + '"><b class="mono">' + esc(code) + '</b><span>' + esc(name) + '</span><kbd>' + esc(key) + '</kbd></button>';
    }
    h.push('<div class="cbs">' + codeBtn('D', 'Day', 'D') + codeBtn('N', 'Night', 'N') + codeBtn('R', 'Rest', 'R') + '</div>');
    h.push('<div class="cbs leaves">');
    var keys = R.leaveKeys();
    S.leaveTypes.forEach(function (l) { h.push(codeBtn(l.code, l.name.replace(/ leave$/i, ''), keys[l.code] || '')); });
    h.push('<button class="cb clear" data-code=""><b class="mono">×</b><span>Clear</span><kbd>Del</kbd></button></div>');

    /* OT */
    if (single && R.isWork(cur)) {
      var p2 = R.personById(cells[0].pid);
      var autoWhy = R.otReason(p2, cells[0].k, { c: cur.c });
      var mode = cur.ot === true ? 'on' : cur.ot === false ? 'off' : 'auto';
      h.push('<div class="otbox"><div class="otl">OT: <b>' + (R.isOT(p2, cells[0].k, cur) ? 'Yes' : 'No') + '</b> <span class="muted">' + (mode === 'auto' ? '(automatic' + (autoWhy ? ' — ' + esc(autoWhy) : ' — regular day') + ')' : '(manual override)') + '</span></div>');
      h.push('<div class="seg" role="group" aria-label="OT setting">' +
        '<button data-ot="auto" aria-pressed="' + (mode === 'auto') + '">Automatic</button>' +
        '<button data-ot="on" aria-pressed="' + (mode === 'on') + '">Force OT</button>' +
        '<button data-ot="off" aria-pressed="' + (mode === 'off') + '">Not OT</button></div>');
      if (mode !== 'auto') h.push('<label class="reason">Reason <input id="otReason" value="' + esc(cur.reason || '') + '" placeholder="e.g. approved by supervisor"></label>');
      h.push('</div>');
    } else if (!single) {
      h.push('<div class="otbox"><div class="seg" role="group" aria-label="OT setting"><button data-ot="auto">OT automatic</button><button data-ot="on">Force OT</button><button data-ot="off">Not OT</button></div></div>');
    }

    /* flags for this cell */
    if (single) {
      var fl = (info && info.flags) || [];
      if (fl.length) h.push('<div class="warn">' + R.icon('warn') + '<div>' + fl.map(function (t) { return '<div>' + esc(t) + '</div>'; }).join('') + '</div></div>');
    }
    h.push('<div class="phint">Tip: type <kbd>D</kbd> <kbd>N</kbd> <kbd>R</kbd> on selected cells · drag to select many · <kbd>Ctrl</kbd>+<kbd>Z</kbd> undo</div>');

    pop.innerHTML = h.join('');
    pop.hidden = false;
    var pr = pop.getBoundingClientRect();
    var ar = anchorEl ? anchorEl.getBoundingClientRect() : { left: 200, right: 230, top: 200, bottom: 230 };
    var left = ar.right + 10, top = ar.top - 20;
    if (left + pr.width > window.innerWidth - 10) left = ar.left - pr.width - 10;
    if (left < 10) left = 10;
    if (top + pr.height > window.innerHeight - 10) top = window.innerHeight - pr.height - 10;
    if (top < 10) top = 10;
    pop.style.left = left + 'px'; pop.style.top = top + 'px';
  };
  R.closeEditor = function () { $('#pop').hidden = true; };

  R.leaveKeys = function () {
    var used = { D: 1, N: 1, R: 1, O: 1, A: 1, Z: 1, Y: 1 }, out = {};
    R.state.settings.leaveTypes.forEach(function (l) {
      var ch = (l.code || '').charAt(0).toUpperCase();
      if (ch && !used[ch]) { out[l.code] = ch; used[ch] = 1; }
    });
    return out;
  };

  /* ---------- sheet events ---------- */
  R.bindSheet = function () {
    var wrap = $('#sheetWrap');
    wrap.addEventListener('mousedown', function (e) {
      var el = e.target.closest('.c[data-r]');
      if (!el || e.button !== 0) return;
      var r = +el.getAttribute('data-r'), i = +el.getAttribute('data-i');
      if (e.shiftKey && R.ui.anchor) R.ui.sel = { r0: R.ui.anchor.r, i0: R.ui.anchor.i, r1: r, i1: i };
      else { R.ui.anchor = { r: r, i: i }; R.ui.sel = { r0: r, i0: i, r1: r, i1: i }; }
      dragging = true;
      R.closeEditor();
      paintSel();
      e.preventDefault();
    });
    wrap.addEventListener('mouseover', function (e) {
      if (!dragging) return;
      var el = e.target.closest('.c[data-r]'); if (!el) return;
      R.ui.sel.r1 = +el.getAttribute('data-r'); R.ui.sel.i1 = +el.getAttribute('data-i');
      paintSel();
    });
    document.addEventListener('mouseup', function () {
      if (!dragging) return;
      dragging = false;
      R.openEditor();
    });
    wrap.addEventListener('click', function (e) {
      var cv = e.target.closest('[data-cover]');
      if (cv) R.openCover(cv.getAttribute('data-k'), cv.getAttribute('data-cover'));
      var g = e.target.closest('[data-goto]');
      if (g) { e.preventDefault(); R.setView(g.getAttribute('data-goto')); }
    });

    $('#pop').addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.getAttribute('data-pop') === 'close') { R.closeEditor(); return; }
      if (b.hasAttribute('data-code')) {
        var code = b.getAttribute('data-code');
        R.applyCode(code === '' ? null : code);
        R.closeEditor();
        return;
      }
      if (b.hasAttribute('data-ot')) {
        var reasonEl = $('#otReason');
        R.applyOT(b.getAttribute('data-ot'), reasonEl ? reasonEl.value : '');
        R.openEditor();
      }
    });
    $('#pop').addEventListener('change', function (e) {
      if (e.target.id === 'otReason') {
        var cells = R.selectedCells();
        if (cells.length !== 1) return;
        var c = R.getCell(cells[0].pid, cells[0].k); if (!c) return;
        var v = R.clone(c); v.reason = e.target.value;
        R.setCells([{ pid: cells[0].pid, k: cells[0].k, v: v }], 'OT reason');
      }
    });

    $('#flags').addEventListener('click', function (e) {
      var b = e.target.closest('[data-flag]'); if (!b) return;
      var f = R.ui.A.flags[+b.getAttribute('data-flag')];
      var act = b.getAttribute('data-act');
      if (act === 'rest') {
        R.setCells([{ pid: f.pid, k: f.k, v: { c: 'R' } }], 'Set Rest · ' + f.who + ' ' + R.label(f.k));
        R.toast('Set ' + f.who + ' to Rest on ' + R.label(f.k) + '. Ctrl+Z to undo.');
      } else if (act === 'cover') R.openCover(f.k, f.kind);
      else if (act === 'goto') {
        if (f.type === 'person') R.selectCell(f.pid, f.k);
        else R.openCover(f.k, f.kind);
      }
    });
  };

  /* keyboard: called from app */
  R.sheetKey = function (e) {
    var s = R.ui.sel; if (!s) return false;
    var key = e.key;
    var maxR = R.ui.order.length - 1, maxI = R.ui.A.days.length - 1;
    function move(dr, di) {
      var r = Math.max(0, Math.min(maxR, s.r1 + dr)), i = Math.max(0, Math.min(maxI, s.i1 + di));
      if (e.shiftKey) { s.r1 = r; s.i1 = i; }
      else { R.ui.sel = { r0: r, r1: r, i0: i, i1: i }; R.ui.anchor = { r: r, i: i }; }
      R.closeEditor(); paintSel();
      var el = cellEls[r] && cellEls[r][i]; if (el) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
    if (key === 'ArrowRight') { move(0, 1); return true; }
    if (key === 'ArrowLeft') { move(0, -1); return true; }
    if (key === 'ArrowDown') { move(1, 0); return true; }
    if (key === 'ArrowUp') { move(-1, 0); return true; }
    if (key === 'Enter') { R.openEditor(); return true; }
    if (key === 'Escape') { R.closeEditor(); R.ui.sel = null; paintSel(); return true; }
    var single = s.r0 === s.r1 && s.i0 === s.i1;
    var up = key.length === 1 ? key.toUpperCase() : key;
    var leaveMap = {}; var lk = R.leaveKeys(); Object.keys(lk).forEach(function (c) { leaveMap[lk[c]] = c; });
    var code = null, handled = false;
    if (up === 'D' || up === 'N' || up === 'R') { code = up; handled = true; }
    else if (leaveMap[up]) { code = leaveMap[up]; handled = true; }
    else if (key === 'Delete' || key === 'Backspace') { R.applyCode(null); handled = 'clear'; }
    else if (up === 'O') {
      var cells = R.selectedCells(), anyOT = false;
      cells.forEach(function (c) { var p = R.personById(c.pid), v = R.getCell(c.pid, c.k); if (R.isOT(p, c.k, v)) anyOT = true; });
      R.applyOT(anyOT ? 'off' : 'on', '');
      handled = 'ot';
    } else if (up === 'A') { R.applyOT('auto', ''); handled = 'ot'; }
    if (!handled) return false;
    if (code) R.applyCode(code);
    R.closeEditor();
    if (single && code) {
      var ni = Math.min(maxI, s.i1 + 1);
      R.ui.sel = { r0: s.r0, r1: s.r0, i0: ni, i1: ni }; R.ui.anchor = { r: s.r0, i: ni };
      paintSel();
    }
    return true;
  };

  /* ---------- modal helpers ---------- */
  R.openModal = function (html, cls) {
    var m = $('#modal');
    $('#modalBox').className = 'modal' + (cls ? ' ' + cls : '');
    $('#modalBox').innerHTML = html;
    m.hidden = false;
    var f = $('#modalBox').querySelector('[autofocus]') || $('#modalBox').querySelector('button');
    if (f) f.focus();
  };
  R.closeModal = function () { $('#modal').hidden = true; $('#modalBox').innerHTML = ''; };

  /* ---------- cover finder ---------- */
  R.openCover = function (k, kind) {
    R.closeEditor();
    var res = R.coverCandidates(k, kind);
    var S = R.state.settings;
    var n = R.ui.A && R.ui.A.cov[k] ? R.ui.A.cov[k][kind] : 0;
    var min = kind === 'day' ? S.minDay : S.minNight;
    var h = [];
    h.push('<div class="mh"><div><div class="eyebrow ' + (n < min ? 'red' : '') + '">' + (kind === 'day' ? 'Day' : 'Night') + ' shift' + (n < min ? ' under minimum' : '') + '</div><h2>' + esc(R.label(k)) + ' · WW' + R.wwOf(k) + '</h2><p>' + n + ' of ' + min + ' on duty' + (n < min ? ' — need ' + (min - n) + ' more' : '') + '.</p></div><button class="icon" data-close aria-label="Close">' + R.icon('x') + '</button></div>');
    h.push('<div class="eyebrow">Can cover · ' + res.ok.length + '</div>');
    if (!res.ok.length) h.push('<p class="muted">Nobody can cover without breaking a rule. Check the reasons below, or override manually on the sheet.</p>');
    res.ok.forEach(function (c) {
      h.push('<div class="cand ok"><i style="background:' + esc(c.color) + '"></i><div class="cd"><b>' + esc(c.p.name) + '</b> <span class="muted">· ' + esc(c.p.role || '') + (c.shift ? ' · ' + esc(c.shift.name) : '') + ' · OT this month: ' + c.ot + '</span>' +
        (c.otWhy ? '<div class="small">Will count as OT — ' + esc(c.otWhy) + '</div>' : '<div class="small">Regular shift for them</div>') +
        (c.offTemplate ? '<div class="small warnt">Not their usual shift type</div>' : '') + '</div>' +
        '<button class="btn dark" data-assign="' + esc(c.p.id) + '">Assign</button></div>');
    });
    h.push('<div class="eyebrow">Not allowed · ' + res.blocked.length + '</div>');
    res.blocked.forEach(function (c) {
      h.push('<div class="cand"><i style="background:' + esc(c.color) + '"></i><div class="cd"><b>' + esc(c.p.name) + '</b><div class="small">' + esc(c.why) + '</div></div></div>');
    });
    R.openModal(h.join(''), 'wide');
    $('#modalBox').onclick = function (e) {
      var b = e.target.closest('[data-assign]');
      if (b) {
        var p = R.personById(b.getAttribute('data-assign'));
        R.setCells([{ pid: p.id, k: k, v: { c: res.code } }], 'Assign ' + (kind === 'day' ? 'Day' : 'Night') + ' cover · ' + p.name + ' ' + R.label(k));
        R.toast(p.name + ' assigned to ' + kind + ' shift on ' + R.label(k) + '.');
        R.openCover(k, kind);
      }
      if (e.target.closest('[data-close]')) R.closeModal();
    };
  };

  /* ---------- generate ---------- */
  R.openGenerate = function () {
    var y = R.ui.y, m = R.ui.m;
    function preview(mode) {
      var plan = R.generatePlan(y, m, mode);
      var backup = R.state.entries;
      R.state.entries = R.clone(backup);
      plan.list.forEach(function (it) { var E = R.state.entries; if (!E[it.pid]) E[it.pid] = {}; E[it.pid][it.k] = it.v; });
      var flags = R.analyze(y, m).flags.length;
      R.state.entries = backup;
      return { filled: plan.filled, kept: plan.kept, flags: flags, plan: plan };
    }
    function draw(mode) {
      var pv = preview(mode);
      var opts = [
        ['empty', 'Fill empty days only', 'Your edits, OT and leave stay exactly as they are.', true],
        ['replace', 'Replace shifts, keep leave', 'Resets D / N / Rest and OT overrides to the templates. Leave is kept.'],
        ['fresh', 'Start over', 'Clears everything this month, including leave, then generates.']
      ];
      var h = [];
      h.push('<div class="mh"><div><h2>Generate ' + R.MONTHS[m] + ' ' + y + ' from templates</h2><p>Uses each person\'s shift template, personal rest weekday and the holiday calendar. Sunday / weekend cover is not auto-assigned — use “Show who can cover” on each gap.</p></div><button class="icon" data-close aria-label="Close">' + R.icon('x') + '</button></div>');
      h.push('<fieldset class="radios"><legend>What to do with this month’s existing entries</legend>');
      opts.forEach(function (o) {
        h.push('<label class="radio' + (mode === o[0] ? ' on' : '') + '"><input type="radio" name="gm" value="' + o[0] + '"' + (mode === o[0] ? ' checked' : '') + '><span><b>' + o[1] + (o[3] ? ' <em>Recommended</em>' : '') + '</b><span>' + o[2] + '</span></span></label>');
      });
      h.push('</fieldset>');
      h.push('<div class="kpis"><div><b>' + pv.filled + '</b><span>days to fill</span></div><div><b>' + pv.kept + '</b><span>entries kept</span></div><div><b>' + pv.flags + '</b><span>flags after</span></div></div>');
      h.push('<p class="muted small">This is one step in History — Ctrl+Z undoes it completely.</p>');
      h.push('<div class="mf"><button class="btn" data-close>Cancel</button><button class="btn primary" data-gen="' + mode + '"' + (pv.filled ? '' : ' disabled') + '>Generate</button></div>');
      R.openModal(h.join(''));
      $('#modalBox').onchange = function (e) { if (e.target.name === 'gm') draw(e.target.value); };
      $('#modalBox').onclick = function (e) {
        if (e.target.closest('[data-close]')) R.closeModal();
        var g = e.target.closest('[data-gen]');
        if (g) {
          var n = R.setCells(pv.plan.list, 'Generate ' + R.MONTHS[m] + ' ' + y + ' (' + g.getAttribute('data-gen') + ')');
          R.closeModal();
          R.toast(n ? 'Generated ' + n + ' days. Ctrl+Z to undo.' : 'Nothing to change.');
        }
      };
    }
    draw('empty');
  };

  /* ---------- history ---------- */
  R.openHistory = function () {
    var h = [];
    h.push('<div class="mh"><div><h2>History</h2><p>Undo works for changes made since the app was opened. The log below is kept with your data.</p></div><button class="icon" data-close aria-label="Close">' + R.icon('x') + '</button></div>');
    h.push('<div class="mf left"><button class="btn" data-h="undo"' + (R.undoStack.length ? '' : ' disabled') + '>Undo' + (R.undoStack.length ? ': ' + esc(R.undoStack[R.undoStack.length - 1].label) : '') + '</button><button class="btn" data-h="redo"' + (R.redoStack.length ? '' : ' disabled') + '>Redo</button></div>');
    h.push('<div class="log">');
    if (!R.state.log.length) h.push('<p class="muted">No changes yet.</p>');
    R.state.log.slice(0, 120).forEach(function (l) {
      var d = new Date(l.t);
      h.push('<div class="lrow"><span class="mono muted">' + d.getDate() + ' ' + R.MON[d.getMonth()] + ' ' + R.timeStr(d) + '</span><span>' + esc(l.label) + '</span></div>');
    });
    h.push('</div>');
    R.openModal(h.join(''), 'wide');
    $('#modalBox').onclick = function (e) {
      if (e.target.closest('[data-close]')) R.closeModal();
      var b = e.target.closest('[data-h]');
      if (b) { if (b.getAttribute('data-h') === 'undo') R.undo(); else R.redo(); R.openHistory(); }
    };
  };

  /* ---------- icons ---------- */
  var ICONS = {
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    warn: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18h.01"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    check: '<path d="M5 12l5 5L20 7"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'
  };
  R.icon = function (n) { return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || '') + '</svg>'; };
})();
