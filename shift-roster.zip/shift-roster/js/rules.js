/* Shift Roster — rules engine: OT, rule checks, coverage, month analysis, generator */
(function () {
  'use strict';
  var R = window.R;

  R.CONT = '↳ ';
  R.isCont = function (msg) { return msg.indexOf(R.CONT) === 0; };

  R.isWork = function (c) { return !!c && (c.c === 'D' || c.c === 'N'); };
  R.isLeave = function (c) { return !!c && R.leaveCodes().indexOf(c.c) >= 0; };

  R.isHoliday = function (k) {
    var s = R.state.settings;
    return (s.holidayDays || []).indexOf(R.dom(k)) >= 0 || (s.holidayDates || []).indexOf(k) >= 0;
  };

  /* Why a worked cell is OT ('' = not OT) */
  R.otReason = function (p, k, c) {
    if (!R.isWork(c)) return '';
    if (c.ot === true) return c.reason ? 'Manual: ' + c.reason : 'Manual OT';
    if (c.ot === false) return '';
    var d = R.dow(k), sh = R.shiftOf(p);
    if (R.isHoliday(k)) return 'Company holiday';
    if (sh && sh.days.indexOf(d) < 0) return 'Rest day (' + R.WD_LONG[d] + ')';
    if (p.restDow === d) return 'Personal rest weekday';
    if (p.otDow === d) return 'Designated OT weekday';
    return '';
  };
  R.isOT = function (p, k, c) { return R.otReason(p, k, c) !== ''; };

  R.hoursFor = function (p, code) {
    var sh = R.shiftOf(p), kind = code === 'N' ? 'night' : 'day';
    if (sh && sh.kind === kind) return R.hoursOf(sh);
    for (var i = 0; i < R.state.shifts.length; i++) if (R.state.shifts[i].kind === kind) return R.hoursOf(R.state.shifts[i]);
    return 0;
  };

  /* Rule checks for one person over [from, to]. ov = {dateKey: cell|null} to simulate.
     Returns {dateKey: [message, ...]} */
  R.personViolations = function (p, from, to, ov) {
    var S = R.state.settings, sh = R.shiftOf(p), res = {};
    function get(k) { return ov && Object.prototype.hasOwnProperty.call(ov, k) ? ov[k] : R.getCell(p.id, k); }
    function add(k, msg) { (res[k] = res[k] || []).push(msg); }

    var run = 0, prev = null, k, prevK = null, runStart = null, over = [];
    function closeRun(endK) {
      if (over.length) {
        add(over[0], run + ' days in a row (max ' + S.maxRun + '), ' + R.label(runStart) + ' – ' + R.label(endK));
        for (var j = 1; j < over.length; j++) add(over[j], R.CONT + 'Still over ' + S.maxRun + ' days in a row');
      }
      over = [];
    }
    var start = R.addDays(from, -45);
    for (k = start; k <= to; k = R.addDays(k, 1)) {
      var c = get(k);
      if (R.isWork(c)) {
        if (run === 0) runStart = k;
        run++;
        if (k >= from) {
          if (run > S.maxRun) over.push(k);
          if (S.nightToDay && c.c === 'D' && prev && prev.c === 'N') add(k, 'Day shift right after a night shift (24 h on duty)');
        }
      } else {
        if (run > 0) closeRun(prevK);
        run = 0;
      }
      prev = c; prevK = k;
    }
    if (run > 0) {
      /* run continues past the window: look ahead to find where it ends */
      var endK = to;
      while (R.isWork(get(R.addDays(endK, 1))) && R.dayDiff(to, endK) < 60) { endK = R.addDays(endK, 1); run++; }
      closeRun(endK);
    }

    if (!sh) return res;
    for (var ws = R.weekStartKey(from); ws <= to; ws = R.addDays(ws, 7)) {
      var wd = 0, weekendWork = [], otWd = [];
      for (var i = 0; i < 7; i++) {
        k = R.addDays(ws, i);
        var cc = get(k);
        if (!R.isWork(cc)) continue;
        var d = R.dow(k), hol = R.isHoliday(k);
        if (d >= 1 && d <= 5) wd++;
        if ((d === 0 || d === 6) && sh.days.indexOf(d) < 0 && !hol) weekendWork.push(k);
        if (d >= 1 && d <= 5 && !hol && R.isOT(p, k, cc)) otWd.push(k);
      }
      if (sh.weekendRule) {
        var allowed = wd >= S.weekendFull ? +S.weekendFullAllow : +S.weekendShortAllow;
        if (weekendWork.length > allowed) {
          add(weekendWork[weekendWork.length - 1], 'Works ' + weekendWork.length + ' weekend rest days after ' + wd + ' weekdays in WW' + R.wwOf(ws) + ' (max ' + allowed + ')');
        }
      }
      if (sh.maxOtWeekdays != null && sh.maxOtWeekdays !== '' && otWd.length > +sh.maxOtWeekdays) {
        add(otWd[otWd.length - 1], otWd.length + ' OT weekdays in WW' + R.wwOf(ws) + ' (max ' + sh.maxOtWeekdays + ')');
      }
    }
    return res;
  };

  /* run length ending on day k (inclusive) */
  R.runEnding = function (p, k) {
    var run = 0;
    for (var i = 0; i < 60; i++) {
      if (!R.isWork(R.getCell(p.id, R.addDays(k, -i)))) break;
      run++;
    }
    return run;
  };

  function isEngineer(p) {
    var role = (R.state.settings.engineerRole || '').toLowerCase();
    return role && (p.role || '').toLowerCase().indexOf(role) >= 0;
  }

  /* Full analysis of a month */
  R.analyze = function (y, m) {
    var S = R.state.settings;
    var n = R.daysInMonth(y, m);
    var first = R.key(y, m, 1), last = R.key(y, m, n);
    var today = R.todayKey();
    var days = [];
    for (var d = 1; d <= n; d++) {
      var k = R.key(y, m, d);
      days.push({ k: k, d: d, dow: R.dow(k), hol: R.isHoliday(k), ww: R.wwOf(k), today: k === today });
    }
    var people = R.activePeople();
    var cov = {}, flags = [];
    days.forEach(function (x) { cov[x.k] = { day: 0, night: 0, dayEng: 0, nightEng: 0 }; });

    var rows = people.map(function (p) {
      var viol = R.personViolations(p, first, last);
      var carry = R.runEnding(p, R.addDays(first, -1));
      var run = carry, worked = 0, hours = 0, ot = 0, otHours = 0, leave = {};
      var cells = days.map(function (x) {
        var c = R.getCell(p.id, x.k);
        var info = { k: x.k, c: c, work: R.isWork(c), ot: false, otWhy: '', run: 0, flags: viol[x.k] || [] };
        if (info.work) {
          run++; worked++;
          var h = R.hoursFor(p, c.c);
          hours += h;
          info.run = run;
          info.otWhy = R.otReason(p, x.k, c);
          info.ot = info.otWhy !== '';
          if (info.ot) { ot++; otHours += h; }
          if (c.c === 'D') { cov[x.k].day++; if (isEngineer(p)) cov[x.k].dayEng++; }
          else { cov[x.k].night++; if (isEngineer(p)) cov[x.k].nightEng++; }
        } else {
          run = 0;
          if (R.isLeave(c)) leave[c.c] = (leave[c.c] || 0) + 1;
        }
        info.flags.forEach(function (msg) {
          if (!R.isCont(msg)) flags.push({ type: 'person', pid: p.id, who: p.name, k: x.k, rule: msg });
        });
        return info;
      });
      return { p: p, shift: R.shiftOf(p), color: R.colorOf(p), cells: cells, carry: carry, worked: worked, hours: hours, ot: ot, otHours: otHours, leave: leave };
    });

    var otTotal = 0, otHoursTotal = 0;
    rows.forEach(function (r) { otTotal += r.ot; otHoursTotal += r.otHours; });

    var minDay = null, minNight = null;
    days.forEach(function (x) {
      if (x.hol && !S.coverageOnHolidays) return;
      var c = cov[x.k];
      if (minDay == null || c.day < minDay.n) minDay = { n: c.day, k: x.k };
      if (minNight == null || c.night < minNight.n) minNight = { n: c.night, k: x.k };
      if (c.day < S.minDay) flags.push({ type: 'cover', kind: 'day', who: 'Day coverage', k: x.k, rule: 'Only ' + c.day + ' on day shift (min ' + S.minDay + ')' });
      if (c.night < S.minNight) flags.push({ type: 'cover', kind: 'night', who: 'Night coverage', k: x.k, rule: 'Only ' + c.night + ' on night shift (min ' + S.minNight + ')' });
      if (S.engineerPerShift) {
        if (c.day > 0 && c.dayEng === 0) flags.push({ type: 'cover', kind: 'day', eng: true, who: 'Day shift', k: x.k, rule: 'No ' + S.engineerRole + ' on day shift' });
        if (c.night > 0 && c.nightEng === 0) flags.push({ type: 'cover', kind: 'night', eng: true, who: 'Night shift', k: x.k, rule: 'No ' + S.engineerRole + ' on night shift' });
      }
    });
    flags.sort(function (a, b) { return a.k < b.k ? -1 : a.k > b.k ? 1 : 0; });

    return { y: y, m: m, days: days, rows: rows, cov: cov, flags: flags, otTotal: otTotal, otHours: otHoursTotal, minDay: minDay, minNight: minNight, first: first, last: last };
  };

  /* Who can cover a shift on date k */
  R.coverCandidates = function (k, kind) {
    var code = kind === 'night' ? 'N' : 'D';
    var from = R.addDays(k, -40), to = R.addDays(k, 20);
    var monthFirst = k.slice(0, 8) + '01';
    var y = +k.slice(0, 4), m = +k.slice(5, 7) - 1;
    var monthLast = R.key(y, m, R.daysInMonth(y, m));
    var ok = [], blocked = [];
    R.activePeople().forEach(function (p) {
      var c = R.getCell(p.id, k);
      if (R.isWork(c)) return;
      var otCount = 0;
      for (var d = monthFirst; d <= monthLast; d = R.addDays(d, 1)) {
        var cc = R.getCell(p.id, d);
        if (R.isOT(p, d, cc)) otCount++;
      }
      var entry = { p: p, ot: otCount, color: R.colorOf(p), shift: R.shiftOf(p) };
      if (R.isLeave(c)) { entry.why = 'On leave (' + c.c + ')'; blocked.push(entry); return; }
      var before = R.personViolations(p, from, to);
      var ov = {}; ov[k] = { c: code };
      var after = R.personViolations(p, from, to, ov);
      var fresh = [];
      Object.keys(after).forEach(function (dk) {
        after[dk].forEach(function (msg) {
          if (!before[dk] || before[dk].indexOf(msg) < 0) fresh.push((dk === k ? '' : R.label(dk) + ': ') + msg);
        });
      });
      entry.otWhy = R.otReason(p, k, { c: code });
      entry.offTemplate = entry.shift && ((entry.shift.kind === 'night') !== (kind === 'night'));
      fresh = fresh.filter(function (t) { return t.indexOf(R.CONT) < 0; });
      if (fresh.length) { entry.why = fresh[0]; blocked.push(entry); }
      else ok.push(entry);
    });
    ok.sort(function (a, b) { return (a.offTemplate - b.offTemplate) || (a.ot - b.ot); });
    return { ok: ok, blocked: blocked, code: code };
  };

  /* Template value for a person on a date */
  R.templateCell = function (p, k) {
    var sh = R.shiftOf(p), d = R.dow(k);
    if (!sh || R.isHoliday(k)) return { c: 'R' };
    if (sh.days.indexOf(d) >= 0 && p.restDow !== d) return { c: sh.kind === 'night' ? 'N' : 'D' };
    return { c: 'R' };
  };

  /* Build the change list for "generate from templates" */
  R.generatePlan = function (y, m, mode) {
    var n = R.daysInMonth(y, m), list = [], kept = 0, filled = 0;
    R.activePeople().forEach(function (p) {
      for (var d = 1; d <= n; d++) {
        var k = R.key(y, m, d), c = R.getCell(p.id, k), t = R.templateCell(p, k);
        if (mode === 'empty') {
          if (c) { kept++; continue; }
          list.push({ pid: p.id, k: k, v: t }); filled++;
        } else if (mode === 'replace') {
          if (R.isLeave(c)) { kept++; continue; }
          list.push({ pid: p.id, k: k, v: t }); filled++;
        } else {
          list.push({ pid: p.id, k: k, v: t }); filled++;
        }
      }
    });
    return { list: list, kept: kept, filled: filled };
  };
})();
