/* Shift Roster — core: dates, data model, saving, history */
(function () {
  'use strict';
  var R = (window.R = window.R || {});

  /* ---------- small helpers ---------- */
  R.WD = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  R.WD_LONG = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  R.MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  R.MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  R.pad = pad;
  R.key = function (y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); };
  R.parse = function (k) { var a = k.split('-'); return new Date(+a[0], +a[1] - 1, +a[2]); };
  R.keyOf = function (dt) { return R.key(dt.getFullYear(), dt.getMonth(), dt.getDate()); };
  R.addDays = function (k, n) { var d = R.parse(k); d.setDate(d.getDate() + n); return R.keyOf(d); };
  R.dow = function (k) { return R.parse(k).getDay(); };
  R.dom = function (k) { return +k.slice(8, 10); };
  R.daysInMonth = function (y, m) { return new Date(y, m + 1, 0).getDate(); };
  R.todayKey = function () { return R.keyOf(new Date()); };
  R.dayDiff = function (a, b) { return Math.round((R.parse(b) - R.parse(a)) / 86400000); };
  R.label = function (k) { var d = R.parse(k); return R.WD_LONG[d.getDay()] + ' ' + d.getDate() + ' ' + R.MON[d.getMonth()]; };
  R.uid = function () { return Math.random().toString(36).slice(2, 9); };
  R.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  R.clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  R.timeStr = function (d) { return pad(d.getHours()) + ':' + pad(d.getMinutes()); };

  R.hoursOf = function (shift) {
    if (!shift) return 0;
    var a = (shift.start || '0:0').split(':'), b = (shift.end || '0:0').split(':');
    var m = (+b[0] * 60 + +b[1]) - (+a[0] * 60 + +a[1]);
    if (m <= 0) m += 24 * 60;
    return Math.round((m / 60) * 100) / 100;
  };

  /* ---------- work weeks ---------- */
  R.weekStartKey = function (k) {
    var ws = R.state.settings.weekStart;
    return R.addDays(k, -((R.dow(k) - ws + 7) % 7));
  };
  R.wwOf = function (k) {
    var s = R.state.settings;
    var anchor = R.weekStartKey(s.wwAnchorDate);
    var weeks = Math.round(R.dayDiff(anchor, R.weekStartKey(k)) / 7);
    var per = Math.max(1, +s.wwPerYear || 52);
    var n = (+s.wwAnchorNum || 1) + weeks;
    return (((n - 1) % per) + per) % per + 1;
  };

  /* ---------- default data ---------- */
  R.PALETTE = ['#9DC3EE', '#E5DDFB', '#A3D9B1', '#F9D3DE', '#8FD0CF', '#DDE3EA', '#F2B9A0', '#C9E4A6', '#B9C4F2', '#F3D7B6'];

  R.defaultSettings = function () {
    return {
      weekStart: 6,
      wwAnchorDate: '2026-10-10',
      wwAnchorNum: 28,
      wwPerYear: 52,
      minDay: 3,
      minNight: 3,
      maxRun: 6,
      nightToDay: true,
      engineerPerShift: false,
      engineerRole: 'Engineer',
      weekendFull: 5,
      weekendFullAllow: 1,
      weekendShortAllow: 2,
      otColor: '#FFD43B',
      holidayDays: [3, 4],
      holidayDates: [],
      coverageOnHolidays: false,
      backupDays: 2,
      leaveTypes: [
        { code: 'VL', name: 'Vacation leave' },
        { code: 'SL', name: 'Sick leave' },
        { code: 'EL', name: 'Emergency leave' },
        { code: 'TR', name: 'Training' }
      ]
    };
  };

  R.sampleState = function () {
    var groups = [
      { id: 'g1', name: 'Pair A', color: '#9DC3EE' },
      { id: 'g2', name: 'Pair B', color: '#E5DDFB' },
      { id: 'g3', name: 'Pair C', color: '#A3D9B1' },
      { id: 'g4', name: 'Pair D', color: '#F9D3DE' },
      { id: 'g5', name: 'Pair E', color: '#8FD0CF' },
      { id: 'g6', name: 'Pair F', color: '#DDE3EA' }
    ];
    var shifts = [
      { id: 'L4', name: 'L4', kind: 'day', start: '07:30', end: '17:00', days: [1, 2, 3, 4, 5], weekendRule: true, maxOtWeekdays: null },
      { id: 'D6', name: 'D6', kind: 'day', start: '07:30', end: '18:30', days: [1, 2, 3, 4, 5, 6], weekendRule: true, maxOtWeekdays: 1 },
      { id: 'E6', name: 'E6', kind: 'night', start: '19:30', end: '06:30', days: [1, 2, 3, 4, 5, 6], weekendRule: false, maxOtWeekdays: null }
    ];
    function P(name, role, shiftId, groupId, extra) {
      var p = { id: R.uid(), name: name, role: role, shiftId: shiftId, groupId: groupId, restDow: null, otDow: null, active: true };
      for (var k in extra) p[k] = extra[k];
      return p;
    }
    var people = [
      P('Engineer 1', 'Engineer', 'L4', 'g1'),
      P('Engineer 2', 'Engineer', 'L4', 'g1'),
      P('Engineer 3', 'Engineer', 'L4', 'g2'),
      P('Engineer 4', 'Engineer', 'L4', 'g2'),
      P('Technician 1', 'Technician', 'D6', 'g3', { otDow: 2 }),
      P('Technician 2', 'Technician', 'D6', 'g3', { otDow: 3 }),
      P('Technician 3', 'Technician', 'D6', 'g4', { otDow: 4 }),
      P('Technician 4', 'Technician', 'D6', 'g4', { otDow: 5 }),
      P('Technician 5', 'Technician', 'E6', 'g5', { restDow: 2 }),
      P('Technician 6', 'Technician', 'E6', 'g5', { restDow: 3 }),
      P('Technician 7', 'Technician', 'E6', 'g6', { restDow: 4 }),
      P('Technician 8', 'Technician', 'E6', 'g6', { restDow: 5 })
    ];
    return { version: 1, settings: R.defaultSettings(), shifts: shifts, groups: groups, people: people, entries: {}, log: [], lastExport: null };
  };

  R.blankState = function () {
    var s = R.sampleState();
    s.people = []; s.groups = [{ id: 'g1', name: 'Pair A', color: R.PALETTE[0] }]; s.entries = {};
    return s;
  };

  R.normalize = function (s) {
    if (!s || typeof s !== 'object') throw new Error('Not a roster file');
    if (!Array.isArray(s.people) || !Array.isArray(s.shifts)) throw new Error('Missing people or shift templates');
    var d = R.defaultSettings();
    s.settings = s.settings || {};
    for (var k in d) if (!(k in s.settings)) s.settings[k] = d[k];
    s.groups = s.groups || [];
    s.entries = s.entries || {};
    s.log = s.log || [];
    s.version = 1;
    s.people.forEach(function (p) { if (!p.id) p.id = R.uid(); if (p.active == null) p.active = true; });
    return s;
  };

  /* ---------- storage ---------- */
  var KEY = 'shiftRoster.v1';
  var UIKEY = 'shiftRoster.ui';
  var saveTimer = null;
  R.savedAt = null;
  R.saveOk = true;

  R.load = function () {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { R.saveOk = false; }
    if (raw) {
      try { R.state = R.normalize(JSON.parse(raw)); return 'loaded'; } catch (e) { /* fall through */ }
    }
    R.state = R.sampleState();
    return 'sample';
  };

  R.saveNow = function () {
    try {
      localStorage.setItem(KEY, JSON.stringify(R.state));
      R.savedAt = new Date();
      R.saveOk = true;
    } catch (e) { R.saveOk = false; }
    if (R.onSaved) R.onSaved();
  };
  R.save = function () {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(R.saveNow, 250);
  };
  window.addEventListener('beforeunload', function () { clearTimeout(saveTimer); try { localStorage.setItem(KEY, JSON.stringify(R.state)); } catch (e) {} });

  R.loadUI = function () { try { return JSON.parse(localStorage.getItem(UIKEY)) || {}; } catch (e) { return {}; } };
  R.saveUI = function (ui) { try { localStorage.setItem(UIKEY, JSON.stringify(ui)); } catch (e) {} };

  /* ---------- cells ---------- */
  R.getCell = function (pid, k) { var e = R.state.entries[pid]; return e ? e[k] : undefined; };
  function rawSet(pid, k, v) {
    var E = R.state.entries;
    if (v == null) { if (E[pid]) { delete E[pid][k]; } return; }
    if (!E[pid]) E[pid] = {};
    E[pid][k] = v;
  }

  /* ---------- history ---------- */
  R.undoStack = [];
  R.redoStack = [];
  function logIt(label) {
    R.state.log.unshift({ t: new Date().toISOString(), label: label });
    if (R.state.log.length > 300) R.state.log.length = 300;
  }
  function push(op) {
    R.undoStack.push(op);
    if (R.undoStack.length > 150) R.undoStack.shift();
    R.redoStack.length = 0;
    logIt(op.label);
  }

  /* list: [{pid, k, v}] where v is a cell object or null */
  R.setCells = function (list, label) {
    var changes = [];
    list.forEach(function (it) {
      var before = R.getCell(it.pid, it.k);
      var after = it.v == null ? null : R.clone(it.v);
      if (JSON.stringify(before || null) === JSON.stringify(after)) return;
      changes.push({ pid: it.pid, k: it.k, before: before ? R.clone(before) : null, after: after });
      rawSet(it.pid, it.k, after);
    });
    if (!changes.length) return 0;
    push({ kind: 'cells', label: label, changes: changes });
    R.changed();
    return changes.length;
  };

  function configSnap() {
    return JSON.stringify({ settings: R.state.settings, shifts: R.state.shifts, groups: R.state.groups, people: R.state.people });
  }
  R.configChange = function (label, fn) {
    var before = configSnap();
    fn();
    var after = configSnap();
    if (before === after) return;
    push({ kind: 'config', label: label, before: before, after: after });
    R.changed();
  };
  function applyConfig(json) {
    var o = JSON.parse(json);
    R.state.settings = o.settings; R.state.shifts = o.shifts; R.state.groups = o.groups; R.state.people = o.people;
  }
  R.undo = function () {
    var op = R.undoStack.pop();
    if (!op) return null;
    if (op.kind === 'cells') op.changes.forEach(function (c) { rawSet(c.pid, c.k, c.before ? R.clone(c.before) : null); });
    else applyConfig(op.before);
    R.redoStack.push(op);
    logIt('Undo: ' + op.label);
    R.changed();
    return op.label;
  };
  R.redo = function () {
    var op = R.redoStack.pop();
    if (!op) return null;
    if (op.kind === 'cells') op.changes.forEach(function (c) { rawSet(c.pid, c.k, c.after ? R.clone(c.after) : null); });
    else applyConfig(op.after);
    R.undoStack.push(op);
    logIt('Redo: ' + op.label);
    R.changed();
    return op.label;
  };
  R.replaceState = function (s, label) {
    R.state = R.normalize(s);
    R.undoStack.length = 0; R.redoStack.length = 0;
    logIt(label);
    R.changed();
  };

  R.changed = function () { R.save(); if (R.onChange) R.onChange(); };

  /* ---------- lookups ---------- */
  R.shiftOf = function (p) {
    for (var i = 0; i < R.state.shifts.length; i++) if (R.state.shifts[i].id === p.shiftId) return R.state.shifts[i];
    return null;
  };
  R.groupOf = function (p) {
    for (var i = 0; i < R.state.groups.length; i++) if (R.state.groups[i].id === p.groupId) return R.state.groups[i];
    return null;
  };
  R.colorOf = function (p) { var g = R.groupOf(p); return g ? g.color : '#E4E6E1'; };
  R.personById = function (id) {
    for (var i = 0; i < R.state.people.length; i++) if (R.state.people[i].id === id) return R.state.people[i];
    return null;
  };
  R.activePeople = function () { return R.state.people.filter(function (p) { return p.active !== false; }); };
  R.leaveCodes = function () { return R.state.settings.leaveTypes.map(function (l) { return l.code; }); };

  /* ---------- download helper ---------- */
  R.download = function (name, mime, text) {
    var blob = new Blob([text], { type: mime });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  };
})();
