/* Shift Roster — app shell: init, views, header actions, exports, keyboard */
(function () {
  'use strict';
  var R = window.R, esc = R.esc;
  var $ = function (s, el) { return (el || document).querySelector(s); };

  /* ---------- toast ---------- */
  var toastTimer;
  R.toast = function (msg) {
    var t = $('#toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 3200);
  };

  /* ---------- status & backup bar ---------- */
  R.onSaved = function () {
    var el = $('#saveStatus');
    if (!R.saveOk) { el.className = 'status bad'; el.textContent = 'Not saving in this browser — export JSON!'; return; }
    el.className = 'status';
    el.innerHTML = R.icon('check') + 'Autosaved · ' + R.timeStr(R.savedAt || new Date());
    updateBackupBar();
  };
  function updateBackupBar() {
    var last = R.state.lastExport ? new Date(R.state.lastExport) : null;
    var days = last ? Math.floor((Date.now() - last.getTime()) / 86400000) : null;
    var need = !last || days >= (+R.state.settings.backupDays || 2);
    var bar = $('#backupBar');
    bar.hidden = !need;
    if (need) $('#backupText').innerHTML = 'Saved in this browser only. ' + (last ? 'Last backup file: <b>' + last.toLocaleDateString() + '</b> (' + days + ' day' + (days === 1 ? '' : 's') + ' ago).' : 'No backup file exported yet.');
  }

  /* ---------- views ---------- */
  R.setView = function (v) {
    R.ui.view = v;
    $('#monthView').hidden = v !== 'month';
    $('#setupView').hidden = v !== 'setup';
    document.querySelectorAll('[data-view]').forEach(function (a) { a.setAttribute('aria-current', a.getAttribute('data-view') === v ? 'page' : 'false'); });
    R.closeEditor();
    render();
    window.scrollTo(0, 0);
  };
  function render() {
    if (R.ui.view === 'month') R.renderMonth();
    else R.renderSetup();
  }
  R.onChange = function () {
    var pop = $('#pop');
    var wasOpen = !pop.hidden;
    render();
    if (wasOpen && R.ui.view === 'month') R.closeEditor();
  };

  function goMonth(delta) {
    var d = new Date(R.ui.y, R.ui.m + delta, 1);
    R.ui.y = d.getFullYear(); R.ui.m = d.getMonth(); R.ui.sel = null;
    R.saveUI({ y: R.ui.y, m: R.ui.m });
    R.closeEditor();
    R.renderMonth();
  }

  /* ---------- exports ---------- */
  R.exportJson = function () {
    R.state.lastExport = new Date().toISOString();
    R.saveNow();
    var d = new Date();
    R.download('shift-roster-backup-' + d.getFullYear() + '-' + R.pad(d.getMonth() + 1) + '-' + R.pad(d.getDate()) + '.json', 'application/json', JSON.stringify(R.state, null, 1));
    updateBackupBar();
    if (R.ui.view === 'setup') R.renderSetup();
    R.toast('Backup file downloaded.');
  };

  function monthTableHtml(A, forExcel) {
    var S = R.state.settings;
    var h = ['<table border="1" style="border-collapse:collapse;font-family:Arial;font-size:10pt">'];
    h.push('<tr><td colspan="' + (A.days.length + 6) + '" style="font-size:14pt;font-weight:bold">' + R.MONTHS[A.m] + ' ' + A.y + ' — Shift Roster</td></tr>');
    var ww = '<tr><td colspan="6" style="font-weight:bold">Work week</td>';
    A.days.forEach(function (x) { ww += '<td style="text-align:center;font-size:8pt">WW' + x.ww + '</td>'; });
    h.push(ww + '</tr>');
    var hd = '<tr style="font-weight:bold"><td>Name</td><td>Role</td><td>Shift</td><td>Days</td><td>Hrs</td><td>OT</td>';
    A.days.forEach(function (x) { hd += '<td style="text-align:center;' + (x.hol ? 'background:#DADDD6;' : (x.dow === 0 || x.dow === 6) ? 'background:#ECEDE8;' : '') + '">' + R.WD[x.dow] + '<br>' + x.d + '</td>'; });
    h.push(hd + '</tr>');
    A.rows.forEach(function (r) {
      var row = '<tr><td style="background:' + r.color + '">' + esc(r.p.name) + '</td><td>' + esc(r.p.role || '') + '</td><td>' + esc(r.shift ? r.shift.name : '') + '</td><td>' + r.worked + '</td><td>' + r.hours + '</td><td>' + r.ot + '</td>';
      r.cells.forEach(function (ci, di) {
        var x = A.days[di], c = ci.c, bg = '', txt = '', color = '#000';
        if (ci.work) { txt = c.c; bg = ci.ot ? S.otColor : r.color; if (c.c === 'N') { color = '#000'; } }
        else if (c && R.isLeave(c)) txt = c.c;
        else if (x.hol) bg = '#DADDD6';
        row += '<td style="text-align:center;' + (bg ? 'background:' + bg + ';' : '') + (ci.work && c.c === 'N' ? 'border-top:3px solid #26313F;' : '') + (ci.flags.length ? 'border:2px solid #C2410C;' : '') + 'color:' + color + '">' + txt + '</td>';
      });
      h.push(row + '</tr>');
    });
    [['day', 'Day coverage', S.minDay], ['night', 'Night coverage', S.minNight]].forEach(function (cv) {
      var row = '<tr style="font-weight:bold"><td colspan="6">' + cv[1] + ' (min ' + cv[2] + ')</td>';
      A.days.forEach(function (x) { var n = A.cov[x.k][cv[0]]; row += '<td style="text-align:center;' + (n < cv[2] && !(x.hol && !S.coverageOnHolidays) ? 'background:#C2410C;color:#fff;' : '') + '">' + n + '</td>'; });
      h.push(row + '</tr>');
    });
    h.push('</table>');
    if (forExcel) h.push('<p style="font-family:Arial;font-size:9pt">Yellow = OT · dark top border = night · orange border = rule break · ' + esc(S.leaveTypes.map(function (l) { return l.code + ' ' + l.name; }).join(', ')) + '</p>');
    return h.join('');
  }
  function fileStem() { return 'shift-roster-' + R.ui.y + '-' + R.pad(R.ui.m + 1); }
  R.exportExcel = function () {
    var A = R.analyze(R.ui.y, R.ui.m);
    var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body>' + monthTableHtml(A, true) + '</body></html>';
    R.download(fileStem() + '.xls', 'application/vnd.ms-excel', html);
    R.toast('Excel file downloaded. If Excel warns about the format, click Yes to open.');
  };
  R.exportCsv = function () {
    var A = R.analyze(R.ui.y, R.ui.m);
    function q(s) { s = String(s == null ? '' : s); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
    var lines = [];
    lines.push(['Name', 'Role', 'Shift', 'Days', 'Hours', 'OT'].concat(A.days.map(function (x) { return x.k; })).map(q).join(','));
    A.rows.forEach(function (r) {
      lines.push([r.p.name, r.p.role, r.shift ? r.shift.name : '', r.worked, r.hours, r.ot].concat(r.cells.map(function (ci) {
        if (!ci.c) return '';
        return ci.c.c + (ci.ot ? '*' : '');
      })).map(q).join(','));
    });
    lines.push('');
    lines.push('"* = OT"');
    R.download(fileStem() + '.csv', 'text/csv', '﻿' + lines.join('\r\n'));
    R.toast('CSV downloaded.');
  };
  R.print = function () {
    R.closeEditor();
    document.title = fileStem();
    window.print();
    document.title = 'Shift Roster';
  };

  /* ---------- import ---------- */
  function importFile(file) {
    var fr = new FileReader();
    fr.onload = function () {
      var data;
      try { data = R.normalize(JSON.parse(fr.result)); }
      catch (e) { R.toast('Could not read that file: ' + e.message); return; }
      var n = data.people.length, months = {};
      Object.keys(data.entries).forEach(function (pid) { Object.keys(data.entries[pid]).forEach(function (k) { months[k.slice(0, 7)] = 1; }); });
      R.openModal('<div class="mh"><div><h2>Import “' + esc(file.name) + '”?</h2><p>This file has <b>' + n + '</b> people and schedules for <b>' + Object.keys(months).length + '</b> month(s). It will <b>replace all current data</b> in this browser.</p></div><button class="icon" data-close aria-label="Close">' + R.icon('x') + '</button></div>' +
        '<div class="mf"><button class="btn" data-close>Cancel</button><button class="btn" data-imp="backup">Export current first</button><button class="btn primary" data-imp="go">Replace with file</button></div>');
      $('#modalBox').onclick = function (e) {
        if (e.target.closest('[data-close]')) R.closeModal();
        var b = e.target.closest('[data-imp]'); if (!b) return;
        if (b.getAttribute('data-imp') === 'backup') { R.exportJson(); return; }
        R.replaceState(data, 'Imported ' + file.name);
        R.closeModal();
        R.toast('Imported ' + file.name + '.');
      };
    };
    fr.readAsText(file);
  }

  /* ---------- export menu ---------- */
  function toggleExportMenu(force) {
    var m = $('#exportMenu');
    var open = force != null ? force : m.hidden;
    m.hidden = !open;
    $('#exportBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  /* ---------- keyboard ---------- */
  document.addEventListener('keydown', function (e) {
    var tag = (e.target.tagName || '').toLowerCase();
    var typing = tag === 'input' || tag === 'textarea' || tag === 'select';
    var mod = e.ctrlKey || e.metaKey;
    if (mod && !typing && (e.key === 'z' || e.key === 'Z')) {
      e.preventDefault();
      var l = e.shiftKey ? R.redo() : R.undo();
      R.toast(l ? (e.shiftKey ? 'Redo: ' : 'Undo: ') + l : (e.shiftKey ? 'Nothing to redo' : 'Nothing to undo'));
      return;
    }
    if (mod && !typing && (e.key === 'y' || e.key === 'Y')) {
      e.preventDefault();
      var l2 = R.redo(); R.toast(l2 ? 'Redo: ' + l2 : 'Nothing to redo');
      return;
    }
    if (e.key === 'Escape') {
      if (!$('#modal').hidden) { R.closeModal(); return; }
      toggleExportMenu(false);
    }
    if (typing || mod || e.altKey) return;
    if (!$('#modal').hidden) return;
    if (R.ui.view === 'month' && R.sheetKey(e)) e.preventDefault();
  });

  /* ---------- init ---------- */
  function init() {
    var how = R.load();
    var ui = R.loadUI();
    var now = new Date();
    R.ui.y = ui.y != null ? ui.y : now.getFullYear();
    R.ui.m = ui.m != null ? ui.m : now.getMonth();

    if (how === 'sample') {
      /* first run: fill the current month from templates so the sheet isn't empty */
      var plan = R.generatePlan(R.ui.y, R.ui.m, 'empty');
      plan.list.forEach(function (it) { var E = R.state.entries; if (!E[it.pid]) E[it.pid] = {}; E[it.pid][it.k] = it.v; });
      R.state.log.unshift({ t: new Date().toISOString(), label: 'Started with sample data' });
      R.saveNow();
    }

    R.bindSheet();
    R.bindSetup();

    document.querySelectorAll('[data-view]').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); R.setView(a.getAttribute('data-view')); });
    });
    $('#prevMonth').addEventListener('click', function () { goMonth(-1); });
    $('#nextMonth').addEventListener('click', function () { goMonth(1); });
    $('#todayBtn').addEventListener('click', function () { var d = new Date(); R.ui.y = d.getFullYear(); R.ui.m = d.getMonth(); goMonth(0); });
    $('#genBtn').addEventListener('click', R.openGenerate);
    $('#historyBtn').addEventListener('click', R.openHistory);
    $('#printBtn').addEventListener('click', R.print);
    $('#exportBtn').addEventListener('click', function (e) { e.stopPropagation(); toggleExportMenu(); });
    $('#exportMenu').addEventListener('click', function (e) {
      var b = e.target.closest('[data-exp]'); if (!b) return;
      toggleExportMenu(false);
      var t = b.getAttribute('data-exp');
      if (t === 'xls') R.exportExcel();
      else if (t === 'csv') R.exportCsv();
      else if (t === 'json') R.exportJson();
      else if (t === 'pdf') R.print();
    });
    document.addEventListener('click', function (e) {
      if (!e.target.closest('#exportMenu') && !e.target.closest('#exportBtn')) toggleExportMenu(false);
      var pop = $('#pop');
      if (!pop.hidden && !e.target.closest('#pop') && !e.target.closest('.c[data-r]')) R.closeEditor();
    });
    $('#importBtn').addEventListener('click', function () { $('#importFile').click(); });
    $('#importFile').addEventListener('change', function (e) { var f = e.target.files[0]; if (f) importFile(f); e.target.value = ''; });
    $('#backupNow').addEventListener('click', R.exportJson);
    $('#modal').addEventListener('mousedown', function (e) { if (e.target.id === 'modal') R.closeModal(); });
    window.addEventListener('resize', function () { R.closeEditor(); });
    $('#sheetWrap').addEventListener('scroll', function () { R.closeEditor(); });

    R.savedAt = new Date();
    R.onSaved();
    R.setView('month');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
