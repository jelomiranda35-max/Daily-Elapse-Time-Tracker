/* Shift Roster — Rules & setup page */
(function () {
  'use strict';
  var R = window.R, esc = R.esc;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var DAY_ORDER = [6, 0, 1, 2, 3, 4, 5]; // Sat-first, matches the work week

  function num(path, label, val, opts) {
    opts = opts || {};
    return '<label class="numf">' + (label ? '<span>' + label + '</span>' : '') + '<input type="number" data-bind="' + path + '" data-type="num"' + (opts.allowBlank ? ' data-blank="1"' : '') + ' value="' + (val == null ? '' : esc(val)) + '" min="' + (opts.min != null ? opts.min : 0) + '" max="' + (opts.max || 99) + '"' + (opts.aria ? ' aria-label="' + esc(opts.aria) + '"' : '') + '></label>';
  }
  function check(path, val, label) {
    return '<label class="chk"><input type="checkbox" data-bind="' + path + '" data-type="bool"' + (val ? ' checked' : '') + '>' + (label || 'Enable') + '</label>';
  }
  function text(path, val, aria, w) {
    return '<input type="text" class="txt" data-bind="' + path + '" value="' + esc(val || '') + '" aria-label="' + esc(aria) + '"' + (w ? ' style="width:' + w + 'px"' : '') + '>';
  }
  function dowSelect(path, val, blankLabel, aria) {
    var h = '<select data-bind="' + path + '" data-type="dow" aria-label="' + esc(aria) + '"><option value="">' + blankLabel + '</option>';
    for (var d = 1; d <= 6; d++) h += '<option value="' + d + '"' + (val === d ? ' selected' : '') + '>' + R.WD_LONG[d] + '</option>';
    h += '<option value="0"' + (val === 0 ? ' selected' : '') + '>Sun</option>';
    return h + '</select>';
  }
  function ruleRow(title, sub, control) {
    return '<div class="rrow"><div class="rtext"><b>' + title + '</b><span>' + sub + '</span></div><div class="rctl">' + control + '</div></div>';
  }

  R.renderSetup = function () {
    var S = R.state.settings, st = R.state;
    var h = [];
    h.push('<div class="stitle"><h1>Rules &amp; setup</h1><p>Everything here drives the month sheet: colours, OT, hours, coverage and rule flags. Changes save automatically and can be undone with Ctrl+Z.</p></div>');
    h.push('<div class="cols">');

    /* ===== left column ===== */
    h.push('<div class="col">');

    /* shift templates */
    h.push('<section class="card"><div class="ctitle"><h2>Shift templates</h2><button class="btn" data-act="addShift">+ Add shift</button></div>');
    st.shifts.forEach(function (s, i) {
      var P = 'shifts.' + i + '.';
      h.push('<div class="shift">');
      h.push('<div class="srow">' + text(P + 'name', s.name, 'Shift code', 64) +
        '<select data-bind="' + P + 'kind" aria-label="Day or night"><option value="day"' + (s.kind === 'day' ? ' selected' : '') + '>Day</option><option value="night"' + (s.kind === 'night' ? ' selected' : '') + '>Night</option></select>' +
        '<span class="times"><input type="time" data-bind="' + P + 'start" value="' + esc(s.start) + '" aria-label="Start">–<input type="time" data-bind="' + P + 'end" value="' + esc(s.end) + '" aria-label="End"></span>' +
        '<span class="muted">' + R.hoursOf(s) + ' h</span>' +
        '<button class="icon" data-act="delShift" data-i="' + i + '" aria-label="Delete shift ' + esc(s.name) + '">' + R.icon('trash') + '</button></div>');
      h.push('<div class="srow"><span class="lbl">Regular days</span><span class="dtog">');
      DAY_ORDER.forEach(function (d) {
        var on = s.days.indexOf(d) >= 0;
        h.push('<button data-act="toggleDay" data-i="' + i + '" data-d="' + d + '" aria-pressed="' + on + '" class="' + (on ? 'on' : '') + '">' + R.WD[d] + '</button>');
      });
      h.push('</span></div>');
      h.push('<div class="srow small">' + check(P + 'weekendRule', s.weekendRule, 'Weekend OT eligibility rule applies') +
        '<span class="numinline">Max OT weekdays / week ' + num(P + 'maxOtWeekdays', '', s.maxOtWeekdays, { allowBlank: true, max: 5, aria: 'Max OT weekdays per week for ' + s.name }) + '<span class="muted">(blank = no limit)</span></span></div>');
      h.push('</div>');
    });
    h.push('<p class="muted small">Work on a day that is not a regular day (or a holiday) is OT automatically and turns yellow.</p>');
    h.push('</section>');

    /* rules */
    h.push('<section class="card"><div class="ctitle"><h2>Rules</h2></div><p class="muted small">Broken rules show as an orange outline and in “Needs a decision”. Nothing is blocked — you decide.</p>');
    h.push(ruleRow('Minimum per shift, per day', 'Day = everyone on D · Night = everyone on N', num('settings.minDay', 'Day', S.minDay) + num('settings.minNight', 'Night', S.minNight)));
    h.push(ruleRow('Max consecutive working days', 'Counts across weeks and months; leave and rest reset it', num('settings.maxRun', 'Days', S.maxRun, { min: 1 })));
    h.push(ruleRow('No day shift right after a night shift', 'e.g. Sunday night → Monday day = 24 h on duty', check('settings.nightToDay', S.nightToDay)));
    h.push(ruleRow('Weekend OT eligibility', 'For templates with the rule on. Weekdays worked in the week decide how many weekend rest days may be worked.',
      '<div class="stack"><span>Worked ' + num('settings.weekendFull', '', S.weekendFull, { max: 5, aria: 'Weekdays for full week' }) + '+ weekdays → max ' + num('settings.weekendFullAllow', '', S.weekendFullAllow, { max: 2, aria: 'Weekend days allowed after full week' }) + '</span>' +
      '<span>Fewer weekdays → max ' + num('settings.weekendShortAllow', '', S.weekendShortAllow, { max: 2, aria: 'Weekend days allowed after short week' }) + '</span></div>'));
    h.push(ruleRow('At least one per shift with role', 'Optional — flags shifts with nobody of this role', check('settings.engineerPerShift', S.engineerPerShift) + text('settings.engineerRole', S.engineerRole, 'Role name', 120)));
    h.push(ruleRow('OT highlight colour', 'Used for every OT cell', '<input type="color" data-bind="settings.otColor" value="' + esc(S.otColor) + '" aria-label="OT colour">'));
    h.push('</section>');
    h.push('</div>');

    /* ===== right column ===== */
    h.push('<div class="col">');

    /* calendar */
    h.push('<section class="card"><div class="ctitle"><h2>Calendar</h2></div>');
    h.push('<div class="grid2">');
    var ws = '<select data-bind="settings.weekStart" data-type="num" aria-label="Week starts on">';
    for (var d = 0; d < 7; d++) ws += '<option value="' + d + '"' + (S.weekStart === d ? ' selected' : '') + '>' + R.WD_LONG[d] + '</option>';
    ws += '</select>';
    h.push('<label class="field"><span>Week starts on</span>' + ws + '</label>');
    h.push('<label class="field"><span>Weeks per year (WW resets after)</span><input type="number" data-bind="settings.wwPerYear" data-type="num" value="' + esc(S.wwPerYear) + '" min="1" max="60"></label>');
    h.push('<label class="field"><span>Work week anchor date</span><input type="date" data-bind="settings.wwAnchorDate" value="' + esc(S.wwAnchorDate) + '"></label>');
    h.push('<label class="field"><span>…is in work week number</span><input type="number" data-bind="settings.wwAnchorNum" data-type="num" value="' + esc(S.wwAnchorNum) + '" min="1" max="60"></label>');
    h.push('</div>');
    h.push('<p class="muted small">Check: today is <b>WW' + R.wwOf(R.todayKey()) + '</b>.</p>');

    h.push('<h3>Company holidays</h3><p class="muted small">Hatched on the sheet. Work on a holiday counts as OT.</p>');
    h.push('<label class="field"><span>Every month on day(s) — comma separated</span><input type="text" class="txt" data-bind="settings.holidayDays" data-type="daylist" value="' + esc((S.holidayDays || []).join(', ')) + '" placeholder="e.g. 3, 4"></label>');
    h.push('<div class="chips">');
    (S.holidayDates || []).slice().sort().forEach(function (k) {
      h.push('<span class="chipx">' + esc(R.label(k) + ' ' + k.slice(0, 4)) + '<button class="icon sm" data-act="delHoliday" data-k="' + k + '" aria-label="Remove ' + esc(k) + '">' + R.icon('x') + '</button></span>');
    });
    h.push('</div><div class="srow"><input type="date" id="newHoliday" aria-label="One-off holiday date"><button class="btn" data-act="addHoliday">+ Add one-off holiday</button></div>');
    h.push('<div class="srow">' + check('settings.coverageOnHolidays', S.coverageOnHolidays, 'Check minimum coverage on holidays too') + '</div>');

    h.push('<h3>Leave types</h3><p class="muted small">Leave breaks a days-in-a-row run. Keyboard key = first letter.</p>');
    S.leaveTypes.forEach(function (l, i) {
      h.push('<div class="srow">' + text('settings.leaveTypes.' + i + '.code', l.code, 'Leave code', 56) + text('settings.leaveTypes.' + i + '.name', l.name, 'Leave name', 200) +
        '<button class="icon" data-act="delLeave" data-i="' + i + '" aria-label="Delete ' + esc(l.code) + '">' + R.icon('trash') + '</button></div>');
    });
    h.push('<button class="btn" data-act="addLeave">+ Add leave type</button>');
    h.push('</section>');

    /* pairs */
    h.push('<section class="card"><div class="ctitle"><h2>Pairs &amp; colours</h2><button class="btn" data-act="addGroup">+ Add pair</button></div><p class="muted small">People in the same pair share a row colour.</p>');
    st.groups.forEach(function (g, i) {
      var count = st.people.filter(function (p) { return p.groupId === g.id; }).length;
      h.push('<div class="srow"><input type="color" data-bind="groups.' + i + '.color" value="' + esc(g.color) + '" aria-label="Colour for ' + esc(g.name) + '">' + text('groups.' + i + '.name', g.name, 'Pair name', 160) + '<span class="muted small">' + count + ' people</span>' +
        '<button class="icon" data-act="delGroup" data-i="' + i + '" aria-label="Delete pair ' + esc(g.name) + '">' + R.icon('trash') + '</button></div>');
    });
    h.push('</section>');
    h.push('</div></div>');

    /* people — full width */
    h.push('<section class="card" id="people"><div class="ctitle"><h2>People</h2><button class="btn" data-act="addPerson">+ Add person</button></div>');
    h.push('<p class="muted small">Rest weekday = a regular weekday this person is off (e.g. night rotation). OT weekday = the one weekday that always counts as OT (yellow), e.g. for D6.</p>');
    h.push('<div class="ptable"><div class="pthead"><span></span><span>Name</span><span>Role</span><span>Shift</span><span>Pair</span><span>Rest weekday</span><span>OT weekday</span><span>Active</span><span></span></div>');
    st.people.forEach(function (p, i) {
      var P = 'people.' + i + '.';
      var shiftSel = '<select data-bind="' + P + 'shiftId" aria-label="Shift for ' + esc(p.name) + '"><option value="">—</option>' + st.shifts.map(function (s) { return '<option value="' + esc(s.id) + '"' + (s.id === p.shiftId ? ' selected' : '') + '>' + esc(s.name) + '</option>'; }).join('') + '</select>';
      var grpSel = '<select data-bind="' + P + 'groupId" aria-label="Pair for ' + esc(p.name) + '"><option value="">—</option>' + st.groups.map(function (g) { return '<option value="' + esc(g.id) + '"' + (g.id === p.groupId ? ' selected' : '') + '>' + esc(g.name) + '</option>'; }).join('') + '</select>';
      h.push('<div class="ptrow' + (p.active === false ? ' off' : '') + '"><span class="sw" style="background:' + esc(R.colorOf(p)) + '"></span>' +
        text(P + 'name', p.name, 'Name') + text(P + 'role', p.role, 'Role') + shiftSel + grpSel +
        dowSelect(P + 'restDow', p.restDow, 'None', 'Rest weekday for ' + p.name) + dowSelect(P + 'otDow', p.otDow, 'None', 'OT weekday for ' + p.name) +
        '<input type="checkbox" data-bind="' + P + 'active" data-type="bool"' + (p.active !== false ? ' checked' : '') + ' aria-label="Active">' +
        '<span class="acts"><button class="icon" data-act="up" data-i="' + i + '" aria-label="Move up">' + R.icon('up') + '</button><button class="icon" data-act="down" data-i="' + i + '" aria-label="Move down">' + R.icon('down') + '</button><button class="icon" data-act="delPerson" data-i="' + i + '" aria-label="Delete ' + esc(p.name) + '">' + R.icon('trash') + '</button></span></div>');
    });
    h.push('</div></section>');

    /* data */
    h.push('<section class="card dark"><div class="ctitle"><h2>Data &amp; backup</h2></div>');
    h.push('<p>Autosaves to this browser after every change. Export a JSON file regularly — clearing browser data deletes the autosave.</p>');
    h.push('<div class="srow"><button class="btn primary" data-act="exportJson">Export JSON backup</button><button class="btn ghost" data-act="importJson">Import JSON…</button></div>');
    h.push('<div class="srow small">Remind me to back up after ' + num('settings.backupDays', '', S.backupDays, { min: 1, max: 60, aria: 'Backup reminder days' }) + ' days · Last export: <b>' + (st.lastExport ? new Date(st.lastExport).toLocaleString() : 'never') + '</b></div>');
    h.push('<div class="srow danger"><button class="btn ghost" data-act="loadSample">Reset to sample data</button><button class="btn ghost" data-act="startBlank">Start blank (keep shift templates &amp; rules)</button></div>');
    h.push('</section>');

    $('#setupView').innerHTML = h.join('');
  };

  /* ---------- binding ---------- */
  function setPath(obj, path, value) {
    var parts = path.split('.');
    for (var i = 0; i < parts.length - 1; i++) obj = obj[parts[i]];
    obj[parts[parts.length - 1]] = value;
  }
  function readValue(el) {
    var t = el.getAttribute('data-type');
    if (t === 'bool') return el.checked;
    if (t === 'num') {
      if (el.value === '' && el.hasAttribute('data-blank')) return null;
      var n = parseFloat(el.value);
      return isNaN(n) ? 0 : n;
    }
    if (t === 'dow') return el.value === '' ? null : +el.value;
    if (t === 'daylist') {
      return el.value.split(/[\s,]+/).map(function (x) { return parseInt(x, 10); }).filter(function (n) { return n >= 1 && n <= 31; })
        .filter(function (n, i, a) { return a.indexOf(n) === i; }).sort(function (a, b) { return a - b; });
    }
    return el.value;
  }

  R.bindSetup = function () {
    var view = $('#setupView');
    view.addEventListener('change', function (e) {
      var el = e.target, path = el.getAttribute('data-bind');
      if (!path) return;
      var v = readValue(el);
      if (path.indexOf('.name') > 0 || path.indexOf('.code') > 0) v = String(v).trim();
      if (/^settings\.leaveTypes\.\d+\.code$/.test(path)) {
        v = v.toUpperCase();
        if (!v || ['D', 'N', 'R'].indexOf(v) >= 0) { R.toast('Leave code can’t be empty, D, N or R.'); R.renderSetup(); return; }
      }
      R.configChange('Setup: ' + path.replace(/\.\d+\./g, ' ').replace('settings.', ''), function () { setPath(R.state, path, v); });
    });
    view.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      var act = b.getAttribute('data-act'), i = +b.getAttribute('data-i'), st = R.state;
      switch (act) {
        case 'toggleDay':
          R.configChange('Setup: shift days', function () {
            var s = st.shifts[i], d = +b.getAttribute('data-d'), at = s.days.indexOf(d);
            if (at >= 0) s.days.splice(at, 1); else s.days.push(d);
          });
          break;
        case 'addShift':
          R.configChange('Add shift template', function () {
            st.shifts.push({ id: 'S' + R.uid(), name: 'NEW', kind: 'day', start: '08:00', end: '17:00', days: [1, 2, 3, 4, 5], weekendRule: false, maxOtWeekdays: null });
          });
          break;
        case 'delShift':
          var s = st.shifts[i];
          var users = st.people.filter(function (p) { return p.shiftId === s.id; }).length;
          if (!confirm('Delete shift template ' + s.name + '?' + (users ? '\n' + users + ' people use it and will become “no template”.' : ''))) return;
          R.configChange('Delete shift ' + s.name, function () { st.shifts.splice(i, 1); });
          break;
        case 'addHoliday':
          var v = $('#newHoliday').value;
          if (!v) { R.toast('Pick a date first.'); return; }
          R.configChange('Add holiday ' + v, function () { if (st.settings.holidayDates.indexOf(v) < 0) st.settings.holidayDates.push(v); });
          break;
        case 'delHoliday':
          var k = b.getAttribute('data-k');
          R.configChange('Remove holiday ' + k, function () { st.settings.holidayDates = st.settings.holidayDates.filter(function (x) { return x !== k; }); });
          break;
        case 'addLeave':
          R.configChange('Add leave type', function () { st.settings.leaveTypes.push({ code: 'XL', name: 'New leave' }); });
          break;
        case 'delLeave':
          if (!confirm('Delete leave type ' + st.settings.leaveTypes[i].code + '? Existing cells with this code will show as unknown.')) return;
          R.configChange('Delete leave type', function () { st.settings.leaveTypes.splice(i, 1); });
          break;
        case 'addGroup':
          R.configChange('Add pair', function () {
            st.groups.push({ id: 'g' + R.uid(), name: 'Pair ' + String.fromCharCode(65 + st.groups.length % 26), color: R.PALETTE[st.groups.length % R.PALETTE.length] });
          });
          break;
        case 'delGroup':
          R.configChange('Delete pair', function () {
            var g = st.groups[i];
            st.people.forEach(function (p) { if (p.groupId === g.id) p.groupId = ''; });
            st.groups.splice(i, 1);
          });
          break;
        case 'addPerson':
          R.configChange('Add person', function () {
            st.people.push({ id: R.uid(), name: 'New person', role: 'Technician', shiftId: st.shifts[0] ? st.shifts[0].id : '', groupId: st.groups[0] ? st.groups[0].id : '', restDow: null, otDow: null, active: true });
          });
          setTimeout(function () { var rows = document.querySelectorAll('.ptrow'); var last = rows[rows.length - 1]; if (last) { last.scrollIntoView({ block: 'center' }); var inp = last.querySelector('input[type=text]'); if (inp) { inp.focus(); inp.select(); } } }, 30);
          break;
        case 'delPerson':
          var p = st.people[i];
          if (!confirm('Delete ' + p.name + ' and all their schedule entries?\nTip: untick “Active” instead to hide them but keep history.')) return;
          R.configChange('Delete person ' + p.name, function () { st.people.splice(i, 1); });
          break;
        case 'up': case 'down':
          var j = act === 'up' ? i - 1 : i + 1;
          if (j < 0 || j >= st.people.length) return;
          R.configChange('Reorder people', function () { var t = st.people[i]; st.people[i] = st.people[j]; st.people[j] = t; });
          break;
        case 'exportJson': R.exportJson(); break;
        case 'importJson': $('#importFile').click(); break;
        case 'loadSample':
          if (!confirm('Replace ALL data with the sample roster? Export a backup first if you need the current data.')) return;
          R.replaceState(R.sampleState(), 'Reset to sample data');
          break;
        case 'startBlank':
          if (!confirm('Remove all people and schedule entries? Shift templates and rules are kept.')) return;
          var keep = R.clone(st);
          keep.people = []; keep.entries = {}; keep.groups = keep.groups.length ? keep.groups : [{ id: 'g1', name: 'Pair A', color: R.PALETTE[0] }];
          R.replaceState(keep, 'Start blank');
          break;
      }
    });
  };
})();
