/* ==========================================================================
   04-board.js — router + the status board
   The board is the screenshot. One tile per machine, identical framing, sized
   so 14–18 tiles fit a 1366x768 screen without scrolling.
   ========================================================================== */

function show(name){
  screen=name;
  $$('.page').forEach(function(s){ s.hidden = s.id!=='scr-'+name; });
  $$('#nav button').forEach(function(b){ b.setAttribute('aria-current', String(b.dataset.screen===name)); });
  if(name!=='board' && document.body.classList.contains('wall')) exitWall();
  closeBell();
  render();
  window.scrollTo(0,0);
}

function render(){
  var stamp=new Date().toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
  ['#printDate','#printDate2','#printDate3','#printDate4','#printDate5'].forEach(function(s){
    var e=$(s); if(e) e.textContent='Generated '+stamp;
  });
  var ws=$('#wallStamp'); if(ws) ws.textContent=stamp+(DB.meta.site?'  ·  '+DB.meta.site:'');
  var pt=$('#printTitle'); if(pt) pt.textContent='Equipment PM Status Board'+(DB.meta.site?' — '+DB.meta.site:'');
  $('#asOf').textContent = DB.readings.length
    ? DB.readings.length.toLocaleString()+' readings · latest '+fmtDate(latestDate())
    : 'No readings yet';
  $('#railFoot').textContent = activeMachines().length+' machines · '+activeParams().length+
    ' parameters'+(DB.meta.site?' · '+DB.meta.site:'');
  paintSaveState();
  if(typeof paintFolderState==='function') paintFolderState();

  refreshChartColors();
  if(!DB.parameters.length && screen!=='config' && screen!=='data' && screen!=='guide'){ renderEmpty(); return; }
  restoreFromEmpty();
  ({ board:renderBoard, entry:renderEntry, charts:renderCharts, analysis:renderAnalysis,
     machine:renderMachine, report:renderReport, config:renderConfig, data:renderData,
     pm:renderPM, guide:renderGuide
   }[screen]||function(){})();
  updateNavBadge();
  renderBell();
}

function updateNavBadge(){
  var rows=assessAll();
  var n=rows.filter(function(r){ return r.status==='crit'; }).length;
  var w=rows.filter(function(r){ return r.status==='warn'; }).length;
  var b=$('#navBadge');
  if(n){ b.hidden=false; b.className='badge'; b.textContent=n; }
  else if(w){ b.hidden=false; b.className='badge amber'; b.textContent=w; }
  else b.hidden=true;

  var due=activeMachines().map(pmSchedule).filter(function(x){ return x&&x.due; });
  var pb=$('#navPM');
  if(pb){
    var od=due.filter(function(x){ return x.overdue; }).length;
    if(due.length){ pb.hidden=false; pb.className='badge'+(od?'':' amber'); pb.textContent=due.length; }
    else pb.hidden=true;
  }
}

/* put back whatever renderEmpty hid, on every screen */
function restoreFromEmpty(){
  $$('.emptystate').forEach(function(e){ e.remove(); });
  $$('[data-empty-hidden]').forEach(function(c){
    c.style.display = c.getAttribute('data-empty-hidden') || '';
    c.removeAttribute('data-empty-hidden');
  });
}
function renderEmpty(){
  var host=$('#scr-'+screen);
  /* Hide, never destroy: wiping innerHTML here removed #boardGrid permanently,
     so importing data afterwards threw and left the board dead until reload. */
  Array.prototype.forEach.call(host.children, function(c){
    if(c.classList.contains('phead') || c.classList.contains('printhead')
       || c.classList.contains('emptystate')) return;
    if(!c.hasAttribute('data-empty-hidden')){
      c.setAttribute('data-empty-hidden', c.style.display||'');
      c.style.display='none';
    }
  });
  if(host.querySelector('.emptystate')) return;
  var d=document.createElement('div'); d.className='panel emptystate';
  d.innerHTML='<div class="empty"><h4>Nothing is set up yet</h4>'+
    '<p>Load an existing data file, paste your Excel grid to bring in machines and history at once, '+
    'or open the demo to see how it all works.</p>'+
    '<div style="display:flex;gap:9px;justify-content:center;flex-wrap:wrap">'+
    '<button class="btn primary" onclick="show(\'data\')">Load or import data</button>'+
    '<button class="btn" onclick="loadDemo()">Open demo data</button>'+
    '<button class="btn" onclick="show(\'config\')">Add machines by hand</button></div></div>';
  host.appendChild(d);
}

/* ---------- toolbar segmented controls ---------- */
function segChips(sel, items, current, onPick){
  var host=$(sel); if(!host) return;
  host.innerHTML = items.map(function(it){
    return '<button class="chip" data-v="'+esc(it[0])+'" aria-pressed="'+(current===it[0])+'">'+esc(it[1])+'</button>';
  }).join('');
  host.onclick=function(e){
    var b=e.target.closest('.chip'); if(!b) return;
    onPick(b.dataset.v); render();
  };
}

/* ========================= THE BOARD ========================= */
/* ========================= THE BOARD ========================= */
function renderBoard(){
  groupChips('#boardGroups','board');
  segChips('#boardSort', [['risk','By risk'],['name','By name'],['group','By group']],
    boardSort, function(v){ boardSort=v; });
  segChips('#boardCols', [['auto','Auto'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6']],
    String(SETTINGS.cols), function(v){ SETTINGS.cols=v; saveSettings(); });
  segChips('#boardChartH', [['s','S'],['m','M'],['l','L'],['xl','XL']],
    SETTINGS.chartH, function(v){ SETTINGS.chartH=v; saveSettings(); });
  segChips('#boardMode', [['combined','Combined'],['separate','Separate']],
    SETTINGS.chartMode, function(v){ SETTINGS.chartMode=v; saveSettings(); });

  var rows=byGroup(assessVisible(),'board');
  var machines=machineRollup(rows);
  if(boardSort==='risk') machines.sort(function(a,b){ return b.risk-a.risk; });
  else if(boardSort==='name') machines.sort(function(a,b){ return a.m.name.localeCompare(b.m.name); });
  else machines.sort(function(a,b){ var g=a.m.group.localeCompare(b.m.group); return g!==0?g:(b.risk-a.risk); });

  /* summary strip */
  var crit=rows.filter(function(r){ return r.status==='crit'; });
  var warn=rows.filter(function(r){ return r.status==='warn'; });
  var soon=rows.filter(function(r){ return r.status!=='crit' && r.dtt!=null && r.dtt<=14; });
  var pmDue=activeMachines().map(pmSchedule).filter(function(s){ return s&&s.due; });
  var pmOver=pmDue.filter(function(s){ return s.overdue; });
  var nextPM=activeMachines().map(function(m){ return {m:m,s:pmSchedule(m)}; })
    .filter(function(x){ return x.s; }).sort(function(a,b){ return a.s.inDays-b.s.inDays; })[0];
  $('#boardSummary').innerHTML =
    sumCell(machines.length,'Machines on board', rows.length+' parameters shown','')+
    sumCell(crit.length,'At limit', crit.length?'act now':'none', crit.length?'crit':'ok')+
    sumCell(warn.length,'In warning', warn.length?'plan work':'none', warn.length?'warn':'ok')+
    sumCell(soon.length,'Reaching limit in 14d','at current rate', soon.length?'crit':'ok')+
    sumCell(nextPM?(nextPM.s.overdue?Math.abs(nextPM.s.inDays)+'d late':nextPM.s.inDays+'d'):'—',
      'Next PM due', nextPM?nextPM.m.name:'—',
      nextPM&&nextPM.s.overdue?'crit':(nextPM&&nextPM.s.due?'warn':''))+
    sumCell(pmDue.length,'PM due soon', pmOver.length?pmOver.length+' overdue':'within lead time',
      pmOver.length?'crit':(pmDue.length?'warn':'ok'));
  var sb=$('#boardSummary'); if(sb) sb.style.display = SETTINGS.showSummary ? '' : 'none';

  var grid=$('#boardGrid');
  grid.className='boardgrid masonry';
  grid.style.gridTemplateColumns = SETTINGS.cols==='auto' ? '' : 'repeat('+SETTINGS.cols+',minmax(0,1fr))';
  grid.innerHTML = machines.length ? machines.map(tileHTML).join('')
    : '<div class="panel" style="grid-column:1/-1;grid-row:span 34"><div class="empty"><p>No machines in this group.</p></div></div>';

  grid.querySelectorAll('[data-m]').forEach(function(el){
    el.onclick=function(e){
      if(e.target.closest('.tedit')) return;
      openMachine(el.dataset.m);
    };
    el.onkeydown=function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); el.click(); } };
  });
  grid.querySelectorAll('.tedit').forEach(function(btn){
    btn.onclick=function(e){ e.stopPropagation(); editMachineQuick(btn.dataset.mid); };
  });
  layoutMasonry();
  $('#wallBtn').onclick=enterWall;
  $('#wallExit').onclick=exitWall;
  if(document.body.classList.contains('wall')) requestAnimationFrame(fitWall);
}

/* ---------- masonry ----------
   CSS grid makes every tile in a row as tall as the tallest one, which is what
   left a one-parameter machine full of empty space beside a three-parameter
   one. Here each tile is placed in whichever column is currently shortest and
   spans only as many thin rows as its own content needs. Reading order stays
   roughly left-to-right, top-to-bottom, so the riskiest machines still lead. */
var MASONRY_ROW = 4, MASONRY_GAP = 10;
function layoutMasonry(){
  var grid=$('#boardGrid'); if(!grid) return;
  var tiles=Array.prototype.slice.call(grid.querySelectorAll(':scope > .tile'));
  if(!tiles.length) return;
  tiles.forEach(function(t){ t.style.gridColumn=''; t.style.gridRow=''; });
  var cols=getComputedStyle(grid).gridTemplateColumns.split(' ').filter(Boolean).length || 1;
  var heights=[]; for(var i=0;i<cols;i++) heights.push(0);
  tiles.forEach(function(t){
    /* offsetHeight is the layout height, unaffected by the screenshot-view
       scale. getBoundingClientRect() would return the scaled height, so at a
       scale below 1 every tile got too few rows and touched the next one. */
    var h=t.offsetHeight;
    var span=Math.max(1, Math.ceil((h+MASONRY_GAP)/MASONRY_ROW));
    var c=0; for(var k=1;k<cols;k++) if(heights[k]<heights[c]) c=k;
    t.style.gridColumn=String(c+1);
    t.style.gridRow=(heights[c]+1)+' / span '+span;
    heights[c]+=span;
  });
}

function sumCell(v,k,n,cls){
  return '<div class="sumcell '+(cls||'')+'"><div class="v">'+esc(v)+'</div>'+
    '<div class="k">'+esc(k)+'</div><div class="n">'+esc(n||'')+'</div></div>';
}

/* ---------- one tile ---------- */

/* ---------- one tile ---------- */
function tileHTML(x){
  var m=x.m, win=SETTINGS.window;
  var combined = SETTINGS.chartMode==='combined' && x.rows.length>1;
  var compact = SETTINGS.chartH==='s' && !combined;

  var h='<div class="tile '+x.status+'" data-m="'+esc(m.id)+'" role="button" tabindex="0" '+
    'aria-label="'+esc(m.name+', '+STATUS_LABEL[x.status])+'">';
  h+='<div class="th"><div class="tid"><b>'+esc(m.name)+'</b><span>'+esc(m.id)+'<i>'+esc(m.group)+'</i></span></div>'+
     '<span class="tstat '+x.status+'"><i></i>'+STATUS_LABEL[x.status]+'</span>'+
     '<button class="tedit noprint" data-mid="'+esc(m.id)+'" title="Edit limits, PM schedule and activities" '+
     'aria-label="Edit '+esc(m.name)+'">&#9998;</button></div>';

  if(combined){
    /* every parameter of this machine on one indexed chart */
    h+='<div class="pblock"><div class="plabel"><b>'+x.rows.length+' parameters</b>'+
       '<span class="lb">% of limit</span></div>'+
       '<div class="well">'+combinedChart(x.rows, win)+'</div>'+
       combinedLegend(x.rows)+'</div>';
  } else {
    var charted = (compact && x.rows.length>1) ? [x.worst] : x.rows;
    var inline  = x.rows.filter(function(r){ return charted.indexOf(r)<0; });
    charted.forEach(function(a){
      h+='<div class="pblock">'+
        '<div class="plabel"><b>'+esc(a.p.name)+'</b>'+
        (a.p.bound==='lower'?'<span class="lb">falls to limit</span>':'')+'</div>'+
        '<div class="well">'+tileChart(a,win,compact)+'</div>'+
        '<div class="readout">'+
          '<span class="rv '+(a.status==='crit'?'crit':a.status==='warn'?'warn':'')+'">'+esc(num(a.value))+'</span>'+
          '<span class="ru">'+esc(a.p.unit||'')+'</span><span class="rsep"></span>'+
          '<span class="rdays">'+tileDtt(a)+'</span></div>'+
        '<div class="rmeta"><span>'+
          (a.approach!=null?'<b>'+esc(num(a.approach,0))+'%</b> of limit '+esc(num(a.p.threshold)):'limit '+esc(num(a.p.threshold)))+
          '</span><span>'+tileTrend(a)+'</span></div>'+
        (SETTINGS.showTravel?travelBar(a):'')+
      '</div>';
    });
    inline.forEach(function(a){
      h+='<div class="pline"><span class="st '+a.status+'"><i class="gl"></i></span>'+
        '<b>'+esc(a.p.name)+'</b><span class="pv">'+esc(num(a.value))+' <em>'+esc(a.p.unit||'')+'</em></span>'+
        '<span class="pp">'+(a.approach!=null?esc(num(a.approach,0))+'%':'—')+'</span></div>';
    });
  }

  /* recent activities on any parameter of this machine */
  var acts=[];
  x.rows.forEach(function(a){ paramEventsOf(a.p.id).forEach(function(e){
    if(diffDays(todayISO(), e.date)<=30) acts.push({e:e, p:a.p}); }); });
  if(acts.length){
    acts.sort(function(a,b){ return a.e.date<b.e.date?1:-1; });
    var A=acts[0];
    h+='<div class="tact" title="'+esc(acts.map(function(z){ return z.e.type+' — '+z.p.name+', '+fmtDate(z.e.date); }).join('\n'))+'">'+
       '<i></i>'+esc(A.e.type)+', '+esc(A.p.name)+', '+diffDays(todayISO(),A.e.date)+'d ago'+
       (acts.length>1?' <span>+'+(acts.length-1)+'</span>':'')+'</div>';
  }

  if(SETTINGS.showPM){
    var s=x.pmDue;
    h+='<div class="tpm">'+(s
      ? '<span>Last PM '+esc(fmtShort(s.last))+'</span><span class="sp"></span>'+
        '<span class="'+(s.overdue?'over':s.due?'due':'')+'">'+
        (s.overdue?'PM '+Math.abs(s.inDays)+'d overdue':'PM in '+s.inDays+'d')+'</span>'
      : '<span>No PM schedule set</span>')+'</div>';
  }
  return h+'</div>';
}

/* ---------- screenshot / wall mode ----------
   Hides every control, goes fullscreen, and scales the board as one block so
   the whole fleet lands on one screen. Masonry is re-run at each candidate
   scale because widening the board changes how many columns it has. */
function clearWallSizing(){
  var box=$('#wallFit'); if(!box) return;
  box.style.transform=''; box.style.width=''; box.style.height='';
}
function fitWall(){
  var box=$('#wallFit');
  if(!box) return;
  if(!document.body.classList.contains('wall')){ clearWallSizing(); layoutMasonry(); return; }
  var bar=$('.wallbar');
  var avail = window.innerHeight - (bar?bar.getBoundingClientRect().height:0) - 12;
  box.style.transformOrigin='top left';
  function tryK(k){
    box.style.width=(100/k).toFixed(3)+'%';
    box.style.transform = k!==1 ? 'scale('+k.toFixed(4)+')' : '';
    layoutMasonry();
    return box.getBoundingClientRect().height;
  }
  var best=null;
  for(var k=2.0; k>=0.36; k-=0.04){ if(tryK(k)<=avail){ best=k; break; } }
  tryK(best==null?0.36:best);
}
function enterWall(){
  document.body.classList.add('wall');
  $('#wallExit').hidden=false;
  var t=$('#wallTitle');
  if(t) t.textContent='Equipment PM Status Board'+(DB.meta.site?' — '+DB.meta.site:'');
  var el=document.documentElement;
  var req = el.requestFullscreen||el.webkitRequestFullscreen;
  if(req){ try{ var pr=req.call(el); if(pr&&pr.catch) pr.catch(function(){}); }catch(e){} }
  fitWall(); setTimeout(fitWall,150);
}
/* Leaving must undo every inline size fitWall set. Clearing only the
   transform left the board at ~156% width until a resize event came along,
   which is why Ctrl+scroll appeared to "fix" it. */
function exitWall(){
  wallFS=false;                     /* our own exit must not echo back as an Esc */
  document.body.classList.remove('wall');
  $('#wallExit').hidden=true;
  clearWallSizing();
  if(document.fullscreenElement||document.webkitFullscreenElement){
    var ex=document.exitFullscreen||document.webkitExitFullscreen;
    if(ex){ try{ var pr=ex.call(document); if(pr&&pr.catch) pr.catch(function(){}); }catch(e){} }
  }
  requestAnimationFrame(layoutMasonry);
}
/* Fullscreen enter/exit is asynchronous. Leaving screenshot view and quickly
   re-entering used to let the late "fullscreen ended" event from the first
   exit land after the second entry, which read as Esc and bounced you out.
   wallFS is true only while a fullscreen that screenshot view started is
   actually active, so only that one ending counts as leaving. */
var wallFS=false;
document.addEventListener('fullscreenchange', function(){
  if(document.fullscreenElement){ wallFS = document.body.classList.contains('wall'); return; }
  var wasOurs = wallFS; wallFS=false;
  if(wasOurs && document.body.classList.contains('wall')) exitWall();
});
var _rz=null;
window.addEventListener('resize', function(){
  clearTimeout(_rz);
  _rz=setTimeout(function(){
    if(document.body.classList.contains('wall')) fitWall(); else layoutMasonry();
  },60);
});
document.addEventListener('keydown', function(e){
  if(e.key==='Escape' && document.body.classList.contains('wall')) exitWall();
});
function tileDtt(a){
  if(a.status==='crit') return '<span style="color:var(--crit)">at limit</span>';
  if(a.thinSincePM) return '<span style="color:var(--accent)">PM reset</span>';
  if(a.dtt==null) return '<span style="color:var(--ok)">stable</span>';
  var d=Math.round(a.dtt);
  var c = d<=7?'var(--crit)':d<=21?'var(--warn)':'var(--ink-2)';
  return '<span style="color:'+c+'">'+d+'d left</span>';
}
function tileTrend(a){
  if(a.thinSincePM) return 'post-PM';
  if(a.slope==null) return 'new';
  if(a.toward>0) return 'rising';
  if(a.toward<0) return 'easing';
  return 'steady';
}

/* ---------- quick edit straight from a tile ----------
   Warn level, limit and PM schedule for one machine, without leaving the board. */
function editMachineQuick(mid){
  var m=machineById(mid);
  if(!m) return;
  var sch=pmSchedule(m);
  var b='<div class="note" style="margin-bottom:14px">Changes apply the moment you save. '+
    'Lowering a warn level may move this machine straight into warning.</div>';

  b+='<h4 style="font-size:14px;font-weight:600;margin-bottom:9px">Limits</h4>';
  paramsOf(mid).forEach(function(pa,i){
    var a=assess(pa);
    b+='<div class="qrow"><div class="qname"><b>'+esc(pa.name)+'</b>'+
       '<span>now '+esc(num(a.value))+' '+esc(pa.unit||'')+' · '+STATUS_LABEL[a.status]+'</span></div>'+
       '<label class="fld" style="margin:0"><span>Warn at</span>'+
       '<input type="number" step="any" id="qw'+i+'" value="'+esc(pa.warn!=null?pa.warn:'')+'"></label>'+
       '<label class="fld" style="margin:0"><span>Limit</span>'+
       '<input type="number" step="any" id="qt'+i+'" value="'+esc(pa.threshold)+'"></label>'+
       '<label class="fld" style="margin:0"><span>Direction</span>'+
       '<select id="qb'+i+'"><option value="upper"'+(pa.bound!=='lower'?' selected':'')+'>rises to limit</option>'+
       '<option value="lower"'+(pa.bound==='lower'?' selected':'')+'>falls to limit</option></select></label>'+
       '<button class="btn sm" type="button" data-qact="'+esc(pa.id)+'" style="align-self:end">Activity</button></div>';
  });

  b+='<h4 style="font-size:14px;font-weight:600;margin:18px 0 9px">PM schedule</h4>'+
     '<div class="row">'+
     fld('Interval (days)','<input type="number" min="1" id="qiv" value="'+esc(m.pmIntervalDays||'')+'">')+
     fld('Remind ahead (days)','<input type="number" min="0" id="qlead" value="'+esc(m.pmLeadDays||10)+'">')+
     fld('Last PM','<input type="date" id="qlast" value="'+esc(lastPMOf(mid)||m.lastPM||'')+'">')+
     '</div>'+
     '<div class="note">'+(sch
       ? 'Next PM falls on <b>'+esc(fmtDate(sch.next))+'</b>, '+
         (sch.overdue?'<b>'+Math.abs(sch.inDays)+' days overdue</b>.':'in '+sch.inDays+' days.')
       : 'No schedule set yet.')+
     ' Logging a PM below restarts this countdown from that date.</div>'+
     '<label class="pmbox" style="margin-top:12px;display:inline-flex">'+
       '<input type="checkbox" id="qpm"> Log a PM as done on '+
       '<input type="date" id="qpmdate" value="'+todayISO()+'" style="width:auto;margin-left:6px"></label>';

  modal('Edit '+m.name, b, function(){
    var ps=paramsOf(mid);
    for(var i=0;i<ps.length;i++){
      var t=parseFloat($('#qt'+i).value);
      if(!isFinite(t)){ toast('Every parameter needs a limit.',true); return false; }
      var w=parseFloat($('#qw'+i).value);
      ps[i].threshold=t;
      ps[i].warn=isFinite(w)?w:null;
      ps[i].bound=$('#qb'+i).value;
      delete ps[i]._base;
    }
    m.pmIntervalDays = +$('#qiv').value||null;
    m.pmLeadDays = +$('#qlead').value||10;
    var last=$('#qlast').value;
    if(last) m.lastPM=last;
    if($('#qpm').checked){
      var d=$('#qpmdate').value||todayISO();
      if(!DB.pmEvents.some(function(e){ return e.machineId===mid && e.date===d; })){
        DB.pmEvents.push({ id:uid(), date:d, machineId:mid, type:'Scheduled PM',
          tech:DB.meta.lastBy||'', notes:'' });
      }
      if(!m.lastPM || d>m.lastPM) m.lastPM=d;
      toast('PM logged for '+fmtDate(d)+'. Countdown restarts and the trend resets from that date.');
    }
    unsavedOps++; markDirty(); render();
  },'Save changes');
  /* an activity is its own record, so it opens its own dialog */
  $$('[data-qact]').forEach(function(btn){
    btn.onclick=function(){ var pid=btn.dataset.qact; $('#modalHost').innerHTML=''; activityDialog(pid); };
  });
}
function displayMenu(){
  function cb(id,on,label,hint){
    return '<label class="optrow"><input type="checkbox" id="'+id+'"'+(on?' checked':'')+'>'+
      '<span><b>'+label+'</b>'+(hint?'<em>'+hint+'</em>':'')+'</span></label>';
  }
  var b='<div class="subnav" id="dispTabs">'+
    '<button data-t="chart" aria-current="true">Inside the chart</button>'+
    '<button data-t="tile">Around the chart</button>'+
    '<button data-t="params">Which parameters</button></div>'+
    '<div id="dispPane"></div>';

  var close = modal('Chart & tile content', b, function(){
    if($('#oBand')){
      SETTINGS.band=$('#oBand').checked;
      SETTINGS.limitLine=$('#oLimit').checked;
      SETTINGS.warnLine=$('#oWarn').checked;
      SETTINGS.label=$('#oLabel').checked;
      SETTINGS.pmMarks=$('#oPM').checked;
      SETTINGS.dotMode=$('#oDotMode').value;
      SETTINGS.chartMode=$('#oMode').value;
      SETTINGS.projection=$('#oProj').checked;
      SETTINGS.yMode=$('#oY').value;
    }
    if($('#tTravel')){
      SETTINGS.showTravel=$('#tTravel').checked;
      SETTINGS.showPM=$('#tPM').checked;
      SETTINGS.showSummary=$('#tSum').checked;
    }
    saveSettings(); render();
  },'Apply');

  function pane(t){
    var h='';
    if(t==='chart'){
      h='<div class="note" style="margin-bottom:12px">These change every chart on the board '+
        'and on the Trend charts screen.</div>'+
        '<label class="fld"><span>Vertical scale</span><select id="oY">'+
        '<option value="auto"'+(SETTINGS.yMode==='auto'?' selected':'')+'>Always show the limit — safest</option>'+
        '<option value="data"'+(SETTINGS.yMode==='data'?' selected':'')+'>Fit the readings — best for seeing small drift</option>'+
        '<option value="zero"'+(SETTINGS.yMode==='zero'?' selected':'')+'>Start at zero — absolute magnitude</option>'+
        '</select><span class="hint">Fitting the readings magnifies the trend, but when a machine is far '+
        'from its limit the limit line will fall outside the chart. The chart labels itself '+
        '<b>limit off-chart</b> whenever that happens, so a missing line is never mistaken for a safe one.</span></label>'+
        '<label class="fld"><span>Machines with more than one parameter</span><select id="oMode">'+
        '<option value="combined"'+(SETTINGS.chartMode==='combined'?' selected':'')+'>One combined chart, every parameter on a % of limit scale</option>'+
        '<option value="separate"'+(SETTINGS.chartMode==='separate'?' selected':'')+'>A separate chart for each parameter, in its own units</option>'+
        '</select><span class="hint">Combined puts every trend of a machine on one chart. Parameters have different '+
        'units, so each is drawn as how far it has travelled from its healthy baseline (0%) to its limit (100%). '+
        'Real values and units are in the legend underneath.</span></label>'+
        '<div style="height:6px"></div>'+
        cb('oBand',SETTINGS.band,'Grey normal-range band','from the healthy baseline up to the warn level')+
        cb('oLimit',SETTINGS.limitLine,'Limit line','red dashed')+
        cb('oWarn',SETTINGS.warnLine,'Warn line','amber dashed')+
        cb('oLabel',SETTINGS.label,'Value label on the latest reading','')+
        cb('oPM',SETTINGS.pmMarks,'Reset markers','blue flags for PM, violet diamonds for parameter activities')+
        '<label class="fld" style="margin-top:6px"><span>Dots on the line</span><select id="oDotMode">'+
        '<option value="all"'+(SETTINGS.dotMode==='all'?' selected':'')+'>On every reading — dot-line chart</option>'+
        '<option value="alarm"'+(SETTINGS.dotMode==='alarm'?' selected':'')+'>Only on warning and limit readings</option>'+
        '<option value="none"'+(SETTINGS.dotMode==='none'?' selected':'')+'>None — line only</option>'+
        '</select></label>'+
        cb('oProj',SETTINGS.projection,'Projection to the limit','dashed run-out on the full-size charts');
    }
    if(t==='tile'){
      h='<div class="note" style="margin-bottom:12px">Turn these off to fit more machines into one '+
        'screenshot.</div>'+
        cb('tTravel',SETTINGS.showTravel,'Progress bar','how far the reading has travelled to its limit')+
        cb('tPM',SETTINGS.showPM,'PM footer strip','last PM and days remaining')+
        cb('tSum',SETTINGS.showSummary,'Summary figures above the board','');
    }
    if(t==='params'){
      h='<div class="note" style="margin-bottom:12px">Hidden parameters keep their readings and still '+
        'appear in reports. They are only left off the board and the charts.</div>';
      DB.groups.concat(['Ungrouped']).forEach(function(g){
        var ps=DB.parameters.filter(function(x){ return groupOf(x)===g; });
        if(!ps.length) return;
        h+='<div class="optgrp">'+esc(g)+'</div>';
        ps.forEach(function(pa){
          var m=machineById(pa.machineId);
          h+='<label class="optrow"><input type="checkbox" data-pv="'+esc(pa.id)+'"'+
            (pa.hidden?'':' checked')+'>'+
            '<span><b>'+esc(m?m.name:pa.machineId)+'</b><em>'+esc(pa.name)+'</em></span></label>';
        });
      });
      h+='<div class="toolbar" style="margin-top:12px">'+
        '<button class="btn sm" id="pvAll">Show all</button>'+
        '<button class="btn sm" id="pvNone">Hide all</button></div>';
    }
    $('#dispPane').innerHTML=h;
    if(t==='params'){
      $('#dispPane').querySelectorAll('[data-pv]').forEach(function(x){
        x.onchange=function(){
          var pa=DB.parameters.filter(function(q){ return q.id===x.dataset.pv; })[0];
          if(pa){ pa.hidden = !x.checked; unsavedOps++; markDirty(); }
        };
      });
      $('#pvAll').onclick=function(){ DB.parameters.forEach(function(q){ q.hidden=false; });
        unsavedOps++; markDirty(); pane('params'); };
      $('#pvNone').onclick=function(){ DB.parameters.forEach(function(q){ q.hidden=true; });
        unsavedOps++; markDirty(); pane('params'); };
    }
  }
  $$('#dispTabs button').forEach(function(btn){
    btn.onclick=function(){
      $$('#dispTabs button').forEach(function(x){ x.setAttribute('aria-current', String(x===btn)); });
      pane(btn.dataset.t);
    };
  });
  pane('chart');
}
