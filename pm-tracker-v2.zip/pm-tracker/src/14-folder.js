/* ==========================================================================
   14-folder.js — save straight into the data folder

   Chrome and Edge let a page opened from a file path write to a folder the
   user has chosen (the File System Access API). Connect the data folder once;
   after that:

     · Open  — the newest pm-data-*.json in the folder is loaded.
     · Save  — that same file is updated in place. No downloads, no moving.
     · Once a day, before the first save, a dated copy goes to backups/ so an
       in-place overwrite can never destroy the only copy.
     · If someone else saved the file after you opened it, you are asked
       before their changes are overwritten.

   The folder handle is kept in IndexedDB. Chrome 122 and later can remember
   the permission ("Allow on every visit"); otherwise reopening the app needs
   one click on Reconnect. Without the API, saving falls back to downloads.
   ========================================================================== */

var FOLDER = { handle:null, name:'', file:'', loadedMod:0, state:'none' };
/* state: none | unsupported | needs-permission | connected */

function folderSupported(){ return typeof window.showDirectoryPicker==='function'; }

/* ---------- handle persistence ---------- */
function idbOpen(){
  return new Promise(function(res,rej){
    var r=indexedDB.open('pmtracker',1);
    r.onupgradeneeded=function(){ r.result.createObjectStore('kv'); };
    r.onsuccess=function(){ res(r.result); };
    r.onerror=function(){ rej(r.error); };
  });
}
function idbGet(k){
  return idbOpen().then(function(db){ return new Promise(function(res,rej){
    var t=db.transaction('kv','readonly').objectStore('kv').get(k);
    t.onsuccess=function(){ res(t.result); }; t.onerror=function(){ rej(t.error); };
  }); });
}
function idbSet(k,v){
  return idbOpen().then(function(db){ return new Promise(function(res,rej){
    var t=db.transaction('kv','readwrite').objectStore('kv').put(v,k);
    t.onsuccess=function(){ res(); }; t.onerror=function(){ rej(t.error); };
  }); });
}
function idbDel(k){
  return idbOpen().then(function(db){ return new Promise(function(res){
    var t=db.transaction('kv','readwrite').objectStore('kv').delete(k);
    t.onsuccess=function(){ res(); }; t.onerror=function(){ res(); };
  }); });
}

async function permissionOf(h, ask){
  if(!h.queryPermission) return 'granted';          /* origin-private folders */
  var opts={mode:'readwrite'};
  var st=await h.queryPermission(opts);
  if(st==='granted' || !ask) return st;
  return await h.requestPermission(opts);
}

/* ---------- reading the folder ---------- */
async function listDataFiles(dir){
  var out=[];
  for await (var entry of dir.values()){
    if(entry.kind==='file' && /^pm-data-.*\.json$/i.test(entry.name)) out.push(entry);
  }
  /* names carry YYYY-MM-DD-HHMMSS, so name order is creation order */
  out.sort(function(a,b){ return a.name<b.name?-1:1; });
  return out;
}
async function newestFile(dir){
  var files=await listDataFiles(dir);
  if(!files.length) return null;
  /* prefer the most recently MODIFIED file: in-place saves update content,
     not the name, so the newest name is not always the newest data */
  var best=null, bestMod=-1;
  for(var i=0;i<files.length;i++){
    var f=await files[i].getFile();
    if(f.lastModified>bestMod){ bestMod=f.lastModified; best=files[i]; }
  }
  return best;
}

async function loadFromFolder(){
  var h=FOLDER.handle;
  var files=await listDataFiles(h);
  if(!files.length){ FOLDER.file=''; return { loaded:false, reason:'empty' }; }
  /* newest modified first; a damaged file — a half-finished network copy, say —
     must not lock you out, so fall back to the next one that reads cleanly */
  var stamped=[];
  for(var i=0;i<files.length;i++){ var f0=await files[i].getFile(); stamped.push({h:files[i], f:f0}); }
  stamped.sort(function(a,b){ return b.f.lastModified-a.f.lastModified; });
  var skipped=[];
  for(var j=0;j<stamped.length;j++){
    try{
      var db=migrate(JSON.parse(await stamped[j].f.text()));
      DB=db; FOLDER.file=stamped[j].h.name; FOLDER.loadedMod=stamped[j].f.lastModified;
      entryDraft={}; markClean();
      var iss=integrity(db);
      if(skipped.length) iss.unshift(skipped.join(', ')+' could not be read, so the next newest file was opened instead');
      return { loaded:true, name:stamped[j].h.name, issues:iss, skipped:skipped };
    }catch(e){ skipped.push(stamped[j].h.name); }
  }
  FOLDER.file='';
  throw new Error('none of the '+files.length+' data files in the folder could be read');
}

/* ---------- connecting ---------- */
async function connectFolder(){
  if(!folderSupported()){ toast('This browser cannot connect to a folder. Saving will use downloads.',true); return; }
  try{
    var h=await window.showDirectoryPicker({ id:'pmtracker-data', mode:'readwrite' });
    var perm=await permissionOf(h, true);
    if(perm!=='granted'){ toast('Write permission was not granted, so the folder is not connected.',true); return; }
    FOLDER.handle=h; FOLDER.name=h.name; FOLDER.state='connected';
    try{ await idbSet('dataFolder', h); }catch(e){}
    var r=await loadFromFolder();
    if(r.loaded){
      render(); show(screen==='data'?'board':screen);
      toast('Connected to "'+h.name+'". Loaded '+r.name+'.');
    } else {
      render();
      toast('Connected to "'+h.name+'". No data file there yet — the next save will create one.');
    }
    paintFolderState();
  }catch(e){
    if(e && e.name==='AbortError') return;          /* user closed the picker */
    toast('Could not connect to that folder: '+(e.message||e),true);
  }
}
async function reconnectFolder(){
  if(!FOLDER.handle) return connectFolder();
  try{
    var perm=await permissionOf(FOLDER.handle, true);
    if(perm!=='granted'){ toast('Permission was not granted.',true); return; }
    FOLDER.state='connected';
    var r=await loadFromFolder();
    render();
    toast(r.loaded?'Reconnected. Loaded '+r.name+'.':'Reconnected to "'+FOLDER.handle.name+'".');
    offerDraftIfNewer();
    paintFolderState();
  }catch(e){ toast('Could not reconnect: '+(e.message||e),true); }
}
async function disconnectFolder(){
  FOLDER={ handle:null, name:'', file:'', loadedMod:0, state: folderSupported()?'none':'unsupported' };
  try{ await idbDel('dataFolder'); }catch(e){}
  paintFolderState(); render();
  toast('Folder disconnected. Saving goes back to downloads.');
}

/* ---------- saving in place ---------- */
async function writeFile(dir, name, text){
  var fh=await dir.getFileHandle(name, { create:true });
  var w=await fh.createWritable();       /* writes to a temporary copy and swaps it */
  await w.write(text);                   /* in on close, so a crash mid-save cannot */
  await w.close();                       /* leave a half-written file behind         */
  return fh;
}
async function dailyBackup(dir, text){
  var day=todayISO();
  var bdir=await dir.getDirectoryHandle('backups', { create:true });
  var name='pm-data-'+day+'.json';
  try{ await bdir.getFileHandle(name); return false; }   /* already have today's */
  catch(e){ await writeFile(bdir, name, text); return true; }
}
async function saveToFolder(force){
  var dir=FOLDER.handle;
  if(await permissionOf(dir,false)!=='granted'){
    if(await permissionOf(dir,true)!=='granted'){ toast('No permission to write to the folder.',true); return false; }
  }
  var target = FOLDER.file;
  if(!target){ var nf=await newestFile(dir); target = nf ? nf.name : 'pm-data-'+saveStamp()+'.json'; }

  /* someone else saved this file after we opened it? */
  if(!force && FOLDER.loadedMod){
    try{
      var cur=await (await dir.getFileHandle(target)).getFile();
      if(cur.lastModified > FOLDER.loadedMod + 1000){
        var when=new Date(cur.lastModified).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
        if(!confirm(target+' was changed by someone else at '+when+', after you opened it.\n\n'+
          'Saving now will replace their changes with yours.\n\nOK to overwrite, Cancel to keep theirs '+
          '(then reload to see their version).')) return false;
      }
    }catch(e){}
  }

  DB.meta.savedAt=new Date().toISOString();
  DB.meta.lastFile=target;
  var body=JSON.stringify(DB,null,1);
  var backedUp=false;
  try{
    /* back up the version on disk before replacing it */
    try{ var prev=await (await dir.getFileHandle(target)).getFile(); backedUp=await dailyBackup(dir, await prev.text()); }
    catch(e){ backedUp=await dailyBackup(dir, body); }
    var fh=await writeFile(dir, target, body);
    await writeFile(dir, 'latest.js',
      '/* PM Tracker auto-load file, written '+saveStamp()+'. */\nwindow.PM_AUTOLOAD = '+body+';\n');
    FOLDER.file=target;
    FOLDER.loadedMod=(await fh.getFile()).lastModified;
  }catch(e){
    toast('Saving to the folder failed: '+(e.message||e)+'. Your work is still here — try again, or use Download.',true);
    return false;
  }
  markClean(); clearDraft(); paintFolderState(); render();
  toast('Saved to '+target+(backedUp?' · today\u2019s backup made':'')+'.');
  return true;
}
async function saveAsNewFile(){
  if(FOLDER.state!=='connected'){ saveJSON(); return; }
  FOLDER.file='pm-data-'+saveStamp()+'.json'; FOLDER.loadedMod=0;
  await saveToFolder(true);
}

/* the one save button everything calls */
function smartSave(){
  if(FOLDER.state==='connected') return saveToFolder(false);
  if(FOLDER.state==='needs-permission') return reconnectFolder();
  return saveJSON();
}

/* ---------- status in the top bar ---------- */
function paintFolderState(){
  var el=$('#folderState'); if(!el) return;
  if(FOLDER.state==='connected'){
    el.className='folderstate on';
    el.innerHTML='<span class="fd"></span>'+esc(FOLDER.name)+(FOLDER.file?' / '+esc(FOLDER.file):'');
    el.title='Saving writes straight to this file. Click to change folder.';
    el.onclick=connectFolder;
  } else if(FOLDER.state==='needs-permission'){
    el.className='folderstate warn';
    el.innerHTML='<span class="fd"></span>Reconnect to '+esc(FOLDER.name);
    el.title='Chrome needs one click to let the app use this folder again.';
    el.onclick=reconnectFolder;
  } else if(FOLDER.state==='unsupported'){
    el.className='folderstate off';
    el.innerHTML='Saving by download';
    el.title='This browser cannot write to a folder. Use Chrome or Edge to save in place.';
    el.onclick=function(){ show('data'); };
  } else {
    el.className='folderstate off';
    el.innerHTML='<span class="fd"></span>Connect data folder';
    el.title='Pick the data folder once, and saving updates your file there directly.';
    el.onclick=connectFolder;
  }
  var qs=$('#quickSave');
  if(qs){
    qs.textContent = FOLDER.state==='needs-permission' ? 'Reconnect & save' : 'Save';
    qs.title = FOLDER.state==='connected' ? 'Save into '+(FOLDER.file||'the data folder')+' (Ctrl+S)'
             : 'Download the data file (Ctrl+S). Connect the data folder to save in place.';
  }
}

/* ---------- startup ---------- */
async function restoreFolder(){
  if(!folderSupported()){ FOLDER.state='unsupported'; paintFolderState(); return false; }
  var h=null;
  try{ h=await idbGet('dataFolder'); }catch(e){}
  if(!h){ FOLDER.state='none'; paintFolderState(); return false; }
  FOLDER.handle=h; FOLDER.name=h.name;
  var perm='prompt';
  try{ perm=await permissionOf(h,false); }catch(e){}
  if(perm!=='granted'){ FOLDER.state='needs-permission'; paintFolderState(); return false; }
  FOLDER.state='connected';
  try{
    var r=await loadFromFolder();
    paintFolderState();
    return r.loaded ? r : false;
  }catch(e){
    toast('Could not read the data folder: '+(e.message||e),true);
    paintFolderState();
    return false;
  }
}

/* A draft newer than the file we just loaded means work was lost when the tab
   closed. Offer it back rather than silently dropping it. */
function offerDraftIfNewer(){
  var d=readDraft();
  if(!d || !d.db || !(d.db.readings||[]).length) return;
  var loadedAt = DB.meta && DB.meta.savedAt ? new Date(DB.meta.savedAt).getTime() : 0;
  if(new Date(d.at).getTime() <= loadedAt + 2000) { clearDraft(); return; }
  var when=new Date(d.at).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
  setTimeout(function(){
    modal('Unsaved work found',
      '<p style="margin-bottom:12px">There is work from <b>'+esc(when)+'</b> that was never saved — newer than the file '+
      'that just opened. It holds '+d.db.readings.length.toLocaleString()+' readings.</p>'+
      '<p>Restore it and save, or discard it and keep the file as it is.</p>',
      function(){
        DB=migrate(d.db); dirty=true; unsavedOps=Math.max(1,unsavedOps); render();
        toast('Unsaved work restored. Save now so it is not lost again.');
      },'Restore my work');
    var c=$('#mCancel');
    if(c){ c.textContent='Discard it'; c.onclick=function(){ clearDraft(); $('#modalHost').innerHTML=''; }; }
  },400);
}
