/* ==========================================================================
   15-guide.js — Guide & about, and the theme gallery
   ========================================================================== */

var guideTab = 'map';

/* Every destination the guide can send you to. `go` runs after navigating. */
function guideGo(target){
  var t = GUIDE_TARGETS[target];
  if(!t) return;
  show(t.screen);
  if(t.after) setTimeout(t.after, 60);
}
var GUIDE_TARGETS = {
  board:     { screen:'board' },
  wall:      { screen:'board', after:function(){ enterWall(); } },
  bell:      { screen:'board', after:function(){ if(!bellOpen) toggleBell(); } },
  content:   { screen:'board', after:function(){ displayMenu(); } },
  edit:      { screen:'board', after:function(){ var b=document.querySelector('.tedit'); if(b) b.click(); } },
  entry:     { screen:'entry' },
  charts:    { screen:'charts' },
  pm:        { screen:'pm' },
  analysis:  { screen:'analysis' },
  machine:   { screen:'machine' },
  report:    { screen:'report' },
  params:    { screen:'config', after:function(){ configTab='params'; renderConfig(); } },
  machines:  { screen:'config', after:function(){ configTab='machines'; renderConfig(); } },
  groups:    { screen:'config', after:function(){ configTab='groups'; renderConfig(); } },
  data:      { screen:'data' },
  folder:    { screen:'data', after:function(){ if(FOLDER.state!=='connected') connectFolder(); } },
  importer:  { screen:'data', after:function(){ var b=$('#pasteBox'); if(b){ b.scrollIntoView({block:'center'}); b.focus(); } } },
  themes:    { screen:'guide', after:function(){ themeGallery(); } },
  about:     { screen:'guide', after:function(){ guideTab='about'; renderGuide(); } }
};

function renderGuide(){
  $$('#guideTabs button').forEach(function(b){
    b.setAttribute('aria-current', String(b.dataset.g===guideTab));
    b.onclick=function(){ guideTab=b.dataset.g; renderGuide(); };
  });
  var host=$('#guideBody');
  host.innerHTML = guideTab==='map' ? guideMap()
                 : guideTab==='tasks' ? guideTasks()
                 : guideTab==='marks' ? guideMarks()
                 : guideAbout();
  host.querySelectorAll('[data-go]').forEach(function(el){
    el.onclick=function(){ guideGo(el.dataset.go); };
  });
  var f=$('#taskFind');
  if(f){
    f.oninput=function(){
      var q=f.value.trim().toLowerCase();
      $$('.gtask').forEach(function(t){ t.hidden = q && t.textContent.toLowerCase().indexOf(q)<0; });
      var any=$$('.gtask').some(function(t){ return !t.hidden; });
      $('#taskNone').hidden=any;
    };
    f.focus();
  }
}

/* ---------- the map: four workflows, each a path through the tabs ---------- */
function guideMap(){
  function lane(title, sub, steps, numbered){
    return '<div class="glane"><h4>'+title+'</h4><p>'+sub+'</p>'+steps.map(function(s,i){
      return '<button class="gstep" data-go="'+s[0]+'"><span class="gd">'+
        (numbered?'<i>'+(i+1)+'</i>':'<i class="dot"></i>')+'</span>'+
        '<span class="gtx"><b>'+s[1]+'</b><span>'+s[2]+'</span></span></button>';
    }).join('')+'</div>';
  }
  var h='<div class="gmap">';
  h+=lane('Every day','The routine, in order.',[
    ['entry','Log readings','Type today\u2019s values. Tick PM done on any machine serviced.'],
    ['entry','Save these readings','The button under the form.'],
    ['data','Save','Top bar, or Ctrl+S. With a folder connected, it updates your file in place.'],
    ['wall','Screenshot view','On the Status board. Win+Shift+S, paste to the team, Esc to come back.']
  ], true);
  h+=lane('When something looks wrong','Follow the alert to the cause.',[
    ['bell','The bell, top right','Every alert, worst first. Click one to open that machine.'],
    ['machine','Machine detail','Full history across PM cycles, and its activities.'],
    ['charts','Trend charts','Large charts with axes and the projection to the limit.'],
    ['edit','\u270E on a tile','Change a limit or warn level, log a PM or an activity.']
  ], false);
  h+=lane('Each week or month','Is the PM programme working?',[
    ['pm','PM schedule','Countdowns, and whether each interval matches reality.'],
    ['analysis','Analysis','Most concerning, cleanest, fastest-moving machines.'],
    ['report','Monthly report','Breaches, PM done, month-on-month change. Print it.']
  ], false);
  h+=lane('Setting up','Once, then occasionally.',[
    ['folder','Connect the data folder','Saves go straight into your file from then on.'],
    ['importer','Paste from Excel','Bring in machines, limits and history in one go.'],
    ['machines','Machines & limits','Add machines, parameters, PM intervals.'],
    ['content','Chart content','What each chart shows, combined or separate.'],
    ['themes','Theme','Seven looks. Pick one you can read all shift.']
  ], false);
  h+='</div>';
  h+='<div class="note"><b>Lost?</b> The <b>I want to\u2026</b> tab has a search box. Type what you are trying to do, '+
     'such as \u201cfilament\u201d or \u201cundo\u201d, and it shows where to go.</div>';
  return h;
}

/* ---------- the task finder ---------- */
var GUIDE_TASKS = [
  ['Daily', 'Enter today\u2019s readings', 'Log readings, type the values, then Save these readings.', 'entry'],
  ['Daily', 'Send the board to the team', 'Status board \u2192 Screenshot view \u2192 Win+Shift+S. Esc or \u2715 to leave.', 'wall'],
  ['Daily', 'Save my work', 'Save in the top bar, or Ctrl+S anywhere.', 'data'],
  ['Daily', 'See what needs attention', 'The bell, top right. Worst first; Ack silences one until it changes.', 'bell'],
  ['Fix', 'Correct a reading I already saved', 'Log readings \u2192 same date \u2192 retype it, or Revert / Undo on that row.', 'entry'],
  ['Fix', 'Undo the batch I just saved', 'Log readings \u2192 Undo last save. Rolls back readings and any PM with them.', 'entry'],
  ['Fix', 'Recover work after closing the tab', 'Reopen the app. Unsaved work newer than your file is offered back.', 'board'],
  ['PM', 'Record that PM was done', 'Tick PM done on Log readings, or Log PM on the PM schedule. Restarts the countdown and the trend.', 'pm'],
  ['PM', 'Record a PM I forgot to log', 'PM schedule \u2192 Log PM \u2192 set the real date. Backdating is fine.', 'pm'],
  ['PM', 'Change how often a machine gets PM', '\u270E on its tile \u2192 Interval, or PM schedule \u2192 Edit.', 'edit'],
  ['PM', 'Check whether a PM interval is right', 'PM schedule \u2192 Is the interval right?', 'pm'],
  ['Activity', 'Log a filament change or lamp swap', 'Log readings \u2192 Activity on that parameter\u2019s row. Resets that parameter only.', 'entry'],
  ['Activity', 'See every activity on a machine', 'Machine detail \u2192 Parameter activities.', 'machine'],
  ['Limits', 'Change a limit or warn level', '\u270E on the tile. Takes effect immediately.', 'edit'],
  ['Limits', 'Make a parameter that falls toward its limit', '\u270E \u2192 Direction \u2192 falls to limit (e.g. lamp intensity).', 'edit'],
  ['Board', 'Put all of a machine\u2019s trends on one chart', 'Status board \u2192 Parameters: Combined.', 'board'],
  ['Board', 'Make the charts bigger', 'Status board \u2192 Chart size L or XL, and fewer Columns.', 'board'],
  ['Board', 'See a small drift more clearly', 'Chart content \u2192 Vertical scale \u2192 Fit the readings.', 'content'],
  ['Board', 'Hide a noisy parameter from the board', 'Chart content \u2192 Which parameters. Reports still include it.', 'content'],
  ['Board', 'Turn the dots off or on', 'Chart content \u2192 Dots on the line.', 'content'],
  ['Board', 'Get more room on screen', 'The \u2039 arrow at the top of the side panel collapses it to icons.', 'board'],
  ['Setup', 'Add a machine', 'Machines & limits \u2192 Machines & PM schedule \u2192 Add machine.', 'machines'],
  ['Setup', 'Add a parameter to a machine', 'Machines & limits \u2192 Parameters \u2192 Add parameter.', 'params'],
  ['Setup', 'Bring in my old Excel data', 'Save, load & import \u2192 step 3. Copy the grid in Excel, paste, preview, import.', 'importer'],
  ['Setup', 'Save straight into the shared folder', 'Save, load & import \u2192 Connect folder. Choose Allow on every visit.', 'folder'],
  ['Setup', 'Retire a machine but keep its history', 'Machines & limits \u2192 Edit \u2192 State: Retired.', 'machines'],
  ['Reports', 'Get the monthly report', 'Monthly report \u2192 pick the month \u2192 Print report.', 'report'],
  ['Reports', 'Open the data in Excel', 'Save, load & import \u2192 Export to Excel. Two CSV files.', 'data'],
  ['Reports', 'Find the most worrying machine', 'Analysis \u2192 Most concerning machines.', 'analysis'],
  ['Look', 'Change the theme', 'Theme, top right.', 'themes']
];
function guideTasks(){
  var h='<div class="gfind"><input id="taskFind" type="search" placeholder="What are you trying to do? Try \u201cfilament\u201d, \u201cundo\u201d, \u201cExcel\u201d" '+
    'aria-label="Search tasks"></div><div class="gtasks">';
  GUIDE_TASKS.forEach(function(t){
    h+='<div class="gtask"><div class="gq"><b>'+esc(t[1])+'</b><span>'+esc(t[2])+'</span></div>'+
       '<button class="btn sm" data-go="'+t[3]+'">Go</button></div>';
  });
  h+='</div><div class="empty" id="taskNone" hidden><p>Nothing matches. Try a single word, like \u201cPM\u201d or \u201climit\u201d.</p></div>';
  return h;
}

/* ---------- what the marks mean, drawn with the real theme colours ---------- */
function guideMarks(){
  function svg(inner){ return '<svg width="46" height="22" viewBox="0 0 46 22" aria-hidden="true">'+inner+'</svg>'; }
  var C=COL;
  var rows=[
    [svg('<rect x="0" y="0" width="5" height="22" fill="var(--ok)"/><rect x="7" y="4" width="36" height="14" rx="2" fill="var(--surface)" stroke="var(--line)"/>'),
      '<b>Green edge, Normal</b> — comfortable margin to the limit.'],
    [svg('<rect x="0" y="0" width="5" height="22" fill="var(--warn)"/><rect x="7" y="4" width="36" height="14" rx="2" fill="var(--tile-warn)" stroke="var(--warn)"/>'),
      '<b>Amber edge, Warning</b> — past the warn level. Plan the work.'],
    [svg('<rect x="0" y="0" width="5" height="22" fill="var(--crit)"/><rect x="7" y="4" width="36" height="14" rx="2" fill="var(--tile-crit)" stroke="var(--crit)"/>'),
      '<b>Red edge, At limit</b> — reached the limit. Act now.'],
    [svg('<rect x="0" y="6" width="46" height="10" fill="'+C.band+'" opacity=".6"/><polyline points="2,13 12,12 22,13 32,11 44,12" fill="none" stroke="'+C.trace+'" stroke-width="1.6"/>'),
      '<b>Grey band</b> — the normal range, from the healthy level after the last reset up to the warn level.'],
    [svg('<line x1="0" y1="11" x2="46" y2="11" stroke="'+C.thr+'" stroke-width="1.6" stroke-dasharray="4 3"/>'),
      '<b>Red dashed line</b> — the limit the reading must not reach.'],
    [svg('<line x1="0" y1="11" x2="46" y2="11" stroke="'+C.warn+'" stroke-width="1.2" stroke-dasharray="2 3"/>'),
      '<b>Amber dashed line</b> — the warn level.'],
    [svg('<polyline points="2,15 12,13 22,14 32,10 44,8" fill="none" stroke="'+C.trace+'" stroke-width="1.5"/>'+
         [2,12,22,32,44].map(function(x,i){ return '<circle cx="'+x+'" cy="'+[15,13,14,10,8][i]+'" r="1.8" fill="'+C.trace+'"/>'; }).join('')),
      '<b>Dot-line</b> — a dot for every reading, joined in date order.'],
    [svg('<line x1="23" y1="0" x2="23" y2="22" stroke="'+C.pm+'" stroke-dasharray="2 2"/><path d="M19.5,0 L26.5,0 L23,6 Z" fill="'+C.pm+'"/>'+
         '<polyline points="2,6 20,4" fill="none" stroke="'+C.trace+'" stroke-width="1.5"/><line x1="20" y1="4" x2="26" y2="17" stroke="'+C.trace+'" stroke-dasharray="1.5 2.5" opacity=".6"/>'+
         '<polyline points="26,17 44,15" fill="none" stroke="'+C.trace+'" stroke-width="1.5"/>'),
      '<b>Blue flag</b> — a machine PM. The trend restarts; the dotted segment shows the drop across the reset.'],
    [svg('<line x1="23" y1="0" x2="23" y2="22" stroke="'+C.act+'" stroke-dasharray="2 2"/><path d="M23,0 l3.5,3.5 l-3.5,3.5 l-3.5,-3.5 Z" fill="'+C.act+'"/>'),
      '<b>Violet diamond</b> — an activity on that one parameter, such as a filament change. Only that parameter restarts.'],
    [svg('<rect x="2" y="4" width="34" height="14" rx="2.5" fill="'+C.labelBg+'" stroke="'+C.trace+'"/><text x="19" y="14.5" text-anchor="middle" font-size="9" font-weight="700" fill="'+C.trace+'">3.58</text>'),
      '<b>Boxed number</b> — the most recent reading.'],
    [svg('<line x1="0" y1="5" x2="46" y2="5" stroke="'+C.thr+'" stroke-width="1.2" stroke-dasharray="4 3"/><text x="0" y="4" font-size="6" fill="'+C.thr+'">100%</text>'+
         '<polyline points="2,18 22,14 44,9" fill="none" stroke="'+C.series[0]+'" stroke-width="1.6"/><polyline points="2,16 22,15 44,13" fill="none" stroke="'+C.series[1]+'" stroke-width="1.6" stroke-dasharray="6 3"/>'),
      '<b>Combined chart</b> — every parameter of a machine on one scale: 0% healthy, 100% at the limit. Real values are in the legend.'],
    [svg('<text x="0" y="15" font-size="11" font-weight="700" fill="var(--warn)">6d left</text>'),
      '<b>Days left</b> — when the trend since the last reset reaches the limit, at its current rate.'],
    [svg('<text x="0" y="15" font-size="10" fill="var(--ink-3)">PM reset</text>'),
      '<b>PM reset / Rebuilding</b> — just serviced; about three readings are needed before a trend is drawn.']
  ];
  var h='<div class="panel"><div class="body"><div class="gsym">'+
    rows.map(function(r){ return '<div>'+r[0]+'<span>'+r[1]+'</span></div>'; }).join('')+'</div></div></div>';
  h+='<div class="panel"><header><h3>Keyboard</h3></header><div class="body"><div class="keys">'+
    '<kbd>Ctrl</kbd> <kbd>S</kbd><span>Save, from any screen</span>'+
    '<kbd>Esc</kbd><span>Leave screenshot view, close a dialog or the notifications</span>'+
    '<kbd>Tab</kbd><span>Move to the next reading on Log readings</span>'+
    '<kbd>Enter</kbd><span>Open the machine on a focused tile</span>'+
    '</div></div></div>';
  return h;
}

/* ---------- about ---------- */
function guideAbout(){
  var fsa=folderSupported(), store=storageOK;
  var where = FOLDER.state==='connected' ? 'Connected folder <code>'+esc(FOLDER.name)+'</code>'+(FOLDER.file?', file <code>'+esc(FOLDER.file)+'</code>':'')
    : FOLDER.state==='needs-permission' ? 'Folder <code>'+esc(FOLDER.name)+'</code>, waiting for one click to reconnect'
    : window.PM_AUTOLOAD_USED ? '<code>data/latest.js</code> beside the app'
    : DB.meta && DB.meta.isDemo ? 'Demo data — nothing of yours is loaded'
    : 'Loaded by hand from a file';
  return '<div class="panel about"><header><h3>PM Tracker '+esc(APP_VERSION)+'</h3>'+
    '<span class="sub">equipment parameter monitoring for preventive maintenance</span></header><div class="body">'+
    '<p style="max-width:74ch;margin-bottom:16px;font-size:14px;line-height:1.6">Replaces the Excel chart sheet and the screenshot routine. '+
    'You log one or two readings per machine each day; the app shows how far each has travelled toward its limit, '+
    'how fast it is moving since the last PM or activity, when it will get there, and which PMs are due. '+
    'It runs from a file on the shared drive with nothing to install.</p>'+
    '<dl>'+
    '<dt>Data loaded from</dt><dd>'+where+'</dd>'+
    '<dt>In this file</dt><dd><b>'+activeMachines().length+'</b> machines, <b>'+DB.parameters.length+'</b> parameters, <b>'+
      DB.readings.length.toLocaleString()+'</b> readings, <b>'+DB.pmEvents.length+'</b> PM events, <b>'+DB.paramEvents.length+'</b> activities</dd>'+
    '<dt>Last saved</dt><dd>'+(DB.meta.savedAt?esc(new Date(DB.meta.savedAt).toLocaleString()):'not yet')+'</dd>'+
    '<dt>Saving method</dt><dd>'+(FOLDER.state==='connected'?'Writes straight into the file in the connected folder':
      fsa?'Downloads, until a folder is connected':'Downloads — this browser cannot write to a folder')+'</dd>'+
    '<dt>Folder access</dt><dd>'+(fsa?'Available':'Not available in this browser — use Chrome or Edge')+'</dd>'+
    '<dt>Crash recovery</dt><dd>'+(store?'On — unsaved work is kept in this browser until you save':'Off — this browser is not keeping a copy, so save often')+'</dd>'+
    '<dt>File format</dt><dd>Version <b>'+SCHEMA+'</b>, plain JSON. Exports to CSV for Excel.</dd>'+
    '<dt>Theme</dt><dd>'+esc(THEME_INFO[SETTINGS.theme].name)+' — <button class="linkbtn" data-go="themes">change</button></dd>'+
    '</dl></div></div>'+
    '<div class="panel"><header><h3>How it decides</h3></header><div class="body" style="font-size:14px;line-height:1.6;max-width:80ch">'+
    '<p style="margin-bottom:10px"><b>Trend</b> is a straight line fitted only to readings since the last reset — a machine PM, '+
    'or an activity on that parameter. It never crosses a reset, because the rise before and the drop after would average '+
    'into a falsely flat line.</p>'+
    '<p style="margin-bottom:10px"><b>% of limit</b> is how far a reading has travelled from its healthy level after the last reset '+
    '(0%) to its limit (100%). It works the same for readings that rise and readings that fall toward their limit.</p>'+
    '<p style="margin-bottom:10px"><b>Days left</b> projects that trend forward to the limit. It is blank when the trend is flat '+
    'or moving away, and waits for about three readings after a reset.</p>'+
    '<p><b>Layout</b> follows ISA-101 for operator displays — colour is kept for alarms — and Tufte\u2019s small multiples: '+
    'every tile framed the same, so you compare shapes rather than read fourteen different charts.</p>'+
    '</div></div>';
}

/* ---------- theme gallery: every card previews itself in its own theme ---------- */
function themeGallery(){
  function preview(id){
    return '<div class="tprev" data-theme="'+id+'">'+
      '<div class="mt"><b>Dry Pump 14</b><em>27.68</em>'+
        '<svg viewBox="0 0 80 26" preserveAspectRatio="none"><rect y="10" width="80" height="12" fill="var(--c-band)" opacity=".6"/>'+
        '<line x1="0" y1="5" x2="80" y2="5" stroke="var(--c-crit)" stroke-dasharray="3 2"/>'+
        '<polyline points="2,19 14,18 26,19 38,17 50,18 62,16 78,16" fill="none" stroke="var(--c-trace)" stroke-width="1.5"/></svg></div>'+
      '<div class="mt c"><b>Scanner 1</b><em>3.58</em>'+
        '<svg viewBox="0 0 80 26" preserveAspectRatio="none"><rect y="12" width="80" height="12" fill="var(--c-band)" opacity=".6"/>'+
        '<line x1="0" y1="7" x2="80" y2="7" stroke="var(--c-crit)" stroke-dasharray="3 2"/>'+
        '<polyline points="2,22 14,20 26,18 38,15 50,12 62,8 78,4" fill="none" stroke="var(--c-crit)" stroke-width="1.5"/></svg></div>'+
      '</div>';
  }
  var b='<div class="tgal">'+THEMES.map(function(id){
    return '<button class="tcard" data-theme-pick="'+id+'" aria-pressed="'+(SETTINGS.theme===id)+'">'+preview(id)+
      '<span class="tname">'+esc(THEME_INFO[id].name)+'</span><span class="tnote">'+esc(THEME_INFO[id].note)+'</span></button>';
  }).join('')+'</div>';
  var before=SETTINGS.theme;
  modal('Theme', b, function(){ saveSettings(); render(); }, 'Keep this theme');
  var mo=document.querySelector('#modalHost .modal'); if(mo) mo.classList.add('wide');
  $$('[data-theme-pick]').forEach(function(btn){
    btn.onclick=function(){
      SETTINGS.theme=btn.dataset.themePick; applyTheme(); refreshChartColors();
      $$('[data-theme-pick]').forEach(function(x){ x.setAttribute('aria-pressed', String(x===btn)); });
      if(screen!=='guide') render();
    };
  });
  var c=$('#mCancel');
  if(c){ var orig=c.onclick; c.onclick=function(){ SETTINGS.theme=before; applyTheme(); render(); orig&&orig(); }; }
}
