/* ==========================================================================
   03-charts.js — SVG drawn by hand, no charting library.

   Dot-line charts: a dot on every reading joined by a line, as in the Excel
   sheet this replaced. The line breaks at every reset (a machine PM, or an
   activity on that parameter) because the trend restarts there, but the drop
   across the break is still drawn — as a faint dotted connector — so a reset
   is visible rather than looking like missing data.

   Colours come from the active theme's CSS variables, read once per render.
   ========================================================================== */

var COL = {};
function refreshChartColors(){
  var cs = getComputedStyle(document.documentElement);
  function v(n,f){ var x=cs.getPropertyValue(n).trim(); return x||f; }
  COL = {
    trace: v('--c-trace','#2f3d4a'),  bg:   v('--c-plot','#fbfcfd'),
    band:  v('--c-band','#ccd6de'),   thr:  v('--c-crit','#b02a20'),
    warn:  v('--c-warn','#c98a1e'),   pm:   v('--c-pm','#1c5a9e'),
    act:   v('--c-act','#7b4fb5'),    axis: v('--c-axis','#aeb9c3'),
    grid:  v('--c-grid','#e2e8ed'),   text: v('--c-text','#77848f'),
    labelBg: v('--c-label-bg','#ffffff'),
    series:[ v('--s1','#1f5fa8'), v('--s2','#c2410c'), v('--s3','#0f766e'),
             v('--s4','#7c3aed'), v('--s5','#be185d'), v('--s6','#4d7c0f') ]
  };
}
/* dash patterns pair with the series colours so traces stay distinct when
   printed in greyscale or seen by a colour-blind reader */
var SERIES_DASH = ['', '6 3', '2 2.5', '8 3 2 3', '4 4', '1 3'];

/* Tick dates every N days, anchored on the most recent reading so the latest
   date always carries a label. Returns oldest-first. */
function tickDates(first, last, stepDays){
  var out=[], d=last;
  while(dayNum(d) >= dayNum(first)){ out.unshift(d); d = addDays(d, -stepDays); }
  if(out.length && diffDays(out[0], first) >= stepDays*0.6) out.unshift(first);
  return out;
}
var TICK_DAYS = 6;
var CHART_H = { s:62, m:84, l:112, xl:150 };

/* Y range. "auto" keeps the limit on screen. "data" fits the readings so a
   small drift is visible, and the chart says so when the limit falls off.
   "zero" anchors the bottom at zero. */
function yRange(p, vals, base){
  var lo, hi, mode=SETTINGS.yMode||'auto';
  var vLo=Math.min.apply(null,vals), vHi=Math.max.apply(null,vals);
  if(mode==='data'){ lo=vLo; hi=vHi; }
  else {
    lo=Math.min(vLo,p.threshold); hi=Math.max(vHi,p.threshold);
    if(SETTINGS.warnLine && p.warn!=null){ lo=Math.min(lo,p.warn); hi=Math.max(hi,p.warn); }
    if(SETTINGS.band && base!=null){ lo=Math.min(lo,base); hi=Math.max(hi,base); }
    if(mode==='zero'){ lo=Math.min(lo,0); }
  }
  var pad=(hi-lo)*0.14 || Math.abs(hi*0.08) || 1;
  return { lo:lo-pad, hi:hi+pad, clipped: mode==='data' && (p.threshold>vHi || p.threshold<vLo) };
}

function windowed(all, days){
  if(!(days>0)) return all;
  var cut = addDays(latestDate(), -days);
  return all.filter(function(r){ return r.date>=cut; });
}

/* Split readings into runs between resets and data gaps of more than 4 days.
   Returns { runs:[[pt..],..], joins:[[a,b],..] } where joins are the pairs
   that straddle a reset — those get the dotted "reset" connector. */
function splitRuns(pts, resets){
  var runs=[[]], joins=[], lastD=null;
  pts.forEach(function(r){
    var reset=false, gap=false;
    if(lastD!=null){
      if(diffDays(r.date,lastD)>4) gap=true;
      resets.forEach(function(x){ if(x.date>lastD && x.date<=r.date) reset=true; });
    }
    if((reset||gap) && runs[runs.length-1].length){
      var prev=runs[runs.length-1]; prev=prev[prev.length-1];
      if(reset) joins.push([prev, r]);
      runs.push([]);
    }
    runs[runs.length-1].push(r);
    lastD=r.date;
  });
  return { runs:runs, joins:joins };
}

/* draw the reset markers at the top edge: blue PM flag, violet activity flag */
function resetMarkers(resets, X, plotTop, plotBottom, inRange){
  var s='';
  resets.forEach(function(x){
    if(!inRange(x.date) || !SETTINGS.pmMarks) return;
    var cx=X(x.date), c = x.kind==='act'?COL.act:COL.pm;
    s+='<line x1="'+cx+'" y1="'+plotTop+'" x2="'+cx+'" y2="'+plotBottom+'" stroke="'+c+
       '" stroke-width="1" stroke-dasharray="2 2" opacity=".55"/>';
    if(x.kind==='act'){
      s+='<path d="M'+cx+','+plotTop+' l3.5,3.5 l-3.5,3.5 l-3.5,-3.5 Z" fill="'+c+'">'+
         '<title>'+esc((x.type||'Activity')+' on '+fmtDate(x.date))+'</title></path>';
    } else {
      s+='<path d="M'+(cx-3.2)+','+plotTop+' L'+(cx+3.2)+','+plotTop+' L'+cx+','+(plotTop+5.5)+' Z" fill="'+c+'">'+
         '<title>'+esc('PM on '+fmtDate(x.date))+'</title></path>';
    }
  });
  return s;
}

/* dots: every reading (dot-line), alarms only, or none */
function dotsFor(pts, p, X, Y, traceCol, r){
  var mode=SETTINGS.dotMode||'all', s='';
  if(mode==='none') return s;
  pts.forEach(function(q){
    var st=statusOf(p,q.value);
    if(mode==='alarm' && st==='ok') return;
    var c = st==='crit'?COL.thr : st==='warn'?COL.warn : traceCol;
    s+='<circle cx="'+X(q.date)+'" cy="'+Y(q.value)+'" r="'+(st==='ok'?r:r+0.7)+'" fill="'+c+'">'+
       '<title>'+esc(fmtDate(q.date)+': '+num(q.value)+' '+(p.unit||''))+'</title></circle>';
  });
  return s;
}

/* ---------- tile microchart: one parameter ---------- */
function tileChart(a, days, compact){
  var H = CHART_H[SETTINGS.chartH] || CHART_H.m;
  if(compact) H = Math.max(56, H-20);
  var W=268, L=3, T=6, B=17, p=a.p;
  var pts = windowed(a.all, days);
  if(!pts.length){
    return '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="No data">'+
      '<text x="'+(W/2)+'" y="'+(H/2+4)+'" text-anchor="middle" font-size="11" fill="'+COL.text+'">no readings in this window</text></svg>';
  }
  var lastLbl = num(pts[pts.length-1].value);
  var R = SETTINGS.label ? Math.max(26, Math.min(74, lastLbl.length*5.4+15)) : 8;
  var base=a.baseline, vals=pts.map(function(r){ return r.value; });
  var yr=yRange(p, vals, base), lo=yr.lo, hi=yr.hi;
  var d0=dayNum(pts[0].date), d1=dayNum(pts[pts.length-1].date), span=Math.max(1,d1-d0);
  var PLOT=H-B;
  function X(d){ return L + ((dayNum(d)-d0)/span)*(W-L-R); }
  function Y(v){ return T + (1-(v-lo)/(hi-lo))*(PLOT-T-2); }
  function inRange(d){ return d>=pts[0].date && d<=pts[pts.length-1].date; }

  var s='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(p.name+' trend, latest '+num(a.value))+'">';
  if(SETTINGS.band){
    var bandTop = p.warn!=null ? p.warn : p.threshold;
    s+='<rect x="0" y="'+Math.min(Y(base),Y(bandTop))+'" width="'+W+'" height="'+Math.abs(Y(bandTop)-Y(base))+
       '" fill="'+COL.band+'" opacity=".5"/>';
  }
  if(H>=100){
    for(var gi=1;gi<=3;gi++){
      var gv=lo+(hi-lo)*gi/4, gy=Y(gv);
      s+='<line x1="0" y1="'+gy+'" x2="'+(W-R+6)+'" y2="'+gy+'" stroke="'+COL.grid+'" stroke-width=".6"/>';
      s+='<text x="2" y="'+(gy-1.5)+'" font-size="7.5" fill="'+COL.text+'">'+esc(num(gv))+'</text>';
    }
  }
  if(SETTINGS.limitLine && !yr.clipped){
    var yt=Y(p.threshold);
    s+='<line x1="0" y1="'+yt+'" x2="'+(W-R+6)+'" y2="'+yt+'" stroke="'+COL.thr+'" stroke-width="1.4" stroke-dasharray="4 3"/>';
  }
  if(SETTINGS.warnLine && p.warn!=null && !yr.clipped){
    var yw=Y(p.warn);
    s+='<line x1="0" y1="'+yw+'" x2="'+(W-R+6)+'" y2="'+yw+'" stroke="'+COL.warn+'" stroke-width="1" stroke-dasharray="2 3" opacity=".8"/>';
  }
  if(yr.clipped){
    s+='<text x="'+(W-R+4)+'" y="10" text-anchor="end" font-size="8" fill="'+COL.thr+'" font-weight="700">limit off-chart</text>';
  }

  /* x axis, a tick every TICK_DAYS days, labels thinned so they never collide */
  var ticks=tickDates(pts[0].date, pts[pts.length-1].date, TICK_DAYS);
  s+='<line x1="0" y1="'+PLOT+'" x2="'+W+'" y2="'+PLOT+'" stroke="'+COL.axis+'" stroke-width="1"/>';
  var labelW=17, everyN=Math.max(1, Math.ceil(ticks.length/Math.max(1,Math.floor((W-L-R)/labelW))));
  ticks.forEach(function(d,i){
    var x=X(d); if(x<L-1 || x>W-R+2) return;
    s+='<line x1="'+x+'" y1="'+(PLOT-2)+'" x2="'+x+'" y2="'+(PLOT+2.5)+'" stroke="'+COL.axis+'" stroke-width="1"/>';
    var isLast=i===ticks.length-1;
    if(i%everyN!==0 && !isLast) return;
    var anchor = i===0?'start':(isLast?'end':'middle');
    var tx = i===0?Math.max(1,x-2):(isLast?Math.min(W-R+3,x+2):x);
    s+='<text x="'+tx+'" y="'+(PLOT+11)+'" text-anchor="'+anchor+'" font-size="8.5" fill="'+COL.text+'">'+esc(fmtNumeric(d))+'</text>';
  });

  var resets=resetDatesOf(p).filter(function(x){ return inRange(x.date); });
  s+=resetMarkers(resets, X, 0, PLOT, inRange);

  var traceCol = a.status==='crit'?COL.thr : a.status==='warn'?COL.warn : COL.trace;
  var split=splitRuns(pts, resets);
  /* the drop across a reset, drawn so it is seen rather than looking like lost data */
  split.joins.forEach(function(j){
    s+='<line x1="'+X(j[0].date)+'" y1="'+Y(j[0].value)+'" x2="'+X(j[1].date)+'" y2="'+Y(j[1].value)+
       '" stroke="'+traceCol+'" stroke-width="1.1" stroke-dasharray="1.5 2.5" opacity=".55"/>';
  });
  split.runs.forEach(function(run){
    if(run.length<2) return;
    s+='<polyline fill="none" stroke="'+traceCol+'" stroke-width="1.6" stroke-linejoin="round" points="'+
       run.map(function(r){ return X(r.date)+','+Y(r.value); }).join(' ')+'"/>';
  });
  s+=dotsFor(pts, p, X, Y, traceCol, 1.5);

  var last=pts[pts.length-1], lx=X(last.date), ly=Y(last.value);
  s+='<circle cx="'+lx+'" cy="'+ly+'" r="2.9" fill="'+traceCol+'"/>'+
     '<circle cx="'+lx+'" cy="'+ly+'" r="4.8" fill="none" stroke="'+traceCol+'" stroke-width="1" opacity=".4"/>';
  if(SETTINGS.label){
    var lw=lastLbl.length*5.4+8, lxBox=Math.min(lx+5, W-lw-1.5), ly2=Math.max(9, Math.min(PLOT-3, ly+3.2));
    s+='<rect x="'+lxBox+'" y="'+(ly2-8.5)+'" width="'+lw+'" height="12" rx="2.5" fill="'+COL.labelBg+
       '" stroke="'+traceCol+'" stroke-width=".8"/>';
    s+='<text x="'+(lxBox+lw/2)+'" y="'+(ly2+.8)+'" text-anchor="middle" font-size="9.5" font-weight="700" fill="'+traceCol+'">'+esc(lastLbl)+'</text>';
  }
  return s+'</svg>';
}

/* ---------- combined chart: every parameter of a machine on one plot ----------
   Parameters have different units and some fall toward their limit while others
   rise, so they cannot share a raw axis, and a second axis invites misreading.
   Every trace is drawn on the same indexed scale instead: 0% is the healthy
   baseline after the last reset, 100% is the limit. The legend carries the real
   values and units. */
function combinedChart(rows, days){
  var H = (CHART_H[SETTINGS.chartH] || CHART_H.m) + 22;
  var W=268, L=24, R=8, T=7, B=17, PLOT=H-B;
  var series=rows.map(function(a){
    var pts=windowed(a.all, days).map(function(r){
      var v=approach(a.p, r.value);
      return { date:r.date, value:r.value, pct: v==null?null:v };
    }).filter(function(q){ return q.pct!=null && isFinite(q.pct); });
    return { a:a, pts:pts };
  }).filter(function(s){ return s.pts.length; });
  if(!series.length){
    return '<svg viewBox="0 0 '+W+' '+H+'"><text x="'+(W/2)+'" y="'+(H/2)+'" text-anchor="middle" font-size="11" fill="'+COL.text+'">no readings in this window</text></svg>';
  }
  var allPts=[].concat.apply([], series.map(function(s){ return s.pts; }));
  var first=allPts.reduce(function(m,q){ return q.date<m?q.date:m; }, allPts[0].date);
  var lastD=allPts.reduce(function(m,q){ return q.date>m?q.date:m; }, allPts[0].date);
  var pcts=allPts.map(function(q){ return q.pct; });
  var lo=Math.min(0, Math.min.apply(null,pcts)), hi=Math.max(110, Math.max.apply(null,pcts));
  var pad=(hi-lo)*0.06; lo-=pad; hi+=pad;
  var d0=dayNum(first), span=Math.max(1, dayNum(lastD)-d0);
  function X(d){ return L + ((dayNum(d)-d0)/span)*(W-L-R); }
  function Y(v){ return T + (1-(v-lo)/(hi-lo))*(PLOT-T-2); }
  function inRange(d){ return d>=first && d<=lastD; }

  var s='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(rows.length+' parameters on one indexed chart')+'">';
  /* normal band 0% to the lowest warn level among the parameters */
  if(SETTINGS.band){
    var warnPcts=rows.map(function(a){ return a.p.warn!=null?approach(a.p,a.p.warn):null; })
      .filter(function(x){ return x!=null && isFinite(x); });
    var wTop = warnPcts.length?Math.min.apply(null,warnPcts):80;
    s+='<rect x="'+L+'" y="'+Y(wTop)+'" width="'+(W-L-R)+'" height="'+(Y(0)-Y(wTop))+'" fill="'+COL.band+'" opacity=".45"/>';
  }
  [0,50,100].forEach(function(g){
    var gy=Y(g);
    s+='<line x1="'+L+'" y1="'+gy+'" x2="'+(W-R)+'" y2="'+gy+'" stroke="'+(g===100?COL.thr:COL.grid)+
       '" stroke-width="'+(g===100?1.4:.6)+'"'+(g===100?' stroke-dasharray="4 3"':'')+'/>';
    s+='<text x="'+(L-3)+'" y="'+(gy+3)+'" text-anchor="end" font-size="7.5" fill="'+(g===100?COL.thr:COL.text)+
       '" font-weight="'+(g===100?700:400)+'">'+g+'%</text>';
  });

  var ticks=tickDates(first, lastD, TICK_DAYS);
  s+='<line x1="'+L+'" y1="'+PLOT+'" x2="'+(W-R)+'" y2="'+PLOT+'" stroke="'+COL.axis+'"/>';
  var everyN=Math.max(1, Math.ceil(ticks.length/Math.max(1,Math.floor((W-L-R)/17))));
  ticks.forEach(function(d,i){
    var x=X(d), isLast=i===ticks.length-1;
    s+='<line x1="'+x+'" y1="'+(PLOT-2)+'" x2="'+x+'" y2="'+(PLOT+2.5)+'" stroke="'+COL.axis+'"/>';
    if(i%everyN!==0 && !isLast) return;
    s+='<text x="'+x+'" y="'+(PLOT+11)+'" text-anchor="'+(isLast?'end':i===0?'start':'middle')+
       '" font-size="8.5" fill="'+COL.text+'">'+esc(fmtNumeric(d))+'</text>';
  });

  /* machine PMs once; each parameter's own activities in its series colour */
  var seen={}, allResets=[];
  rows.forEach(function(a){ resetDatesOf(a.p).forEach(function(x){
    var k=x.kind+x.date+(x.kind==='act'?a.p.id:''); if(!seen[k]){ seen[k]=1; allResets.push(x); } }); });
  s+=resetMarkers(allResets, X, 0, PLOT, inRange);

  series.forEach(function(sr, i){
    var c=COL.series[i%COL.series.length], dash=SERIES_DASH[i%SERIES_DASH.length];
    var resets=resetDatesOf(sr.a.p).filter(function(x){ return inRange(x.date); });
    var proxy=sr.pts.map(function(q){ return {date:q.date, value:q.pct}; });
    var split=splitRuns(proxy, resets);
    split.joins.forEach(function(j){
      s+='<line x1="'+X(j[0].date)+'" y1="'+Y(j[0].value)+'" x2="'+X(j[1].date)+'" y2="'+Y(j[1].value)+
         '" stroke="'+c+'" stroke-width="1" stroke-dasharray="1.5 2.5" opacity=".5"/>';
    });
    split.runs.forEach(function(run){
      if(run.length<2) return;
      s+='<polyline fill="none" stroke="'+c+'" stroke-width="1.7" stroke-linejoin="round"'+
         (dash?' stroke-dasharray="'+dash+'"':'')+' points="'+
         run.map(function(r){ return X(r.date)+','+Y(r.value); }).join(' ')+'"/>';
    });
    if((SETTINGS.dotMode||'all')!=='none') sr.pts.forEach(function(q){
      var st=statusOf(sr.a.p,q.value);
      if(SETTINGS.dotMode==='alarm' && st==='ok') return;
      s+='<circle cx="'+X(q.date)+'" cy="'+Y(q.pct)+'" r="'+(st==='ok'?1.4:2.2)+'" fill="'+
         (st==='crit'?COL.thr:st==='warn'?COL.warn:c)+'"><title>'+
         esc(sr.a.p.name+' · '+fmtDate(q.date)+': '+num(q.value)+' '+(sr.a.p.unit||'')+' ('+num(q.pct,0)+'% of limit)')+
         '</title></circle>';
    });
    var L2=sr.pts[sr.pts.length-1];
    s+='<circle cx="'+X(L2.date)+'" cy="'+Y(L2.pct)+'" r="3" fill="'+c+'" stroke="'+COL.labelBg+'" stroke-width="1"/>';
  });
  return s+'</svg>';
}

/* legend under a combined chart: swatch, name, real value, % of limit, status */
function combinedLegend(rows){
  return '<div class="clegend">'+rows.map(function(a,i){
    var c=COL.series[i%COL.series.length], dash=SERIES_DASH[i%SERIES_DASH.length];
    return '<div class="cl '+a.status+'" title="'+esc(a.p.name+': '+num(a.value)+' '+(a.p.unit||'')+', '+STATUS_LABEL[a.status])+'">'+
      '<svg width="22" height="8" aria-hidden="true"><line x1="1" y1="4" x2="21" y2="4" stroke="'+c+
        '" stroke-width="2.4"'+(dash?' stroke-dasharray="'+dash+'"':'')+'/></svg>'+
      '<span class="cn" title="'+esc(a.p.name+(a.p.bound==='lower'?' (falls toward its limit)':''))+'">'+esc(a.p.name)+
        (a.p.bound==='lower'?' <em>↓</em>':'')+'</span>'+
      '<span class="cv">'+esc(num(a.value))+'<small>'+esc(a.p.unit||'')+'</small></span>'+
      '<span class="cp" title="'+STATUS_LABEL[a.status]+'">'+(a.approach!=null?esc(num(a.approach,0))+'%':'—')+'</span>'+
      '</div>';
  }).join('')+'</div>';
}

/* ---------- full-size trend chart with axes ---------- */
function trendChart(a, windowDays){
  var p=a.p, W=640, H=252, L=58, R=16, T=14, B=34;
  var pts=windowed(a.all, windowDays);
  if(!pts.length){
    return '<svg viewBox="0 0 '+W+' '+H+'"><text x="'+(W/2)+'" y="'+(H/2)+
      '" text-anchor="middle" fill="'+COL.text+'" font-size="14">No readings in this window</text></svg>';
  }
  var vals=pts.map(function(r){ return r.value; });
  var yr=yRange(p, vals, a.baseline), lo=yr.lo, hi=yr.hi;
  var d0=dayNum(pts[0].date), d1=dayNum(pts[pts.length-1].date), span=Math.max(1,d1-d0);
  function X(d){ return L + ((dayNum(d)-d0)/span)*(W-L-R); }
  function Y(v){ return T + (1-(v-lo)/(hi-lo))*(H-T-B); }
  function inRange(d){ return d>=pts[0].date && d<=pts[pts.length-1].date; }

  var s='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Trend for '+esc(p.name)+'">';
  s+='<rect x="'+L+'" y="'+T+'" width="'+(W-L-R)+'" height="'+(H-T-B)+'" fill="'+COL.bg+'"/>';
  if(SETTINGS.band){
    var bandTop = p.warn!=null?p.warn:p.threshold;
    s+='<rect x="'+L+'" y="'+Math.min(Y(a.baseline),Y(bandTop))+'" width="'+(W-L-R)+
       '" height="'+Math.abs(Y(bandTop)-Y(a.baseline))+'" fill="'+COL.band+'" opacity=".35"/>';
  }
  for(var i=0;i<=4;i++){
    var v=lo+(hi-lo)*i/4, y=Y(v);
    s+='<line x1="'+L+'" y1="'+y+'" x2="'+(W-R)+'" y2="'+y+'" stroke="'+COL.grid+'" stroke-width="1"/>';
    s+='<text x="'+(L-7)+'" y="'+(y+4)+'" text-anchor="end" font-size="11" fill="'+COL.text+'">'+esc(num(v))+'</text>';
  }
  if(SETTINGS.warnLine && p.warn!=null && !yr.clipped){
    var yw=Y(p.warn);
    s+='<line x1="'+L+'" y1="'+yw+'" x2="'+(W-R)+'" y2="'+yw+'" stroke="'+COL.warn+'" stroke-width="1.5" stroke-dasharray="7 4"/>';
    s+='<text x="'+(L+4)+'" y="'+(yw+(p.bound==='lower'?12:-4))+'" font-size="10.5" font-weight="600" fill="'+COL.warn+'">Warn '+esc(num(p.warn))+'</text>';
  }
  var yt=Y(p.threshold);
  if(SETTINGS.limitLine && !yr.clipped){
    s+='<line x1="'+L+'" y1="'+yt+'" x2="'+(W-R)+'" y2="'+yt+'" stroke="'+COL.thr+'" stroke-width="2" stroke-dasharray="3 3"/>';
    s+='<text x="'+(L+4)+'" y="'+(yt+(p.bound==='lower'?12:-4))+'" font-size="10.5" font-weight="700" fill="'+COL.thr+'">Limit '+esc(num(p.threshold))+'</text>';
  }
  if(yr.clipped){
    s+='<text x="'+(W-R-3)+'" y="'+(T+11)+'" text-anchor="end" font-size="10.5" font-weight="700" fill="'+COL.thr+
       '">Limit '+esc(num(p.threshold))+' is off this chart</text>';
  }

  /* reset markers, labelled at full size */
  var resets=resetDatesOf(p).filter(function(x){ return inRange(x.date); });
  if(SETTINGS.pmMarks) resets.forEach(function(x){
    var cx=X(x.date), c=x.kind==='act'?COL.act:COL.pm, lab=x.kind==='act'?'ACT':'PM', w=x.kind==='act'?24:18;
    s+='<line x1="'+cx+'" y1="'+T+'" x2="'+cx+'" y2="'+(H-B)+'" stroke="'+c+'" stroke-width="1.5" stroke-dasharray="2 3" opacity=".85"/>';
    s+='<rect x="'+(cx-w/2)+'" y="'+(T+2)+'" width="'+w+'" height="13" rx="2" fill="'+c+'"><title>'+
       esc((x.kind==='act'?(x.type||'Activity'):'PM')+' on '+fmtDate(x.date))+'</title></rect>';
    s+='<text x="'+cx+'" y="'+(T+12)+'" text-anchor="middle" font-size="9.5" font-weight="700" fill="#fff">'+lab+'</text>';
  });

  var traceCol = COL.pm;
  var split=splitRuns(pts, resets);
  split.joins.forEach(function(j){
    s+='<line x1="'+X(j[0].date)+'" y1="'+Y(j[0].value)+'" x2="'+X(j[1].date)+'" y2="'+Y(j[1].value)+
       '" stroke="'+traceCol+'" stroke-width="1.4" stroke-dasharray="2 3" opacity=".5"><title>Reset</title></line>';
  });
  split.runs.forEach(function(run){
    if(run.length<2) return;
    s+='<polyline fill="none" stroke="'+traceCol+'" stroke-width="2" stroke-linejoin="round" points="'+
       run.map(function(r){ return X(r.date)+','+Y(r.value); }).join(' ')+'"/>';
  });
  s+=dotsFor(pts, p, X, Y, traceCol, 2.6);

  var lastPt=pts[pts.length-1];
  if(SETTINGS.projection && !yr.clipped && a.dtt!=null && a.dtt>0 && a.dtt<span*1.6 && a.status!=='crit'){
    var px=X(addDays(lastPt.date, Math.round(a.dtt)));
    if(px<=W-R){
      s+='<line x1="'+X(lastPt.date)+'" y1="'+Y(lastPt.value)+'" x2="'+px+'" y2="'+yt+'" stroke="'+COL.thr+'" stroke-width="1.5" stroke-dasharray="4 4" opacity=".6"/>';
      s+='<circle cx="'+px+'" cy="'+yt+'" r="3.5" fill="none" stroke="'+COL.thr+'" stroke-width="1.5"/>';
    }
  }
  if(SETTINGS.label){
    var flx=X(lastPt.date), fly=Y(lastPt.value);
    var flText=num(lastPt.value)+(p.unit?' '+p.unit:''), flW=flText.length*6.1+10;
    var flX = flx+6+flW <= W-R ? flx+6 : flx-6-flW;
    var flY = Math.max(T+11, Math.min(H-B-4, fly+4));
    var flCol = a.status==='crit'?COL.thr : a.status==='warn'?COL.warn : COL.pm;
    s+='<rect x="'+flX+'" y="'+(flY-11)+'" width="'+flW+'" height="15.5" rx="3" fill="'+COL.labelBg+'" stroke="'+flCol+'" stroke-width="1"/>';
    s+='<text x="'+(flX+flW/2)+'" y="'+(flY+.5)+'" text-anchor="middle" font-size="11" font-weight="700" fill="'+flCol+'">'+esc(flText)+'</text>';
  }
  s+='<line x1="'+L+'" y1="'+(H-B)+'" x2="'+(W-R)+'" y2="'+(H-B)+'" stroke="'+COL.axis+'"/>';
  var ticks=tickDates(pts[0].date, pts[pts.length-1].date, TICK_DAYS);
  ticks.forEach(function(d,i){
    var x=X(d); if(x<L-1 || x>W-R+1) return;
    s+='<line x1="'+x+'" y1="'+(H-B)+'" x2="'+x+'" y2="'+(H-B+4)+'" stroke="'+COL.axis+'"/>';
    s+='<text x="'+x+'" y="'+(H-B+16)+'" text-anchor="'+(i===0?'start':(i===ticks.length-1?'end':'middle'))+
       '" font-size="11" fill="'+COL.text+'">'+esc(fmtShort(d))+'</text>';
  });
  s+='<text x="'+(L-7)+'" y="'+(H-B+16)+'" text-anchor="end" font-size="10.5" fill="'+COL.text+'">'+esc(p.unit||'')+'</text>';
  return s+'</svg>';
}

/* ---------- small widgets ---------- */
function sparkline(a,w,h){
  w=w||110; h=h||24;
  var pts=a.seg.length>=2?a.seg:a.all;
  if(pts.length<2) return '<svg width="'+w+'" height="'+h+'"></svg>';
  var v=pts.map(function(r){ return r.value; });
  var lo=Math.min.apply(null,v), hi=Math.max.apply(null,v), rng=(hi-lo)||1;
  function X(i){ return (i/(pts.length-1))*(w-2)+1; }
  function Y(x){ return h-2-((x-lo)/rng)*(h-5); }
  var col = a.toward!=null&&a.toward>0 ? COL.thr : (a.toward!=null&&a.toward<0 ? 'var(--ok)' : COL.text);
  return '<svg width="'+w+'" height="'+h+'" aria-hidden="true">'+
    '<polyline fill="none" stroke="'+col+'" stroke-width="1.6" points="'+
      v.map(function(x,i){ return X(i)+','+Y(x); }).join(' ')+'"/>'+
    '<circle cx="'+X(v.length-1)+'" cy="'+Y(v[v.length-1])+'" r="2.2" fill="'+col+'"/></svg>';
}
function statusHTML(st){ return '<span class="st '+st+'"><i class="gl"></i>'+STATUS_LABEL[st]+'</span>'; }
function travelBar(a){
  if(a.approach==null) return '';
  var pct=Math.max(0,Math.min(100,a.approach));
  var cls=a.status==='crit'?'crit':a.status==='warn'?'warn':'ok';
  var warnPos = a.p.warn!=null ? Math.max(0,Math.min(100, approach(a.p,a.p.warn)||0)) : null;
  return '<div class="travel" title="'+esc(num(a.approach,0)+'% of the way from baseline to limit')+'">'+
    '<i class="'+cls+'" style="width:'+pct+'%"></i>'+
    (warnPos!=null&&warnPos>3&&warnPos<98?'<u style="left:'+warnPos+'%"></u>':'')+'</div>';
}
function trendHTML(a){
  if(a.thinSincePM) return '<span class="trend flat" title="The trend restarts after a reset and needs about three readings">'+
    (a.resetKind==='act'?'Rebuilding after activity':'Rebuilding after PM')+'</span>';
  if(a.slope==null) return '<span class="trend flat">Not enough data</span>';
  var mag=Math.abs(a.slope);
  if(mag<1e-9 || (a.p.threshold && mag/Math.abs(a.p.threshold)<0.0006))
    return '<span class="trend flat"><span class="ar">&rarr;</span>Steady</span>';
  var cls=a.toward>0?'rising':'falling';
  var arrow=a.slope>0?'\u2197':'\u2198';
  return '<span class="trend '+cls+'" title="'+esc(num(a.slope,4)+' '+(a.p.unit||'')+' per day')+'">'+
    '<span class="ar">'+arrow+'</span>'+esc((a.slope>0?'+':'')+num(a.slope*7)+'/wk')+'</span>';
}
function dttHTML(a){
  if(a.status==='crit') return '<b style="color:var(--crit)">Reached</b>';
  if(a.thinSincePM) return '<span style="color:var(--ink-3)">'+(a.resetKind==='act'?'after activity':'after PM')+', too soon to say</span>';
  if(a.dtt==null) return '<span style="color:var(--ink-3)">Not trending there</span>';
  var d=Math.round(a.dtt);
  var col = d<=7?'var(--crit)':d<=21?'var(--warn)':'var(--ink-2)';
  return '<span style="color:'+col+';font-weight:'+(d<=7?'700':'600')+'">'+d+' day'+(d===1?'':'s')+'</span>';
}
function anomHTML(a){
  if(a.anom==null) return '<span style="color:var(--ink-3)">—</span>';
  var v=a.anom;
  if(v>2.5) return '<b style="color:var(--crit)">'+num(v,1)+'&times; faster</b>';
  if(v>1.4) return '<span style="color:var(--warn);font-weight:600">'+num(v,1)+'&times; faster</span>';
  if(v<-1.4) return '<span style="color:var(--ok)">recovering</span>';
  return '<span style="color:var(--ink-3)">normal</span>';
}
