/* ==========================================================================
   10-boot.js — startup. Loaded last.

   Where the data comes from, in order:
     1. the connected data folder — its newest pm-data-*.json
     2. data/latest.js, if it sits beside index.html
     3. the demo, so there is something to explore
   After 1 or 2, any unsaved work newer than that file is offered back.
   ========================================================================== */

function wireControls(){
  $('#nav').onclick=function(e){
    var b=e.target.closest('button[data-screen]');
    if(b) show(b.dataset.screen);
  };
  $('#entrySave').onclick=saveEntry;
  var eu=$('#entryUndo'); if(eu) eu.onclick=undoLastBatch;
  $('#entryClear').onclick=function(){
    entryDraft={}; saveDraft(); renderEntry();
    toast('Form cleared. Nothing already saved was removed.');
  };
  $('#quickSave').onclick=smartSave;

  var tb=$('#themeBtn'); if(tb) tb.onclick=themeGallery;
  var bw=$('#boardWindow');
  if(bw){ bw.value=String(SETTINGS.window); bw.onchange=function(){ setSetting('window',+bw.value); }; }
  var db=$('#displayBtn'); if(db) db.onclick=displayMenu;
  var bb=$('#bellBtn'); if(bb) bb.onclick=function(e){ e.stopPropagation(); toggleBell(); };

  var rt=$('#railToggle');
  if(rt) rt.onclick=function(){
    SETTINGS.railCollapsed=!SETTINGS.railCollapsed; saveSettings(); applyTheme();
    rt.setAttribute('aria-expanded', String(!SETTINGS.railCollapsed));
    setTimeout(function(){ if(screen==='board') layoutMasonry(); },220);
  };
  if(rt) rt.setAttribute('aria-expanded', String(!SETTINGS.railCollapsed));

  /* ctrl/cmd+S saves, as anyone would expect */
  document.addEventListener('keydown', function(e){
    if((e.ctrlKey||e.metaKey) && (e.key==='s'||e.key==='S')){ e.preventDefault(); smartSave(); }
  });
}

function loadAutoloadScript(){
  if(!(window.PM_AUTOLOAD && typeof window.PM_AUTOLOAD==='object')) return false;
  try{
    DB=migrate(window.PM_AUTOLOAD);
    window.PM_AUTOLOAD_USED=true;
    markClean();
    return { name:'data/latest.js', issues:integrity(DB) };
  }catch(e){
    setTimeout(function(){ toast('data/latest.js could not be read: '+e.message,true); },600);
    return false;
  }
}

function announceLoad(r){
  var iss=(r.issues||[]).slice();
  if(DB._newerSchema) iss.unshift('saved by a newer version of PM Tracker (format '+
    DB._newerSchema+', this app understands '+SCHEMA+') — update the app');
  setTimeout(function(){
    toast(iss.length
      ? 'Loaded '+r.name+' with '+iss.length+' issue'+(iss.length===1?'':'s')+': '+iss.join('; ')
      : 'Loaded '+DB.readings.length.toLocaleString()+' readings from '+r.name+'.', iss.length>0);
  },600);
}

async function boot(){
  storageOK=testStorage();
  loadSettings();
  wireControls();
  DB=blankDB();

  /* 1. connected folder */
  var r=null;
  try{ r=await restoreFolder(); }catch(e){ r=null; }
  if(r && r.loaded){
    show('board'); announceLoad(r); offerDraftIfNewer();
    return;
  }

  /* 2. data/latest.js */
  r=loadAutoloadScript();
  if(r){
    show('board'); announceLoad(r); offerDraftIfNewer();
    if(FOLDER.state==='needs-permission') setTimeout(function(){
      toast('Showing data/latest.js. Click "Reconnect" at the top to save straight into your data folder again.');
    },2600);
    return;
  }

  /* 3. a draft with no file to compare against */
  var d=readDraft();
  if(d && d.db && (d.db.readings||[]).length){
    var when=new Date(d.at).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
    DB=demoDB(); DB.meta.isDemo=true; show('board');
    setTimeout(function(){
      modal('Unsaved work found',
        '<p style="margin-bottom:12px">Work from <b>'+esc(when)+'</b> was never saved. It holds '+
        d.db.readings.length.toLocaleString()+' readings across '+(d.db.machines||[]).length+' machines.</p>'+
        '<p>Restore it, or discard it and start from the demo.</p>',
        function(){ DB=migrate(d.db); dirty=true; unsavedOps=1; render();
          toast('Draft restored. Save now so it is not lost again.'); },
        'Restore this draft');
      var c=$('#mCancel'); if(c){ c.textContent='Discard draft';
        c.onclick=function(){ clearDraft(); $('#modalHost').innerHTML=''; }; }
    },300);
    return;
  }

  /* 4. demo */
  DB=demoDB(); DB.meta.isDemo=true;
  show('board');
  setTimeout(function(){
    toast(folderSupported()
      ? 'Showing demo data. Click "Connect data folder" at the top to work from your own files.'
      : 'Showing demo data. Load your own file, or paste your Excel grid, from Save, load & import.');
  },800);
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
