/* ==========================================================================
   13-activity.js — activities on a single parameter

   Some work changes how one parameter behaves without being a machine PM: a
   filament change on a CD-SEM resets beam current, a lamp swap resets
   intensity, a recalibration shifts a baseline. Logging one restarts the trend
   and the healthy baseline for that parameter only. The machine's PM countdown
   and its other parameters are left exactly as they were.
   ========================================================================== */

var ACTIVITY_TYPES = ['Filament change','Lamp replacement','Source change','Recalibration',
                      'Sensor replacement','Part replacement','Software update','Other'];

function activityDialog(pid, presetDate){
  var p=DB.parameters.filter(function(x){ return x.id===pid; })[0];
  if(!p) return;
  var m=machineById(p.machineId);
  var past=paramEventsOf(pid);
  var b='<div class="note" style="margin-bottom:14px">This restarts the trend for <b>'+esc(p.name)+'</b> only. '+
    esc(m?m.name:'The machine')+'\u2019s PM countdown and its other parameters are not affected.</div>'+
    '<div class="row">'+
    fld('Date','<input type="date" id="aDate" value="'+esc(presetDate||todayISO())+'">','Backdating is fine.')+
    fld('What was done','<select id="aType">'+ACTIVITY_TYPES.map(function(t){
      return '<option>'+esc(t)+'</option>'; }).join('')+'</select>')+
    '</div>'+
    '<div class="row" id="aOtherRow" style="display:none">'+
    fld('Describe it','<input id="aOther" placeholder="e.g. Gun alignment">')+'</div>'+
    '<div class="row">'+fld('Technician','<input id="aTech" value="'+esc(DB.meta.lastBy||'')+'">')+'</div>'+
    fld('Notes','<textarea id="aNotes" rows="2" placeholder="Part numbers, anything unusual"></textarea>');
  if(past.length){
    b+='<h4 style="font-size:13.5px;font-weight:600;margin:16px 0 8px">Earlier activities on this parameter</h4>'+
       '<div class="actlist">'+past.slice().reverse().map(function(e){
         return '<div><b>'+esc(fmtDate(e.date))+'</b> '+esc(e.type)+(e.notes?' — '+esc(e.notes):'')+'</div>';
       }).join('')+'</div>';
  }
  modal('Log activity — '+(m?m.name+' · ':'')+p.name, b, function(){
    var d=$('#aDate').value;
    if(!d){ toast('Pick a date.',true); return false; }
    var t=$('#aType').value;
    if(t==='Other'){ t=$('#aOther').value.trim(); if(!t){ toast('Describe what was done.',true); return false; } }
    if(DB.paramEvents.some(function(e){ return e.paramId===pid && e.date===d && e.type===t; })){
      toast('That activity is already logged for this date.',true); return false;
    }
    DB.paramEvents.push({ id:uid(), date:d, paramId:pid, type:t,
      tech:$('#aTech').value.trim(), notes:$('#aNotes').value.trim() });
    delete p._base;
    unsavedOps++; markDirty(); render();
    toast(t+' logged on '+fmtDate(d)+'. The trend for '+p.name+' restarts from that date.');
  },'Log activity');
  var sel=$('#aType');
  sel.onchange=function(){ $('#aOtherRow').style.display = sel.value==='Other' ? '' : 'none'; };
}

function removeActivity(id){
  var e=DB.paramEvents.filter(function(x){ return x.id===id; })[0];
  if(!e) return;
  var p=DB.parameters.filter(function(x){ return x.id===e.paramId; })[0];
  if(!confirm('Remove "'+e.type+'" on '+fmtDate(e.date)+(p?' from '+p.name:'')+'?\n\n'+
    'The trend will fall back to the previous reset.')) return;
  DB.paramEvents=DB.paramEvents.filter(function(x){ return x.id!==id; });
  if(p) delete p._base;
  unsavedOps++; markDirty(); render();
  toast('Activity removed.');
}

/* table of activities for one machine, used on the machine detail screen */
function activityTable(mid){
  var ps=paramsOf(mid);
  var rows=[];
  ps.forEach(function(p){ paramEventsOf(p.id).forEach(function(e){ rows.push({e:e,p:p}); }); });
  rows.sort(function(a,b){ return a.e.date<b.e.date?1:-1; });
  var h='<div class="panel"><header><h3>Parameter activities</h3>'+
    '<span class="sub">work that reset a single parameter\u2019s trend without a machine PM</span>'+
    '<span class="spacer"></span>'+
    '<select id="actParamPick" style="width:auto;padding:4px 8px">'+ps.map(function(p){
      return '<option value="'+esc(p.id)+'">'+esc(p.name)+'</option>'; }).join('')+'</select>'+
    '<button class="btn sm primary" id="actAddBtn">Log activity</button></header>';
  if(!rows.length){
    h+='<div class="body"><div class="note">None logged. Use this for things like a filament change, '+
       'a lamp swap or a recalibration — anything that resets one reading but is not a full PM.</div></div></div>';
    return h;
  }
  h+='<div class="body flush"><div class="tblwrap"><table class="tbl"><thead><tr>'+
    '<th class="num">Date</th><th>Parameter</th><th>Activity</th><th>Technician</th><th>Notes</th><th></th>'+
    '</tr></thead><tbody>'+rows.map(function(r){
      return '<tr><td class="num">'+esc(fmtDate(r.e.date))+'</td><td><b>'+esc(r.p.name)+'</b></td>'+
        '<td><span class="acttag">'+esc(r.e.type)+'</span></td><td>'+esc(r.e.tech||'—')+'</td>'+
        '<td style="font-size:13px;color:var(--ink-2)">'+esc(r.e.notes||'')+'</td>'+
        '<td class="num"><button class="btn sm danger" data-delact="'+esc(r.e.id)+'">Remove</button></td></tr>';
    }).join('')+'</tbody></table></div></div></div>';
  return h;
}
function wireActivityTable(){
  var add=$('#actAddBtn');
  if(add) add.onclick=function(){ activityDialog($('#actParamPick').value); };
  $$('[data-delact]').forEach(function(b){ b.onclick=function(){ removeActivity(b.dataset.delact); }; });
}
