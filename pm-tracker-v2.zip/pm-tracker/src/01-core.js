/* ==========================================================================
   01-core.js — application state, storage layer, shared helpers
   Loaded first. Everything else assumes DB exists.
   ========================================================================== */

var SCHEMA = 1;
var DRAFT_KEY = 'pmtracker.draft.v1';

var DB = null;
var dirty = false;
var unsavedOps = 0;
var screen = 'board';
var storageOK = true;
var memDraft = null;

var filterGroup = { board:'All', charts:'All', analysis:'All', entry:'All', pm:'All' };

/* ---------- user settings, remembered per PC ---------- */
var SETTINGS_KEY = 'pmtracker.settings.v1';
var SETTINGS = {
  theme:'graphite',     /* see THEMES below                            */
  cols:'auto',          /* auto | 2 | 3 | 4 | 5 | 6                    */
  chartH:'m',           /* s | m | l | xl  — trend chart height        */
  showTravel:true,      /* progress bar on each tile                   */
  showPM:true,          /* PM footer strip on each tile                */
  showSummary:true,     /* the six-figure bar above the board          */
  window:45,            /* days of history drawn on each tile          */

  /* what is drawn inside each chart */
  band:true,            /* grey normal-range band                      */
  limitLine:true,       /* red dashed limit                            */
  warnLine:true,        /* amber dashed warn level                     */
  label:true,           /* boxed value on the most recent reading      */
  pmMarks:true,         /* blue PM flags and the break in the line     */
  dots:true,            /* a dot on every out-of-range reading         */
  projection:true,      /* dashed run-out to where it meets the limit  */
  yMode:'auto',         /* auto | data | zero                          */
  dotMode:'all',        /* all | alarm | none — dot-line by default    */
  chartMode:'combined', /* combined | separate — params per machine    */
  railCollapsed:false,  /* left panel collapsed to icons               */
  acks:{}               /* acknowledged notifications, key -> date     */
};
/* themes were renamed when they gained character; map the old ids */
var THEME_ALIASES = { light:'graphite', slate:'graphite', warm:'pad', dark:'control', logbook:'pad', carbon:'control' };
var THEMES = ['graphite','isa','control','yellow','blueprint','pad','contrast'];
var THEME_INFO = {
  graphite: { name:'Graphite',        note:'Clean, crisp default. Best for screenshots pasted into email or chat.' },
  isa:      { name:'ISA-101',         note:'The high-performance HMI standard. All grey, so an alarm is the only colour on screen.' },
  control:  { name:'Control Room',    note:'SCADA console at night. Dark, low glare, cyan instrument edges.' },
  yellow:   { name:'Yellow Room',     note:'The lithography bay, lit amber so photoresist is not exposed.' },
  blueprint:{ name:'Blueprint',       note:'An engineering drawing: Prussian blue with a drafting grid.' },
  pad:      { name:'Engineering Pad', note:'Green gridded computation paper, with pencil-red alarms.' },
  contrast: { name:'High Contrast',   note:'Black on white, heavy strokes, no shading. For projectors and tired eyes.' }
};
var APP_VERSION = '2.0';
function loadSettings(){
  try{
    var raw=localStorage.getItem(SETTINGS_KEY);
    if(raw){ var o=JSON.parse(raw); for(var k in o) if(k in SETTINGS) SETTINGS[k]=o[k]; }
  }catch(e){}
  applyTheme();
}
function saveSettings(){
  try{ localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); }catch(e){}
}
function applyTheme(){
  if(THEME_ALIASES[SETTINGS.theme]) SETTINGS.theme = THEME_ALIASES[SETTINGS.theme];
  if(THEMES.indexOf(SETTINGS.theme)<0) SETTINGS.theme='graphite';
  document.documentElement.setAttribute('data-theme', SETTINGS.theme);
  document.body && document.body.classList.toggle('railmin', !!SETTINGS.railCollapsed);
}
function setSetting(k,v){ SETTINGS[k]=v; saveSettings(); if(k==='theme') applyTheme(); render(); }
var boardSort = 'risk';
var boardDensity = 'normal';
var dashSort = { key:'risk', dir:-1 };
var configTab = 'params';
var selectedMachine = null;
function openMachine(mid){ selectedMachine = mid; show('machine'); }

/* ---------- tiny helpers ---------- */
function $(s){ return document.querySelector(s); }
function $$(s){ return Array.prototype.slice.call(document.querySelectorAll(s)); }
function esc(s){
  return String(s==null?'':s).replace(/[&<>"']/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
  });
}
function uid(){ return Math.random().toString(36).slice(2,9); }
function todayISO(){
  var d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function dayNum(d){ return Math.floor(new Date(d+'T00:00:00').getTime()/864e5); }
function addDays(d,n){
  var t = new Date(d+'T00:00:00'); t.setDate(t.getDate()+n);
  return t.getFullYear()+'-'+String(t.getMonth()+1).padStart(2,'0')+'-'+String(t.getDate()).padStart(2,'0');
}
function diffDays(a,b){ return dayNum(a)-dayNum(b); }
var MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var MONTH_FULL = ['January','February','March','April','May','June','July','August','September','October','November','December'];
function fmtDate(d){ if(!d) return '—'; var p=d.split('-'); return p[2]+' '+MON[+p[1]-1]+' '+p[0]; }
function fmtShort(d){ if(!d) return '—'; var p=d.split('-'); return p[2]+' '+MON[+p[1]-1]; }
/* compact d/m for tight tile axes, e.g. 3/9 */
function fmtNumeric(d){ if(!d) return ''; var p=d.split('-'); return (+p[2])+'/'+(+p[1]); }
function num(v,dp){
  if(v==null||!isFinite(v)) return '—';
  var a=Math.abs(v);
  if(dp!=null) return v.toFixed(dp);
  if(a>=1000) return v.toFixed(0);
  if(a>=100) return v.toFixed(1);
  if(a>=1) return v.toFixed(2);
  if(a>=0.01) return v.toFixed(3);
  return v.toPrecision(2);
}
function median(a){
  if(!a.length) return 0;
  var s=a.slice().sort(function(x,y){return x-y;}), m=s.length>>1;
  return s.length%2 ? s[m] : (s[m-1]+s[m])/2;
}
function toast(msg, isErr){
  var h=$('#toastHost'); h.innerHTML='';
  var d=document.createElement('div');
  d.className='toast'+(isErr?' err':''); d.textContent=msg;
  d.setAttribute('role', isErr?'alert':'status');
  h.appendChild(d);
  setTimeout(function(){ if(d.parentNode) d.remove(); }, isErr?7000:3600);
}

/* ---------- draft safety net ----------
   Browsers opened from file:// cannot write to disk, so the durable copy is
   always a JSON file the user saves. This draft only protects against the tab
   closing before that happens.                                               */
function testStorage(){
  try{ localStorage.setItem('pmtracker.test','1'); localStorage.removeItem('pmtracker.test'); return true; }
  catch(e){ return false; }
}
var quotaWarned = false;
function saveDraft(){
  var payload;
  try{ payload = JSON.stringify({ at:new Date().toISOString(), db:DB }); }
  catch(e){ return; }
  if(storageOK){
    try{ localStorage.setItem(DRAFT_KEY, payload); return; }
    catch(e){
      storageOK=false;
      if(!quotaWarned){
        quotaWarned=true;
        setTimeout(function(){
          toast('Your history is now too large for this browser to hold a recovery draft. '+
                'The app still works, but save the data file more often — unsaved work is no longer '+
                'protected if the tab closes. Archiving older years fixes this.', true);
        },400);
      }
    }
  }
  memDraft = payload;
}
function readDraft(){
  if(storageOK){
    try{ var r=localStorage.getItem(DRAFT_KEY); return r?JSON.parse(r):null; }catch(e){}
  }
  return memDraft?JSON.parse(memDraft):null;
}
function clearDraft(){
  try{ localStorage.removeItem(DRAFT_KEY); }catch(e){}
  memDraft=null;
}
function markDirty(){ dirty=true; saveDraft(); paintSaveState(); }
function markClean(){ dirty=false; unsavedOps=0; paintSaveState(); }
function paintSaveState(){
  var el=$('#savePill'); if(!el) return;
  if(dirty){
    el.className='savepill dirty';
    el.textContent = unsavedOps+' unsaved change'+(unsavedOps===1?'':'s');
  } else {
    el.className='savepill clean';
    el.textContent='All changes saved';
  }
}
window.addEventListener('beforeunload', function(e){
  if(dirty){ e.preventDefault(); e.returnValue=''; }
});

/* ---------- data model ---------- */
function blankDB(){
  return {
    schemaVersion:SCHEMA,
    meta:{ site:'', savedAt:null, lastBy:'' },
    groups:['Photo','Vacuum','Metrology'],
    machines:[], parameters:[], readings:[], pmEvents:[], paramEvents:[]
  };
}
function machineById(id){
  for(var i=0;i<DB.machines.length;i++) if(DB.machines[i].id===id) return DB.machines[i];
  return null;
}
function paramsOf(mid){ return DB.parameters.filter(function(p){ return p.machineId===mid; }); }
function activeMachines(){ return DB.machines.filter(function(m){ return m.active!==false; }); }
function activeParams(){
  var live={}; activeMachines().forEach(function(m){ live[m.id]=1; });
  return DB.parameters.filter(function(p){ return live[p.machineId]; });
}
function groupOf(p){ var m=machineById(p.machineId); return m?m.group:'Ungrouped'; }
function seriesOf(pid){
  return DB.readings
    .filter(function(r){ return r.paramId===pid && r.value!=null; })
    .sort(function(a,b){ return a.date<b.date?-1:1; });
}
function pmDatesOf(mid){
  return DB.pmEvents.filter(function(e){ return e.machineId===mid; })
    .map(function(e){ return e.date; }).sort();
}
/* Activities that affect ONE parameter only — a filament change, a lamp swap,
   a recalibration. They restart that parameter's trend; the machine's PM
   countdown and its other parameters are untouched. */
function paramEventsOf(pid){
  return DB.paramEvents.filter(function(e){ return e.paramId===pid; })
    .sort(function(a,b){ return a.date<b.date?-1:1; });
}
function lastParamEventOf(pid, before){
  var d = paramEventsOf(pid).map(function(e){ return e.date; })
    .filter(function(x){ return !before || x<=before; });
  return d.length?d[d.length-1]:null;
}
/* Where this parameter's current trend begins: whichever came later, the
   machine's last PM or this parameter's last activity. */
function segmentStartOf(p, before){
  var a = lastPMOf(p.machineId, before), b = lastParamEventOf(p.id, before);
  if(!a) return b; if(!b) return a;
  return a>b ? a : b;
}
/* every date the trend line should break at, for this parameter */
function resetDatesOf(p){
  var d = pmDatesOf(p.machineId).map(function(x){ return {date:x, kind:'pm'}; })
    .concat(paramEventsOf(p.id).map(function(e){ return {date:e.date, kind:'act', type:e.type}; }));
  return d.sort(function(a,b){ return a.date<b.date?-1:1; });
}
function lastPMOf(mid, before){
  var d = pmDatesOf(mid).filter(function(x){ return !before||x<=before; });
  return d.length?d[d.length-1]:null;
}
function latestDate(){
  return DB.readings.reduce(function(a,r){ return r.date>a?r.date:a; },'0000-00-00');
}

/* ---------- migration ----------
   One block per schema version. Keep them; never rewrite history in place.  */
function migrate(db){
  if(!db || typeof db!=='object') throw new Error('File does not contain PM Tracker data.');
  db.schemaVersion = db.schemaVersion||1;
  db.groups     = db.groups     || ['Photo','Vacuum','Metrology'];
  db.machines   = db.machines   || [];
  db.parameters = db.parameters || [];
  db.readings   = db.readings   || [];
  db.pmEvents   = db.pmEvents   || [];
  db.paramEvents= db.paramEvents|| [];
  db.meta       = db.meta       || {};
  db.machines.forEach(function(m){ if(m.active===undefined) m.active=true; });
  /* if (db.schemaVersion < 2) { ...upgrade steps...; db.schemaVersion = 2; } */
  if(db.schemaVersion > SCHEMA){
    /* Written by a newer version of the app. Load it, but keep its version
       number so saving does not quietly downgrade the file, and flag it. */
    db._newerSchema = db.schemaVersion;
    return db;
  }
  db.schemaVersion = SCHEMA;
  return db;
}

/* ---------- integrity check on load ---------- */
function integrity(db){
  var issues=[], pids={}, mids={}, seen={}, dupes=0, orphans=0, bad=0;
  db.parameters.forEach(function(p){ pids[p.id]=1; });
  db.machines.forEach(function(m){ mids[m.id]=1; });
  db.readings.forEach(function(r){
    var k=r.date+'|'+r.paramId;
    if(seen[k]) dupes++; seen[k]=1;
    if(!pids[r.paramId]) orphans++;
    if(r.value!=null && !isFinite(r.value)) bad++;
  });
  var pmOrph = db.pmEvents.filter(function(e){ return !mids[e.machineId]; }).length;
  var actOrph = (db.paramEvents||[]).filter(function(e){ return !pids[e.paramId]; }).length;
  if(actOrph) issues.push(actOrph+' activit'+(actOrph===1?'y':'ies')+' for a parameter that no longer exists');
  if(dupes)   issues.push(dupes+' duplicate reading'+(dupes===1?'':'s')+' for the same date and parameter');
  if(orphans) issues.push(orphans+' reading'+(orphans===1?'':'s')+' pointing at a parameter that no longer exists');
  if(bad)     issues.push(bad+' reading'+(bad===1?'':'s')+' with an unreadable value');
  if(pmOrph)  issues.push(pmOrph+' PM event'+(pmOrph===1?'':'s')+' for an unknown machine');
  db.parameters.forEach(function(p){
    if(!mids[p.machineId]) issues.push('Parameter "'+p.name+'" has no matching machine');
  });
  return issues;
}

/* ---------- group chip bars ---------- */
function groupChips(sel, key){
  var host=$(sel); if(!host) return;
  var gs=['All'].concat(DB.groups);
  host.innerHTML = gs.map(function(g){
    return '<button class="chip" data-g="'+esc(g)+'" aria-pressed="'+(filterGroup[key]===g)+'">'+esc(g)+'</button>';
  }).join('');
  host.onclick = function(e){
    var b=e.target.closest('.chip'); if(!b) return;
    filterGroup[key]=b.dataset.g; render();
  };
}
function byGroup(rows,key){
  return filterGroup[key]==='All' ? rows : rows.filter(function(r){ return groupOf(r.p)===filterGroup[key]; });
}
