/* ==========================================================================
   12-notify.js — notification centre

   Alerts used to stack above the board and push the tiles off the screen.
   They now live behind a bell in the top bar. The badge counts what still
   needs attention; the panel lists each alert on its own line so it can be
   opened or acknowledged individually.

   Acknowledging follows the alarm-management convention: it silences the
   badge for that alert, not the condition. An acknowledgement is tied to the
   alert's severity, so if a parameter moves from warning to at-limit it comes
   back as a new alert. Acknowledgements for conditions that have cleared are
   pruned automatically.
   ========================================================================== */

var bellOpen = false;
var showAcked = false;

function computeAlerts(){
  var rows=assessVisible(), out=[];
  function add(key, sev, title, detail, mid, who){
    out.push({ key:key, sev:sev, title:title, detail:detail, mid:mid, who:who||'',
               acked: !!(SETTINGS.acks && SETTINGS.acks[key]) });
  }
  rows.forEach(function(a){
    var who=a.m.name, pn=a.p.name, unit=a.p.unit?' '+a.p.unit:'';
    if(a.status==='crit'){
      add('crit|'+a.p.id, 'crit', pn+' is at its limit',
        num(a.value)+unit+' against a limit of '+num(a.p.threshold)+unit, a.p.machineId, who);
    } else if(a.dtt!=null && a.dtt<=14){
      var d=Math.round(a.dtt);
      add('soon'+(d<=7?'7':'14')+'|'+a.p.id, d<=7?'crit':'warn', pn+' reaches its limit in '+d+' day'+(d===1?'':'s'),
        'Now '+num(a.value)+unit+', projected from the trend since the last reset.', a.p.machineId, who);
    } else if(a.status==='warn'){
      add('warn|'+a.p.id, 'warn', pn+' is past its warn level',
        num(a.value)+unit+', warn level '+num(a.p.warn)+unit, a.p.machineId, who);
    }
    if(a.anom!=null && a.anom>2 && a.status!=='crit'){
      add('fast|'+a.p.id, 'info', pn+' is moving unusually fast',
        num(a.anom,1)+'× its normal rate, though still in range', a.p.machineId, who);
    }
    if(a.asOf && diffDays(todayISO(), a.asOf)>3){
      add('stale|'+a.p.id+'|'+a.asOf, 'info', pn+' has not been read for '+diffDays(todayISO(),a.asOf)+' days',
        'Its projection is based on old data.', a.p.machineId, who);
    }
  });
  activeMachines().forEach(function(m){
    var s=pmSchedule(m); if(!s) return;
    if(s.overdue) add('pmover|'+m.id+'|'+s.next, 'crit', 'PM overdue by '+Math.abs(s.inDays)+' days',
      'It was due on '+fmtDate(s.next)+'.', m.id, m.name);
    else if(s.due) add('pmdue|'+m.id+'|'+s.next, 'warn', 'PM due in '+s.inDays+' days',
      'Scheduled for '+fmtDate(s.next)+'.', m.id, m.name);
  });
  var rank={crit:0, warn:1, info:2};
  out.sort(function(a,b){ return rank[a.sev]-rank[b.sev]; });

  /* drop acknowledgements whose condition has cleared */
  if(SETTINGS.acks){
    var live={}; out.forEach(function(x){ live[x.key]=1; });
    var changed=false;
    Object.keys(SETTINGS.acks).forEach(function(k){ if(!live[k]){ delete SETTINGS.acks[k]; changed=true; } });
    if(changed) saveSettings();
  }
  return out;
}

function renderBell(){
  var btn=$('#bellBtn'); if(!btn) return;
  var all=computeAlerts();
  var open=all.filter(function(x){ return !x.acked && x.sev!=='info'; });
  var hasCrit=open.some(function(x){ return x.sev==='crit'; });
  var badge=$('#bellCount');
  if(open.length){
    badge.hidden=false; badge.textContent=open.length>99?'99+':open.length;
    badge.className='bellcount'+(hasCrit?'':' amber');
  } else badge.hidden=true;
  btn.classList.toggle('alarm', hasCrit);
  btn.setAttribute('aria-label', open.length
    ? open.length+' notification'+(open.length===1?'':'s')+' need attention' : 'No notifications');
  if(bellOpen) drawBellPanel(all);
}

function drawBellPanel(all){
  var panel=$('#bellPanel'); if(!panel) return;
  all = all || computeAlerts();
  var visible = all.filter(function(x){ return showAcked || !x.acked; });
  var nAcked = all.filter(function(x){ return x.acked; }).length;
  var icon = { crit:'&#9650;', warn:'&#9670;', info:'&#9679;' };
  var h='<header><b>Notifications</b><span class="sp"></span>'+
    (all.some(function(x){ return !x.acked; })?'<button class="btn sm" id="ackAll">Acknowledge all</button>':'')+
    '</header>';
  if(!visible.length){
    h+='<div class="bellempty">'+(all.length
      ? 'Everything here has been acknowledged.'
      : 'Nothing needs attention. No parameter is near its limit and no PM is due.')+'</div>';
  } else {
    var groups={crit:'Act now', warn:'Plan work', info:'Worth a look'};
    ['crit','warn','info'].forEach(function(sev){
      var g=visible.filter(function(x){ return x.sev===sev; });
      if(!g.length) return;
      h+='<div class="bellgrp">'+groups[sev]+' <span>'+g.length+'</span></div>';
      g.forEach(function(x){
        h+='<div class="bellitem '+x.sev+(x.acked?' acked':'')+'" data-mid="'+esc(x.mid)+'" tabindex="0">'+
          '<span class="bi">'+icon[x.sev]+'</span>'+
          '<div class="bt"><small>'+esc(x.who)+'</small><b>'+esc(x.title)+'</b><span>'+esc(x.detail)+'</span></div>'+
          (x.acked?'<span class="backed">acknowledged</span>'
            :'<button class="btn sm" data-ack="'+esc(x.key)+'" title="Silence this until it changes">Ack</button>')+
          '</div>';
      });
    });
  }
  if(nAcked) h+='<footer><button class="linkbtn" id="toggleAcked">'+
    (showAcked?'Hide':'Show')+' '+nAcked+' acknowledged</button></footer>';
  panel.innerHTML=h;

  panel.querySelectorAll('[data-ack]').forEach(function(b){
    b.onclick=function(e){
      e.stopPropagation();
      SETTINGS.acks=SETTINGS.acks||{}; SETTINGS.acks[b.dataset.ack]=todayISO();
      saveSettings(); renderBell();
    };
  });
  panel.querySelectorAll('.bellitem').forEach(function(it){
    it.onclick=function(){ closeBell(); openMachine(it.dataset.mid); };
    it.onkeydown=function(e){ if(e.key==='Enter') it.click(); };
  });
  var aa=$('#ackAll');
  if(aa) aa.onclick=function(e){
    e.stopPropagation();
    SETTINGS.acks=SETTINGS.acks||{};
    all.forEach(function(x){ SETTINGS.acks[x.key]=todayISO(); });
    saveSettings(); renderBell();
  };
  var ta=$('#toggleAcked');
  if(ta) ta.onclick=function(e){ e.stopPropagation(); showAcked=!showAcked; drawBellPanel(); };
}

function toggleBell(){
  bellOpen=!bellOpen;
  var panel=$('#bellPanel');
  panel.hidden=!bellOpen;
  $('#bellBtn').setAttribute('aria-expanded', String(bellOpen));
  if(bellOpen) drawBellPanel();
}
function closeBell(){
  bellOpen=false;
  var panel=$('#bellPanel'); if(panel) panel.hidden=true;
  var b=$('#bellBtn'); if(b) b.setAttribute('aria-expanded','false');
}
document.addEventListener('click', function(e){
  if(!bellOpen) return;
  if(e.target.closest('#bellPanel') || e.target.closest('#bellBtn')) return;
  closeBell();
});
document.addEventListener('keydown', function(e){ if(e.key==='Escape' && bellOpen) closeBell(); });
