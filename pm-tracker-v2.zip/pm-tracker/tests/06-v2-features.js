/* Tests for the v2 round: folder saving, masonry, combined charts, activities,
   the PM-line fix, the sizing fix, notifications, rail, themes, guide.
   Folder saving is exercised against the browser's origin-private file
   system, which hands back a real FileSystemDirectoryHandle with the same
   API as a folder the user picks — the picker itself needs a human. */
const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
const b=await pup.launch({executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
 args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[];
p.on('pageerror',e=>errs.push(e.message));
let confirmCount=0;
p.on('dialog',async d=>{ if(d.type()==='confirm') confirmCount++; await d.accept(); });
await p.emulateTimezone('America/New_York');
await p.setViewport({width:1366,height:768});
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1600));
const R=[]; const rec=(n,ok,d='')=>R.push({n,ok:!!ok,d:typeof d==='string'?d:JSON.stringify(d)});

/* ---------------- 1. the Ctrl+scroll sizing bug ---------------- */
let r=await p.evaluate(()=>{
  DB=demoDB(); show('board');
  const box=document.querySelector('#wallFit'), page=document.querySelector('#scr-board');
  enterWall(); const during={w:box.style.width,t:box.style.transform};
  exitWall();
  return { during, after:{w:box.style.width,h:box.style.height,t:box.style.transform},
           boxPx:Math.round(box.getBoundingClientRect().width),
           roomPx:Math.round(page.getBoundingClientRect().width - 44) };
});
rec('sizing: screenshot view does set a scaled width', r.during.w!=='', r);
rec('sizing: leaving screenshot view clears width, height and transform',
    r.after.w==='' && r.after.h==='' && r.after.t==='', r);
rec('sizing: board fits its page again without a resize event', r.boxPx<=r.roomPx+2, r);

/* ---------------- 2. masonry: no tile stretched to a neighbour ---------------- */
for (const mode of ['combined','separate']) {
  r=await p.evaluate(m=>{
    DB=demoDB(); SETTINGS.chartMode=m; SETTINGS.cols='3'; show('board');
    const tiles=[...document.querySelectorAll('#boardGrid > .tile')];
    let stretched=0, overlaps=0;
    const rects=tiles.map(t=>t.getBoundingClientRect());
    tiles.forEach((t,i)=>{
      /* natural height = sum of its children; a stretched tile would be taller */
      const kids=[...t.children].reduce((a,c)=>a+c.getBoundingClientRect().height,0);
      if(rects[i].height - kids > 6) stretched++;
    });
    for(let i=0;i<rects.length;i++) for(let j=i+1;j<rects.length;j++){
      const a=rects[i], c=rects[j];
      if(a.left<c.right-1 && c.left<a.right-1 && a.top<c.bottom-1 && c.top<a.bottom-1) overlaps++;
    }
    const heights=rects.map(x=>Math.round(x.height));
    SETTINGS.cols='auto';
    return { tiles:tiles.length, stretched, overlaps, distinctHeights:new Set(heights).size };
  }, mode);
  rec(`masonry (${mode}): no tile is stretched by a taller neighbour`, r.stretched===0, r);
  rec(`masonry (${mode}): no tiles overlap`, r.overlaps===0, r);
}
r=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.chartMode='separate'; show('board');
  const order=[...document.querySelectorAll('#boardGrid > .tile')].map(t=>t.dataset.m);
  const firstTop=document.querySelector('#boardGrid > .tile').getBoundingClientRect().top;
  const topRow=[...document.querySelectorAll('#boardGrid > .tile')]
    .filter(t=>Math.abs(t.getBoundingClientRect().top-firstTop)<2).map(t=>t.dataset.m);
  const riskiest=machineRollup(assessVisible()).sort((a,b)=>b.risk-a.risk)[0].m.id;
  SETTINGS.chartMode='combined';
  return { riskiest, topRow, riskiestInTopRow: topRow.indexOf(riskiest)>=0 };
});
rec('masonry: the riskiest machine still sits in the top row', r.riskiestInTopRow, r);

/* resizing re-packs */
r=await p.evaluate(async()=>{
  DB=demoDB(); show('board');
  const before=getComputedStyle(document.querySelector('#boardGrid')).gridTemplateColumns.split(' ').length;
  SETTINGS.railCollapsed=true; applyTheme(); await new Promise(x=>setTimeout(x,300)); layoutMasonry();
  const grid=document.querySelector('#boardGrid');
  const after=getComputedStyle(grid).gridTemplateColumns.split(' ').length;
  const tiles=[...grid.querySelectorAll('.tile')].map(t=>t.getBoundingClientRect());
  let overlaps=0;
  for(let i=0;i<tiles.length;i++) for(let j=i+1;j<tiles.length;j++){
    const a=tiles[i],c=tiles[j];
    if(a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1) overlaps++; }
  SETTINGS.railCollapsed=false; applyTheme();
  return { before, after, overlaps };
});
rec('rail: collapsing it gives the board another column', r.after>r.before, r);
rec('masonry: re-packs cleanly after the column count changes', r.overlaps===0, r);

/* ---------------- 3. combined chart ---------------- */
r=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.chartMode='combined'; show('board');
  const two=machineRollup(assessVisible()).filter(x=>x.rows.length===2)[0];
  const tile=document.querySelector('.tile[data-m="'+two.m.id+'"]');
  const svgs=tile.querySelectorAll('.well svg').length;
  const legend=[...tile.querySelectorAll('.clegend .cl')].map(c=>c.querySelector('.cn').textContent);
  const legendVals=[...tile.querySelectorAll('.clegend .cv')].map(c=>c.textContent);
  const realVals=two.rows.map(a=>num(a.value));
  const one=machineRollup(assessVisible()).filter(x=>x.rows.length===1)[0];
  const oneTile=document.querySelector('.tile[data-m="'+one.m.id+'"]');
  return { svgs, legend, legendVals, realVals,
           has100: tile.innerHTML.indexOf('>100%<')>=0,
           singleUsesOwnUnits: !!oneTile.querySelector('.readout') && !oneTile.querySelector('.clegend') };
});
rec('combined: a two-parameter machine gets exactly one chart', r.svgs===1, r);
rec('combined: legend lists every parameter', r.legend.length===2, r);
rec('combined: legend shows the real values, not just percentages',
    r.realVals.every(v=>r.legendVals.some(x=>x.indexOf(v)===0)), r);
rec('combined: chart is indexed with 100% marking the limit', r.has100, r);
rec('combined: single-parameter machines keep their own units', r.singleUsesOwnUnits, r);

r=await p.evaluate(()=>{
  /* a falling (lower-limit) parameter must climb toward 100% as it falls */
  DB=blankDB();
  DB.machines.push({id:'L',name:'L',group:'Photo',active:true});
  DB.parameters.push({id:'L::up',machineId:'L',name:'up',unit:'',threshold:10,warn:8,bound:'upper'});
  DB.parameters.push({id:'L::lamp',machineId:'L',name:'lamp',unit:'',threshold:7000,warn:7500,bound:'lower'});
  for(let i=10;i>=0;i--){
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'L::up',value:2+(10-i)*0.5});
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'L::lamp',value:11000-(10-i)*300});
  }
  const a=assess(DB.parameters[1]);
  const first=approach(DB.parameters[1],11000), last=approach(DB.parameters[1],8000);
  return { first:Math.round(first), last:Math.round(last), rising:last>first };
});
rec('combined: a lower-limit parameter rises toward 100% as its reading falls', r.rising && r.first<=5, r);

/* ---------------- 4. the PM line bug ---------------- */
r=await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'M',name:'M',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5});
  DB.parameters.push({id:'M::p',machineId:'M',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
  for(let i=20;i>=1;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'M::p',value:2+(20-i)*0.3});
  DB.pmEvents.push({id:'x',date:todayISO(),machineId:'M'});
  DB.readings.push({date:todayISO(),paramId:'M::p',value:2.1});     /* one reading after PM */
  SETTINGS.dotMode='all';
  const a=assess(DB.parameters[0]); const svg=tileChart(a,45,false);
  const dots=(svg.match(/<circle[^>]*r="1\.5"/g)||[]).length;
  const connector=/stroke-dasharray="1\.5 2\.5"/.test(svg);
  return { readings:a.all.length, dots, connector };
});
rec('PM line: every reading is drawn, including the one right after a PM', r.dots>=r.readings-1, r);
rec('PM line: the drop across the PM is drawn as a reset connector', r.connector, r);

for (const mode of ['all','alarm','none']) {
  r=await p.evaluate(m=>{
    DB=demoDB(); SETTINGS.dotMode=m;
    const a=assessVisible().filter(x=>x.status==='ok')[0];
    const svg=tileChart(a,45,false);
    SETTINGS.dotMode='all';
    return (svg.match(/<circle/g)||[]).length;
  }, mode);
  rec(`dots: "${mode}" mode`, mode==='all'? r>10 : r<=3, 'circles='+r);
}

/* ---------------- 5. activities ---------------- */
r=await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'S',name:'SEM',group:'Metrology',active:true,pmIntervalDays:60,pmLeadDays:5,
    lastPM:addDays(todayISO(),-30)});
  DB.parameters.push({id:'S::beam',machineId:'S',name:'Beam current',unit:'%',threshold:4,warn:3.2,bound:'upper'});
  DB.parameters.push({id:'S::stage',machineId:'S',name:'Stage',unit:'nm',threshold:12,warn:9.5,bound:'upper'});
  DB.pmEvents.push({id:'pm',date:addDays(todayISO(),-30),machineId:'S'});
  for(let i=29;i>=0;i--){
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'S::beam',value:1+(29-i)*0.08});
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'S::stage',value:4+(29-i)*0.1});
  }
  const before={ beam:assess(DB.parameters[0]).seg[0].date, stage:assess(DB.parameters[1]).seg[0].date,
                 pmIn:pmSchedule(machineById('S')).inDays };
  DB.paramEvents.push({id:'a1',date:addDays(todayISO(),-6),paramId:'S::beam',type:'Filament change'});
  DB.parameters.forEach(x=>delete x._base);
  const after={ beam:assess(DB.parameters[0]).seg[0].date, stage:assess(DB.parameters[1]).seg[0].date,
                pmIn:pmSchedule(machineById('S')).inDays, kind:assess(DB.parameters[0]).resetKind };
  return { before, after, actDate:addDays(todayISO(),-6) };
});
rec('activity: restarts the trend of its own parameter', r.after.beam===r.actDate, r);
rec('activity: leaves the other parameter of the machine alone', r.after.stage===r.before.stage, r);
rec('activity: leaves the machine PM countdown alone', r.after.pmIn===r.before.pmIn, r);
rec('activity: assessment knows the reset was an activity, not a PM', r.after.kind==='act', r);

r=await p.evaluate(()=>{
  const a=assess(DB.parameters[0]);
  const tile=tileChart(a,45,false), full=trendChart(a,0);
  return { tileDiamond:/l3\.5,3\.5 l-3\.5,3\.5/.test(tile), fullLabel:full.indexOf('>ACT<')>=0 };
});
rec('activity: violet diamond marker on the tile chart', r.tileDiamond, r);
rec('activity: labelled marker on the full chart', r.fullLabel, r);

r=await p.evaluate(()=>{
  DB=demoDB(); show('entry');
  const btns=document.querySelectorAll('[data-act-log]').length;
  document.querySelector('[data-act-log]').click();
  const opened=!!document.querySelector('#aType');
  document.querySelector('#aType').value='Lamp replacement';
  const n=DB.paramEvents.length;
  document.querySelector('#mSave').click();
  const logged=DB.paramEvents.length===n+1 && DB.paramEvents[DB.paramEvents.length-1].type==='Lamp replacement';
  show('machine'); const inDetail=document.querySelector('#machineBody').innerText.indexOf('Parameter activities')>=0;
  return { btns, opened, logged, inDetail };
});
rec('activity: every entry row has an Activity button', r.btns>=21, r);
rec('activity: logging from the entry screen works', r.opened && r.logged, r);
rec('activity: machine detail lists activities', r.inDetail, r);

r=await p.evaluate(()=>{
  const id=DB.paramEvents[DB.paramEvents.length-1].id, n=DB.paramEvents.length;
  removeActivity(id);
  return { removed: DB.paramEvents.length===n-1 };
});
rec('activity: can be removed', r.removed, r);

r=await p.evaluate(()=>{
  const m=migrate({machines:[],parameters:[],readings:[],pmEvents:[]});
  return Array.isArray(m.paramEvents);
});
rec('activity: older files gain an empty activity list on load', r===true);

/* ---------------- 6. notifications ---------------- */
r=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.acks={}; saveSettings(); show('board');
  const onBoard=!!document.querySelector('#scr-board .alert');
  const all=computeAlerts();
  const badge=+document.querySelector('#bellCount').textContent;
  const expect=all.filter(x=>x.sev!=='info').length;
  toggleBell();
  const items=document.querySelectorAll('#bellPanel .bellitem').length;
  const open=!document.querySelector('#bellPanel').hidden;
  return { onBoard, badge, expect, items, open, sevOrder:all.map(x=>x.sev).join(',') };
});
rec('notifications: alerts no longer stack on the board', !r.onBoard, r);
rec('notifications: badge counts the alerts needing attention', r.badge===r.expect, r);
rec('notifications: panel opens and lists every alert', r.open && r.items>=r.expect, r);
rec('notifications: worst first', /^(crit,)*(warn,)*(info,?)*$/.test(r.sevOrder+','), r.sevOrder);

r=await p.evaluate(()=>{
  const before=+document.querySelector('#bellCount').textContent;
  document.querySelector('#bellPanel [data-ack]').click();
  const after=+document.querySelector('#bellCount').textContent;
  return { before, after };
});
rec('notifications: acknowledging drops the badge by one', r.after===r.before-1, r);

r=await p.evaluate(()=>{
  /* a warning that worsens to at-limit must come back as a new alert */
  DB=blankDB(); SETTINGS.acks={};
  DB.machines.push({id:'W',name:'W',group:'Photo',active:true});
  DB.parameters.push({id:'W::p',machineId:'W',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
  for(let i=5;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'W::p',value:8.4});
  computeAlerts().forEach(x=>SETTINGS.acks[x.key]=todayISO());
  const silenced=computeAlerts().filter(x=>!x.acked).length;
  DB.readings.push({date:addDays(todayISO(),1),paramId:'W::p',value:10.5});
  DB.parameters.forEach(x=>delete x._base);
  const back=computeAlerts().filter(x=>!x.acked && x.sev==='crit').length;
  const stalePruned=Object.keys(SETTINGS.acks).every(k=>computeAlerts().some(x=>x.key===k));
  SETTINGS.acks={}; saveSettings();
  return { silenced, back, stalePruned };
});
rec('notifications: an acknowledged warning is silent', r.silenced===0, r);
rec('notifications: it comes back when it worsens to at-limit', r.back===1, r);
rec('notifications: acknowledgements for cleared conditions are pruned', r.stalePruned, r);

r=await p.evaluate(()=>{
  DB=demoDB(); show('board'); toggleBell();
  const it=document.querySelector('#bellPanel .bellitem'); const mid=it.dataset.mid; it.click();
  return { screen, picked:document.querySelector('#machinePick').value===mid,
           closed:document.querySelector('#bellPanel').hidden };
});
rec('notifications: clicking one opens that machine and closes the panel',
    r.screen==='machine' && r.picked && r.closed, r);

/* ---------------- 7. rail ---------------- */
r=await p.evaluate(async()=>{
  show('board'); await new Promise(x=>setTimeout(x,320));   /* rail animates width over 180ms */
  const w0=document.querySelector('.rail').getBoundingClientRect().width;
  document.querySelector('#railToggle').click(); await new Promise(x=>setTimeout(x,320));
  const w1=document.querySelector('.rail').getBoundingClientRect().width;
  const labelsHidden=getComputedStyle(document.querySelector('.nav .nl')).display==='none';
  const saved=JSON.parse(localStorage.getItem('pmtracker.settings.v1')).railCollapsed;
  const navWorks=(()=>{ document.querySelector('.nav button[data-screen="pm"]').click(); return screen==='pm'; })();
  document.querySelector('#railToggle').click(); await new Promise(x=>setTimeout(x,320));
  const w2=document.querySelector('.rail').getBoundingClientRect().width;
  return { w0:Math.round(w0), w1:Math.round(w1), w2:Math.round(w2), labelsHidden, saved, navWorks };
});
rec('rail: collapses to icons', r.w1<70 && r.labelsHidden, r);
rec('rail: collapsed state is remembered', r.saved===true, r);
rec('rail: navigation still works when collapsed', r.navWorks, r);
rec('rail: expands back', r.w2===r.w0, r);

/* ---------------- 8. themes ---------------- */
r=await p.evaluate(()=>{
  function rgb(h){ h=h.trim().replace('#',''); if(h.length===3) h=h.split('').map(c=>c+c).join('');
    return [0,2,4].map(i=>parseInt(h.substr(i,2),16)); }
  /* hue, but only for colours vivid enough to read as a signal: a near-black
     ink or a grey-brown shares a hue with amber without looking like it */
  function hue(c){ const [r,g,b]=c.map(x=>x/255), mx=Math.max(r,g,b), mn=Math.min(r,g,b), d=mx-mn;
    const l=(mx+mn)/2, s= d===0?0 : d/(1-Math.abs(2*l-1));
    if(d<0.08 || s<0.35 || l<0.18 || l>0.88) return null;
    let h= mx===r?((g-b)/d)%6 : mx===g?(b-r)/d+2 : (r-g)/d+4; return (h*60+360)%360; }
  const out={};
  THEMES.forEach(t=>{
    SETTINGS.theme=t; applyTheme(); refreshChartColors();
    const cs=getComputedStyle(document.documentElement);
    const ink=rgb(cs.getPropertyValue('--ink')), surf=rgb(cs.getPropertyValue('--surface'));
    const L=c=>{ const a=c.map(v=>{ v/=255; return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4); });
      return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2]; };
    const contrast=(Math.max(L(ink),L(surf))+0.05)/(Math.min(L(ink),L(surf))+0.05);
    const alarmHues=['--crit','--warn','--ok'].map(v=>hue(rgb(cs.getPropertyValue(v)))).filter(x=>x!=null);
    const clash=COL.series.filter(s=>{ const h=hue(rgb(s)); if(h==null) return false;
      return alarmHues.some(a=>Math.min(Math.abs(a-h),360-Math.abs(a-h))<22); });
    out[t]={ applied:document.documentElement.getAttribute('data-theme')===t,
             contrast:Math.round(contrast*10)/10, seriesClashingWithAlarms:clash };
  });
  SETTINGS.theme='graphite'; applyTheme();
  return out;
});
Object.keys(r).forEach(t=>{
  rec(`theme ${t}: applies`, r[t].applied, r[t]);
  rec(`theme ${t}: body text contrast is at least 7:1 (WCAG AAA)`, r[t].contrast>=7, r[t]);
  rec(`theme ${t}: no chart series colour looks like an alarm`, r[t].seriesClashingWithAlarms.length===0, r[t]);
});
r=await p.evaluate(()=>{
  const out={};
  ['light','dark','warm','slate'].forEach(old=>{ SETTINGS.theme=old; applyTheme(); out[old]=SETTINGS.theme; });
  SETTINGS.theme='graphite'; applyTheme(); return out;
});
rec('themes: old saved theme names map onto the new ones',
    r.light==='graphite'&&r.dark==='control'&&r.warm==='pad'&&r.slate==='graphite', r);
r=await p.evaluate(()=>{
  themeGallery();
  const cards=document.querySelectorAll('.tcard').length;
  const scoped=[...document.querySelectorAll('.tprev')].map(x=>getComputedStyle(x).backgroundColor);
  document.querySelector('[data-theme-pick="control"]').click();
  const live=document.documentElement.getAttribute('data-theme');
  document.querySelector('#mCancel').click();
  return { cards, distinctPreviews:new Set(scoped).size, live, reverted:document.documentElement.getAttribute('data-theme') };
});
rec('themes: gallery shows all seven', r.cards===7, r);
rec('themes: each card previews in its own theme', r.distinctPreviews>=6, r);
rec('themes: picking previews live, Cancel reverts', r.live==='control' && r.reverted==='graphite', r);

/* ---------------- 9. guide ---------------- */
r=await p.evaluate(()=>{
  show('guide');
  const tabs={};
  ['map','tasks','marks','about'].forEach(t=>{ guideTab=t; renderGuide(); tabs[t]=document.querySelector('#guideBody').innerText.length; });
  guideTab='map'; renderGuide();
  const targets=[...document.querySelectorAll('#guideBody [data-go]')].map(x=>x.dataset.go);
  guideTab='tasks'; renderGuide();
  const allTargets=targets.concat([...document.querySelectorAll('#guideBody [data-go]')].map(x=>x.dataset.go));
  const broken=allTargets.filter(t=>!GUIDE_TARGETS[t]);
  const f=document.querySelector('#taskFind'); f.value='filament'; f.oninput();
  const shown=[...document.querySelectorAll('.gtask')].filter(x=>!x.hidden).length;
  f.value='zzqqx'; f.oninput(); const none=!document.querySelector('#taskNone').hidden;
  return { tabs, links:allTargets.length, broken, shown, none };
});
rec('guide: all four tabs have content', Object.values(r.tabs).every(n=>n>200), r.tabs);
rec('guide: every "go" link points somewhere real', r.broken.length===0, r);
rec('guide: task search narrows to the right task', r.shown>=1 && r.shown<=3, r);
rec('guide: task search says so when nothing matches', r.none, r);
for (const t of ['entry','pm','machines','importer','report']) {
  const ok=await p.evaluate(x=>{ guideGo(x); return screen; }, t);
  rec(`guide: "${t}" link lands on the right screen`,
      ok===({entry:'entry',pm:'pm',machines:'config',importer:'data',report:'report'})[t], ok);
}

/* ---------------- 10. saving into a folder ---------------- */
r=await p.evaluate(async()=>{
  if(!navigator.storage || !navigator.storage.getDirectory) return { skip:'no OPFS' };
  const root=await navigator.storage.getDirectory();
  for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
  DB=demoDB(); DB.meta.isDemo=false; markDirty();
  FOLDER.handle=root; FOLDER.name='data'; FOLDER.state='connected'; FOLDER.file=''; FOLDER.loadedMod=0;
  const ok1=await saveToFolder(false);
  const names=[]; for await (const e of root.values()) names.push(e.name);
  const first=names.filter(n=>/^pm-data-/.test(n));
  const bnames=[]; const bd=await root.getDirectoryHandle('backups'); for await (const e of bd.values()) bnames.push(e.name);
  /* second save: same file, updated in place */
  DB.readings.push({date:addDays(todayISO(),1),paramId:DB.parameters[0].id,value:1.111,by:'QA'}); markDirty();
  await new Promise(x=>setTimeout(x,1100));
  const ok2=await saveToFolder(false);
  const names2=[]; for await (const e of root.values()) names2.push(e.name);
  const second=names2.filter(n=>/^pm-data-/.test(n));
  const text=await (await (await root.getFileHandle(second[0])).getFile()).text();
  const latest=await (await (await root.getFileHandle('latest.js')).getFile()).text();
  return { ok1, ok2, first, second, backups:bnames, clean:!dirty,
           inPlace: first.length===1 && second.length===1 && first[0]===second[0],
           updated: text.indexOf('1.111')>=0, latestOk: latest.indexOf('window.PM_AUTOLOAD')===0 || latest.indexOf('window.PM_AUTOLOAD')>0 };
});
if(r.skip) rec('folder: origin-private file system available for testing', false, r.skip);
else {
  rec('folder: first save creates one dated data file', r.ok1 && r.first.length===1, r);
  rec('folder: later saves update that same file in place', r.ok2 && r.inPlace, r);
  rec('folder: the file really holds the new reading', r.updated, r);
  rec('folder: latest.js is kept in step for auto-load', r.latestOk, r);
  rec('folder: a dated daily backup is written', r.backups.length===1, r);
  rec('folder: saving clears the unsaved flag', r.clean, r);
}

r=await p.evaluate(async()=>{
  const root=await navigator.storage.getDirectory();
  /* a newer file appears: opening the folder must pick it up */
  const older=DB.readings.length;
  const newer=JSON.parse(JSON.stringify(DB)); newer.readings=newer.readings.slice(0,10); newer.meta.savedAt=new Date().toISOString();
  await new Promise(x=>setTimeout(x,1100));
  const fh=await root.getFileHandle('pm-data-2026-01-01-000000.json',{create:true});
  const w=await fh.createWritable(); await w.write(JSON.stringify(newer)); await w.close();
  const res=await loadFromFolder();
  return { loaded:res.name, readings:DB.readings.length, older };
});
rec('folder: opening loads the most recently modified file, whatever its name',
    r.loaded==='pm-data-2026-01-01-000000.json' && r.readings===10, r);

r=await p.evaluate(async()=>{
  const root=await navigator.storage.getDirectory();
  /* someone else saves after we opened: we must be asked before overwriting */
  await new Promise(x=>setTimeout(x,1100));
  const fh=await root.getFileHandle(FOLDER.file);
  const w=await fh.createWritable(); await w.write(JSON.stringify(Object.assign({},DB,{meta:{savedAt:'x'}}))); await w.close();
  window.__asked=0; const orig=window.confirm; window.confirm=function(){ window.__asked++; return false; };
  markDirty();
  const saved=await saveToFolder(false);
  window.confirm=orig;
  return { asked:window.__asked, saved, stillDirty:dirty };
});
rec('folder: asks before overwriting a file someone else changed', r.asked===1, r);
rec('folder: declining keeps their file and your unsaved work', r.saved===false && r.stillDirty, r);

r=await p.evaluate(async()=>{
  const n=[]; const root=await navigator.storage.getDirectory();
  FOLDER.file=''; FOLDER.loadedMod=0;
  await saveAsNewFile();
  for await (const e of root.values()) if(/^pm-data-/.test(e.name)) n.push(e.name);
  return { files:n.length };
});
rec('folder: Save as new file starts a second dated file', r.files>=3, r);

r=await p.evaluate(()=>{
  FOLDER.state='connected'; paintFolderState();
  const a={ label:document.querySelector('#quickSave').textContent, chip:document.querySelector('#folderState').className };
  FOLDER.state='needs-permission'; FOLDER.name='data'; paintFolderState();
  const b2={ label:document.querySelector('#quickSave').textContent, chip:document.querySelector('#folderState').className };
  FOLDER.state='none'; paintFolderState();
  return { a, b2 };
});
rec('folder: top bar shows when saving goes straight to the folder', r.a.label==='Save' && /on/.test(r.a.chip), r);
rec('folder: top bar asks for one click when permission lapsed', /Reconnect/.test(r.b2.label) && /warn/.test(r.b2.chip), r);

/* ---------------- 11. unsaved work is never dropped by auto-load ---------------- */
r=await p.evaluate(()=>{
  DB=demoDB(); DB.meta.savedAt=new Date(Date.now()-3600e3).toISOString();
  const draftDb=JSON.parse(JSON.stringify(DB)); draftDb.readings.push({date:todayISO(),paramId:DB.parameters[0].id,value:9.99});
  localStorage.setItem('pmtracker.draft.v1', JSON.stringify({at:new Date().toISOString(), db:draftDb}));
  document.querySelector('#modalHost').innerHTML='';
  offerDraftIfNewer();
  return new Promise(res=>setTimeout(()=>{
    const offered=/Unsaved work found/.test(document.querySelector('#modalHost').innerText);
    document.querySelector('#mSave').click();
    res({ offered, restored: DB.readings.some(x=>x.value===9.99), dirty });
  },600));
});
rec('draft: work newer than the auto-loaded file is offered back', r.offered, r);
rec('draft: restoring it brings the reading back and marks it unsaved', r.restored && r.dirty, r);
r=await p.evaluate(()=>{
  DB=demoDB(); DB.meta.savedAt=new Date().toISOString();
  localStorage.setItem('pmtracker.draft.v1', JSON.stringify({at:new Date(Date.now()-3600e3).toISOString(), db:DB}));
  document.querySelector('#modalHost').innerHTML='';
  offerDraftIfNewer();
  return new Promise(res=>setTimeout(()=>res({
    offered:/Unsaved work found/.test(document.querySelector('#modalHost').innerText),
    cleared:!localStorage.getItem('pmtracker.draft.v1') }),600));
});
rec('draft: an older draft is not offered, and is cleared', !r.offered && r.cleared, r);

/* ---------------- 12. Ctrl+S ---------------- */
r=await p.evaluate(()=>{
  let called=0; const orig=window.smartSave; window.smartSave=function(){ called++; };
  document.dispatchEvent(new KeyboardEvent('keydown',{key:'s',ctrlKey:true,bubbles:true}));
  window.smartSave=orig; return called;
});
rec('Ctrl+S saves from anywhere', r===1, 'calls='+r);

/* ---------------- 13. every screen in every theme ---------------- */
r=await p.evaluate(()=>{
  const fails=[];
  DB=demoDB();
  THEMES.forEach(t=>{ SETTINGS.theme=t; applyTheme();
    ['board','entry','charts','pm','analysis','machine','report','config','data','guide'].forEach(s=>{
      try{ show(s); }catch(e){ fails.push(t+'/'+s+': '+e.message); } }); });
  SETTINGS.theme='graphite'; applyTheme(); show('board');
  return fails;
});
rec('all 10 screens render in all 7 themes', r.length===0, r);

const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
console.log(`\nV2 FEATURES — ${pass}/${R.length} passed`);
if(fail.length){ console.log('FAILURES:'); fail.forEach(f=>console.log('  x '+f.n+'\n      '+f.d)); }
console.log(errs.length?'RUNTIME ERRORS:\n  '+errs.join('\n  '):'No runtime errors.');
await b.close(); process.exit(fail.length?1:0);
})();
