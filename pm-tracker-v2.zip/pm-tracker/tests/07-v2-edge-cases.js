/* Adversarial cases for the v2 code: combined charts with awkward data,
   activities at odd dates, notifications on empty data, folders holding
   damaged files, and the four gaps found by reading the code. */
const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{
const b=await pup.launch({executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',
 args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[];
p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',async d=>await d.accept());
await p.emulateTimezone('Pacific/Chatham');
await p.setViewport({width:1366,height:768});
await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
await new Promise(r=>setTimeout(r,1500));

const R = await p.evaluate(async()=>{
  const R=[]; const ok=(n,c,d)=>R.push({n,ok:!!c,d:d==null?'':String(d)});
  const run=async(n,fn)=>{ try{ const v=await fn(); ok(n, v===true, v===true?'':v); }catch(e){ ok(n,false,'THREW '+e.message); } };
  const noNaN=s=>s.indexOf('NaN')<0 && s.indexOf('undefined')<0 && s.indexOf('Infinity')<0;
  function mk(nParams){
    DB=blankDB();
    DB.machines.push({id:'X',name:'X',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5});
    for(let k=0;k<nParams;k++){
      DB.parameters.push({id:'X::p'+k,machineId:'X',name:'p'+k,unit:'u',threshold:10,warn:8,bound:'upper'});
      for(let i=14;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'X::p'+k,value:2+k*0.4+(14-i)*0.2});
    }
  }

  /* ---------- combined chart, awkward data ---------- */
  await run('combined: seven parameters cycle colours without undefined', ()=>{
    mk(7); refreshChartColors();
    const rows=paramsOf('X').map(assess);
    const svg=combinedChart(rows,45), leg=combinedLegend(rows);
    return (noNaN(svg) && noNaN(leg) && (leg.match(/class="cl /g)||[]).length===7) || 'bad output';
  });
  await run('combined: a parameter with no readings in the window', ()=>{
    mk(2);
    DB.readings=DB.readings.filter(r=>r.paramId!=='X::p1');
    const rows=paramsOf('X').map(assess);
    const svg=combinedChart(rows,45), leg=combinedLegend(rows);
    return (noNaN(svg) && leg.indexOf('—')>=0) || 'missing placeholder or NaN';
  });
  await run('combined: zero-span limit (limit equals baseline) drops out cleanly', ()=>{
    mk(2);
    DB.parameters[1].threshold=2.4; DB.parameters[1].warn=2.4;
    DB.readings.filter(r=>r.paramId==='X::p1').forEach(r=>r.value=2.4);
    DB.parameters.forEach(x=>delete x._base);
    const svg=combinedChart(paramsOf('X').map(assess),45);
    return noNaN(svg) || 'NaN in svg';
  });
  await run('combined: every reading identical', ()=>{
    mk(2); DB.readings.forEach(r=>r.value=5); DB.parameters.forEach(x=>delete x._base);
    return noNaN(combinedChart(paramsOf('X').map(assess),45)) || 'NaN';
  });
  await run('combined: one reading per parameter', ()=>{
    mk(2); const keep={}; DB.readings=DB.readings.filter(r=>{ if(keep[r.paramId]) return false; keep[r.paramId]=1; return true; });
    return noNaN(combinedChart(paramsOf('X').map(assess),45)) || 'NaN';
  });
  await run('combined: one parameter hidden leaves a normal single chart', ()=>{
    mk(2); DB.parameters[1].hidden=true; SETTINGS.chartMode='combined'; show('board');
    const t=document.querySelector('.tile');
    return (!t.querySelector('.clegend') && !!t.querySelector('.readout')) || 'still combined';
  });
  await run('combined: values far past the limit stay on the chart', ()=>{
    mk(2); DB.readings.filter(r=>r.paramId==='X::p0').slice(-1)[0].value=60; DB.parameters.forEach(x=>delete x._base);
    const svg=combinedChart(paramsOf('X').map(assess),45);
    const ys=[...svg.matchAll(/cy="([\d.\-]+)"/g)].map(m=>+m[1]);
    return (noNaN(svg) && Math.min(...ys)>=0) || 'point drawn off the top';
  });

  /* ---------- activities at odd dates ---------- */
  await run('activity dated before any reading restarts nothing visible', ()=>{
    mk(1); DB.paramEvents.push({id:'a',date:addDays(todayISO(),-200),paramId:'X::p0',type:'Recalibration'});
    DB.parameters.forEach(x=>delete x._base);
    const a=assess(DB.parameters[0]);
    return (a.seg.length===a.all.length) || 'seg='+a.seg.length+' all='+a.all.length;
  });
  await run('activity dated in the future does not apply yet', ()=>{
    mk(1); DB.paramEvents.push({id:'a',date:addDays(todayISO(),20),paramId:'X::p0',type:'Recalibration'});
    DB.parameters.forEach(x=>delete x._base);
    const a=assess(DB.parameters[0]);
    return (a.seg.length===a.all.length && a.resetKind!=='act') || 'future activity applied';
  });
  await run('activity and PM on the same day', ()=>{
    mk(1); const d=addDays(todayISO(),-5);
    DB.pmEvents.push({id:'pm',date:d,machineId:'X'});
    DB.paramEvents.push({id:'a',date:d,paramId:'X::p0',type:'Filament change'});
    DB.parameters.forEach(x=>delete x._base);
    const a=assess(DB.parameters[0]);
    const svg=tileChart(a,45,false);
    return (a.seg[0].date===d && noNaN(svg)) || 'seg='+a.seg[0].date;
  });
  await run('two activities on one parameter: the later one wins', ()=>{
    mk(1);
    DB.paramEvents.push({id:'a',date:addDays(todayISO(),-10),paramId:'X::p0',type:'Recalibration'});
    DB.paramEvents.push({id:'b',date:addDays(todayISO(),-4),paramId:'X::p0',type:'Filament change'});
    DB.parameters.forEach(x=>delete x._base);
    return (assess(DB.parameters[0]).seg[0].date===addDays(todayISO(),-4)) || 'wrong segment';
  });
  await run('duplicate activity on the same date is refused', ()=>{
    DB=demoDB(); const pid=DB.parameters[0].id;
    activityDialog(pid, todayISO()); document.querySelector('#aType').value='Recalibration';
    document.querySelector('#mSave').click();
    const n=DB.paramEvents.length;
    activityDialog(pid, todayISO()); document.querySelector('#aType').value='Recalibration';
    document.querySelector('#mSave').click();
    const still=!!document.querySelector('#aType');
    if(still) document.querySelector('#mCancel').click();
    return (DB.paramEvents.length===n) || 'duplicate saved';
  });
  await run('"Other" activity needs a description', ()=>{
    DB=demoDB(); const n=DB.paramEvents.length;
    activityDialog(DB.parameters[0].id); document.querySelector('#aType').value='Other';
    document.querySelector('#aType').onchange();
    document.querySelector('#mSave').click();
    const refused=DB.paramEvents.length===n && !!document.querySelector('#aOther');
    document.querySelector('#aOther').value='Gun alignment'; document.querySelector('#mSave').click();
    return (refused && DB.paramEvents.slice(-1)[0].type==='Gun alignment') || 'not enforced';
  });

  /* ---------- the four gaps ---------- */
  await run('deleting a parameter removes its activities too', ()=>{
    DB=demoDB(); const pid=DB.parameters[0].id;
    DB.paramEvents.push({id:'z',date:todayISO(),paramId:pid,type:'Recalibration'});
    configAct('delParam', pid);
    return (!DB.paramEvents.some(e=>e.paramId===pid)) || 'orphan left behind';
  });
  await run('integrity check reports orphaned activities', ()=>{
    const db=blankDB(); db.paramEvents.push({id:'q',date:todayISO(),paramId:'GONE::x',type:'Other'});
    return integrity(db).some(s=>/activit/.test(s)) || 'not reported';
  });
  await run('Export to Excel includes activities', ()=>{
    DB=demoDB(); DB.paramEvents.push({id:'q',date:todayISO(),paramId:DB.parameters[0].id,type:'Filament change',notes:'a, "b"'});
    const names=[]; const orig=window.download;
    window.download=function(n,t){ names.push({n,t}); };
    exportCSV();
    return new Promise(res=>setTimeout(()=>{ window.download=orig;
      const a=names.filter(x=>/^pm-activities-/.test(x.n))[0];
      res((a && a.t.indexOf('Filament change')>=0 && a.t.indexOf('"a, ""b"""')>=0) || JSON.stringify(names.map(x=>x.n)));
    },1500));
  });
  await run('a damaged newest file falls back to the previous good one', async()=>{
    const root=await navigator.storage.getDirectory();
    for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
    const good=demoDB(); good.meta.site='GOOD';
    let w=await (await root.getFileHandle('pm-data-2026-01-01-000000.json',{create:true})).createWritable();
    await w.write(JSON.stringify(good)); await w.close();
    await new Promise(x=>setTimeout(x,1100));
    w=await (await root.getFileHandle('pm-data-2026-02-01-000000.json',{create:true})).createWritable();
    await w.write('{"schemaVersion":1,"machines":[{"id":"trunc'); await w.close();   /* truncated copy */
    FOLDER.handle=root; FOLDER.state='connected';
    const r=await loadFromFolder();
    return (r.loaded && DB.meta.site==='GOOD' && r.skipped.length===1 && /could not be read/.test(r.issues[0]))
      || JSON.stringify({name:r.name, skipped:r.skipped});
  });
  await run('a folder of nothing but damaged files says so instead of hanging', async()=>{
    const root=await navigator.storage.getDirectory();
    for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
    const w=await (await root.getFileHandle('pm-data-bad.json',{create:true})).createWritable();
    await w.write('not json'); await w.close();
    FOLDER.handle=root;
    try{ await loadFromFolder(); return 'did not throw'; }
    catch(e){ return /could be read/.test(e.message) || e.message; }
  });
  await run('an empty folder reports empty, and the first save creates a file', async()=>{
    const root=await navigator.storage.getDirectory();
    for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
    FOLDER.handle=root; FOLDER.state='connected'; FOLDER.file=''; FOLDER.loadedMod=0;
    const r=await loadFromFolder();
    DB=demoDB(); markDirty();
    await saveToFolder(false);
    const n=[]; for await (const e of root.values()) if(/^pm-data-/.test(e.name)) n.push(e.name);
    FOLDER.state='none';
    return (r.loaded===false && n.length===1) || JSON.stringify({r,n});
  });
  await run('files that are not PM data are ignored', async()=>{
    const root=await navigator.storage.getDirectory();
    for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
    for(const nm of ['notes.json','pm-data.txt','random.js']){
      const w=await (await root.getFileHandle(nm,{create:true})).createWritable(); await w.write('x'); await w.close(); }
    const list=await listDataFiles(root);
    return list.length===0 || list.map(x=>x.name).join(',');
  });

  /* ---------- notifications on odd data ---------- */
  await run('notifications on an empty database', ()=>{
    DB=blankDB(); const a=computeAlerts(); renderBell(); toggleBell();
    const txt=document.querySelector('#bellPanel').innerText; closeBell();
    return (a.length===0 && /Nothing needs attention/.test(txt)) || txt.slice(0,80);
  });
  await run('acks missing or null in saved settings', ()=>{
    DB=demoDB(); SETTINGS.acks=null; computeAlerts(); renderBell(); toggleBell();
    const btn=document.querySelector('#bellPanel [data-ack]'); if(btn) btn.click();
    closeBell(); const ok2=SETTINGS.acks && typeof SETTINGS.acks==='object';
    SETTINGS.acks={}; saveSettings(); return ok2 || 'acks not recreated';
  });
  await run('Acknowledge all, then Show acknowledged', ()=>{
    DB=demoDB(); SETTINGS.acks={}; renderBell(); toggleBell();
    document.querySelector('#ackAll').click();
    const badgeGone=document.querySelector('#bellCount').hidden;
    document.querySelector('#toggleAcked').click();
    const shown=document.querySelectorAll('#bellPanel .bellitem.acked').length;
    closeBell(); SETTINGS.acks={}; saveSettings();
    return (badgeGone && shown>0) || JSON.stringify({badgeGone,shown});
  });
  await run('Esc and clicking outside close the panel', ()=>{
    DB=demoDB(); toggleBell();
    document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));
    const a=document.querySelector('#bellPanel').hidden;
    toggleBell(); document.querySelector('.phead').click();
    const b=document.querySelector('#bellPanel').hidden;
    return (a && b) || JSON.stringify({esc:a,outside:b});
  });

  /* ---------- layout extremes ---------- */
  await run('empty group shows a message, not a crushed 4px row', ()=>{
    DB=demoDB(); DB.groups.push('Empty'); filterGroup.board='Empty'; show('board');
    const pnl=document.querySelector('#boardGrid .panel');
    const h=pnl?pnl.getBoundingClientRect().height:0;
    filterGroup.board='All';
    return h>60 || 'height='+h;
  });
  await run('forty machines still fit one screen in screenshot view', ()=>{
    DB=demoDB(); const base=DB.machines.slice();
    for(let k=0;k<2;k++) base.forEach(m=>{ const id=m.id+'c'+k;
      DB.machines.push(Object.assign({},m,{id:id,name:m.name+' '+k}));
      paramsOf(m.id).forEach(pa=>{ const pid=id+'::'+pa.name;
        DB.parameters.push(Object.assign({},pa,{id:pid,machineId:id}));
        seriesOf(pa.id).slice(-30).forEach(r=>DB.readings.push({date:r.date,paramId:pid,value:r.value})); }); });
    show('board'); enterWall();
    const fits=document.body.scrollHeight<=window.innerHeight+2, n=document.querySelectorAll('.tile').length;
    exitWall(); return (fits && n===48) || JSON.stringify({fits,n});
  });
  await run('switching combined/separate repeatedly keeps the layout clean', ()=>{
    DB=demoDB(); let overl=0;
    for(let i=0;i<6;i++){ SETTINGS.chartMode=i%2?'separate':'combined'; SETTINGS.chartH=['s','m','l','xl'][i%4]; show('board'); }
    const rs=[...document.querySelectorAll('#boardGrid > .tile')].map(t=>t.getBoundingClientRect());
    for(let i=0;i<rs.length;i++) for(let j=i+1;j<rs.length;j++){ const a=rs[i],c=rs[j];
      if(a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1) overl++; }
    SETTINGS.chartMode='combined'; SETTINGS.chartH='m';
    return overl===0 || 'overlaps='+overl;
  });
  await run('guide renders with an empty database', ()=>{
    DB=blankDB(); show('guide');
    return (document.querySelector('#guideBody').innerText.length>200) || 'empty guide';
  });

  return R;
});

/* Cold-load cases need a fresh page: once any screen fills the machine
   picker the bug hides, which is how it survived every earlier suite. */
for (const via of ['tile','notification','analysis row']) {
  await p.goto('file:///home/claude/pm-tracker/index.html',{waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,1400));
  const res = await p.evaluate(v=>{
    let want;
    if(v==='tile'){ const t=[...document.querySelectorAll('.tile')][4]; want=t.dataset.m; t.click(); }
    else if(v==='notification'){ toggleBell(); const it=[...document.querySelectorAll('#bellPanel .bellitem')].pop(); want=it.dataset.mid; it.click(); }
    else { show('analysis'); const tr=[...document.querySelectorAll('#analysisBody tr[data-m]')][3]; want=tr.dataset.m; tr.click(); }
    const got=document.querySelector('#machinePick').value;
    const name=machineById(want).name;
    return { want, got, headerShowsIt: document.querySelector('#machinePick').selectedOptions[0].textContent===name };
  }, via);
  R.push({ n:'cold load: clicking a '+via+' opens that machine, not the first one',
           ok: res.want===res.got && res.headerShowsIt, d: JSON.stringify(res) });
}

const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
console.log(`\nV2 EDGE CASES — ${pass}/${R.length} clean`);
if(fail.length){ console.log('ISSUES:'); fail.forEach(f=>console.log('  ! '+f.n+'\n      '+f.d)); }
console.log(errs.length?'RUNTIME ERRORS:\n  '+errs.join('\n  '):'No runtime errors.');
await b.close(); process.exit(fail.length?1:0);
})();
