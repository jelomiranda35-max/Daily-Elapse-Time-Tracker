/* Tests for the v2 changes: folder save, masonry, combined charts, activities,
   notifications, collapsible rail, themes, guide, and the two reported bugs. */
const pup=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
const CHROME='/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome';
const URL='file:///home/claude/pm-tracker/index.html';

(async()=>{
const b=await pup.launch({executablePath:CHROME,args:['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage']});
const p=await b.newPage(); const errs=[];
p.on('pageerror',e=>errs.push(e.message));
let dialogs=[]; p.on('dialog',async d=>{ dialogs.push(d.message()); await d.accept(); });
await p.emulateTimezone('America/New_York');
await p.setViewport({width:1366,height:768});

await p.goto(URL,{waitUntil:'networkidle0'}); await new Promise(r=>setTimeout(r,1500));
const R=[]; const rec=(n,ok,d='')=>R.push({n,ok:!!ok,d:typeof d==='string'?d:JSON.stringify(d)});

/* ---------------- reported bug: Ctrl+scroll sizing ---------------- */
const size=await p.evaluate(()=>{
  DB=demoDB(); show('board');
  const box=document.querySelector('#wallFit');
  const before=Math.round(box.getBoundingClientRect().width);
  enterWall(); exitWall();
  return { before, after:Math.round(box.getBoundingClientRect().width),
    page:Math.round(document.querySelector('#scr-board').getBoundingClientRect().width),
    w:box.style.width, h:box.style.height, t:box.style.transform };
});
rec('sizing bug: leaving screenshot view clears every inline size', !size.w && !size.h && !size.t, size);
rec('sizing bug: board returns to its exact width', size.after===size.before && size.after<=size.page, size);

const sizeChange=await p.evaluate(()=>{
  const widths=[];
  ['s','m','l','xl','m'].forEach(h=>{ SETTINGS.chartH=h; show('board');
    widths.push(Math.round(document.querySelector('#boardGrid').getBoundingClientRect().width)); });
  return widths;
});
rec('changing chart size never changes board width', new Set(sizeChange).size===1, sizeChange);

/* ---------------- reported bug: line disappears after PM ---------------- */
const pmLine=await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'M',name:'M',group:'Photo',active:true,pmIntervalDays:30,pmLeadDays:5});
  DB.parameters.push({id:'M::p',machineId:'M',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
  for(let i=20;i>=0;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'M::p',value:2+(20-i)*0.3});
  DB.pmEvents=[{id:'a',date:todayISO(),machineId:'M'}];          // PM today, one reading after it
  DB.readings[DB.readings.length-1].value=2.0;                     // the reset drop
  SETTINGS.dotMode='all';
  const a=assess(DB.parameters[0]);
  const svg=tileChart(a,45,false);
  const dots=(svg.match(/<circle/g)||[]).length;
  const connector=/stroke-dasharray="1.5 2.5"/.test(svg);
  const full=trendChart(a,0);
  return { readings:a.all.length, dots, connector, fullConnector:/<title>Reset<\/title>/.test(full) };
});
rec('every reading gets a dot, so a lone post-PM reading is visible', pmLine.dots>=pmLine.readings, pmLine);
rec('the drop across a PM is drawn as a reset connector', pmLine.connector && pmLine.fullConnector, pmLine);

/* ---------------- masonry ---------------- */
const mas=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.chartMode='separate'; SETTINGS.cols='4'; show('board');
  const tiles=[...document.querySelectorAll('#boardGrid > .tile')];
  // no tile is stretched: its height equals its own content
  const stretched=tiles.filter(t=>{
    const kids=[...t.children]; const inner=kids.reduce((s,k)=>s+k.getBoundingClientRect().height,0);
    return t.getBoundingClientRect().height - inner > 6;
  }).length;
  // no two tiles overlap
  let overlap=0;
  for(let i=0;i<tiles.length;i++) for(let j=i+1;j<tiles.length;j++){
    const a=tiles[i].getBoundingClientRect(), c=tiles[j].getBoundingClientRect();
    if(a.left<c.right-1 && c.left<a.right-1 && a.top<c.bottom-1 && c.top<a.bottom-1) overlap++;
  }
  const heights=tiles.map(t=>Math.round(t.getBoundingClientRect().height));
  return { tiles:tiles.length, stretched, overlap, minH:Math.min(...heights), maxH:Math.max(...heights) };
});
rec('masonry: no tile is stretched by a taller neighbour', mas.stretched===0, mas);
rec('masonry: no tiles overlap', mas.overlap===0, mas);
rec('masonry: one- and two-parameter tiles keep different heights', mas.maxH>mas.minH*1.3, mas);

/* ---------------- combined chart ---------------- */
const comb=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.chartMode='combined'; SETTINGS.cols='auto'; show('board');
  const multi=machineRollup(assessVisible()).filter(x=>x.rows.length>1);
  const tile=document.querySelector('.tile[data-m="'+multi[0].m.id+'"]');
  const charts=tile.querySelectorAll('.well svg').length;
  const legendRows=tile.querySelectorAll('.cl').length;
  const svg=tile.querySelector('.well svg').outerHTML;
  const has100=/>100%</.test(svg);
  const legendVal=tile.querySelector('.cl .cv').textContent;
  const realVal=num(multi[0].rows[0].value);
  // series colours must stay clear of the alarm colours
  const alarm=[COL.thr.toLowerCase(),COL.warn.toLowerCase()];
  const clash=COL.series.filter(c=>alarm.indexOf(c.toLowerCase())>=0);
  return { charts, legendRows, params:multi[0].rows.length, has100, legendVal, realVal, clash };
});
rec('combined: one chart for a multi-parameter machine', comb.charts===1, comb);
rec('combined: one legend row per parameter', comb.legendRows===comb.params, comb);
rec('combined: indexed scale with the limit at 100%', comb.has100, comb);
rec('combined: legend shows the real value, not the index', comb.legendVal.indexOf(comb.realVal)===0, comb);
rec('combined: series colours never reuse an alarm colour', comb.clash.length===0, comb);

const indexMath=await p.evaluate(()=>{
  const up={threshold:10,warn:8,bound:'upper',id:'u',machineId:'x',_base:2};
  const lo={threshold:20,warn:26,bound:'lower',id:'l',machineId:'x',_base:40};
  return { upAtBase:approach(up,2), upAtLimit:approach(up,10), loAtBase:approach(lo,40), loAtLimit:approach(lo,20) };
});
rec('index: 0% at baseline and 100% at limit, rising or falling',
  indexMath.upAtBase===0 && indexMath.upAtLimit===100 && indexMath.loAtBase===0 && indexMath.loAtLimit===100, indexMath);

/* ---------------- activities ---------------- */
const act=await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'S',name:'CD-SEM',group:'Metrology',active:true,pmIntervalDays:60,pmLeadDays:5});
  DB.parameters.push({id:'S::beam',machineId:'S',name:'Beam',unit:'%',threshold:10,warn:8,bound:'upper'});
  DB.parameters.push({id:'S::stage',machineId:'S',name:'Stage',unit:'nm',threshold:10,warn:8,bound:'upper'});
  DB.pmEvents.push({id:'pm',date:addDays(todayISO(),-30),machineId:'S'});
  for(let i=29;i>=0;i--){
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'S::beam',value:2+(29-i)*0.2});
    DB.readings.push({date:addDays(todayISO(),-i),paramId:'S::stage',value:2+(29-i)*0.1});
  }
  const beamBefore=assess(DB.parameters[0]), stageBefore=assess(DB.parameters[1]);
  const schedBefore=pmSchedule(machineById('S'));
  DB.paramEvents.push({id:'f1',date:addDays(todayISO(),-10),paramId:'S::beam',type:'Filament change'});
  DB.parameters.forEach(x=>delete x._base);
  const beamAfter=assess(DB.parameters[0]), stageAfter=assess(DB.parameters[1]);
  const schedAfter=pmSchedule(machineById('S'));
  const svg=tileChart(beamAfter,45,false);
  return {
    beamSegBefore:beamBefore.seg[0].date, beamSegAfter:beamAfter.seg[0].date, actDate:addDays(todayISO(),-10),
    stageSegBefore:stageBefore.seg[0].date, stageSegAfter:stageAfter.seg[0].date,
    pmBefore:schedBefore.next, pmAfter:schedAfter.next, resetKind:beamAfter.resetKind,
    marker:/Filament change on/.test(svg), cycles:pmCycles('S').length
  };
});
rec('activity restarts that parameter\u2019s trend', act.beamSegAfter===act.actDate, act);
rec('activity leaves the other parameter alone', act.stageSegBefore===act.stageSegAfter, act);
rec('activity leaves the machine PM countdown alone', act.pmBefore===act.pmAfter, act);
rec('activity is recorded as the reset type', act.resetKind==='act', act);
rec('activity marker is drawn on the chart', act.marker, act);
rec('activity does not create a PM cycle', act.cycles===1, act);

const actUI=await p.evaluate(()=>{
  show('entry');
  const btns=document.querySelectorAll('[data-act-log]').length;
  document.querySelector('[data-act-log]').click();
  const dlg=!!document.querySelector('#aType');
  document.querySelector('#aType').value='Lamp replacement';
  const n=DB.paramEvents.length;
  document.querySelector('#mSave').click();
  const added=DB.paramEvents.length===n+1;
  document.querySelector('#machinePick').value='S'; show('machine');
  const listed=document.querySelectorAll('[data-delact]').length;
  show('report');
  const inReport=/Parameter activities/.test(document.querySelector('#reportBody').innerText);
  return {btns, dlg, added, listed, inReport};
});
rec('activity button on every entry row', actUI.btns===2, actUI);
rec('activity dialog logs a new activity', actUI.dlg && actUI.added, actUI);
rec('activities listed on machine detail', actUI.listed===2, actUI);
rec('activities appear in the monthly report', actUI.inReport, actUI);

/* ---------------- notifications ---------------- */
const bell=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.acks={}; saveSettings(); show('board');
  const all=computeAlerts();
  const open=all.filter(x=>!x.acked && x.sev!=='info').length;
  const badge=+document.querySelector('#bellCount').textContent;
  const boardHasAlerts=!!document.querySelector('#scr-board .alerts');
  toggleBell();
  const panelOpen=!document.querySelector('#bellPanel').hidden;
  const items=document.querySelectorAll('.bellitem').length;
  document.querySelector('[data-ack]').click();
  const badge2=+document.querySelector('#bellCount').textContent;
  document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));
  const closed=document.querySelector('#bellPanel').hidden;
  return {open, badge, boardHasAlerts, panelOpen, items, badge2, closed};
});
rec('bell count equals unacknowledged alerts', bell.badge===bell.open, bell);
rec('alerts no longer stack on the board', !bell.boardHasAlerts, bell);
rec('bell panel lists every alert', bell.panelOpen && bell.items>=bell.open, bell);
rec('acknowledging lowers the count by one', bell.badge2===bell.badge-1, bell);
rec('Esc closes the panel', bell.closed, bell);

const reAlert=await p.evaluate(()=>{
  DB=blankDB();
  DB.machines.push({id:'W',name:'W',group:'Photo',active:true});
  DB.parameters.push({id:'W::p',machineId:'W',name:'p',unit:'',threshold:10,warn:8,bound:'upper'});
  for(let i=10;i>=1;i--) DB.readings.push({date:addDays(todayISO(),-i),paramId:'W::p',value:8.5});
  DB.readings.push({date:todayISO(),paramId:'W::p',value:8.5});
  SETTINGS.acks={};
  computeAlerts().forEach(x=>SETTINGS.acks[x.key]=todayISO());
  const silenced=computeAlerts().every(x=>x.acked);
  DB.readings[DB.readings.length-1].value=11;          // worsens to at-limit
  const worse=computeAlerts().filter(x=>!x.acked && x.sev==='crit').length;
  DB.readings.forEach(r=>r.value=3);                   // clears completely
  computeAlerts();
  const pruned=Object.keys(SETTINGS.acks).length;
  return {silenced, worse, pruned};
});
rec('acknowledged alerts stay silent while unchanged', reAlert.silenced, reAlert);
rec('an alert that worsens comes back', reAlert.worse===1, reAlert);
rec('acknowledgements for cleared conditions are pruned', reAlert.pruned===0, reAlert);

/* ---------------- collapsible rail ---------------- */
const rail=await p.evaluate(()=>{
  DB=demoDB(); SETTINGS.railCollapsed=false; applyTheme(); show('board');
  const wide=Math.round(document.querySelector('.rail').getBoundingClientRect().width);
  document.querySelector('#railToggle').click();
  return new Promise(r=>setTimeout(()=>r({wide,
    narrow:Math.round(document.querySelector('.rail').getBoundingClientRect().width),
    labelsHidden:getComputedStyle(document.querySelector('.nav .nl')).display==='none',
    iconsShown:document.querySelectorAll('.nav .ni').length}),300));
});
rec('rail collapses to icons', rail.narrow<70 && rail.wide>200 && rail.labelsHidden && rail.iconsShown===10, rail);
await p.reload({waitUntil:'networkidle0'}); await new Promise(r=>setTimeout(r,1300));
const railPersist=await p.evaluate(()=>({collapsed:SETTINGS.railCollapsed, cls:document.body.classList.contains('railmin')}));
rec('rail stays collapsed after reload', railPersist.collapsed && railPersist.cls, railPersist);
await p.evaluate(()=>{ SETTINGS.railCollapsed=false; saveSettings(); applyTheme(); });

/* ---------------- themes ---------------- */
const themes=await p.evaluate(()=>{
  function lum(hex){ hex=hex.replace('#',''); if(hex.length===3) hex=hex.split('').map(c=>c+c).join('');
    const v=[0,2,4].map(i=>parseInt(hex.substr(i,2),16)/255).map(c=>c<=.03928?c/12.92:Math.pow((c+.055)/1.055,2.4));
    return .2126*v[0]+.7152*v[1]+.0722*v[2]; }
  function ratio(a,b){ const x=lum(a), y=lum(b); return (Math.max(x,y)+.05)/(Math.min(x,y)+.05); }
  const out={};
  THEMES.forEach(t=>{
    SETTINGS.theme=t; applyTheme(); refreshChartColors(); DB=demoDB(); show('board');
    const cs=getComputedStyle(document.documentElement);
    const g=n=>cs.getPropertyValue(n).trim();
    out[t]={ ink:+ratio(g('--ink'),g('--surface')).toFixed(1), ink2:+ratio(g('--ink-2'),g('--surface')).toFixed(1),
             crit:+ratio(g('--crit'),g('--surface')).toFixed(1), trace:COL.trace,
             tiles:document.querySelectorAll('.tile').length };
  });
  SETTINGS.theme='graphite'; applyTheme(); refreshChartColors();
  return out;
});
Object.keys(themes).forEach(t=>{
  const x=themes[t];
  rec(`theme ${t}: body text contrast at least 7:1 (AAA)`, x.ink>=7, x);
  rec(`theme ${t}: secondary text at least 4.5:1 (AA)`, x.ink2>=4.5, x);
  rec(`theme ${t}: alarm colour readable, at least 3:1`, x.crit>=3, x);
});
rec('themes: charts repaint in each theme', new Set(Object.values(themes).map(x=>x.trace)).size>=5, themes);
const oldId=await p.evaluate(()=>{ SETTINGS.theme='dark'; applyTheme(); const r=SETTINGS.theme; SETTINGS.theme='graphite'; applyTheme(); return r; });
rec('themes: an old saved theme id still maps to a new one', oldId==='control', oldId);
const gallery=await p.evaluate(()=>{
  themeGallery();
  const cards=document.querySelectorAll('[data-theme-pick]').length;
  document.querySelector('[data-theme-pick="blueprint"]').click();
  const live=document.documentElement.getAttribute('data-theme');
  document.querySelector('#mCancel').click();
  return {cards, live, reverted:document.documentElement.getAttribute('data-theme')};
});
rec('theme gallery shows all seven, previews live, Cancel reverts',
  gallery.cards===7 && gallery.live==='blueprint' && gallery.reverted==='graphite', gallery);

/* ---------------- guide ---------------- */
const guide=await p.evaluate(()=>{
  show('guide');
  const lanes=document.querySelectorAll('.glane').length;
  document.querySelector('[data-g="tasks"]').click();
  const tasks=document.querySelectorAll('.gtask').length;
  const f=document.querySelector('#taskFind'); f.value='filament'; f.dispatchEvent(new Event('input'));
  const matched=[...document.querySelectorAll('.gtask')].filter(t=>!t.hidden).length;
  f.value='zzzz'; f.dispatchEvent(new Event('input'));
  const noneShown=!document.querySelector('#taskNone').hidden;
  f.value=''; f.dispatchEvent(new Event('input'));
  document.querySelector('.gtask [data-go="pm"]').click();
  const went=screen;
  show('guide'); document.querySelector('[data-g="marks"]').click();
  const marks=document.querySelectorAll('.gsym > div').length;
  document.querySelector('[data-g="about"]').click();
  const about=/PM Tracker/.test(document.querySelector('#guideBody').innerText);
  return {lanes,tasks,matched,noneShown,went,marks,about};
});
rec('guide: four workflow lanes on the map', guide.lanes===4, guide);
rec('guide: task finder lists 30 tasks', guide.tasks===30, guide);
rec('guide: searching narrows the list', guide.matched>=1 && guide.matched<5, guide);
rec('guide: a search with no match says so', guide.noneShown, guide);
rec('guide: Go jumps to the right screen', guide.went==='pm', guide);
rec('guide: every mark explained', guide.marks>=12, guide);
rec('guide: about page renders', guide.about, guide);

/* ---------------- folder save (real code, private file system) ---------------- */
dialogs=[];
const folder=await p.evaluate(async()=>{
  const root=await navigator.storage.getDirectory();
  for await (const e of root.values()) await root.removeEntry(e.name,{recursive:true});
  DB=demoDB(); markClean();
  FOLDER.handle=root; FOLDER.name='data'; FOLDER.state='connected'; FOLDER.file=''; FOLDER.loadedMod=0;
  const names=async()=>{ const n=[]; for await (const e of root.values()) n.push(e.name); return n.sort(); };

  await saveToFolder(false);
  const first=await names();
  const fileA=FOLDER.file;
  DB.readings.push({date:todayISO(),paramId:DB.parameters[0].id,value:12345,by:'qa'}); markDirty();
  await saveToFolder(false);
  const second=await names();
  const content=JSON.parse(await (await (await root.getFileHandle(fileA)).getFile()).text());
  const kept=content.readings.some(r=>r.value===12345);
  const bdir=await root.getDirectoryHandle('backups');
  const backups=[]; for await (const e of bdir.values()) backups.push(e.name);
  const latest=await (await (await root.getFileHandle('latest.js')).getFile()).text();

  // reload from the folder: newest data wins
  DB=blankDB();
  const r=await loadFromFolder();
  const reloaded=DB.readings.some(x=>x.value===12345);
  return { first, second, fileA, sameFile:FOLDER.file===fileA, kept, backups, latestOK:/PM_AUTOLOAD/.test(latest),
           reloaded, loadedName:r.name, clean:!dirty };
});
rec('folder: first save creates one dated data file', folder.first.filter(n=>/^pm-data-/.test(n)).length===1, folder);
rec('folder: second save updates the SAME file in place', folder.sameFile && folder.second.filter(n=>/^pm-data-/.test(n)).length===1, folder);
rec('folder: the update actually lands in that file', folder.kept, folder);
rec('folder: a dated daily backup is kept', folder.backups.length===1 && /pm-data-\d{4}-\d{2}-\d{2}\.json/.test(folder.backups[0]), folder);
rec('folder: latest.js is kept in step for auto-load', folder.latestOK, folder);
rec('folder: opening loads the newest file', folder.reloaded && folder.loadedName===folder.fileA, folder);
rec('folder: saving clears the unsaved flag', folder.clean, folder);

dialogs=[];
const conflict=await p.evaluate(async()=>{
  const root=FOLDER.handle;
  await new Promise(r=>setTimeout(r,1300));
  // someone else writes the same file after we opened it
  const fh=await root.getFileHandle(FOLDER.file);
  const w=await fh.createWritable(); await w.write(JSON.stringify(Object.assign({},DB,{meta:{site:'someone else'}}))); await w.close();
  DB.meta.site='me'; markDirty();
  await saveToFolder(false);
  return true;
});
await new Promise(r=>setTimeout(r,200));
rec('folder: warns before overwriting someone else\u2019s save', dialogs.some(m=>/changed by someone else/.test(m)), dialogs);

const newFile=await p.evaluate(async()=>{
  const root=FOLDER.handle; const before=FOLDER.file;
  await new Promise(r=>setTimeout(r,1100));
  await saveAsNewFile();
  const n=[]; for await (const e of root.values()) if(/^pm-data-/.test(e.name)) n.push(e.name);
  return {before, after:FOLDER.file, count:n.length};
});
rec('folder: Save as new file starts a second dated file', newFile.count===2 && newFile.after!==newFile.before, newFile);

const quick=await p.evaluate(()=>({ label:document.querySelector('#quickSave').textContent,
  state:document.querySelector('#folderState').className }));
rec('folder: top bar shows Save and the connected folder', quick.label==='Save' && /\bon\b/.test(quick.state), quick);

/* ---------------- latent bug: unsaved work dropped when auto-load is used ---------------- */
const draft=await p.evaluate(async()=>{
  DB=demoDB(); DB.meta.savedAt=new Date(Date.now()-3600e3).toISOString();
  const saved=JSON.parse(JSON.stringify(DB));
  DB.readings.push({date:todayISO(),paramId:DB.parameters[0].id,value:777,by:'qa'});
  saveDraft();                                   // newer unsaved work
  DB=saved;                                      // the older file opens
  document.querySelector('#modalHost').innerHTML='';
  offerDraftIfNewer();
  await new Promise(r=>setTimeout(r,600));
  const offered=/Unsaved work found/.test(document.querySelector('#modalHost').innerText);
  document.querySelector('#mSave').click();
  return { offered, restored:DB.readings.some(r=>r.value===777) };
});
rec('unsaved work newer than the opened file is offered back', draft.offered, draft);
rec('restoring brings that work back', draft.restored, draft);

/* ---------------- screenshot view still fills the screen ---------------- */
const wall=await p.evaluate(()=>new Promise(res=>{
  DB=demoDB(); SETTINGS.chartMode='combined'; SETTINGS.chartH='m'; SETTINGS.cols='auto'; show('board'); enterWall();
  setTimeout(()=>{ const box=document.querySelector('#wallFit');
    const bar=document.querySelector('.wallbar').getBoundingClientRect().height;
    const used=box.getBoundingClientRect().height+bar;
    const r={ fits:document.body.scrollHeight<=window.innerHeight+2, fill:Math.round(used/window.innerHeight*100),
      tiles:document.querySelectorAll('.tile').length };
    exitWall(); res(r); },400);
}));
rec('screenshot view: whole fleet, no scrolling', wall.fits && wall.tiles===16, wall);

for (const vp of [[1366,768],[1920,1080],[1280,720]]){
  await p.setViewport({width:vp[0],height:vp[1]});
  const wm=await p.evaluate(()=>new Promise(res=>{
    DB=demoDB(); SETTINGS.chartMode='combined'; show('board'); enterWall();
    setTimeout(()=>{
      const tiles=[...document.querySelectorAll('#boardGrid > .tile')].map(t=>t.getBoundingClientRect());
      let overlap=0, tight=0;
      for(let i=0;i<tiles.length;i++) for(let j=0;j<tiles.length;j++){ if(i===j) continue;
        const a=tiles[i], c=tiles[j];
        const sameCol=Math.abs(a.left-c.left)<2;
        if(a.left<c.right-1 && c.left<a.right-1 && a.top<c.bottom-1 && c.top<a.bottom-1) overlap++;
        if(sameCol && c.top>=a.top && c.top-a.bottom<2) tight++;
      }
      const box=document.querySelector('#wallFit');
      const scale=box.style.transform;
      const dbg={wallClass:document.body.classList.contains('wall'), width:box.style.width,
        boxH:Math.round(box.getBoundingClientRect().height), vh:innerHeight, screen,
        boardHidden:document.querySelector('#scr-board').hidden, tiles:tiles.length};
      exitWall(); res({overlap,tight,scale,dbg});
    },400);
  }));
  rec(`screenshot view ${vp[0]}x${vp[1]}: still in screenshot view and scaled`, wm.dbg.wallClass && wm.scale!=='', wm);
  rec(`screenshot view ${vp[0]}x${vp[1]}: tiles never overlap or touch`, wm.overlap===0 && wm.tight===0, wm);
}
await p.setViewport({width:1366,height:768});

const race=await p.evaluate(()=>new Promise(res=>{
  DB=demoDB(); show('board');
  enterWall(); exitWall(); enterWall();           // close and reopen in quick succession
  /* simulate the late event from the first exit arriving now */
  document.dispatchEvent(new Event('fullscreenchange'));
  setTimeout(()=>{ const still=document.body.classList.contains('wall'); exitWall(); res({still}); },300);
}));
rec('screenshot view survives a quick close-and-reopen', race.still, race);

const pass=R.filter(x=>x.ok).length, fail=R.filter(x=>!x.ok);
console.log(`\nV2 SUITE — ${pass}/${R.length} passed`);
if(fail.length){ console.log('\nFAILURES:'); fail.forEach(f=>console.log('  x '+f.n+'\n      '+f.d)); }
console.log(errs.length?'\nRUNTIME ERRORS:\n  '+errs.join('\n  '):'\nNo runtime errors.');
await b.close(); process.exit(fail.length?1:0);
})();
