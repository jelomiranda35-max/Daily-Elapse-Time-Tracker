# PM Tracker

A single-screen status board for preventive-maintenance parameter monitoring.
It replaces the Excel chart sheet and the screenshot-to-the-team routine.

Nothing to install. No dependencies, no build step, no server. Plain HTML, CSS and
JavaScript that runs from a file on the shared drive.

**Version 2.0** · file format 1 · 342 automated checks

---

## Contents

1. [Start here](#start-here)
2. [What changed in 2.0](#what-changed-in-20)
3. [Install](#install)
4. [Saving: connect the folder once](#saving-connect-the-folder-once)
5. [Daily routine](#daily-routine)
6. [Finding your way around](#finding-your-way-around)
7. [Reading the board](#reading-the-board)
8. [Combined charts](#combined-charts)
9. [Notifications](#notifications)
10. [Laying out the board](#laying-out-the-board)
11. [What the charts show](#what-the-charts-show)
12. [Themes](#themes)
13. [How PM works](#how-pm-works)
14. [Parameter activities](#parameter-activities)
15. [Entering readings, and undoing them](#entering-readings-and-undoing-them)
16. [Editing limits from a tile](#editing-limits-from-a-tile)
17. [Importing from Excel](#importing-from-excel)
18. [Capacity](#capacity)
19. [Repository layout](#repository-layout)
20. [Updating the app](#updating-the-app)
21. [Privacy](#privacy)
22. [Troubleshooting](#troubleshooting)
23. [Design notes](#design-notes)
24. [Testing](#testing)

---

## Start here

1. Open `index.html` in **Chrome or Edge**.
2. Top bar → **Connect data folder** → pick the `data` folder beside `index.html` →
   choose **Allow on every visit**.
3. **Guide & about** in the side panel shows where everything is. Its **I want to…**
   tab has a search box: type what you are trying to do.

That is all the setup there is. From then on the app opens your newest data file by
itself, and **Save** (or <kbd>Ctrl</kbd>+<kbd>S</kbd>) writes straight back into it.

---

## What changed in 2.0

| You asked for | What it does now |
|---|---|
| Save should update the most recent file | Connect the data folder once. Opening loads the newest file; Save updates it in place. No downloads, nothing to move. |
| Themes with character | Seven themes, each from a real place in a fab: Graphite, ISA-101, Control Room, Yellow Room, Blueprint, Engineering Pad, High Contrast. |
| A guide, because it was hard to navigate | **Guide & about**: a map of four workflows, a searchable task finder, a key to every mark, and an About page. |
| Machines with one parameter stretching beside machines with many | Masonry layout: each tile is its own height and packs into the shortest column. Nothing stretches. |
| Sizes drifting until Ctrl+scroll | Fixed. Leaving screenshot view left the board at 156% width until a resize event. |
| A collapsible side panel | The ‹ arrow at its top collapses it to icons. Remembered. |
| Notifications taking up the screen | Moved behind a bell with a count. Each one can be opened or acknowledged. |
| All of a machine's trends on one chart | **Combined** charts, on a % of limit scale with real values in the legend. |
| Filament changes affecting one parameter | **Activities**: logged per parameter, restart that parameter's trend only. |
| The line disappearing after a PM | Fixed. Every reading now has a dot, and the drop across a PM is drawn. |

**Bugs found and fixed along the way**, none of which you reported:

- **Unsaved work could be silently lost.** When the app auto-loaded `latest.js`, it
  skipped checking for unsaved work from a closed tab. It now offers that work back
  whenever it is newer than the file that opened.
- **Clicking a tile on a fresh load opened the wrong machine.** Every tile,
  notification and Analysis row opened the *first* machine until you had visited
  Machine detail once. Present since version 1.
- **Healthy chart lines could look like alarms.** In several themes the second
  series colour was red, orange or yellow. Series colours now never use an alarm hue.
- **A damaged data file could lock you out.** If the newest file in the folder could
  not be read, the app now opens the next good one and tells you which it skipped.
- **Deleting a parameter left its activities orphaned**, and **Export to Excel
  left activities out**. Both fixed.

**A correction.** Earlier I said a page opened from a file cannot write to a folder.
That was wrong for current Chrome and Edge: a `file://` page counts as a secure
context there, so the File System Access API works. That is what makes in-place
saving possible.

---

## Install

No admin rights and nothing to install.

1. On the GitHub repo page: **Code → Download ZIP**
2. Right-click the ZIP → **Extract All**
3. Copy the `pm-tracker` folder to the shared drive, e.g. `\\PC-ENG-01\shared\pm-tracker\`
4. Open `index.html` in Chrome or Edge, and [connect the folder](#saving-connect-the-folder-once)

Make a desktop shortcut: right-click `index.html` → **Send to → Desktop (create
shortcut)**. If Windows opens it in another browser, right-click the shortcut →
**Open with → Chrome**.

> **If the page loads but looks unstyled,** group policy is blocking scripts from a
> network location. Copy the folder to `C:\PM-Tracker\` on each PC instead, and
> connect that PC to the shared `data` folder. Saving still goes to the shared drive.

---

## Saving: connect the folder once

**Top bar → Connect data folder**, or **Save, load & import → step 1**.

Pick the `data` folder beside `index.html`. When Chrome asks, choose **Allow on every
visit**. Then:

| When you… | The app… |
|---|---|
| open it | loads the most recently saved `pm-data-*.json` in the folder |
| press Save or <kbd>Ctrl</kbd>+<kbd>S</kbd> | writes your changes into that same file |
| save for the first time each day | first copies the file as it was into `backups/pm-data-YYYY-MM-DD.json` |
| save after someone else saved | asks before replacing their changes |
| find the newest file damaged | opens the next good one and names the one it skipped |

The pill top-left says whether everything is saved. Beside it, the folder chip shows
which file you are writing to.

### Safety details

**Writes are atomic.** The browser writes to a temporary copy and swaps it in when
finished, so a crash or network drop mid-save cannot leave a half-written file.

**One backup a day, automatically.** Because saving overwrites in place, the first
save of each day copies the previous version into `backups/` first. A bad day's
edits can always be undone from yesterday's copy.

**Two people, one file.** The app remembers when it opened the file. If the file
changed on disk since then, Save stops and asks. Cancel keeps their version; reload
to see it. The simplest habit is still that one person owns entry each day.

**Starting fresh.** *Save as new file* begins a new dated file — for example at the
start of a month — and leaves the old one untouched. Opening always picks whichever
file was saved most recently, whatever its name.

### When Chrome asks again

If the folder chip turns amber and says **Reconnect**, Chrome needs one click to let
the app use the folder again. That happens if *Allow on every visit* was not chosen,
or Chrome cleared site permissions. Click it, or press Save, which reconnects first.

### Without a folder

If the browser cannot connect to a folder, or you would rather not, saving falls back
to downloads. Save produces two files — a dated `pm-data-*.json` and `latest.js` —
which you move into `data`. `Open PM Tracker.bat` moves them for you the next time
you open the app with it. `latest.js` is what lets the app open your data by itself
without a connected folder.

---

## Daily routine

1. Open the app. Your newest file loads by itself.
2. **Log readings**: check the date, type your initials, enter today's values.
   Tick **PM done** on any machine serviced today.
3. **Save these readings**, then **Save** in the top bar (or <kbd>Ctrl</kbd>+<kbd>S</kbd>).
4. **Status board → Screenshot view** → <kbd>Win</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> →
   paste to the team. <kbd>Esc</kbd> or the round **✕** to come back.
5. Glance at the bell. Anything red needs action today.

If the tab closes before you save, reopen it: work newer than your file is offered back.

---

## Finding your way around

**Guide & about** (the last item in the side panel) has four tabs:

| Tab | Use it for |
|---|---|
| **Map** | Four workflows — every day, when something looks wrong, each week or month, setting up — each a path through the tabs. Click any step to go there. |
| **I want to…** | Thirty common jobs with where to do them. Search box: try "filament", "undo", "Excel", "PM". |
| **What the marks mean** | Every colour, line, flag and label, drawn in your current theme. Plus keyboard shortcuts. |
| **About** | Where your data came from, when it was last saved, how saving works on this PC, and how the app decides trends and days left. |

The side panel groups the tabs the same way: the daily tabs at the top, analysis in
the middle, setup at the bottom.

---

## Reading the board

| What you see | What it means |
|---|---|
| Green edge, **Normal** | Comfortable margin |
| Amber edge, **Warning** | Past the warn level. Plan work. |
| Red edge, **At limit** | Reached the limit. Act now. |
| Grey band | The normal range: from the healthy level after the last reset up to the warn level. The line leaving it is the signal. |
| Red dashed line | The limit it must not reach |
| Amber dashed line | The warn level |
| Dot-line | A dot for every reading, joined in date order — as in the old Excel sheet |
| Blue flag | A machine PM. The trend restarts there. |
| Violet diamond | An activity on that one parameter, such as a filament change |
| Faint dotted segment | The drop across a reset. Shows the reset happened rather than leaving a gap. |
| Boxed number | The most recent reading |
| Dates along the bottom | Every 6 days, anchored on the latest reading |
| "6d left" | When the trend since the last reset reaches the limit at its current rate |
| "PM reset" | Just serviced. About three readings are needed before a trend is drawn. |

---

## Combined charts

**Status board → Parameters: Combined** (the default).

A machine with two or more parameters gets one chart holding every trend. Parameters
have different units, and some fall toward their limit while others rise, so they
cannot share a raw axis. A second axis would invite misreading — when two scales
are overlaid, crossings and slopes depend on how each scale happens to be set.

So every trace is drawn on the same **indexed** scale instead:

- **0%** — the healthy level after the last reset
- **100%** — the limit, marked with the red dashed line

That works the same for a reading that rises to its limit and one that falls to it,
and the reference points are meaningful rather than arbitrary. The legend under the
chart carries each parameter's **real value and unit**, its % of limit, and its
status. Each trace has its own colour *and* dash pattern, so they stay distinct when
printed in greyscale.

Single-parameter machines keep their own units and full readout. **Separate** gives
every parameter its own chart in its own units.

---

## Notifications

The bell, top right. The badge counts what needs attention.

| Group | What lands there |
|---|---|
| **Act now** | At the limit; reaching the limit within 7 days; PM overdue |
| **Plan work** | Reaching the limit within 14 days; past the warn level; PM due within its reminder window |
| **Worth a look** | Moving unusually fast for its own normal behaviour; not read for over three days |

Click any notification to open that machine. **Ack** silences one; **Acknowledge
all** silences everything showing.

Acknowledging follows alarm-management practice: it silences the *notification*,
not the condition. An acknowledgement is tied to severity, so a warning that worsens
to at-limit comes back as a new notification. Acknowledgements for conditions that
have cleared are removed automatically. *Show acknowledged* lists the silenced ones.

---

## Laying out the board

Everything here is in the toolbar above the board, and remembered on each PC.

| Control | Effect |
|---|---|
| Group chips | Photo, Vacuum, Metrology, or all |
| Sort | By risk, name or group |
| Columns | Auto, or force 2 to 6 |
| Chart size | S, M, L, XL. L and XL add value gridlines. |
| Parameters | Combined or Separate |
| Days | 30, 45, 60, 90 or all history on each tile |
| Chart content | What each chart draws — see below |
| ‹ on the side panel | Collapses it to icons for another column of tiles |

**Tiles pack like masonry.** Each tile is exactly as tall as its own content and goes
into whichever column is currently shortest, so a one-parameter machine never
stretches to match a three-parameter neighbour. Riskiest machines still lead, top left.

**Screenshot view** hides every control, goes fullscreen, and scales the board so the
whole fleet lands on one screen. Checked with 16 and with 48 machines.

---

## What the charts show

**Chart content**, in the board toolbar. Three tabs.

**Inside the chart**

| Option | Effect |
|---|---|
| Machines with more than one parameter | Combined, or separate charts |
| Vertical scale | *Always show the limit* (safest) · *Fit the readings* (magnifies small drift) · *Start at zero* |
| Dots on the line | Every reading (dot-line) · warning and limit readings only · none |
| Normal-range band, limit line, warn line | Each switchable |
| Value label | The boxed latest reading |
| Reset markers | PM flags and activity diamonds |
| Projection | The dashed run-out to the limit, on full-size charts |

*Fit the readings* makes a gentle drift several times taller on screen. When that
pushes the limit outside the chart, the chart prints **limit off-chart** in red, so a
missing line is never mistaken for a safe one.

**Around the chart** — the progress bar, the PM footer, the summary figures.

**Which parameters** — hide any parameter from the board and trend charts. It keeps
its readings and still appears in reports and machine detail.

---

## Themes

**Theme**, top right. Each card previews itself in its own colours; click to try one,
**Cancel** to go back.

| Theme | Grounded in | Its character |
|---|---|---|
| **Graphite** | The default | Crisp and neutral. Best for screenshots pasted into email or chat. |
| **ISA-101** | The high-performance HMI standard | Everything grey. Colour appears *only* when something alarms, so an alarm cannot be missed. |
| **Control Room** | A SCADA console at night | Deep navy, cyan instrument edges. Low glare. |
| **Yellow Room** | The lithography bay | Lit amber, as photo bays are so photoresist is not exposed. Warning stays burnt orange with its diamond shape so it never blends into the room light. |
| **Blueprint** | An engineering drawing | Prussian blue with a drafting grid, white linework. |
| **Engineering Pad** | Green gridded computation paper | Graph-paper board, ink-blue traces, pencil-red alarms. |
| **High Contrast** | Projectors and tired eyes | Black on white, heavy strokes, no shading. |

Numbers use **Bahnschrift** in every theme — Microsoft's DIN-derived face, the
lettering of industrial signage and instrument panels, already on every Windows
10+ PC.

Every theme was checked for body-text contrast of at least 7:1 (WCAG AAA), and for
chart series colours that could be mistaken for red, amber or green.

---

## How PM works

**Logging a PM does two things at once:**

1. **Restarts the countdown.** Next due becomes the PM date plus the interval.
2. **Resets the trend.** Slope, projection and days left are computed only on
   readings since the last reset.

The second matters. A trend fitted across a PM would average the rise before and the
drop after into a falsely flat, reassuring line, so the app never crosses a reset.

**Right after a PM** there are not enough new readings to fit a line, so the tile
says **PM reset** rather than guessing. The chart still shows every reading as a dot,
and draws the drop across the PM as a faint dotted segment.

**Log a PM from** the PM done box on Log readings, the ✎ on a tile, the PM schedule,
or Machines & limits. Backdating works everywhere.

**PM schedule** shows every countdown, and after a few cycles compares each
interval with how long the machine actually holds before reaching its warn level —
suggesting a shorter interval, or one that could be stretched.

---

## Parameter activities

Some work changes how one parameter behaves without being a machine PM: a **filament
change** resets a CD-SEM's beam current, a **lamp swap** resets intensity, a
**recalibration** shifts a baseline.

Logging one restarts the trend and healthy baseline for **that parameter only**. The
machine's PM countdown and its other parameters are left exactly as they were.

| To… | Go to |
|---|---|
| Log one | **Activity** on that parameter's row in Log readings, or on the ✎ panel of the tile |
| See or remove them | Machine detail → Parameter activities |
| See this month's | Monthly report |

Types: Filament change, Lamp replacement, Source change, Recalibration, Sensor
replacement, Part replacement, Software update, or Other with your own description.

On charts an activity is a violet diamond, labelled **ACT** on full-size charts.
A tile shows the most recent activity from the last 30 days along its bottom.

If an activity and a PM fall on the same day, the trend restarts from that day either
way.

---

## Entering readings, and undoing them

Yesterday's value sits beside each field. A field turns amber past the warn level and
red at the limit. "Below/above expected range" means check the decimal point — the
value still saves, because a real spike must be recordable.

| Situation | Use |
|---|---|
| Not saved yet | Retype it |
| Changed an already-saved value | **Revert** on that row |
| A saved reading should not exist | **Undo** on that row |
| The whole batch was wrong | **Undo last save** — also rolls back any PM logged with it |

A green **saved** tag marks fields already stored for that date.

---

## Editing limits from a tile

The **✎** on each tile opens one panel for that machine: warn level, limit and
direction for each parameter, an **Activity** button for each, the PM interval,
reminder lead time and last PM date, and a box to log a PM. Changes apply as soon as
you save the panel.

---

## Importing from Excel

**Save, load & import → step 3.** The screen walks through it with a worked example.

| Date | SCN-01 Lens drift | Target | DPM-11 Base pressure | Target |
|---|---|---|---|---|
| 01/09/2026 | 0.92 | 3.5 | 18.4 | 60 |
| 02/09/2026 | 1.05 | 3.5 | 19.1 | 60 |

- First column is the date. `2026-09-01`, `01/09/2026` and `1/9/26` all work.
- Each reading column is followed by its target column, headed `Target`, `Limit` or `Spec`.
- Name reading columns `MACHINE Parameter`; put units in brackets at the end.
- Select the block including the header, <kbd>Ctrl</kbd>+<kbd>C</kbd>, click the box,
  <kbd>Ctrl</kbd>+<kbd>V</kbd>, read the preview, confirm.

Direction is detected: readings above their target are treated as falling toward it.
Pasting the same block twice updates rather than duplicates.

---

## Capacity

| History | Readings | File size | Slowest screen |
|---|---|---|---|
| 1 year | 6,800 | 0.6 MB | 56 ms |
| 5 years | 34,000 | 2.9 MB | 58 ms |
| 10 years | 68,000 | 5.8 MB | 93 ms |
| 20 years | 137,000 | 11.6 MB | 161 ms |

Speed is not the limit. The recovery copy of unsaved work lives in browser storage,
which holds about 5 MB; past that the app warns you and simply relies on saving. For
30 machines and about 45 parameters that is roughly four years of daily readings.
Starting a new file each year with *Save as new file* keeps everything comfortable.

---

## Repository layout

```
pm-tracker/
├── index.html                 The application. Open this to run.
├── Open PM Tracker.bat        For saving by download: files your downloads, then opens the app.
├── README.md
├── .gitignore                 Keeps real data out of the public repo.
│
├── assets/
│   ├── styles.css             All styling. Seven themes as token sets at the top.
│   └── favicon.svg
│
├── src/                       Classic scripts, loaded in this order by index.html.
│   ├── 01-core.js             State, settings, themes, storage, dates, data model.
│   ├── 02-analysis.js         Status, trend, projection, anomaly, risk, PM cycles.
│   ├── 03-charts.js           All SVG: tile, combined and full-size charts.
│   ├── 04-board.js            Router, the board, masonry, tile edit, screenshot view.
│   ├── 05-entry.js            Reading entry, undo and revert, trend charts screen.
│   ├── 06-reports.js          Analysis, machine detail, monthly report.
│   ├── 07-config.js           Machines, parameters and groups.
│   ├── 08-data.js             Save, load and import screen; CSV; Excel importer.
│   ├── 09-demo.js             Sample fleet. Safe to delete once live.
│   ├── 11-pmsched.js          PM schedule screen.
│   ├── 12-notify.js           The bell and notification panel.
│   ├── 13-activity.js         Parameter activities.
│   ├── 14-folder.js           Connecting the data folder and saving in place.
│   ├── 15-guide.js            Guide & about, theme gallery.
│   └── 10-boot.js             Startup. Loaded last.
│
├── data/                      Your real data. NOT in the repo.
│   ├── pm-data-*.json         Your data file(s). The most recently saved one opens.
│   ├── latest.js              Auto-load copy, kept in step on every save.
│   ├── backups/               One automatic copy per day.
│   └── config.example.json    Shape reference only.
│
├── docs/
│   ├── INSTALL.md             Team setup.
│   ├── DAILY-USE.md           One page to print and pin up.
│   └── RECOVERY.md            Getting your data out without the app.
│
└── tests/                     Seven suites, 342 checks. See tests/README.md.
```

These are classic scripts rather than ES modules because modules fail on a
`file://` path. `10-boot.js` loads last; the others load in numeric order. Add new
files to both `src/` and the `<script>` list at the bottom of `index.html`.

---

## Updating the app

```bash
git pull
```

Copy `index.html`, `assets/`, `src/` and the `.bat` into the shared folder. **Never
touch `data/`.** Users get the update on their next refresh. Settings — theme, layout,
connected folder — are kept.

Files saved by 1.x open in 2.0 unchanged: they gain an empty list of activities. Old
theme names map onto the new ones (Light → Graphite, Dark → Control Room, Warm →
Engineering Pad).

---

## Privacy

The code is public; the data is not. `.gitignore` excludes `data/`, all `*.csv`, and
any `pm-data-*.json`, `pm-backup-*.json` and `latest.js`. A file committed once stays
in git history even after deletion, so check `git status` before the first push.

The connected-folder permission belongs to this browser on this PC. It is not stored
in your data file and cannot be used by anyone else.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| No **Connect data folder** button | The browser cannot write to folders. Use Chrome or Edge. |
| Folder chip is amber and says Reconnect | Click it once. Choose *Allow on every visit* to stop it recurring. |
| "changed by someone else" when saving | Cancel keeps their version — reload to see it. OK replaces it with yours. |
| Opened an older file than expected | The newest was unreadable. The message names it; check it, or delete it. |
| Board unstyled | Scripts blocked from the network path. Copy the app to `C:\PM-Tracker\`. |
| Demo data instead of mine | No folder connected and no `data/latest.js`. Connect the folder. |
| Closed the tab before saving | Reopen. Unsaved work newer than the file is offered back. |
| Trend says Rebuilding after PM or activity | Correct. It needs about three readings since the reset. |
| A healthy line I cannot tell apart from another | Each trace also has its own dash pattern. Or switch Parameters to Separate. |
| Tiles look too small | Collapse the side panel, use fewer Columns, or a bigger Chart size. |
| Machine disappeared | It may be retired. Machines & limits → edit → Active. |

`docs/RECOVERY.md` covers getting data out without the app.

---

## Design notes

**ISA-101 high-performance HMI.** Overview screens of 15–25 items, a neutral base,
and colour reserved for abnormal state. That is why tiles stay neutral until
something is wrong, why the ISA-101 theme goes fully grey, and why chart series
colours never use red, amber or green.

**Tufte's small multiples.** Identical framing so the eye compares shapes rather than
reading many different charts, and the grey normal-range band from his clinical
sparklines.

**Indexed rather than dual-axis charts.** Overlaying series in different units on two
axes makes crossings and slopes depend on arbitrary scale choices. The combined chart
indexes every parameter on the same meaningful scale — healthy to limit — and keeps
real values in the legend.

**Gaps are gaps.** A missing reading leaves a break, never an invented straight line.
A reset is a break too, with the drop drawn faintly so it is seen.

**Alarm acknowledgement.** Acknowledging silences a notification without hiding the
condition, and a worsening condition re-alerts.

---

## Testing

`tests/` holds seven suites, **342 checks**, run against a real headless Chrome.

| Suite | Checks | Covers |
|---|---|---|
| `01-unit.js` | 91 | Dates across DST and year boundaries, thresholds, projection, slope, round trips, migration, parsing, escaping |
| `02-features.js` | 65 | Every screen and feature |
| `03-chart-controls.js` | 20 | Chart toggles, scale modes, parameter visibility |
| `04-edge-cases.js` | 25 | Hostile input and boundary conditions |
| `05-regressions.js` | 14 | Guards on version 1 bugs |
| `06-v2-features.js` | 96 | Folder saving, masonry, combined charts, activities, the PM-line and sizing fixes, notifications, rail, all seven themes, guide, unsaved-work recovery |
| `07-v2-edge-cases.js` | 31 | Combined charts with awkward data, activities at odd dates, damaged files, empty folders, cold-load navigation |

Folder saving is tested against the browser's origin-private file system, which
returns a real directory handle with the same API as a folder you pick. The folder
picker itself needs a person.

The suites were checked for teeth by deliberately breaking fixes and confirming the
right checks fail. See `tests/README.md`.
