# Recovery and troubleshooting

Written for whoever inherits this. You do not need the original author.

---

## Your data is not locked in

Everything lives in one plain JSON file in the shared `data` folder:

```
pm-data-2026-09-15-143052.json
```

It is text. Open it in Notepad and you can read it. Inside:

- `machines` — what you track
- `parameters` — limits, units, and whether the reading climbs or falls toward the limit
- `readings` — one entry per date per parameter
- `pmEvents` — when PM was done

**To get it into Excel without the app:** open the app, go to
**Save, load & import → Export readings as CSV**. Two CSV files download — readings
and PM events — and both open directly in Excel.

If the app will not open at all, any JSON-to-CSV converter will do the same job, or
paste the file into any spreadsheet tool that imports JSON.

---

## Common problems

### Blank page, or the page looks unstyled

Scripts are being blocked from the network location. Copy the whole `pm-tracker`
folder to `C:\PM-Tracker\` and open it from there.

### "That file could not be read as PM Tracker data"

You picked the wrong file, or it was truncated mid-save by a network drop. Load the
previous `pm-data-*.json` — one earlier by name — and re-enter the last day.
This is exactly what the weekly backups in `data/backups/` are for.

### Warning about duplicate or orphaned readings on load

The app reports these but still loads. Duplicates mean the same date and parameter
appear twice; the app uses one. Orphans mean readings for a parameter that was
deleted. Neither is dangerous. To clean up, export to CSV, fix in Excel, and rebuild.

### Someone overwrote a good file with an older one

Look in `data/`. Because every save is timestamped, nothing is ever truly overwritten.
Load the newest by name.

### Two people entered readings the same day

Whoever saved last wins for the file they saved. Load the other person's file, re-enter
the missing machines, and save again. To avoid it entirely, agree that one person owns
entry for the day.

---

## Going back to an earlier version

With the folder connected, the first save each day copies the previous version into
`data/backups/pm-data-YYYY-MM-DD.json`. To go back: **Save, load & import → Choose a
data file** → pick the backup, check it, then **Save as new file** to make it the
current one.

If the newest file is damaged, the app opens the next readable one automatically and
names the one it skipped. Delete or rename the damaged file so it stops being picked.

## Editing the code

Plain HTML, CSS and JavaScript. No build step, no package manager, no framework.

- Styling: `assets/styles.css`
- The maths: `src/02-analysis.js`
- The board and its tiles: `src/04-board.js`
- Charts: `src/03-charts.js`

Files in `src/` load in numeric order (with `10-boot.js` last) and are classic scripts, not ES modules — ES
modules fail on a `file://` path. Keep the number prefixes, and add new files in
sequence in both `src/` and the `<script>` list at the bottom of `index.html`.

To change the data shape, bump `SCHEMA` in `01-core.js` and add an upgrade block in
`migrate()`. Old files keep loading.
