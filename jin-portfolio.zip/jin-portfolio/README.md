# Jin Lowell C. Miranda | 3D Portfolio

A one-page portfolio with a live 3D circuit board behind it. The board has your name printed on it, signals running along the gold traces, and an oscilloscope showing a knock wave (a nod to your coconut thesis). As visitors scroll, the camera flies to a different part of the board for each section.

No coding tools needed. You will put it online for free using GitHub Pages, all from your web browser.

---

## What is inside this folder

```
index.html     All your text: name, about, projects, experience, skills, contact
style.css      Colors, fonts, spacing
scene.js       The 3D board (you do not need to touch this)
assets/
  profile.jpg  Your photo
README.md      This guide
```

---

## Part A: See it on your computer first (2 minutes)

1. Unzip the file you downloaded. Right-click the zip, then **Extract All** (Windows) or double-click it (Mac).
2. Open the folder you just extracted.
3. Double-click **index.html**. It opens in your browser.
4. Scroll down slowly. The camera should move around the board.

You need internet for this, because the 3D library and the fonts load online.

If you see a flat blue grid instead of the board, your browser has 3D turned off. That is fine. The site still works, and most phones and laptops will show the board.

---

## Part B: Put it online with GitHub Pages (about 15 minutes)

### Step 1. Make a GitHub account

1. Go to **https://github.com**
2. Click **Sign up**.
3. Pick a **username** carefully. It becomes part of your website address.
   Example: username `jinmiranda` gives you `https://jinmiranda.github.io`
4. Finish the sign up and verify your email.

### Step 2. Create the repository (the folder that holds your site)

1. When logged in, click the **+** at the top right, then **New repository**.
2. In **Repository name**, type exactly:

   ```
   YOUR-USERNAME.github.io
   ```

   Replace `YOUR-USERNAME` with your real GitHub username, all lowercase.
   Example: if your username is `jinmiranda`, type `jinmiranda.github.io`

   Why this name? It makes your site live at the short address `https://YOUR-USERNAME.github.io`. Any other name still works, but your address becomes longer (see the note at the end of Step 4).

3. Set it to **Public**. GitHub Pages is free only for public repositories.
4. Leave everything else as it is. Do **not** tick "Add a README file".
5. Click **Create repository**.

### Step 3. Upload your files

1. On the new empty repository page, find the link that says **uploading an existing file** and click it.
2. Open your unzipped portfolio folder on your computer.
3. Select everything **inside** it: `index.html`, `style.css`, `scene.js`, `README.md`, and the `assets` folder.
4. Drag them all into the GitHub upload box in your browser.

   Important: drag the files that are *inside* the folder, not the folder itself. `index.html` must end up at the top level of the repository, not inside another folder. If you drag the outer folder, the site will show a 404 error.

5. Wait until every file shows in the list, including `assets/profile.jpg`.
6. Scroll down and click the green **Commit changes** button.

When it finishes, your repository page should list: `assets`, `README.md`, `index.html`, `scene.js`, `style.css`.

### Step 4. Turn on GitHub Pages

1. In your repository, click **Settings** (the gear tab at the top).
2. In the left menu, click **Pages**.
3. Under **Build and deployment**, find **Source** and choose **Deploy from a branch**.
4. Under **Branch**, choose **main**, and next to it choose **/ (root)**.
5. Click **Save**.
6. Wait 1 to 5 minutes, then refresh the Settings > Pages page. A box appears saying **Your site is live at** with your link.

Open that link. Your portfolio is online.

Note: if you named the repository something else, like `portfolio`, your address is `https://YOUR-USERNAME.github.io/portfolio/` instead.

### Step 5. Test it on your phone

Open the link on your phone. The board sits at the top and your text sits below it. Scroll through every section once to be sure everything loads.

---

## Part C: Changing things later

You can edit directly on GitHub. No software needed.

### Step 6. Edit your text

1. In your repository, click **index.html**.
2. Click the **pencil icon** (Edit this file) at the top right of the file.
3. Find the text you want to change. Press **Ctrl + F** (Windows) or **Cmd + F** (Mac) to search.
4. Change only the words between the tags. For example, in

   ```html
   <h3>AMTEC Tooltracker</h3>
   ```

   change `AMTEC Tooltracker` but leave `<h3>` and `</h3>` alone.
5. Click **Commit changes**, then **Commit changes** again.
6. Wait 1 minute and refresh your website. If it still shows the old version, press **Ctrl + Shift + R** (Windows) or **Cmd + Shift + R** (Mac).

Each section in `index.html` starts with a label like this, so you can find it fast:

```html
<!-- ============ ABOUT ============ -->
```

### Step 7. Add your GitHub or LinkedIn button (optional)

1. Open **index.html** in edit mode and search for `YOUR-USERNAME`.
2. You will see these three lines:

   ```html
   <!--
   <a class="btn" href="https://github.com/YOUR-USERNAME" target="_blank" rel="noopener">GitHub</a>
   -->
   ```

3. Delete the `<!--` line and the `-->` line. Keep the middle line.
4. Replace `YOUR-USERNAME` with your real username.
5. For LinkedIn instead, change the link to your LinkedIn profile address and change the word `GitHub` to `LinkedIn`.
6. Commit changes.

### Step 8. Change your photo

1. Prepare a square photo and name it exactly `profile.jpg` (lowercase, `.jpg`).
2. In your repository, click the **assets** folder.
3. Click **Add file**, then **Upload files**, and drag in the new `profile.jpg`.
4. Commit changes. It replaces the old one.

File names on GitHub are case-sensitive. `Profile.JPG` is not the same as `profile.jpg`, and the photo will not show.

### Step 9. Add a new project

1. Open **index.html** in edit mode and search for `Offline interactive learning hub`.
2. Copy that whole block, from `<article class="project">` down to its `</article>`.
3. Paste it right after the `</article>`.
4. Change the title, the date line, the description, and the tags.
5. Commit changes.

### Step 10. Change colors

Open **style.css** and look at the top:

```css
--gold: #C9A45C;   /* the accent color */
--silk: #ECEEE8;   /* main text */
```

Change the codes after the colon. Find color codes at https://htmlcolorcodes.com. The 3D board has its own colors near the top of `scene.js` if you ever want to match them.

---

## Before you share the link: check these

These came up while building your resume files and were never fully confirmed. Fix them in `index.html` if they are wrong.

- [ ] **Award names.** The site lists "Best Thesis Design Award", "Proficiency Award", and "Best in OJT Award" from the Department of Computer Engineering, as on your own resume. You also mentioned "Best Thesis Paper and Title (Experimental Category)" from the Department of Engineering. Check the exact names and which department gave them.
- [ ] **Award years.** Years were left off the awards on purpose because your files disagreed (2025 in some, 2026 in others). Add them once you confirm.
- [ ] **Freelance start year.** The site says "Ongoing". Add the year you started if you want.
- [ ] **Phone number.** Left off on purpose. A public website gets scraped by spam bots. Email is enough. Add it only if you are fine with that.

---

## Problems and fixes

**The site shows "404 There isn't a GitHub Pages site here."**
Wait 5 minutes, then refresh. If it still fails, open your repository and check that `index.html` is at the top level, not inside a folder. Also check Settings > Pages says Branch **main** and **/ (root)**.

**My photo does not show.**
The file must be at `assets/profile.jpg`, exactly that name, lowercase.

**The board is missing and I only see a flat grid.**
That is the backup design. It appears when the device cannot run 3D or the 3D library did not load. Check your internet and refresh. Try another browser like Chrome.

**My changes do not appear.**
Wait a minute, then hard refresh: **Ctrl + Shift + R** (Windows) or **Cmd + Shift + R** (Mac).

**The board looks slow on an old phone.**
Normal on very old devices. The site already lowers the detail on small screens. If someone has "Reduce motion" turned on in their phone settings, the board stays still for them automatically.

**Link previews on Facebook or Messenger show no photo.**
In `index.html`, find `og:image` near the top and change `assets/profile.jpg` to your full address, for example
`https://YOUR-USERNAME.github.io/assets/profile.jpg`

---

## Built with

- [three.js](https://threejs.org) r128 for the 3D board, loaded from cdnjs
- Chakra Petch and IBM Plex Sans from Google Fonts
- Plain HTML, CSS, and JavaScript. No build step, no installs.
