/*
  scene.js
  Draws the 3D circuit board behind the page.
  You normally never need to edit this file. All your text lives in index.html.

  What it does:
  - Builds a PCB: chip (U1), a smaller chip (U2), headers, capacitors, gold traces.
  - Sends glowing signals along the traces, starting from the chip.
  - Floats an oscilloscope trace behind the board showing a "knock" wave,
    a nod to the coconut thesis (knock, record, analyse).
  - Moves the camera to a new angle as you scroll to each section.
  - If 3D cannot run, it quietly shows a flat background instead.
*/
(function () {
  'use strict';

  var root = document.documentElement;
  root.classList.add('js');

  var reduceMotion = !!(window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  setupNav();

  if (typeof THREE === 'undefined' || !hasWebGL()) {
    fallback();
    return;
  }

  try {
    start();
  } catch (err) {
    if (window.console) console.error('3D scene failed, showing the flat background instead.', err);
    fallback();
    return;
  }
  ready();

  /* ---------------------------------------------------------------- */

  function ready() {
    requestAnimationFrame(function () { root.classList.add('ready'); });
  }

  function fallback() {
    document.body.classList.add('no-webgl');
    ready();
  }

  function hasWebGL() {
    try {
      var c = document.createElement('canvas');
      return !!(window.WebGLRenderingContext &&
        (c.getContext('webgl') || c.getContext('experimental-webgl')));
    } catch (e) {
      return false;
    }
  }

  // Underlines the nav link for the section you are reading.
  function setupNav() {
    var links = document.querySelectorAll('.nav nav a');
    if (!links.length || !('IntersectionObserver' in window)) return;
    var byId = {};
    for (var i = 0; i < links.length; i++) {
      byId[links[i].getAttribute('href').slice(1)] = links[i];
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        for (var k in byId) byId[k].classList.remove('is-active');
        if (byId[e.target.id]) byId[e.target.id].classList.add('is-active');
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    var secs = document.querySelectorAll('main section[id]');
    for (var j = 0; j < secs.length; j++) obs.observe(secs[j]);
  }

  /* ================================================================ */

  function start() {
    var canvas = document.getElementById('board');
    if (!canvas) throw new Error('No #board canvas found');

    var W = 8, D = 5.2, T = 0.16;           // board size in scene units
    var C = {
      shadow: 0x0C1426, mask: 0x16233F, gold: 0xC9A45C,
      goldLight: 0xF2D9A2, silk: 0xECEEE8
    };
    var small = Math.min(window.innerWidth, window.innerHeight) < 700;

    /* ---------- renderer, scene, camera ---------- */
    var renderer = new THREE.WebGLRenderer({
      canvas: canvas, antialias: true, powerPreference: 'high-performance'
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, small ? 1.5 : 1.75));
    renderer.setClearColor(C.shadow, 1);

    var scene = new THREE.Scene();
    scene.fog = new THREE.Fog(C.shadow, 15, 34);

    var camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);

    var world = new THREE.Group();
    scene.add(world);

    /* ---------- lights ---------- */
    scene.add(new THREE.HemisphereLight(0x9fb3e0, 0x0C1426, 0.6));
    var key = new THREE.DirectionalLight(0xfff1dc, 0.95);
    key.position.set(5, 8, 4);
    scene.add(key);
    var rim = new THREE.DirectionalLight(0x7088cc, 0.4);
    rim.position.set(-6, 3, -5);
    scene.add(rim);
    var chipGlow = new THREE.PointLight(0xE8C27A, 0.7, 5.5, 2);
    chipGlow.position.set(0, 1.1, 0);
    world.add(chipGlow);

    /* ---------- materials ---------- */
    var maskMat = new THREE.MeshStandardMaterial({ color: C.mask, roughness: 0.62, metalness: 0.08 });
    var goldMat = new THREE.MeshStandardMaterial({
      color: C.gold, metalness: 0.2, roughness: 0.64, emissive: 0x3d2c0d
    });
    var blackMat = new THREE.MeshStandardMaterial({ color: 0x15171d, roughness: 0.42, metalness: 0.1 });
    var silverMat = new THREE.MeshStandardMaterial({ color: 0xb4bcc9, roughness: 0.28, metalness: 0.65 });
    var sleeveMat = new THREE.MeshStandardMaterial({ color: 0x2a3f6e, roughness: 0.5, metalness: 0.1 });

    /* ---------- board slab ---------- */
    var slab = new THREE.Mesh(new THREE.BoxGeometry(W, T, D), maskMat);
    slab.position.y = -T / 2;
    world.add(slab);

    // Soft light pool under the board so it does not float in pure black
    var pool = new THREE.Mesh(
      new THREE.PlaneGeometry(18, 13),
      new THREE.MeshBasicMaterial({
        map: radialTexture('rgba(201,164,92,0.55)', 'rgba(22,35,63,0.0)'),
        transparent: true, opacity: 0.32, depthWrite: false,
        blending: THREE.AdditiveBlending
      })
    );
    pool.rotation.x = -Math.PI / 2;
    pool.position.y = -0.9;
    world.add(pool);

    /* ---------- trace routes (x, z) ---------- */
    // Drawn by hand so nothing crosses. Every route starts at a chip pin.
    var routes = [
      // U1 left side, straight bus to header J1
      [[-0.88, -0.585], [-3.21, -0.585]],
      [[-0.88, -0.195], [-3.21, -0.195]],
      [[-0.88, 0.195], [-3.21, 0.195]],
      [[-0.88, 0.585], [-3.21, 0.585]],
      // U1 top side
      [[-0.455, -0.88], [-0.455, -1.0], [-3.21, -1.0]],
      [[-0.195, -0.88], [-0.195, -1.4], [-3.21, -1.4]],
      [[0.195, -0.88], [0.195, -1.3], [0.7, -1.8], [1.76, -1.8]],
      [[0.455, -0.88], [0.455, -1.05], [1.3, -1.05], [1.5, -1.25], [1.66, -1.25]],
      [[-0.065, -0.88], [-0.065, -1.9], [0.3, -2.265]],
      // U1 right side into U2
      [[0.88, -0.325], [1.9, -0.325], [2.075, -0.5], [2.24, -0.5]],
      [[0.88, -0.065], [1.9, -0.065], [2.135, -0.3], [2.24, -0.3]],
      [[0.88, 0.195], [1.9, 0.195], [2.195, -0.1], [2.24, -0.1]],
      [[0.88, 0.455], [1.885, 0.455], [2.24, 0.1]],
      // U1 bottom side
      [[-0.455, 0.88], [-0.455, 1.0], [-3.21, 1.0]],
      [[-0.195, 0.88], [-0.195, 1.4], [-3.21, 1.4]],
      [[0.195, 0.88], [0.195, 1.3], [0.9, 2.0], [2.12, 2.0]],
      [[0.455, 0.88], [0.455, 1.05], [1.3, 1.05], [1.5, 1.25], [1.66, 1.25]],
      [[-0.065, 0.88], [-0.065, 2.0], [-0.3, 2.235]],
      // U2 out to header J2
      [[2.96, -0.5], [3.29, -0.5]],
      [[2.96, -0.3], [3.29, -0.3]],
      [[2.96, -0.1], [3.29, -0.1]],
      [[2.96, 0.1], [3.29, 0.1]]
    ];

    var traces = new THREE.Mesh(ribbonGeometry(routes, 0.045, 0.003), goldMat);
    world.add(traces);

    /* ---------- small gold parts (pins, pads) in one draw call ---------- */
    var parts = [];
    var k, p;
    for (k = 0; k < 10; k++) {                    // U1: 10 pins per side
      p = (k - 4.5) * 0.13;
      parts.push([p, 0.02, -0.815, 0.06, 0.04, 0.13]);
      parts.push([p, 0.02, 0.815, 0.06, 0.04, 0.13]);
      parts.push([-0.815, 0.02, p, 0.13, 0.04, 0.06]);
      parts.push([0.815, 0.02, p, 0.13, 0.04, 0.06]);
    }
    [-0.5, -0.3, -0.1, 0.1].forEach(function (z) {   // U2 pins + J2 header pins
      parts.push([2.27, 0.02, z, 0.12, 0.04, 0.06]);
      parts.push([2.93, 0.02, z, 0.12, 0.04, 0.06]);
      parts.push([3.42, 0.275, z, 0.06, 0.55, 0.06]);
    });
    [-1.4, -1.0, -0.585, -0.195, 0.195, 0.585, 1.0, 1.4].forEach(function (z) { // J1 header pins
      parts.push([-3.38, 0.275, z, 0.06, 0.55, 0.06]);
    });
    [[0.3, -2.265], [-0.3, 2.235], [3.1, 1.7], [3.35, 1.7]].forEach(function (q) { // test pads
      parts.push([q[0], 0.004, q[1], 0.14, 0.008, 0.14]);
    });
    [[1.85, -1.25], [1.85, 1.25], [-2.5, -1.95], [1.05, -2.25]].forEach(function (q) { // resistor end caps
      parts.push([q[0] - 0.17, 0.04, q[1], 0.05, 0.08, 0.15]);
      parts.push([q[0] + 0.17, 0.04, q[1], 0.05, 0.08, 0.15]);
    });

    var pinMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), goldMat, parts.length);
    var m4 = new THREE.Matrix4(), q4 = new THREE.Quaternion(), v3 = new THREE.Vector3(), s3 = new THREE.Vector3();
    parts.forEach(function (a, i) {
      m4.compose(v3.set(a[0], a[1], a[2]), q4, s3.set(a[3], a[4], a[5]));
      pinMesh.setMatrixAt(i, m4);
    });
    pinMesh.instanceMatrix.needsUpdate = true;
    world.add(pinMesh);

    /* ---------- components ---------- */
    addBox(1.5, 0.2, 1.5, 0, 0.1, 0, blackMat);             // U1 main chip
    var chipTop = new THREE.Mesh(
      new THREE.PlaneGeometry(1.4, 1.4),
      new THREE.MeshBasicMaterial({ map: chipTexture(), transparent: true, depthWrite: false })
    );
    chipTop.rotation.x = -Math.PI / 2;
    chipTop.position.y = 0.202;
    world.add(chipTop);

    addBox(0.6, 0.14, 0.84, 2.6, 0.07, -0.2, blackMat);      // U2
    addBox(0.3, 0.14, 3.1, -3.38, 0.07, 0, blackMat);        // J1 header base
    addBox(0.26, 0.14, 0.86, 3.42, 0.07, -0.2, blackMat);    // J2 header base
    addBox(0.55, 0.16, 0.22, -1.6, 0.08, -1.95, silverMat);  // Y1 crystal

    [[1.85, -1.25], [1.85, 1.25], [-2.5, -1.95], [1.05, -2.25]].forEach(function (q) {
      addBox(0.29, 0.07, 0.14, q[0], 0.035, q[1], blackMat); // resistor bodies
    });

    [[1.95, -1.8], [2.4, -1.8], [2.3, 2.0], [2.75, 2.0]].forEach(function (q) { // capacitors
      var body = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.34, 28), sleeveMat);
      body.position.set(q[0], 0.17, q[1]);
      world.add(body);
      var cap = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.012, 28), silverMat);
      cap.position.set(q[0], 0.346, q[1]);
      world.add(cap);
    });

    [[-3.62, -2.22], [3.62, -2.22], [-3.62, 2.22], [3.62, 2.22]].forEach(function (q) { // mounting holes
      var ring = new THREE.Mesh(new THREE.RingGeometry(0.11, 0.2, 32), goldMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(q[0], 0.004, q[1]);
      world.add(ring);
      var hole = new THREE.Mesh(new THREE.CircleGeometry(0.11, 32),
        new THREE.MeshBasicMaterial({ color: 0x05080f }));
      hole.rotation.x = -Math.PI / 2;
      hole.position.set(q[0], 0.005, q[1]);
      world.add(hole);
    });

    /* ---------- silkscreen (white printing on the board) ---------- */
    var silk = silkTexture();
    var silkPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(W, D),
      new THREE.MeshBasicMaterial({ map: silk.texture, transparent: true, depthWrite: false })
    );
    silkPlane.rotation.x = -Math.PI / 2;
    silkPlane.position.y = 0.006;
    world.add(silkPlane);
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function () { silk.draw(); needsRender = true; });
    }

    /* ---------- oscilloscope trace: the knock wave ---------- */
    var SCOPE_W = 4.8, SCOPE_H = 1.35, SAMPLES = 260;
    var scope = new THREE.Group();
    scope.position.set(-0.2, 1.5, -3.35);
    world.add(scope);
    scope.add(scopeGrid(SCOPE_W, SCOPE_H));

    var waveCore = waveRibbon(0.03, 0.95);
    var waveGlow = waveRibbon(0.16, 0.13);
    scope.add(waveGlow.mesh);
    scope.add(waveCore.mesh);

    function knockSignal(time) {
      var period = 1.7;
      var local = ((time % period) + period) % period;
      var ring = Math.exp(-local * 5.2) *
        (0.72 * Math.sin(Math.PI * 2 * 7 * local) + 0.28 * Math.sin(Math.PI * 2 * 19 * local));
      var floor = 0.018 * Math.sin(Math.PI * 2 * 53 * time) + 0.012 * Math.sin(Math.PI * 2 * 31 * time);
      return ring + floor;
    }

    function updateWave(now) {
      var windowSec = 1.5;
      var ys = new Array(SAMPLES + 1);
      for (var i = 0; i <= SAMPLES; i++) {
        var s = i / SAMPLES;
        ys[i] = knockSignal(now - (1 - s) * windowSec) * 0.62;
      }
      waveCore.set(ys);
      waveGlow.set(ys);
      var period = 1.7;
      var local = ((now % period) + period) % period;
      chipGlow.intensity = 0.55 + 1.3 * Math.exp(-local * 4);
    }

    function waveRibbon(thickness, opacity) {
      var geo = new THREE.PlaneGeometry(SCOPE_W, 1, SAMPLES, 1);
      var mat = new THREE.MeshBasicMaterial({
        color: C.goldLight, transparent: true, opacity: opacity,
        depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending
      });
      var mesh = new THREE.Mesh(geo, mat);
      var posAttr = geo.attributes.position;
      return {
        mesh: mesh,
        set: function (ys) {
          // PlaneGeometry order: top row (SAMPLES+1 verts), then bottom row
          for (var i = 0; i <= SAMPLES; i++) {
            posAttr.setY(i, ys[i] + thickness / 2);
            posAttr.setY(i + SAMPLES + 1, ys[i] - thickness / 2);
          }
          posAttr.needsUpdate = true;
        }
      };
    }

    /* ---------- signal pulses along traces ---------- */
    var pulseTex = radialTexture('rgba(255,236,196,1)', 'rgba(201,164,92,0)');
    var pulses = routes.map(function (r, i) {
      var segs = [], total = 0;
      for (var j = 0; j < r.length - 1; j++) {
        var dx = r[j + 1][0] - r[j][0], dz = r[j + 1][1] - r[j][1];
        var len = Math.sqrt(dx * dx + dz * dz);
        segs.push({ ax: r[j][0], az: r[j][1], dx: dx, dz: dz, len: len });
        total += len;
      }
      var sprite = new THREE.Sprite(new THREE.SpriteMaterial({
        map: pulseTex, color: 0xffe2a8, transparent: true,
        depthWrite: false, blending: THREE.AdditiveBlending
      }));
      sprite.scale.set(0.26, 0.26, 1);
      sprite.visible = false;
      world.add(sprite);
      var fromU2 = i >= 18;
      return {
        segs: segs, total: total, sprite: sprite,
        speed: 1.3 + Math.random() * 0.6,
        // power-up wave: chip traces fire first, U2 outputs fire after
        wait: (fromU2 ? 1.1 : 0.25) + (i % 18) * 0.05 + Math.random() * 0.25,
        d: 0
      };
    });

    function pointOn(pulse, dist) {
      var left = dist;
      for (var i = 0; i < pulse.segs.length; i++) {
        var s = pulse.segs[i];
        if (left <= s.len || i === pulse.segs.length - 1) {
          var f = s.len > 0 ? Math.min(left / s.len, 1) : 0;
          return [s.ax + s.dx * f, s.az + s.dz * f];
        }
        left -= s.len;
      }
      return [0, 0];
    }

    function updatePulses(dt) {
      pulses.forEach(function (pl) {
        if (pl.wait > 0) {
          pl.wait -= dt;
          pl.sprite.visible = false;
          if (pl.wait <= 0) pl.d = 0;
          return;
        }
        pl.d += pl.speed * dt;
        if (pl.d >= pl.total) {
          pl.sprite.visible = false;
          pl.wait = 0.5 + Math.random() * 2.4;
          return;
        }
        var xz = pointOn(pl, pl.d);
        pl.sprite.position.set(xz[0], 0.05, xz[1]);
        var edge = Math.min(pl.d / 0.25, (pl.total - pl.d) / 0.25, 1);
        pl.sprite.material.opacity = Math.max(edge, 0);
        pl.sprite.visible = true;
      });
    }

    /* ---------- floating dust ---------- */
    var DUST = small ? 150 : 320;
    var dustPos = new Float32Array(DUST * 3);
    var dustSpeed = new Float32Array(DUST);
    for (var d = 0; d < DUST; d++) {
      dustPos[d * 3] = (Math.random() - 0.5) * 20;
      dustPos[d * 3 + 1] = -2 + Math.random() * 7;
      dustPos[d * 3 + 2] = -9 + Math.random() * 16;
      dustSpeed[d] = 0.04 + Math.random() * 0.1;
    }
    var dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    var dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({
      color: C.gold, size: 0.035, transparent: true, opacity: 0.5,
      depthWrite: false, blending: THREE.AdditiveBlending
    }));
    scene.add(dust);

    function updateDust(dt) {
      for (var i = 0; i < DUST; i++) {
        var y = dustPos[i * 3 + 1] + dustSpeed[i] * dt;
        if (y > 5) y = -2;
        dustPos[i * 3 + 1] = y;
      }
      dustGeo.attributes.position.needsUpdate = true;
    }

    /* ---------- camera shots, one per section ---------- */
    var shots = [
      { p: [8.3, 6.0, 9.5], t: [0.6, 0.35, -0.7] },     // hero: the whole board
      { p: [2.3, 2.1, 2.6], t: [0, 0.1, 0] },          // about: close on the chip
      { p: [0, 8.4, 1.4], t: [0, 0, 0.1] },            // work: top-down, the traces
      { p: [-5.2, 2.6, 4.2], t: [-1.6, 0, 0.2] },      // experience: along the bus
      { p: [4.8, 1.7, 2.6], t: [2.3, 0.2, -0.3] },     // skills: U2 and header
      { p: [0.6, 4.6, 10.2], t: [0.3, 0.9, -1.2] }     // contact: pulled back
    ];
    var sections = Array.prototype.slice.call(document.querySelectorAll('[data-shot]'));
    var anchors = [];
    function measure() {
      anchors = sections.map(function (s) {
        return s.getBoundingClientRect().top + window.pageYOffset;
      });
    }

    var distScale = 1;
    function layout() {
      var w = window.innerWidth, h = window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      // On wide screens, push the board right so text on the left stays clear
      var shiftX = w >= 900 ? w * 0.22 : 0;
      var shiftY = (w < 900 && h > w) ? h * 0.2 : 0;
      camera.setViewOffset(w, h, -shiftX, shiftY, w, h);
      camera.updateProjectionMatrix();
      var a = w / h;
      distScale = a < 0.75 ? 1.5 : a < 1.1 ? 1.22 : 1;
      measure();
      needsRender = true;
    }

    var desiredPos = new THREE.Vector3(), desiredTarget = new THREE.Vector3();
    var camPos = new THREE.Vector3(), camTarget = new THREE.Vector3();
    var tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();

    function computeDesired() {
      var y = window.pageYOffset;
      var n = Math.min(anchors.length, shots.length);
      var i = 0, f = 0;
      if (n > 1 && y > anchors[0]) {
        i = n - 1;
        for (var j = 0; j < n - 1; j++) {
          if (y < anchors[j + 1]) {
            i = j;
            f = (y - anchors[j]) / Math.max(anchors[j + 1] - anchors[j], 1);
            break;
          }
        }
      }
      var e = f * f * (3 - 2 * f);
      var a = shots[i], b = shots[Math.min(i + 1, shots.length - 1)];
      desiredTarget.set(
        a.t[0] + (b.t[0] - a.t[0]) * e,
        a.t[1] + (b.t[1] - a.t[1]) * e,
        a.t[2] + (b.t[2] - a.t[2]) * e
      );
      tmpA.set(a.p[0], a.p[1], a.p[2]);
      tmpB.set(b.p[0], b.p[1], b.p[2]);
      tmpA.lerp(tmpB, e);
      desiredPos.copy(tmpA).sub(desiredTarget).multiplyScalar(distScale).add(desiredTarget);
    }

    /* ---------- input ---------- */
    var mouse = { x: 0, y: 0, sx: 0, sy: 0 };
    var finePointer = !!(window.matchMedia && window.matchMedia('(pointer: fine)').matches);
    if (finePointer && !reduceMotion) {
      window.addEventListener('pointermove', function (ev) {
        mouse.x = (ev.clientX / window.innerWidth) * 2 - 1;
        mouse.y = (ev.clientY / window.innerHeight) * 2 - 1;
      }, { passive: true });
    }

    var needsRender = true;
    window.addEventListener('scroll', function () { needsRender = true; }, { passive: true });
    window.addEventListener('resize', layout);
    window.addEventListener('load', function () { measure(); needsRender = true; });
    if ('ResizeObserver' in window) {
      new ResizeObserver(function () { measure(); needsRender = true; })
        .observe(document.getElementById('main') || document.body);
    }

    /* ---------- loop ---------- */
    layout();
    if (reduceMotion) {
      updateWave(0.42);       // one still frame of the knock wave
      pulses.forEach(function (pl) { pl.sprite.visible = false; });
    }

    var clock = new THREE.Clock();
    var first = true;

    function frame() {
      requestAnimationFrame(frame);
      var dt = Math.min(clock.getDelta(), 0.12);
      var t = clock.elapsedTime;

      if (reduceMotion && !needsRender) return;
      needsRender = false;

      computeDesired();
      if (first || reduceMotion) {
        camPos.copy(desiredPos);
        camTarget.copy(desiredTarget);
      } else {
        var k = 1 - Math.exp(-dt * 3.2);
        camPos.lerp(desiredPos, k);
        camTarget.lerp(desiredTarget, k);
      }

      if (!reduceMotion) {
        mouse.sx += (mouse.x - mouse.sx) * Math.min(dt * 3, 1);
        mouse.sy += (mouse.y - mouse.sy) * Math.min(dt * 3, 1);
        world.rotation.y = Math.sin(t * 0.15) * 0.035 + mouse.sx * 0.05;
        world.position.y = Math.sin(t * 0.5) * 0.04;
        updatePulses(dt);
        updateWave(t);
        updateDust(dt);
      }

      camera.position.set(camPos.x, camPos.y - mouse.sy * 0.25, camPos.z);
      camera.lookAt(camTarget);
      renderer.render(scene, camera);

      if (first) {
        first = false;
        document.body.classList.add('scene-on');
      }
    }
    requestAnimationFrame(frame);

    /* ================= helpers ================= */

    function addBox(w, h, d, x, y, z, mat) {
      var mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y, z);
      world.add(mesh);
      return mesh;
    }

    // Flat gold ribbons following each route, merged into one geometry.
    function ribbonGeometry(list, width, y) {
      var pos = [], nrm = [], idx = [], v = 0, hw = width / 2;
      list.forEach(function (r) {
        for (var i = 0; i < r.length - 1; i++) {
          var ax = r[i][0], az = r[i][1], bx = r[i + 1][0], bz = r[i + 1][1];
          var dx = bx - ax, dz = bz - az, len = Math.sqrt(dx * dx + dz * dz);
          if (len < 1e-6) continue;
          var ux = dx / len, uz = dz / len;
          ax -= ux * hw; az -= uz * hw; bx += ux * hw; bz += uz * hw; // overlap joints
          var nx = -uz * hw, nz = ux * hw;
          pos.push(ax + nx, y, az + nz, ax - nx, y, az - nz, bx - nx, y, bz - nz, bx + nx, y, bz + nz);
          nrm.push(0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0);
          idx.push(v, v + 2, v + 1, v, v + 3, v + 2);   // faces point up
          v += 4;
        }
      });
      var g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
      g.setIndex(idx);
      return g;
    }

    function radialTexture(inner, outer) {
      var c = document.createElement('canvas');
      c.width = c.height = 128;
      var ctx = c.getContext('2d');
      var g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
      g.addColorStop(0, inner);
      g.addColorStop(1, outer);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 128, 128);
      return new THREE.CanvasTexture(c);
    }

    function chipTexture() {
      var c = document.createElement('canvas');
      c.width = c.height = 512;
      var ctx = c.getContext('2d');
      ctx.fillStyle = 'rgba(210,214,222,0.55)';
      ctx.beginPath();
      ctx.arc(70, 70, 22, 0, Math.PI * 2);   // pin 1 marker
      ctx.fill();
      ctx.textAlign = 'center';
      ctx.font = '600 92px "Chakra Petch", sans-serif';
      ctx.fillText('JLCM', 256, 250);
      ctx.font = '500 46px "Chakra Petch", sans-serif';
      ctx.fillText('MCU-26  LSPU', 256, 330);
      ctx.fillText('LAGUNA PH', 256, 390);
      var tex = new THREE.CanvasTexture(c);
      tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(function () {
          ctx.clearRect(0, 0, 512, 512);
          ctx.fillStyle = 'rgba(210,214,222,0.55)';
          ctx.beginPath(); ctx.arc(70, 70, 22, 0, Math.PI * 2); ctx.fill();
          ctx.font = '600 92px "Chakra Petch", sans-serif';
          ctx.fillText('JLCM', 256, 250);
          ctx.font = '500 46px "Chakra Petch", sans-serif';
          ctx.fillText('MCU-26  LSPU', 256, 330);
          ctx.fillText('LAGUNA PH', 256, 390);
          tex.needsUpdate = true;
        });
      }
      return tex;
    }

    function silkTexture() {
      var cw = 2048, ch = Math.round(2048 * D / W), S = cw / W;
      var c = document.createElement('canvas');
      c.width = cw; c.height = ch;
      var ctx = c.getContext('2d');
      var tex = new THREE.CanvasTexture(c);
      tex.anisotropy = renderer.capabilities.getMaxAnisotropy();

      function X(x) { return (x + W / 2) * S; }
      function Z(z) { return (z + D / 2) * S; }
      function rect(cx, cz, w, d) { ctx.strokeRect(X(cx - w / 2), Z(cz - d / 2), w * S, d * S); }
      function label(txt, x, z, size, align) {
        ctx.font = '600 ' + size + 'px "Chakra Petch", sans-serif';
        ctx.textAlign = align || 'left';
        ctx.fillText(txt, X(x), Z(z));
      }

      function draw() {
        ctx.clearRect(0, 0, cw, ch);
        ctx.strokeStyle = 'rgba(236,238,232,0.78)';
        ctx.fillStyle = 'rgba(236,238,232,0.82)';
        ctx.lineWidth = 5;

        ctx.strokeRect(X(-W / 2 + 0.12), Z(-D / 2 + 0.12), (W - 0.24) * S, (D - 0.24) * S);

        rect(0, 0, 1.95, 1.95);                        // U1 outline
        ctx.beginPath(); ctx.arc(X(-1.12), Z(-1.12), 9, 0, Math.PI * 2); ctx.fill();
        label('U1', 1.05, 1.18, 46);
        rect(2.6, -0.2, 0.95, 1.0);  label('U2', 2.35, -0.82, 40);
        rect(-3.38, 0, 0.42, 3.25);  label('J1', -3.55, -1.78, 40);
        rect(3.42, -0.2, 0.38, 1.0); label('J2', 3.25, -0.82, 40);
        rect(-1.6, -1.95, 0.7, 0.36); label('Y1', -1.95, -2.2, 34);
        [[1.85, -1.25, 'R1'], [1.85, 1.25, 'R2'], [-2.5, -1.95, 'R3'], [1.05, -2.25, 'R4']].forEach(function (r) {
          rect(r[0], r[1], 0.48, 0.24); label(r[2], r[0] + 0.3, r[1] + 0.08, 30);
        });
        [[1.95, -1.8, 'C1'], [2.4, -1.8, 'C2'], [2.3, 2.0, 'C3'], [2.75, 2.0, 'C4']].forEach(function (q) {
          ctx.beginPath(); ctx.arc(X(q[0]), Z(q[1]), 0.21 * S, 0, Math.PI * 2); ctx.stroke();
          label(q[2], q[0] - 0.13, q[1] - 0.29, 28);
        });
        label('TP1', 0.45, -2.2, 26);
        label('TP2', -0.95, 2.3, 26);

        // title block, bottom left
        ctx.lineWidth = 4;
        ctx.strokeRect(X(-3.35), Z(1.7), 2.55 * S, 0.62 * S);
        label('JLCM-01', -3.25, 1.93, 50);
        label('J. L. C. MIRANDA', -3.25, 2.12, 30);
        label('LOS BAÑOS, LAGUNA   REV 2026', -3.25, 2.27, 26);
        label('+', 3.22, -2.18, 40, 'center');
        tex.needsUpdate = true;
      }
      draw();
      return { texture: tex, draw: draw };
    }

    function scopeGrid(w, h) {
      var g = new THREE.Group();
      var pts = [];
      var cols = 10, rows = 4, i;
      for (i = 0; i <= cols; i++) {
        var x = -w / 2 + (w * i) / cols;
        pts.push(x, -h / 2, 0, x, h / 2, 0);
      }
      for (i = 0; i <= rows; i++) {
        var yy = -h / 2 + (h * i) / rows;
        pts.push(-w / 2, yy, 0, w / 2, yy, 0);
      }
      var geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
      g.add(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({
        color: C.gold, transparent: true, opacity: 0.13, depthWrite: false
      })));
      var frameGeo = new THREE.BufferGeometry();
      frameGeo.setAttribute('position', new THREE.Float32BufferAttribute([
        -w / 2, -h / 2, 0, w / 2, -h / 2, 0, w / 2, -h / 2, 0, w / 2, h / 2, 0,
        w / 2, h / 2, 0, -w / 2, h / 2, 0, -w / 2, h / 2, 0, -w / 2, -h / 2, 0
      ], 3));
      g.add(new THREE.LineSegments(frameGeo, new THREE.LineBasicMaterial({
        color: C.gold, transparent: true, opacity: 0.34, depthWrite: false
      })));
      return g;
    }
  }
})();
